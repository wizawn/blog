# Google AI Ultra Trial Tool

- 博客：https://blog.caowo.de/
- 发卡网：https://faka.cdkey.si/

通过 Frida 注入 Google One 进程调用 BillingClient API，发现并激活隐藏的 $0 免费试用。

## 前提条件

| 组件 | 说明 |
|---|---|
| **MuMu 模拟器** | 已启动，已登录 Google 账号，已绑定付款方式 |
| **adb** | 在 PATH 中，或设置 `ADB_PATH` 环境变量 |
| **frida** (host) | `pip install frida-tools`，版本 ≥ 16 |
| **frida-server** (device) | 推送到设备 `/data/local/tmp/frida-server` 并赋予执行权限 |
| **module.apk** (device) | 包含 BillingClient 库的 APK，推送到 `/data/local/tmp/module.apk` |
| **Google One** | 设备上已安装 (`com.google.android.apps.subscriptions.red`) |

## 设备准备

```bash
# 连接 MuMu
adb connect 127.0.0.1:16384

# 推送 frida-server（从 https://github.com/frida/frida/releases 下载对应架构）
adb push frida-server /data/local/tmp/frida-server
adb shell "chmod 755 /data/local/tmp/frida-server"

# 推送 module.apk（包含 com.android.billingclient 的 APK）
adb push module.apk /data/local/tmp/module.apk
```

## 用法

```bash
# 列出当前账号所有可用试用
./auto-trial.sh --list

# 激活 Ultra 20x (30TB, $199.99/mo) 12个月免费试用
./auto-trial.sh --product 20x --dur 12mo

# 激活 Ultra 5x (20TB, $99.99/mo) 6个月免费试用
./auto-trial.sh --product 5x --dur 6mo

# 自动选最长试用（默认 20x）
./auto-trial.sh --product 20x

# 指定 MuMu ADB 端口
./auto-trial.sh --port 16416 --product 5x --dur 12mo
```

### 参数

| 参数 | 说明 | 默认值 |
|---|---|---|
| `--list` | 只列出试用，不激活 | (激活模式) |
| `--product` | `5x` / `20x` / `auto` / `g1.play.*` 完整 ID | `auto` |
| `--dur` | `1mo` / `3mo` / `6mo` / `12mo` / `longest` | `longest` |
| `--port` | MuMu ADB 端口 | 自动扫描 |
| `--adb` | adb 路径 | 自动检测 |

### 环境变量

| 变量 | 说明 |
|---|---|
| `ADB_PATH` | adb 可执行文件路径 |
| `FRIDA_SCRIPT` | frida-auto-trial.js 路径（默认同目录） |
| `FRIDA_SERVER_PATH` | 设备上 frida-server 路径（默认 `/data/local/tmp/frida-server`） |
| `MODULE_APK_DEVICE` | 设备上 module.apk 路径（默认 `/data/local/tmp/module.apk`） |

## 产品 ID 对照

| 别名 | 产品 ID | 容量 | 月费 | 试用 |
|---|---|---|---|---|
| **20x** | `g1.play.ai.pro` | 30TB | $199.99 | 1/3/6/12 月 |
| **5x** | `g1.play.20tb` | 20TB | $99.99 | 1/3/6/12 月 |
| — | `g1.ai.pro` | 30TB | $199.99 | 无 |
| — | `g1.30tb` | 30TB | $149.99 | 无 |

只有名字带 `play` 的产品 ID 才有试用 offer。App 界面"升级"按钮走的是不带试用的 `g1.ai.pro`。

## 注意事项

- 脚本只拉起 Google Play 支付弹窗，需要手动确认（输入密码）
- 试用到期后自动续费，记得提前取消
- 账号必须已绑付款方式且无现有订阅，否则试用不可用
- `launchBillingFlow` 返回 code=0 可能消耗试用资格，即使弹窗未显示
- 全程在模拟器中操作，建议绑定小额余额卡作为安全网

## 文件说明

- `auto-trial.sh` — Shell 启动器，自动检测设备、管理 frida-server、注入脚本、监控结果
- `frida-auto-trial.js` — Frida 注入脚本，通过 DexClassLoader 加载 BillingClient 查询和激活试用
