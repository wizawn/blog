// Google AI iOS · Clash JS 覆写脚本 (AI Ultra 20TB (5x) · 前 3 个月 1 折 (US$9.99/月) -> g1.20tb.3months_ip_90p.acq)
// 用法: 在 Clash Mi / FlClash / CrossGo / Clash Verge 的「覆写 (Override) -> JavaScript 脚本」中粘贴或填入脚本链接
function main(config) {
  if (!config || typeof config !== 'object') return config;
  if (config.sniffer && typeof config.sniffer === 'object') {
    config.sniffer['override-destination'] = true;
  }
  const gwProxy = {"name": "GTool-iOS-Rewrite", "type": "http", "server": "<YOUR_COMPUTER_LAN_IP>", "port": 18910, "username": "gtool", "password": "<YOUR_STUDIO_LAN_TOKEN>"};
  const headRules = ["IP-CIDR,192.168.0.0/16,DIRECT,no-resolve", "IP-CIDR,10.0.0.0/8,DIRECT,no-resolve", "IP-CIDR,172.16.0.0/12,DIRECT,no-resolve", "AND,((NETWORK,UDP),(DST-PORT,443),(DOMAIN-SUFFIX,one.google.com)),REJECT", "AND,((NETWORK,UDP),(DST-PORT,443),(DOMAIN,subscriptionsmobile-pa.googleapis.com)),REJECT", "DOMAIN-SUFFIX,one.google.com,GTool-iOS-Rewrite", "DOMAIN,subscriptionsmobile-pa.googleapis.com,GTool-iOS-Rewrite", "DOMAIN-SUFFIX,itunes.apple.com,DIRECT", "DOMAIN-SUFFIX,apps.apple.com,DIRECT", "DOMAIN-SUFFIX,mzstatic.com,DIRECT", "DOMAIN-SUFFIX,xp.apple.com,DIRECT", "DOMAIN-SUFFIX,apple.com,DIRECT", "DOMAIN-SUFFIX,icloud.com,DIRECT"];
  const oldProxies = Array.isArray(config.proxies) ? config.proxies.filter(p => p && p.name !== 'GTool-iOS-Rewrite') : [];
  config.proxies = [gwProxy, ...oldProxies];
  const headSet = new Set(headRules);
  const oldRules = Array.isArray(config.rules) ? config.rules.filter(r => !headSet.has(r)) : [];
  config.rules = [...headRules, ...oldRules];
  return config;
}
