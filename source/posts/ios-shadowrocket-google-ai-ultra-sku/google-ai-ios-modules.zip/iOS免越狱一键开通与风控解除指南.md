# Google AI · iOS 免越狱全客户端一键配置与证书启用指南 (v6.0)

- 技术博客：https://blog.caowo.de/
- GPT 代充发卡网（仅提供 ChatGPT 代充服务）：https://faka.cdkey.si/
- 支持客户端：**Shadowrocket（基于已有 `default.conf` 叠加）** · **Clash 全生态（Stash / Clash Mi / FlClash / CrossGo / Karing）** · **Surge** · **Loon** · **Quantumult X**

---

## 零、必看：Google AI Ultra「首月 $0 免费试用 (`1month_eft.acq`)」与付费 1 折双路线说明

### 路线 A：你要的是「首月 $0 免费试用 (`1month_eft.acq` 已实测复现)」（默认第 1 / 第 2 档）
1. **已实测复现的核心映射关系（匹配 `^https://one\.google\.com/ai.*$` 与原生 Protobuf）**：
   - **默认第 1 档（满血 20x 直通版）**：将 `g1.ios.20tb.m.v2`（20TB 5x 按钮）与 `g1.ios.30tb.ai.pro.m`（30TB 20x 按钮）统一改写为 **`g1.ai.ultra.1month_eft.acq`** —— 点击任意 Ultra 升级按钮直接弹出 **Google AI Ultra 20x (30TB) · 1个月 `$0` 免费试用**！
   - **第 2 档（同步 G1-ACQ v7.6 三档自动版）**：`20TB -> g1.20tb.1month_eft.acq`（5x 免费 1 个月，独立回退 90p `$9.99`）、`30TB -> g1.ai.ultra.1month_eft.acq`（20x 免费 1 个月，独立回退 90p `$19.99`）、`2TB -> g1.2tb.ai.12months_ip_90p`（Pro `$1.99/月×12期`）。
   - **第 3 档（独立 5x 免费 1 个月池）**：由于 `g1.20tb.1month_eft.acq` 与 `g1.ai.ultra.1month_eft.acq` 是两个独立内购商品，领过 20x 试用的账号还可单独测 `g1.20tb.1month_eft.acq`！
2. **重要排雷（切勿误点系统「查看所有方案」）**：
   - 激活首月免费试用后，苹果 `设置 -> Apple 账户 -> 订阅 -> 查看所有方案 (See All Plans)` 列表中不会展示任何 `$0` 免费试用或低价入门折扣（已订阅同组商品后系统仅列出日常原价），切勿在「查看所有方案」中盲目点击切换以免按原价排期扣费。

### 路线 B：无免费试用资格老号，改开付费 1 折特惠（选择第 5 档 `三档合一付费1折版`）

| 目标档位 | 原位被替换 SKU (`SRC`) | 改写后隐藏优惠 SKU (`DST`) | 苹果扣款价 | **必须打开的 iOS 入口 App** |
|---|---|---|---|---|
| **5x AI Ultra (20TB)** | `g1.ios.20tb.m.v2` | `g1.20tb.3months_ip_90p.acq`（备选 `75p`） | **US\$9.99/月**（前 3 个月） | **Gemini App**（点右上角头像 -> 升级 -> 选 20TB 卡片） |
| **20x AI Ultra (30TB)** | `g1.ios.30tb.ai.pro.m` | `g1.ai.ultra.3months_ip_90p.acq`（备选 `75p`） | **US\$19.99/月**（前 3 个月） | **Google 搜索 App（彩色 G 图标）**（点右上角头像 -> 升级 -> 选 30TB 卡片） |
| **AI Pro (2TB/5TB)** | `g1.ios.2tb.<任意后缀>` | `g1.2tb.ai.12months_ip_90p`（无 `.acq`） | **US\$1.99/月**（前 12 个月） | **Google 搜索 App（彩色 G 图标）** 或 **Gemini App** |

- **为什么切勿在 `Google One App` 内点击？** 苹果商店每个 iOS App 的内购商品表（`SKProduct`）相互独立。`Google One App` 的商品表只注册了 `g1.ios.*` 前缀商品，不认识非 `ios` 前缀的优惠 SKU，因此会回退弹出 **US\$199.99/月（1个月免费试用）**；改从 **Gemini App** 或 **Google 搜索 App（彩色 G）** 进入即可正常弹出 **US\$9.99/月** 与 **US\$19.99/月**！
- **关于 PayPal 延迟扣款现象**：苹果美区内购支持小额账单合并（Batch Billing），弹出购买完成且 App Store 订阅生效后，PayPal 可能在 **1～72 小时内** 才实际入账扣款。只需保持 PayPal 余额/绑卡充足等待自动结算即可，切勿解绑支付方式以免产生苹果欠费单。
- **手机端实时诊断报告**：配置生效后，在手机 Safari 打开 `https://one.google.com/g1-sku-report` 即可查看网关接管状态与替换明细。

---

## 一、Shadowrocket 标准操作流程（基于已有 `default.conf` 叠加 + HTTPS 解密证书 4 步启用）

> **核心原理解析（为什么不能新起独立空白 `.conf`？）**
> 在 Shadowrocket 中，你生成并信任好的根证书私钥（`ca-p12` / `ca-passphrase`）与机场节点、分流规则都保存在当前激活的 **`default.conf`** 内。若导入一个新建的独立 `.conf` 文件，不仅不会自动切换选中，而且独立文件内没有 `default.conf` 的 CA 证书私钥，因此无法解密 `one.google.com`！
> **正确做法是：始终保持选中原有的 `default.conf`，先在 `default.conf` 完成 HTTPS 解密证书启用，再一键挂载 `.sgmodule` 叠加模块（或将正文重写规则填入 `default.conf`）。**

### 第 1 步：在已有 `default.conf` 开启 HTTPS 解密并生成证书
1. 打开 Shadowrocket，**先保持顶部 VPN 连接开关处于「关闭」状态**（避免未配好跳过规则前把局域网请求发往代理节点导致超时）。
2. 切换到「配置」页，点击当前正在使用的 **`default.conf` 右侧 `(i)` 图标**。
3. 点击进入 **「HTTPS 解密」**：
   - 打开顶部的 **「HTTPS 解密」** 开关；
   - 点击 **「证书 -> 生成新的 CA 证书」**；
   - 点击 **「安装证书 -> 允许」** 下载配置描述文件。（注：若你此前已在 `default.conf` 安装并信任过证书，可直接跳到第 4 步）

### 第 2 步：在 iPhone 系统设置安装描述文件
1. 打开 iPhone 系统 **「设置」**，点击顶部的 **「已下载描述文件」**（或前往 `设置 -> 通用 -> VPN 与设备管理`）。
2. 点击刚下载的 `Shadowrocket` 描述文件 -> 点击右上角 **「安装」** 并输入锁屏密码完成安装。

### 第 3 步：开启根证书完全信任（最关键一步，漏做则重写不生效）
1. 打开 iPhone **`设置 -> 通用 -> 关于本机 -> 滑到最底部「证书信任设置」`**。
2. 在「针对根证书启用完全信任」列表中，找到刚安装的 `Shadowrocket` 根证书，**打开右侧绿色开关**并在弹窗点击「继续」。
   - *排坑提示：如果进入「证书信任设置」发现里面是空的，说明漏做了上面的「第 2 步：安装已下载描述文件」。*

### 第 4 步：保存 `default.conf` 并一键叠加 `.sgmodule` 模块
1. 返回 Shadowrocket，**连续点击右上角 `✓` 保存 `default.conf`**（切勿左滑返回，否则 HTTPS 解密开关不会保存）。
2. 在电脑打开 **Google AI Trial Studio ->「iOS 免越狱」** 页，用 iPhone 相机扫描二维码，点击卡片中的首选按钮：
   - **「Shadowrocket 首选：一键叠加模块 (.sgmodule · 基于已有 default.conf 生效)」**
   - *首次点击提示：iOS 首次访问电脑局域网 IP 会弹出系统「本地网络」权限框，请点击 **「允许」**；若首次因权限弹窗拦截提示失败，允许后再点一次即可立即成功。*
   - *备选离线导入*：也可直接将本目录 `Shadowrocket叠加模块(.sgmodule基于default.conf)/` 下的 `.sgmodule` 通过 AirDrop 发送到 iPhone 导入至 Shadowrocket「配置 -> 模块」，或打开 `*-default.conf增量规则.txt` 直接填入 `default.conf` 的「正文重写」。
3. 确认「配置 -> 模块」中已勾选启用模块，且首页全局路由为「配置」，打开 Shadowrocket 顶部连接开关（选择美国原生节点）。
4. **上滑彻底关闭旧 `Google One` 后台**，重新打开 `Google One -> 升级 -> Ultra -> 选择下方 30 TB 卡片点击订阅`，核对弹出的 Apple StoreKit 付款单显示优惠金额（如 `$19.99/月 · 前 3 个月`）后确认。

---

## 二、iOS Clash 用户专属步骤（叠加规则库到当前配置 · 保留 100% 原有机场节点）

> **为什么不能直接导入空白 Clash 配置？**
> 普通 `clash://install-config` 导入的是独立「节点配置库」，会把你正在使用的机场订阅替换成无外部节点的空配置。正确做法是**在你当前正在使用的 Clash 配置上挂载「覆写规则 (Override)」或「规则集 (Rule-Set)」**，100% 保留原有全部节点！

### 方案 1：使用 Stash（App Store 上的 iOS 版 Clash · 免电脑独立生效）
Stash 原生内置 `http.mitm` 与 `http.script` 引擎（已适配 `binary-mode: true` 二进制 Protobuf 改写、内联 `payload` 脚本与 `UDP 443` QUIC 拦截）：
1. 在 Stash「工具 -> HTTPS 解密」中生成、安装并在系统 `设置 -> 通用 -> 关于本机 -> 证书信任设置` 开启完全信任。
2. 在电脑 Studio「iOS 免越狱」页扫码，点击 **「Stash (iOS Clash)：一键叠加覆写规则到当前配置 (.stoverride · 保留原节点)」**（或导入本目录 `Clash与Stash规则库/*.stoverride`），在当前配置下勾选启用覆写、MitM 与脚本即可。

### 方案 2：使用 Clash Mi / FlClash / Mihomo / Karing（叠加规则至当前配置）
1. 电脑与 iPhone 连接同一 Wi-Fi，在 Studio「iOS 免越狱」页扫码打开手机控制台。
2. 在 Safari 点击 **「1. 下载安装域限定 CA 根证书 (.mobileconfig)」**（仅对 `one.google.com` 与 `subscriptionsmobile-pa.googleapis.com` 生效），完成「已下载描述文件安装」+「通用 -> 关于本机 -> 证书信任设置开启完全信任」。
3. **推荐方式 A（叠加覆写规则，保留全部原节点）**：点击扫码页上的 **「复制覆写规则 (+proxies/+rules)」** 或 **「复制 JS 覆写脚本 main(config)」**，粘贴到 Clash Mi / FlClash 的 **「配置 -> 覆写 (Override)」** 中启用；Karing 用户也可直接复制 `.json` 分流规则集链接挂载至当前分流组。
4. **可选方式 B（原订阅无损合成一键导入）**：在扫码页或电脑 Studio 粘贴你当前使用的机场 Clash 订阅链接（仅驻留本机内存、不落盘），点击「绑定原订阅」后即可一键导入已合入你全部原节点的完整配置。
   - *若弹窗提示 `Your payment method was declined`：请前往 iPhone `设置 -> Apple 账户 -> 媒体与购买项目 -> 查看账户 -> 购买记录` 检查是否有历史订阅续费失败的未结清账单。*

---

## 三、Surge / Loon / Quantumult X 步骤

- **Surge iOS**：先在 Surge 开启 MitM 并安装信任根证书，导入 `Shadowrocket叠加模块(.sgmodule基于default.conf)/*.sgmodule` 模块。
- **Loon**：先在 Loon 开启 MITM 并安装信任根证书，导入 `Loon插件/*.plugin`。
- **Quantumult X**：先开启 MitM 并安装信任根证书，引用 `QuantumultX片段/*.snippet` 与同目录 `.js`。

---

## 四、Apple 内购「购买未完成 / 提交审核」客服解锁话术

若双击侧边键后提示「购买未完成 — 提交申请至 Apple 支持以供审核」，说明重写查价已成功，仅触发美区 Apple ID 首单内购风控。打开 `https://getsupport.apple.com/` -> `Billing & Subscriptions` -> `Unable to purchase` -> `Chat`，发送以下英文说明给在线客服即可解锁：

```text
Hi, I tried to purchase a Google One subscription ($19.99) via In-App Purchase on my iPhone, and received "Your Purchase Could Not Be Completed - Submit a request to Apple Support for review". Could you please help review and unblock In-App Purchases on my Apple Account? Thank you.
```
