# Checkout Server V3

本地 Platform Checkout 订单编排网站 V2-D。使用 SQLite 和原生前端；Checkout 与续费取消模块需要 `curl_cffi`。

## 启动

```powershell
cd D:\ky\xy
pip install -r requirements.txt
python server.py
```

或双击 `run.cmd`。默认地址：`http://127.0.0.1:5602/`。

可选参数：

```powershell
python server.py --host 127.0.0.1 --port 5602 --data-dir .\data --step-delay 0.55
```

## V3 功能

- 自动生成和本地保存 50-128 位 API Key
- Plus 套餐（Platform Checkout 当前适配计划）
- `/api/auth/session` JSON 本地校验和脱敏摘要；提链只要求有效 `accessToken`，Session Cookie 作为可选增强上下文
- SQLite 订单持久化
- 后台单任务队列和每 3 秒状态轮询
- API Key 隔离的历史订单分页
- 失败订单重试
- Sandbox 仅用于单元测试，不作为工作台支付渠道
- 管理员首次初始化、登录和 HttpOnly 会话
- 受管 API Key 创建、列表和吊销
- Session 只做本地即时校验；支持只含 `accessToken` 的 `/api/auth/session` JSON，输入阶段不请求 Stripe、不创建 Checkout、PaymentMethod 或订单
- 旧版 Stripe bootstrap 兼容接口仍按账号短期缓存只读公钥，默认 TTL 为 60 秒（上限 300 秒）；当前工作台不在输入阶段调用它
- 用户填完普通 HTML 银行卡字段并点击“立即支付”后，才创建 Platform Checkout、校验商户 key，并由后端选择卡片合同进入确认链路
- Session JWT 缺少 `account_id` 时通过 Platform `accounts/check` 自动解析当前账号
- Preflight 从当前 `account_id` 节点读取历史 `billing_currency`：历史币种为空或与本次币种相同时使用 `custom`（保留 `entry_point`，通常返回 `oaics_`）；两个币种都有值且不同时使用 `hosted`（无 `entry_point`、`locale=zh-CN`，通常返回 `cs_live_`）
- Custom 创建返回 `currency_incompatible`、`cannot combine currencies` 或 `currency mismatch` 时，在同一 Session/Cookie Jar 和代理上单次升级到 Hosted 重建；最终支付合同始终按实际 `oaics_`/`cs_` 前缀选择
- 点击支付后预检读取账号级 Stripe bootstrap key，并要求 Checkout、PaymentMethod/ConfirmationToken 与账号商户完全匹配
- Preflight 识别 Checkout Provider：`oaics_` 使用 Vendor API 合同，`cs_` 才初始化 Stripe Payment Page；金额缺失时停止，不回退为 PHP 0.00
- 前端统一使用普通 HTML 卡号、有效期和 CVC 输入框；`oaics_` 默认先用后端原始 `payment_method_data[...]` 创建 `ConfirmationToken`，复用 Elements Session 已建立的 Stripe 传输并使用 15 秒独立超时；Stripe 明确拒绝 publishable-key tokenization 或发生传输错误时启动真实 Chrome/Edge 加载 Stripe.js 与 Elements 生成 `pm_`，同一 Stripe 代理短期失败后 120 秒内直接走浏览器方案；`cs_` 继续使用 cat-cw `inline_payment_method_data`
- 美国账单信息固定为姓名、邮箱、地址1、城市、州、邮编、国家七项，并同时写入 PaymentMethod、Platform Taxes 与 Stripe Payment Page tax region；管理后台可选择本地 `billing_profiles.json` 或 `address-api.example.com` 地址 API
- 管理后台可热更新内存代理池并检测出口 IP、国家和延迟；代理凭据不回显、不落库
- `oaics_`/`cs_` Checkout ID 作为服务端幂等键，重复提交只返回原订单
- `requires_action/3DS` 或缺少会话绑定确认数据时，订单进入等待验证状态并持久化 Checkout 链接
- PaymentMethod/Checkout 确认等远程变更提交后禁止切换代理重放，避免重复绑卡或扣款
- 成功条件同时要求 Stripe 支付终态、Vendor Checkout 回跳、Plus 激活和 PaymentMethod 已同步到 Platform 账号
- 完整验证固定启用（`fast_verify=false`）；多账号批量前端不属于 Checkout Server
- `oaics_` 使用 `Taxes amount_total → Elements Session（金额存在时）→ 原始 payment_method_data → ConfirmationToken → Platform checkout/confirm → Stripe Intent confirm`，明确不支持或 Raw 传输失败时回退 `后台 Stripe.js Elements → pm_ → ConfirmationToken`；Raw 具体 curl/TLS 错误写入订单时间线，Taxes 未返回金额时跳过 Elements Session 而不再伪造小金额；`cs_` 使用 Payment Page `init → elements/sessions → inline confirm → poll`，两条合同最后都核验 Platform Plus
- Platform Checkout 成功后自动调用 `cancel_renewal.py` 取消 Platform 自动续费，失败最多重试三次；Session 仅在当前进程内存中暂存

## 支付状态判定

- `stripe_action_required`：Stripe Intent 仍为 `requires_action`，需要完成 3DS；此时仍处于支付确认阶段。
- `checkout_session_confirmation_required`：缺少浏览器 Checkout 会话确认，保留确认链接与订单，不能视为扣款成功。
- `payment_processing`：Stripe Intent 仍在处理，继续查询原 Intent，禁止创建新 Checkout 或重复扣款。
- `payment_terminal_unverified`：上游返回了订阅等待提示，但没有可核验的 Intent/Payment Page 成功终态，仍处于支付阶段。
- `subscription_pending`：仅在已取得可核验的支付成功证据后使用；`oaics_` 需要 `pi_`/`seti_`、Intent 类型和 `succeeded` 状态，`cs_` 需要 Payment Page 轮询成功。
- `payment_recovery_exhausted` 与 `subscription_recovery_exhausted` 分别表示支付确认恢复和 Plus 同步恢复达到上限，二者不会互相覆盖。
- Checkout 链接、错误文本、`step=verify_result` 或账号已经存在 Plus，都不能单独证明本订单支付成功。
- Checkout 回跳按浏览器顺序执行：`confirm_return_url → Checkout 状态预读 → payments/success.data → auth/session → Checkout 终态轮询 → Plus 核验`。预读阶段的 `requires_action` 会在 success loader 后复查；复查仍未解除时才进入浏览器确认状态。
- 启动时数据库迁移会修复旧版把 `subscription_pending` 误写成支付成功的记录，并把缺少终态证据的订单恢复到支付确认阶段。

## 数据边界

- 数据库只保存 API Key 的 SHA-256，不保存 API Key 明文。
- Session JSON 只在创建请求内解析，数据库只保存邮箱、账户引用和指纹。
- Sandbox 支付字段使用本地测试支付标识，不接收或保存卡号、有效期和 CVC。
- 普通 HTML 卡片字段只在点击“立即支付”时随请求发送；服务端不会把卡号、有效期或 CVC 写入数据库、日志或订单响应，处理结束后立即清理内存副本。
- `stripe_elements` 仍作为后端兼容模式接受外部 `pm_...`；当前工作台前端不加载 Stripe.js，只有点击支付并识别为 `oaics_` 后，后台浏览器 Runner 才加载 Stripe.js 和 Elements。
- `cs_` Payment Page 兼容模式可在上游明确声明 `api_card` 能力时使用 inline card confirm；该模式不调用 `/v1/payment_methods`，且 SQLite、订单响应和历史记录只保存卡片末四位。
- PayPal、GoPay、QRIS、ABCard 和浏览器自动化流程不属于当前版本。
- 取消续费动作只在支付成功后执行；Session/accessToken 不加密、不写入数据库，只在当前进程内存中保留到取消动作结束。
- Stripe Poll、Plus 激活和续费取消分别记录；任一必选条件失败时订单不会显示 SUCCESS。

## 管理后台

访问 `http://127.0.0.1:5602/admin`。首次访问创建管理员，密码至少 10 位。登录后生成受管 API Key，明文只在创建响应中显示一次。

后台“账单地址来源”可以选择：

- `billing_profiles_json`：从项目内 200 条账单资料随机选择。
- `remote_address_api`：调用 `https://address-api.example.com/api/v1/address?country_code=us&area_code=DE` 自动生成；可调整两位 `area_code`。

选择结果保存在 SQLite。每个 Checkout 只生成或抽取一次地址，Taxes、PaymentMethod 和支付确认阶段复用同一条资料；邮箱始终取自 Session。

将受管 Key 设为所有订单都必须使用：

```powershell
$env:CS_REQUIRE_MANAGED_KEYS = "1"
python server.py
```

## Platform Checkout 配置

Checkout Server 不使用独立 Stripe 商户的 `sk_*` 或 Webhook 配置。输入有效 Platform Session 后，服务端仍以 `PH/PHP` 创建 Checkout，但账单国家和 Checkout tax region 默认使用美国 `US`，并返回 Checkout URL、Checkout ID、processor entity 和 Stripe publishable key。

```powershell
$env:CS_PLATFORM_COUNTRY = "PH"
$env:CS_PLATFORM_CURRENCY = "PHP"
$env:CS_PLATFORM_BILLING_COUNTRY = "US"
$env:CS_PLATFORM_PROXY_POOL = "socks5h://USER:PASSWORD_country-us@HOST:PORT"
$env:CS_STRIPE_PROXY_POOL = "socks5h://USER:PASSWORD_country-us@HOST:PORT"
$env:CS_PLATFORM_REQUIRE_PROXY = "1"
$env:CS_STRIPE_REQUIRE_PROXY = "1"
python server.py
```

`CS_PLATFORM_PROXY_POOL` 和 `CS_STRIPE_PROXY_POOL` 支持逗号或换行分隔的 `socks5h` 代理。每个 Checkout 分别固定一条 Platform 代理和一条 Stripe 代理；`platform.example.com` 请求走前者，`api.stripe.com`、`stripe.com`、`stripe.network` 与 `stripecdn.com` 请求走后者。发生连接、TLS 或超时错误时，各自从对应代理池切换。两个代理池都不使用直连回退。

代理池仅接受 `socks5h://USER:PASSWORD_country-us@HOST:PORT` 格式，由代理端解析目标域名。

管理后台分别配置 Platform 与 Stripe 代理，并保存到 `checkout-server.db`；服务启动时优先加载数据库配置，数据库尚无对应记录时会导入环境变量作为初始值。两个出口均不限制国家，并按对应目标独立检测。PH/PHP 仍然是 Platform Checkout 的提链地区和币种，与代理出口国家分开。Stripe 探测允许未授权请求返回 `400/401/403/404`，但代理网关的 SOCKS/CONNECT 拒绝会判定为不可用。

支付请求中的 Session 只保存在当前 Python 进程内存，支付成功并执行续费取消后立即释放。服务重启不会恢复未完成订单的 Session。

`POST /api/platform/stripe/bootstrap` 仅为旧版 Elements 兼容调用保留，当前工作台不会自动调用。

点击“立即支付”后服务端按 Checkout 类型读取商户公钥并继续卡片合同；不会缓存 Session、accessToken、卡片、PaymentMethod、Checkout 或订单数据。

点击“立即支付”后执行 Checkout 预检：`POST /api/platform/checkout/preflight`。

## API

```text
GET  /api/health
GET  /api/meta
POST /api/session/validate
POST /api/platform/stripe/bootstrap
POST /api/platform/checkout/preflight
POST /api/platform/checkout/charge
POST /api/platform/checkout/sync
POST /api/orders/query
POST /api/stripe/charge
POST /api/stripe/sync
POST /api/stripe/webhook
GET  /api/admin/state
POST /api/admin/setup
POST /api/admin/login
POST /api/admin/logout
GET  /api/admin/api-keys
POST /api/admin/api-keys
POST /api/admin/api-keys/{id}/revoke
GET  /api/admin/proxy
POST /api/admin/proxy
POST /api/admin/proxy/test
GET  /api/admin/billing
POST /api/admin/billing
POST /api/admin/billing/test
```

支付成功后，系统会自动执行 XY 项目根目录内置的 `cancel_renewal.py`，并回查 `will_renew=false`。取消状态会显示为“已取消”“取消失败”或“缺少 Session”。

创建订单：

```json
{
  "apiKey": "64_CHAR_LOCAL_KEY",
  "session": {
    "user": {"email": "fixture@example.test"},
    "expires": "2099-01-01T00:00:00Z"
  },
  "planType": "plus",
  "paymentMode": "stripe_elements",
  "paymentMethodId": "pm_card_visa",
  "billing": {
    "name": "CARD_HOLDER",
    "email": "EMAIL",
    "line1": "ADDRESS",
    "city": "CITY",
    "state": "STATE",
    "postal_code": "POSTAL_CODE",
    "country": "US"
  }
}
```

普通 HTML 卡片字段的后端输入：`oaics_` 默认尝试原始 `payment_method_data[...]` 创建 ConfirmationToken，收到明确的 publishable-key tokenization 不支持错误时使用后台 Stripe.js 生成 PaymentMethod 后再创建 ConfirmationToken；`cs_` 仅在同一预检响应的 `cardInputModes` 明确包含 `api_card` 时使用 inline card confirm：

```json
{
  "apiKey": "64_CHAR_LOCAL_KEY",
  "session": {"accessToken": "ACCESS_TOKEN"},
  "planType": "plus",
  "paymentMode": "api_card",
  "billing": {
    "name": "CARD_HOLDER",
    "email": "EMAIL",
    "line1": "ADDRESS",
    "city": "CITY",
    "state": "STATE",
    "postal_code": "POSTAL_CODE",
    "country": "US"
  },
  "card": {
    "number": "CARD_NUMBER",
    "expMonth": "MM",
    "expYear": "YYYY",
    "cvc": "CVC"
  },
  "checkout": {
    "checkoutId": "cs_CHECKOUT_ID",
    "paymentPageId": "cs_CHECKOUT_ID",
    "processorEntity": "vendor_ie",
    "publishableKey": "pk_live_PUBLISHABLE_KEY"
  }
}
```

## 测试

```powershell
python -m unittest discover -s tests -v
```

只创建一次 `redirect` 模式 Checkout、检查是否返回 `cs_`，不提交银行卡或确认支付：

```powershell
python tools\test_hosted_checkout.py --session-file .\session.json --country US --currency USD
```

脚本默认读取 `data\checkout-server.db` 中的 Platform 代理。`responseTag` 可能是 `hosted_checkout_session` 或 `custom_checkout_session`，它不决定 Checkout ID 前缀；`generatedCs=true` 才表示响应中成功提取到 `cs_`。退出码 `2` 表示服务端生成了其他 Checkout ID 类型。

临时把支持国家路由的代理切换为菲律宾出口，不修改数据库：

```powershell
python tools\test_hosted_checkout.py --session-file .\session.json --country PH --currency PHP --proxy-country PH
```

## 目录

```text
xy/
  backend/        SQLite、Session、订单服务和适配器
    vendor/       XY 固定使用的 Platform Checkout 核心
  config/         项目内 Stripe runtime 元数据
  fixtures/       随机账单资料
  static/         工作台和管理后台前端
  tests/          标准库单元测试
  data/           运行时数据库
  cancel_renewal.py  内置续费取消模块
  server.py       HTTP 服务入口
  run.cmd         Windows 启动脚本
```

运行时不会读取 `xy` 目录之外的本地项目文件；联网支付仍会访问 Platform 和 Stripe API。
