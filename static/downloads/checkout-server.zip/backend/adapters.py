from __future__ import annotations

import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable


ProgressCallback = Callable[[str, int], None]


class AdapterError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass(frozen=True)
class AdapterResult:
    confirmation_ref: str


class SandboxAdapter:
    key = "sandbox"
    label = "本地测试引擎"

    def __init__(self, step_delay: float = 0.55):
        self.step_delay = max(0.0, step_delay)

    def process(self, order: dict[str, Any], progress: ProgressCallback) -> AdapterResult:
        steps = [
            ("validate_session", 18),
            ("prepare_checkout", 38),
            ("create_payment_method", 62),
            ("confirm_payment", 84),
            ("verify_result", 96),
        ]
        for step, percent in steps:
            progress(step, percent)
            time.sleep(self.step_delay)
            if order["payment_fixture"] == "test_declined" and step == "confirm_payment":
                raise AdapterError("test_declined", "测试支付方式返回拒绝")
        return AdapterResult(confirmation_ref=f"sbx_{secrets.token_hex(8)}")


def integration_catalog(project_root: Path) -> list[dict[str, Any]]:
    definitions = [
        ("sandbox", "本地测试引擎", project_root, True, "ready"),
    ]
    return [
        {
            "key": key,
            "label": label,
            "available": path.exists(),
            "enabled": enabled,
            "status": status if path.exists() else "missing",
        }
        for key, label, path, enabled, status in definitions
    ]
