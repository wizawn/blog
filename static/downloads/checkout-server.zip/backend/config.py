from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Settings:
    host: str = os.environ.get("CS_HOST", "127.0.0.1")
    port: int = int(os.environ.get("CS_PORT", "5602"))
    data_dir: Path = Path(os.environ.get("CS_DATA_DIR", ROOT / "data"))
    worker_step_delay: float = float(os.environ.get("CS_WORKER_STEP_DELAY", "0.55"))
    require_managed_keys: bool = os.environ.get("CS_REQUIRE_MANAGED_KEYS", "0").lower() in {"1", "true", "yes"}
    stripe_secret_key: str = os.environ.get("CS_STRIPE_SECRET_KEY", "")
    stripe_publishable_key: str = os.environ.get("CS_STRIPE_PUBLISHABLE_KEY", "")
    stripe_webhook_secret: str = os.environ.get("CS_STRIPE_WEBHOOK_SECRET", "")
    stripe_api_base: str = os.environ.get("CS_STRIPE_API_BASE", "https://api.stripe.com")
    platform_country: str = os.environ.get("CS_PLATFORM_COUNTRY", "PH").upper()
    platform_currency: str = os.environ.get("CS_PLATFORM_CURRENCY", "PHP").upper()
    platform_billing_country: str = os.environ.get("CS_PLATFORM_BILLING_COUNTRY", "US").upper()
    platform_proxy_pool: str = os.environ.get("CS_PLATFORM_PROXY_POOL", "")
    platform_require_proxy: bool = os.environ.get("CS_PLATFORM_REQUIRE_PROXY", "1").lower() in {"1", "true", "yes"}
    platform_proxy_timeout: float = float(os.environ.get("CS_PLATFORM_PROXY_TIMEOUT", "12"))
    stripe_proxy_pool: str = os.environ.get("CS_STRIPE_PROXY_POOL", "")
    stripe_require_proxy: bool = os.environ.get("CS_STRIPE_REQUIRE_PROXY", "1").lower() in {"1", "true", "yes"}
    stripe_proxy_timeout: float = float(os.environ.get("CS_STRIPE_PROXY_TIMEOUT", "12"))
    stripe_browser_executable: str = os.environ.get("CS_STRIPE_BROWSER_EXECUTABLE", "")
    confirmation_token_mode: str = os.environ.get("CS_CONFIRMATION_TOKEN_MODE", "dual").lower()

    @property
    def stripe_enabled(self) -> bool:
        return bool(self.stripe_secret_key)

    @property
    def database_path(self) -> Path:
        return self.data_dir / "checkout-server.db"

    @property
    def static_dir(self) -> Path:
        return ROOT / "static"
