from __future__ import annotations

import secrets
import sqlite3
import time
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = """
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_key TEXT NOT NULL UNIQUE,
    card_key TEXT NOT NULL UNIQUE,
    api_key_hash TEXT NOT NULL,
    api_key_prefix TEXT NOT NULL,
    plan_type TEXT NOT NULL,
    plan_name TEXT NOT NULL,
    amount_minor INTEGER NOT NULL,
    currency TEXT NOT NULL,
    email TEXT NOT NULL,
    account_ref TEXT NOT NULL,
    session_fingerprint TEXT NOT NULL,
    provider TEXT NOT NULL,
    payment_fixture TEXT NOT NULL,
    payment_last4 TEXT NOT NULL,
    provider_ref TEXT,
    checkout_provider TEXT,
    checkout_country TEXT,
    payment_page_id TEXT,
    processor_entity TEXT,
    payment_contract TEXT,
    checkout_publishable_key TEXT,
    confirm_return_url TEXT,
    intent_type TEXT,
    payment_terminal_status TEXT,
    checkout_terminal_status TEXT,
    return_url_status INTEGER,
    recovery_attempts INTEGER NOT NULL DEFAULT 0,
    recovery_last_at TEXT,
    recovery_next_at TEXT,
    renewal_cancel_requested INTEGER NOT NULL DEFAULT 0,
    renewal_cancel_status TEXT NOT NULL DEFAULT 'not_required',
    renewal_cancel_message TEXT,
    renewal_active_until TEXT,
    renewal_cancelled_at TEXT,
    renewal_retry_count INTEGER NOT NULL DEFAULT 0,
    payment_action_url TEXT,
    payment_action_type TEXT,
    payment_action_payload TEXT,
    status TEXT NOT NULL,
    step TEXT NOT NULL,
    progress INTEGER NOT NULL DEFAULT 0,
    retry_count INTEGER NOT NULL DEFAULT 0,
    confirmation_ref TEXT,
    error_code TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_orders_api_created
    ON orders(api_key_hash, id DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status
    ON orders(status, id);

CREATE TABLE IF NOT EXISTS order_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    stage TEXT NOT NULL,
    message TEXT NOT NULL,
    elapsed_ms INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_order_events_order
    ON order_events(order_id, id);

CREATE TABLE IF NOT EXISTS admin_users (
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_sessions (
    token_hash TEXT PRIMARY KEY,
    username TEXT NOT NULL,
    created_at REAL NOT NULL,
    expires_at REAL NOT NULL,
    FOREIGN KEY (username) REFERENCES admin_users(username) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key_hash TEXT NOT NULL UNIQUE,
    key_prefix TEXT NOT NULL,
    label TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at REAL NOT NULL,
    last_used_at REAL,
    revoked_at REAL
);

CREATE INDEX IF NOT EXISTS idx_api_keys_status ON api_keys(status, id DESC);

CREATE TABLE IF NOT EXISTS proxy_configurations (
    role TEXT PRIMARY KEY CHECK(role IN ('platform', 'stripe')),
    proxies TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS billing_configuration (
    id INTEGER PRIMARY KEY CHECK(id = 1),
    source TEXT NOT NULL DEFAULT 'billing_profiles_json'
        CHECK(source IN ('billing_profiles_json', 'remote_address_api')),
    address_api_url TEXT NOT NULL DEFAULT
        'https://address-api.example.com/api/v1/address?country_code=us&area_code=DE',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
"""


ORDER_COLUMNS = {
    "amount_minor",
    "status",
    "step",
    "progress",
    "retry_count",
    "confirmation_ref",
    "error_code",
    "error_message",
    "updated_at",
    "completed_at",
    "provider_ref",
    "payment_last4",
    "renewal_cancel_requested",
    "renewal_cancel_status",
    "renewal_cancel_message",
    "renewal_active_until",
    "renewal_cancelled_at",
    "renewal_retry_count",
    "payment_action_url",
    "payment_action_type",
    "payment_action_payload",
    "checkout_provider",
    "checkout_country",
    "payment_page_id",
    "processor_entity",
    "payment_contract",
    "checkout_publishable_key",
    "confirm_return_url",
    "intent_type",
    "payment_terminal_status",
    "checkout_terminal_status",
    "return_url_status",
    "recovery_attempts",
    "recovery_last_at",
    "recovery_next_at",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as conn:
            conn.executescript(SCHEMA)
            proxy_columns = {
                row[1] for row in conn.execute("PRAGMA table_info(proxy_configurations)").fetchall()
            }
            expected_proxy_columns = {"role", "proxies", "created_at", "updated_at"}
            if proxy_columns != expected_proxy_columns:
                conn.execute("ALTER TABLE proxy_configurations RENAME TO proxy_configurations_legacy")
                conn.execute(
                    "CREATE TABLE proxy_configurations ("
                    "role TEXT PRIMARY KEY CHECK(role IN ('platform', 'stripe')), "
                    "proxies TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL)"
                )
                conn.execute(
                    "INSERT INTO proxy_configurations(role, proxies, created_at, updated_at) "
                    "SELECT role, proxies, created_at, updated_at FROM proxy_configurations_legacy"
                )
                conn.execute("DROP TABLE proxy_configurations_legacy")
            columns = {row[1] for row in conn.execute("PRAGMA table_info(orders)").fetchall()}
            if "provider_ref" not in columns:
                conn.execute("ALTER TABLE orders ADD COLUMN provider_ref TEXT")
            migrations = {
                "card_key": "TEXT",
                "renewal_cancel_requested": "INTEGER NOT NULL DEFAULT 0",
                "renewal_cancel_status": "TEXT NOT NULL DEFAULT 'not_required'",
                "renewal_cancel_message": "TEXT",
                "renewal_active_until": "TEXT",
                "renewal_cancelled_at": "TEXT",
                "renewal_retry_count": "INTEGER NOT NULL DEFAULT 0",
                "payment_action_url": "TEXT",
                "payment_action_type": "TEXT",
                "payment_action_payload": "TEXT",
                "checkout_provider": "TEXT",
                "checkout_country": "TEXT",
                "payment_page_id": "TEXT",
                "processor_entity": "TEXT",
                "payment_contract": "TEXT",
                "checkout_publishable_key": "TEXT",
                "confirm_return_url": "TEXT",
                "intent_type": "TEXT",
                "payment_terminal_status": "TEXT",
                "checkout_terminal_status": "TEXT",
                "return_url_status": "INTEGER",
                "recovery_attempts": "INTEGER NOT NULL DEFAULT 0",
                "recovery_last_at": "TEXT",
                "recovery_next_at": "TEXT",
            }
            for column, definition in migrations.items():
                if column not in columns:
                    conn.execute(f"ALTER TABLE orders ADD COLUMN {column} {definition}")
            missing_card_keys = conn.execute(
                "SELECT id FROM orders WHERE card_key IS NULL OR card_key = '' ORDER BY id"
            ).fetchall()
            for row in missing_card_keys:
                conn.execute(
                    "UPDATE orders SET card_key = ? WHERE id = ?",
                    (self._new_card_key(), int(row[0])),
                )
            conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_card_key ON orders(card_key)"
            )
            conn.execute(
                "UPDATE orders SET "
                "checkout_provider = CASE "
                "WHEN provider_ref GLOB 'oaics_*' THEN 'oaics' "
                "WHEN provider_ref GLOB 'cs_*' THEN 'stripe' "
                "ELSE checkout_provider END, "
                "processor_entity = COALESCE(processor_entity, CASE "
                "WHEN provider = 'platform_checkout' THEN 'vendor_ie' END), "
                "payment_contract = CASE "
                "WHEN provider_ref GLOB 'oaics_*' THEN 'oaics_confirmation_token' "
                "WHEN provider_ref GLOB 'cs_*' THEN 'stripe_payment_page' "
                "ELSE payment_contract END, "
                "payment_page_id = CASE "
                "WHEN provider_ref GLOB 'oaics_*' THEN NULL "
                "WHEN provider_ref GLOB 'cs_*' THEN COALESCE(payment_page_id, provider_ref) "
                "ELSE payment_page_id END, "
                "payment_terminal_status = COALESCE(payment_terminal_status, CASE "
                "WHEN status = 'succeeded' THEN 'succeeded' END), "
                "checkout_terminal_status = COALESCE(checkout_terminal_status, CASE "
                "WHEN status = 'succeeded' THEN 'succeeded' END) "
                "WHERE provider = 'platform_checkout'"
            )
            conn.execute(
                "UPDATE orders SET payment_terminal_status = NULL "
                "WHERE provider = 'platform_checkout' AND status != 'succeeded' "
                "AND payment_terminal_status = 'succeeded' "
                "AND COALESCE(error_code, '') != 'auth_refresh_required' "
                "AND COALESCE(intent_type, '') = '' "
                "AND COALESCE(confirmation_ref, '') NOT GLOB 'pi_*' "
                "AND COALESCE(confirmation_ref, '') NOT GLOB 'seti_*' "
                "AND return_url_status IS NULL "
                "AND LOWER(COALESCE(checkout_terminal_status, '')) "
                "NOT IN ('succeeded', 'complete', 'completed', 'paid', 'active')"
            )
            conn.execute(
                "UPDATE orders SET "
                "error_code = CASE "
                "WHEN error_code = 'subscription_recovery_exhausted' "
                "THEN 'payment_recovery_exhausted' "
                "WHEN payment_action_url IS NOT NULL AND payment_action_url != '' "
                "THEN 'payment_confirmation_required' ELSE 'payment_terminal_unverified' END, "
                "error_message = CASE "
                "WHEN error_code = 'subscription_recovery_exhausted' "
                "THEN '历史自动恢复已达到上限，仍缺少可核验的 Stripe Intent 支付终态' "
                "WHEN payment_action_url IS NOT NULL AND payment_action_url != '' "
                "THEN '支付确认仍需完成；历史记录未保存可核验的 Stripe Intent 终态' "
                "ELSE '订单缺少可核验的 Stripe Intent 支付终态证据' END, "
                "step = 'confirm_payment', progress = 70, "
                "payment_action_type = CASE WHEN payment_action_url IS NOT NULL AND payment_action_url != '' "
                "THEN COALESCE(payment_action_type, 'payment_confirmation') "
                "ELSE payment_action_type END "
                "WHERE provider = 'platform_checkout' AND status = 'awaiting_payment' "
                "AND error_code IN ('subscription_pending', 'subscription_recovery_exhausted') "
                "AND COALESCE(payment_terminal_status, '') != 'succeeded'"
            )
            conn.execute(
                "UPDATE orders SET payment_action_type = CASE "
                "WHEN error_code = 'checkout_session_confirmation_required' "
                "THEN 'checkout_session_confirmation' "
                "WHEN error_code = 'stripe_action_required' THEN 'stripe_3ds' "
                "WHEN error_code = 'payment_processing' THEN 'payment_processing' "
                "ELSE payment_action_type END "
                "WHERE provider = 'platform_checkout' AND payment_action_type IS NULL"
            )
            if "renewal_session_ciphertext" in columns:
                conn.execute("UPDATE orders SET renewal_session_ciphertext = NULL")
            conn.commit()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def create_order(self, values: dict[str, Any]) -> dict[str, Any]:
        now = utc_now()
        values = dict(values)
        values.setdefault("card_key", self._new_card_key())
        initial_status = values.pop("_status", "queued")
        initial_step = values.pop("_step", "queued")
        initial_progress = values.pop("_progress", 0)
        payload = {
            **values,
            "status": initial_status,
            "step": initial_step,
            "progress": initial_progress,
            "retry_count": 0,
            "created_at": now,
            "updated_at": now,
        }
        columns = ", ".join(payload)
        placeholders = ", ".join("?" for _ in payload)
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                f"INSERT INTO orders ({columns}) VALUES ({placeholders})",
                tuple(payload.values()),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM orders WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    @staticmethod
    def _new_card_key() -> str:
        return f"XYK-{secrets.token_hex(12).upper()}"

    def get_order_by_id(self, order_id: int) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        return dict(row) if row else None

    def get_order(self, order_key: str, api_key_hash: str) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT * FROM orders WHERE order_key = ? AND api_key_hash = ?",
                (order_key, api_key_hash),
            ).fetchone()
        return dict(row) if row else None

    def get_order_by_key(self, order_key: str) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute("SELECT * FROM orders WHERE order_key = ?", (order_key,)).fetchone()
        return dict(row) if row else None

    def get_order_by_provider_ref(self, provider: str, provider_ref: str) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT * FROM orders WHERE provider = ? AND provider_ref = ? ORDER BY id DESC LIMIT 1",
                (provider, provider_ref),
            ).fetchone()
        return dict(row) if row else None

    def add_order_event(
        self,
        order_id: int,
        stage: str,
        message: str,
        elapsed_ms: int = 0,
    ) -> None:
        normalized_stage = str(stage or "event").strip()[:80] or "event"
        normalized_message = str(message or "").strip()[:500]
        elapsed = max(0, int(elapsed_ms or 0))
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO order_events(order_id, stage, message, elapsed_ms, created_at) "
                "VALUES (?, ?, ?, ?, ?)",
                (
                    int(order_id),
                    normalized_stage,
                    normalized_message,
                    elapsed,
                    utc_now(),
                ),
            )
            conn.execute(
                "DELETE FROM order_events WHERE order_id = ? AND id NOT IN ("
                "SELECT id FROM order_events WHERE order_id = ? ORDER BY id DESC LIMIT 100)",
                (int(order_id), int(order_id)),
            )
            conn.commit()

    def order_events(self, order_id: int) -> list[dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT stage, message, elapsed_ms, created_at "
                "FROM order_events WHERE order_id = ? ORDER BY id",
                (int(order_id),),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_orders(
        self,
        api_key_hash: str,
        page: int,
        page_size: int,
    ) -> tuple[list[dict[str, Any]], int]:
        offset = (page - 1) * page_size
        with closing(self._connect()) as conn:
            total = conn.execute(
                "SELECT COUNT(*) FROM orders WHERE api_key_hash = ?",
                (api_key_hash,),
            ).fetchone()[0]
            rows = conn.execute(
                "SELECT * FROM orders WHERE api_key_hash = ? "
                "ORDER BY id DESC LIMIT ? OFFSET ?",
                (api_key_hash, page_size, offset),
            ).fetchall()
        return [dict(row) for row in rows], int(total)

    def update_order(self, order_id: int, **values: Any) -> dict[str, Any] | None:
        invalid = set(values) - ORDER_COLUMNS
        if invalid:
            raise ValueError(f"unsupported order columns: {sorted(invalid)}")
        if not values:
            return self.get_order_by_id(order_id)
        values.setdefault("updated_at", utc_now())
        assignments = ", ".join(f"{column} = ?" for column in values)
        with closing(self._connect()) as conn:
            conn.execute(
                f"UPDATE orders SET {assignments} WHERE id = ?",
                (*values.values(), order_id),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        return dict(row) if row else None

    def retry_order(self, order_id: int) -> dict[str, Any] | None:
        now = utc_now()
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                "UPDATE orders SET status = 'queued', step = 'queued', progress = 0, "
                "retry_count = retry_count + 1, confirmation_ref = NULL, error_code = NULL, "
                "error_message = NULL, completed_at = NULL, payment_action_url = NULL, "
                "payment_action_type = NULL, payment_action_payload = NULL, updated_at = ? "
                "WHERE id = ? AND status = 'failed'",
                (now, order_id),
            )
            conn.commit()
            if cursor.rowcount != 1:
                return None
            row = conn.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        return dict(row)

    def recover_incomplete(self) -> list[int]:
        now = utc_now()
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE orders SET status = 'queued', step = 'queued', progress = 0, "
                "updated_at = ? WHERE status IN ('queued', 'running') AND provider = 'sandbox'",
                (now,),
            )
            conn.execute(
                "UPDATE orders SET status = 'awaiting_payment', "
                "step = CASE WHEN step = 'verify_result' "
                "AND payment_terminal_status = 'succeeded' THEN 'verify_result' "
                "ELSE 'confirm_payment' END, "
                "progress = CASE WHEN step = 'verify_result' "
                "AND payment_terminal_status = 'succeeded' THEN 90 ELSE 70 END, "
                "error_code = CASE WHEN step = 'verify_result' "
                "AND payment_terminal_status = 'succeeded' THEN 'subscription_pending' "
                "ELSE 'payment_recovery_required' END, "
                "error_message = CASE WHEN step = 'verify_result' "
                "AND payment_terminal_status = 'succeeded' "
                "THEN '服务在订阅核验时重启；等待使用原账号 Session 继续核验 Plus' "
                "ELSE '服务在支付确认时重启；订单已冻结，等待使用原账号 Session 核验，禁止重复扣款' END, "
                "completed_at = NULL, updated_at = ? "
                "WHERE status IN ('queued', 'running') AND provider IN ('platform_checkout', 'stripe')",
                (now,),
            )
            rows = conn.execute(
                "SELECT id FROM orders WHERE status = 'queued' AND provider = 'sandbox' ORDER BY id"
            ).fetchall()
            conn.commit()
        return [int(row[0]) for row in rows]

    def stats(self) -> dict[str, int]:
        result = {"total": 0, "queued": 0, "running": 0, "awaiting_payment": 0, "succeeded": 0, "failed": 0}
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT status, COUNT(*) AS count FROM orders GROUP BY status"
            ).fetchall()
        for row in rows:
            result[str(row["status"])] = int(row["count"])
            result["total"] += int(row["count"])
        return result

    def pending_renewal_orders(self) -> list[dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT * FROM orders WHERE renewal_cancel_requested = 1 "
                "AND renewal_cancel_status IN ('pending', 'running') "
                "AND status IN ('queued', 'running', 'awaiting_payment', 'succeeded') ORDER BY id"
            ).fetchall()
        return [dict(row) for row in rows]

    def pending_checkout_recoveries(self, now: str, max_attempts: int) -> list[dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT * FROM orders WHERE provider = 'platform_checkout' "
                "AND status = 'awaiting_payment' "
                "AND error_code IN ("
                "'subscription_pending', 'auth_refresh_required', 'payment_terminal_unverified', "
                "'payment_recovery_required', 'payment_confirmation_required', "
                "'checkout_session_confirmation_required', 'stripe_action_required', "
                "'payment_processing') "
                "AND COALESCE(recovery_attempts, 0) < ? "
                "AND (recovery_next_at IS NULL OR recovery_next_at <= ?) ORDER BY id",
                (max_attempts, now),
            ).fetchall()
        return [dict(row) for row in rows]

    def proxy_configurations(self) -> dict[str, dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT role, proxies, created_at, updated_at "
                "FROM proxy_configurations ORDER BY role"
            ).fetchall()
        return {str(row["role"]): dict(row) for row in rows}

    def save_proxy_configuration(
        self,
        role: str,
        proxies: str,
    ) -> dict[str, Any]:
        if role not in {"platform", "stripe"}:
            raise ValueError("invalid proxy role")
        now = utc_now()
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO proxy_configurations(role, proxies, created_at, updated_at) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(role) DO UPDATE SET "
                "proxies = excluded.proxies, updated_at = excluded.updated_at",
                (role, proxies, now, now),
            )
            conn.commit()
            row = conn.execute(
                "SELECT role, proxies, created_at, updated_at "
                "FROM proxy_configurations WHERE role = ?",
                (role,),
            ).fetchone()
        return dict(row)

    def billing_configuration(self) -> dict[str, Any]:
        default_url = "https://address-api.example.com/api/v1/address?country_code=us&area_code=DE"
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT source, address_api_url, created_at, updated_at "
                "FROM billing_configuration WHERE id = 1"
            ).fetchone()
            if row is None:
                now = utc_now()
                conn.execute(
                    "INSERT INTO billing_configuration"
                    "(id, source, address_api_url, created_at, updated_at) "
                    "VALUES (1, 'billing_profiles_json', ?, ?, ?)",
                    (default_url, now, now),
                )
                conn.commit()
                row = conn.execute(
                    "SELECT source, address_api_url, created_at, updated_at "
                    "FROM billing_configuration WHERE id = 1"
                ).fetchone()
        return dict(row)

    def save_billing_configuration(
        self,
        source: str,
        address_api_url: str,
    ) -> dict[str, Any]:
        if source not in {"billing_profiles_json", "remote_address_api"}:
            raise ValueError("invalid billing source")
        now = utc_now()
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO billing_configuration"
                "(id, source, address_api_url, created_at, updated_at) "
                "VALUES (1, ?, ?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET source = excluded.source, "
                "address_api_url = excluded.address_api_url, updated_at = excluded.updated_at",
                (source, address_api_url, now, now),
            )
            conn.commit()
            row = conn.execute(
                "SELECT source, address_api_url, created_at, updated_at "
                "FROM billing_configuration WHERE id = 1"
            ).fetchone()
        return dict(row)

    def admin_count(self) -> int:
        with closing(self._connect()) as conn:
            return int(conn.execute("SELECT COUNT(*) FROM admin_users").fetchone()[0])

    def create_admin(self, username: str, password_hash: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO admin_users(username, password_hash, created_at) VALUES (?, ?, ?)",
                (username, password_hash, time.time()),
            )
            conn.commit()

    def get_admin(self, username: str) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute("SELECT * FROM admin_users WHERE username = ?", (username,)).fetchone()
        return dict(row) if row else None

    def create_admin_session(self, token_hash_value: str, username: str, ttl_seconds: int) -> None:
        now = time.time()
        with closing(self._connect()) as conn:
            conn.execute(
                "INSERT INTO admin_sessions(token_hash, username, created_at, expires_at) VALUES (?, ?, ?, ?)",
                (token_hash_value, username, now, now + ttl_seconds),
            )
            conn.commit()

    def lookup_admin_session(self, token_hash_value: str) -> str | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT username, expires_at FROM admin_sessions WHERE token_hash = ?",
                (token_hash_value,),
            ).fetchone()
        if not row:
            return None
        if time.time() >= float(row["expires_at"]):
            self.delete_admin_session(token_hash_value)
            return None
        return str(row["username"])

    def delete_admin_session(self, token_hash_value: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute("DELETE FROM admin_sessions WHERE token_hash = ?", (token_hash_value,))
            conn.commit()

    def create_api_key(self, key_hash: str, key_prefix: str, label: str) -> dict[str, Any]:
        now = time.time()
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                "INSERT INTO api_keys(key_hash, key_prefix, label, created_at) VALUES (?, ?, ?, ?)",
                (key_hash, key_prefix, label, now),
            )
            conn.commit()
            row = conn.execute("SELECT * FROM api_keys WHERE id = ?", (cursor.lastrowid,)).fetchone()
        return dict(row)

    def get_active_api_key(self, key_hash: str) -> dict[str, Any] | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT * FROM api_keys WHERE key_hash = ? AND status = 'active'",
                (key_hash,),
            ).fetchone()
        return dict(row) if row else None

    def touch_api_key(self, key_hash: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute("UPDATE api_keys SET last_used_at = ? WHERE key_hash = ?", (time.time(), key_hash))
            conn.commit()

    def list_api_keys(self) -> list[dict[str, Any]]:
        with closing(self._connect()) as conn:
            rows = conn.execute("SELECT * FROM api_keys ORDER BY id DESC").fetchall()
        return [dict(row) for row in rows]

    def revoke_api_key(self, key_id: int) -> bool:
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                "UPDATE api_keys SET status = 'revoked', revoked_at = ? WHERE id = ? AND status = 'active'",
                (time.time(), key_id),
            )
            conn.commit()
        return cursor.rowcount == 1
