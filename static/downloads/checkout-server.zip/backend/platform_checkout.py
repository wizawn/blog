from __future__ import annotations

import base64
import hashlib
import json
import re
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from .proxy_pool import ProxyPool, mask_proxy


class CheckoutError(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        proxy_retry_safe: bool = True,
        action_required: str = "",
        checkout_link: str = "",
        checkout_id: str = "",
        processor_entity: str = "",
        stage: str = "",
        code: str = "",
        action_details: dict[str, Any] | None = None,
        renewal_session: Any = None,
    ):
        super().__init__(message)
        self.proxy_retry_safe = bool(proxy_retry_safe)
        self.action_required = str(action_required or "").strip()
        self.checkout_link = str(checkout_link or "").strip()
        self.checkout_id = str(checkout_id or "").strip()
        self.processor_entity = str(processor_entity or "").strip()
        self.stage = str(stage or "").strip()
        self.code = str(code or "").strip()
        self.action_details = dict(action_details or {})
        self.renewal_session = renewal_session


PLATFORM_CHECKOUT_REGIONS: tuple[dict[str, str], ...] = (
    {"code": "PH", "name": "Philippines", "currency": "PHP"},
    {"code": "US", "name": "United States", "currency": "USD"},
    {"code": "CA", "name": "Canada", "currency": "CAD"},
    {"code": "GB", "name": "United Kingdom", "currency": "GBP"},
    {"code": "AU", "name": "Australia", "currency": "AUD"},
    {"code": "NZ", "name": "New Zealand", "currency": "NZD"},
    {"code": "SG", "name": "Singapore", "currency": "SGD"},
    {"code": "HK", "name": "Hong Kong", "currency": "HKD"},
    {"code": "JP", "name": "Japan", "currency": "JPY"},
    {"code": "DE", "name": "Germany", "currency": "EUR"},
    {"code": "FR", "name": "France", "currency": "EUR"},
    {"code": "IE", "name": "Ireland", "currency": "EUR"},
)
PLATFORM_CHECKOUT_PLAN_NAMES: dict[str, str] = {
    "plus": "basic_plan",
    "pro5": "standard_plan",
    "pro20": "premium_plan",
}
PLATFORM_CHECKOUT_PLAN_ALIASES: dict[str, frozenset[str]] = {
    "plus": frozenset({"plus", "platformplus", "platform_plus", "basic_plan"}),
    "pro5": frozenset({"pro5", "pro5x", "pro_5x", "gptpro5x", "prolite", "standard_plan"}),
    "pro20": frozenset({"pro20", "pro20x", "pro_20x", "gptpro20x", "pro", "premium_plan"}),
}
_PLATFORM_CHECKOUT_REGION_MAP = {
    item["code"]: item for item in PLATFORM_CHECKOUT_REGIONS
}


def checkout_plan_name(plan_type: Any) -> str:
    value = str(plan_type or "plus").strip().lower()
    try:
        return PLATFORM_CHECKOUT_PLAN_NAMES[value]
    except KeyError as exc:
        raise CheckoutError("Platform Checkout plan is not supported") from exc


def subscription_matches_plan(plan_type: Any, subscription_plan: Any) -> bool:
    target = str(plan_type or "plus").strip().lower()
    observed = str(subscription_plan or "").strip().lower()
    return observed in PLATFORM_CHECKOUT_PLAN_ALIASES.get(target, frozenset())


def _checkout_terminal_state(payload: Any) -> str:
    if not isinstance(payload, dict):
        return "unknown"
    candidates = [
        payload.get("state"),
        payload.get("status"),
        payload.get("checkout_status"),
        payload.get("payment_status"),
        payload.get("payment_object_status"),
    ]
    for key in ("submission_attempt", "payment_intent", "setup_intent"):
        nested = payload.get(key)
        if isinstance(nested, dict):
            candidates.extend((nested.get("state"), nested.get("status")))
    normalized = [str(item or "").strip().lower() for item in candidates if item]
    for state in normalized:
        if state in {"failed", "expired", "canceled", "cancelled", "requires_payment_method"}:
            return state
    for state in normalized:
        if state in {"succeeded", "complete", "completed", "paid", "active"}:
            return "succeeded"
    return normalized[0] if normalized else "unknown"


class _DomainProxySession:
    """Route Platform and Stripe hosts through independent proxy exits."""

    _STRIPE_SUFFIXES = ("stripe.com", "stripe.network", "stripecdn.com")

    def __init__(self, session: Any, platform_proxy: str, stripe_proxy: str):
        self._session = session
        self.platform_proxy = str(platform_proxy or "").strip()
        self.stripe_proxy = str(stripe_proxy or "").strip()

    @classmethod
    def _is_stripe_url(cls, url: Any) -> bool:
        hostname = str(urlsplit(str(url or "")).hostname or "").lower()
        return any(hostname == suffix or hostname.endswith(f".{suffix}") for suffix in cls._STRIPE_SUFFIXES)

    def _call(self, method: str, url: Any, *args: Any, **kwargs: Any) -> Any:
        proxy = self.stripe_proxy if self._is_stripe_url(url) else self.platform_proxy
        if proxy:
            kwargs["proxies"] = {"http": proxy, "https": proxy}
            kwargs.pop("proxy", None)
        return getattr(self._session, method)(url, *args, **kwargs)

    def get(self, url: Any, *args: Any, **kwargs: Any) -> Any:
        return self._call("get", url, *args, **kwargs)

    def post(self, url: Any, *args: Any, **kwargs: Any) -> Any:
        return self._call("post", url, *args, **kwargs)

    def request(self, method: str, url: Any, *args: Any, **kwargs: Any) -> Any:
        proxy = self.stripe_proxy if self._is_stripe_url(url) else self.platform_proxy
        if proxy:
            kwargs["proxies"] = {"http": proxy, "https": proxy}
            kwargs.pop("proxy", None)
        return self._session.request(method, url, *args, **kwargs)

    def close(self) -> None:
        close = getattr(self._session, "close", None)
        if callable(close):
            close()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._session, name)


class PlatformCheckoutAdapter:
    """Adapter for the Platform Checkout contract used by the local fixture."""

    def __init__(
        self,
        project_root: Path,
        timeout: int = 90,
        *,
        country: str = "PH",
        currency: str = "PHP",
        billing_country: str = "US",
        proxy_pool: ProxyPool | None = None,
        stripe_proxy_pool: ProxyPool | None = None,
        require_proxy: bool = False,
        require_stripe_proxy: bool = False,
        stripe_bootstrap_cache_ttl: float = 60.0,
        stripe_browser_runner_url: str = "http://127.0.0.1:5602/static/stripe-runner.html",
        stripe_browser_executable: str = "",
        confirmation_token_mode: str = "dual",
    ):
        self.project_root = Path(project_root)
        self.timeout = max(30, min(300, int(timeout)))
        self.country = str(country or "PH").upper()
        self.currency = str(currency or "PHP").upper()
        self.billing_country = str(billing_country or "US").upper()
        self.proxy_pool = proxy_pool or ProxyPool()
        self.stripe_proxy_pool = stripe_proxy_pool or ProxyPool()
        self.require_proxy = bool(require_proxy)
        self.require_stripe_proxy = bool(require_stripe_proxy)
        self.stripe_browser_runner_url = str(stripe_browser_runner_url or "").strip()
        self.stripe_browser_executable = str(stripe_browser_executable or "").strip()
        mode = str(confirmation_token_mode or "dual").strip().lower()
        self.confirmation_token_mode = mode if mode in {"dual", "raw", "browser"} else "dual"
        self.stripe_bootstrap_cache_ttl = max(
            0.0, min(300.0, float(stripe_bootstrap_cache_ttl))
        )
        self._checkout_proxies: dict[str, str] = {}
        self._checkout_stripe_proxies: dict[str, str] = {}
        self._proxy_lock = threading.Lock()
        self._stripe_bootstrap_cache: dict[str, tuple[float, dict[str, str]]] = {}
        self._stripe_bootstrap_cache_lock = threading.Lock()
        # Preflight and charge are separate HTTP requests. Keep only short-lived
        # browser/runtime metadata between them; card data and payment objects
        # never enter this cache.
        self._checkout_runtime_cache: dict[
            str, tuple[float, str, str, dict[str, str]]
        ] = {}
        self._checkout_runtime_cache_lock = threading.Lock()
        self._checkout_http_sessions: dict[
            str, tuple[float, str, str, str, str, Any]
        ] = {}
        self._checkout_http_sessions_lock = threading.Lock()
        self.checkout_runtime_cache_ttl = 45.0
        self._module: Any = None
        self._stripe_runtime_cache: dict[str, str] | None = None
        self._stripe_runtime_mtime_ns: int = -1
        self._stripe_runtime_lock = threading.Lock()

    @property
    def enabled(self) -> bool:
        try:
            self._load()
            return True
        except CheckoutError:
            return False

    @property
    def proxy_configured(self) -> bool:
        return self.proxy_pool.configured and (
            self.stripe_proxy_pool.configured or not self.require_stripe_proxy
        )

    @property
    def proxy_rotation(self) -> str:
        return self.proxy_pool.rotation

    def proxy_status(self) -> dict[str, Any]:
        platform = self.proxy_pool.status()
        stripe = self.stripe_proxy_pool.status()
        configured = platform["configured"] and (stripe["configured"] or not self.require_stripe_proxy)
        return {
            "configured": configured,
            "count": int(platform.get("count") or 0) + int(stripe.get("count") or 0),
            "rotation": "domain_split",
            "countries": sorted(set(platform.get("countries") or []) | set(stripe.get("countries") or [])),
            "lifetimes": sorted(set(platform.get("lifetimes") or []) | set(stripe.get("lifetimes") or [])),
            "proxies": platform.get("proxies") or [],
            "split": True,
            "platform": {**platform, "required": self.require_proxy},
            "stripe": {**stripe, "required": self.require_stripe_proxy},
        }

    def configure_proxy(
        self,
        values: Any,
        *,
        role: str = "both",
    ) -> dict[str, Any]:
        try:
            normalized_role = str(role or "both").strip().lower()
            if normalized_role not in {"platform", "stripe", "both"}:
                raise ValueError("代理角色必须是 platform 或 stripe")
            source = values if isinstance(values, (str, list)) else ""
            if normalized_role in {"platform", "both"}:
                self.proxy_pool.replace(source)
            if normalized_role in {"stripe", "both"}:
                self.stripe_proxy_pool.replace(source)
            return self.proxy_status()
        except ValueError as exc:
            raise CheckoutError(str(exc)) from exc

    def probe_proxy(self) -> dict[str, Any]:
        platform = self.proxy_pool.probe(("platform",))
        stripe = self.stripe_proxy_pool.probe(("stripe",))
        targets = {
            "platform": (platform.get("targets") or {}).get("platform", {"ok": False}),
            "stripe": (stripe.get("targets") or {}).get("stripe", {"ok": False}),
        }
        ok = bool(platform.get("ok") and stripe.get("ok"))
        errors = []
        if not platform.get("ok"):
            errors.append(f"Platform 代理：{platform.get('error') or '不可达'}")
        if not stripe.get("ok"):
            errors.append(f"Stripe 代理：{stripe.get('error') or '不可达'}")
        return {
            "ok": ok,
            "targets": targets,
            "routes": {
                "platform": platform,
                "stripe": stripe,
            },
            "error": "；".join(errors)[:500],
        }

    def _load(self) -> Any:
        if self._module is not None:
            return self._module
        try:
            from .vendor import card_payment
        except Exception as exc:  # pragma: no cover - depends on local install
            raise CheckoutError(f"Checkout Server 核心加载失败: {exc}") from exc
        self._module = card_payment
        return self._module

    @staticmethod
    def _session_data(value: Any) -> dict[str, Any]:
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError as exc:
                raise CheckoutError("Session JSON 格式错误") from exc
        if not isinstance(value, dict):
            raise CheckoutError("Session 必须是 JSON 对象")
        return value

    @classmethod
    def _token_and_account(
        cls,
        value: Any,
        fallback_account_id: str = "",
        *,
        require_account: bool = True,
    ) -> tuple[str, str]:
        data = cls._session_data(value)
        token = str(data.get("accessToken") or data.get("access_token") or "").strip()
        if not token:
            raise CheckoutError("Session 缺少 accessToken")
        parts = token.split(".")
        claims: dict[str, Any] = {}
        if len(parts) >= 2:
            try:
                raw = parts[1] + "=" * (-len(parts[1]) % 4)
                decoded = json.loads(base64.urlsafe_b64decode(raw.encode("ascii")))
                if isinstance(decoded, dict):
                    claims = decoded
            except (ValueError, TypeError, UnicodeDecodeError, json.JSONDecodeError):
                pass
        auth = claims.get("https://api.vendor.com/auth")
        account = ""
        if isinstance(auth, dict):
            account = str(auth.get("platform_account_id") or auth.get("account_id") or "").strip()
        account = account or str(
            claims.get("platform_account_id")
            or claims.get("account_id")
            or data.get("account_id")
            or data.get("accountId")
            or fallback_account_id
            or ""
        ).strip()
        if not account and require_account:
            raise CheckoutError("Session 缺少 Platform account_id")
        return token, account

    @staticmethod
    def _account_snapshot(http_session: Any, module: Any, timeout: int) -> dict[str, Any]:
        """Read account identity and subscription state before Checkout creation."""
        response = module._get_app(
            http_session,
            f"{module.APP_BASE}/api/v1/accounts/check/v4-2023-04-27",
            params={"timezone_offset_min": -480},
            referer=f"{module.APP_BASE}/",
            route="/api/v1/accounts/check/v4-2023-04-27",
            timeout=timeout,
        )
        status = int(getattr(response, "status_code", 0) or 0)
        if status == 401:
            raise CheckoutError("Session accessToken expired")
        if status >= 400:
            raise CheckoutError(f"Platform account check failed: HTTP {status}")
        payload = module._response_json(response)
        accounts = payload.get("accounts") if isinstance(payload, dict) else None
        candidates: list[Any] = []
        if isinstance(accounts, dict):
            if isinstance(accounts.get("default"), dict):
                candidates.append(accounts["default"])
            candidates.extend(value for value in accounts.values() if isinstance(value, dict))
        elif isinstance(accounts, list):
            candidates.extend(value for value in accounts if isinstance(value, dict))
        session_headers = getattr(http_session, "headers", {}) or {}
        requested_account_id = str(
            session_headers.get("platform-account-id")
            or session_headers.get("Platform-Account-Id")
            or ""
        ).strip()
        selected_item: dict[str, Any] = {}
        selected_account: dict[str, Any] = {}
        account_id = ""
        for item in candidates:
            account = item.get("account") if isinstance(item.get("account"), dict) else item
            candidate_id = str(
                account.get("account_id") or account.get("id") or item.get("account_id") or ""
            ).strip()
            if candidate_id and requested_account_id and candidate_id == requested_account_id:
                account_id = candidate_id
                selected_item = item
                selected_account = account
                break
            if candidate_id and not account_id:
                account_id = candidate_id
                selected_item = item
                selected_account = account
        account_id = account_id or str(
            module._find_key(payload, ("account_id", "accountId")) or ""
        ).strip()
        if not account_id:
            raise CheckoutError("Platform account check returned no account_id")

        def bool_value(value: Any) -> bool:
            if isinstance(value, bool):
                return value
            return str(value or "").strip().lower() in {"1", "true", "yes", "active"}

        selected_payload: Any = {
            "item": selected_item,
            "account": selected_account,
        } if selected_item or selected_account else {}

        def account_value(names: tuple[str, ...]) -> Any:
            value = module._find_key(selected_payload, names) if selected_payload else ""
            if value is None or str(value).strip() == "":
                value = module._find_key(payload, names)
            return value

        return {
            "account_id": account_id,
            "plan_type": account_value(("plan_type", "planType")),
            "subscription_plan": account_value(
                ("subscription_plan", "subscriptionPlan")
            ),
            "has_active_subscription": bool_value(
                account_value(("has_active_subscription", "hasActiveSubscription"))
            ),
            "is_grace_period": bool_value(
                account_value(("is_grace_period", "isGracePeriod"))
            ),
            "is_delinquent": bool_value(
                account_value(("is_delinquent", "isDelinquent"))
            ),
            "billing_currency": account_value(
                ("billing_currency", "billingCurrency")
            ),
            "billing_period": account_value(("billing_period", "billingPeriod")),
            "purchase_origin_platform": account_value(
                ("purchase_origin_platform", "purchaseOriginPlatform")
            ),
            "will_renew": account_value(("will_renew", "willRenew")),
            "renews_at": account_value(("renews_at", "renewsAt")),
            "cancels_at": account_value(("cancels_at", "cancelsAt")),
            "expires_at": account_value(("expires_at", "expiresAt")),
            "processor": account_value(
                ("processor", "processor_entity", "processorEntity")
            ),
        }

    @staticmethod
    def _select_checkout_mode(
        currency: Any,
        billing_currency: Any,
    ) -> tuple[str, str]:
        """Choose custom unless a known historical currency conflicts."""
        requested = str(currency or "").strip().lower()
        historical = str(billing_currency or "").strip().lower()
        if not historical:
            return "custom", "billing_currency_empty"
        if requested == historical:
            return "custom", "currency_matched"
        return "hosted", "currency_mismatched"

    @staticmethod
    def _is_currency_incompatible_error(value: Any) -> bool:
        text = re.sub(r"[_\s-]+", " ", str(value or "").strip().lower())
        return any(
            marker in text
            for marker in (
                "currency incompatible",
                "cannot combine currencies",
                "currency mismatch",
            )
        )

    @staticmethod
    def _resolve_account_id(http_session: Any, module: Any, timeout: int) -> str:
        response = module._get_app(
            http_session,
            f"{module.APP_BASE}/api/v1/accounts/check/v4-2023-04-27",
            params={"timezone_offset_min": -480},
            referer=f"{module.APP_BASE}/",
            route="/api/v1/accounts/check/v4-2023-04-27",
            timeout=timeout,
        )
        status = int(getattr(response, "status_code", 0) or 0)
        if status == 401:
            raise CheckoutError("Session accessToken 已失效")
        if status >= 400:
            raise CheckoutError(f"Platform account_id 自动解析失败：HTTP {status}")
        payload = module._response_json(response)
        accounts = payload.get("accounts") if isinstance(payload, dict) else None
        candidates: list[Any] = []
        if isinstance(accounts, dict):
            if isinstance(accounts.get("default"), dict):
                candidates.append(accounts["default"])
            candidates.extend(value for value in accounts.values() if isinstance(value, dict))
        elif isinstance(accounts, list):
            candidates.extend(value for value in accounts if isinstance(value, dict))
        for item in candidates:
            account = item.get("account") if isinstance(item.get("account"), dict) else item
            account_id = str(
                account.get("account_id") or account.get("id") or item.get("account_id") or ""
            ).strip()
            if account_id:
                return account_id
        raise CheckoutError("Platform account_id 自动解析没有返回可用账号")

    @classmethod
    def _sentinel_token(cls, value: Any) -> str:
        return cls._sentinel_context(value)[0]

    @classmethod
    def _sentinel_context(cls, value: Any) -> tuple[str, str]:
        data = cls._session_data(value)
        raw_headers = data.get("headers") if isinstance(data.get("headers"), dict) else {}
        headers = {
            str(key).lower(): str(item or "").strip()
            for key, item in raw_headers.items()
        }
        nested = data.get("checkoutContext") or data.get("checkout_context")
        nested = nested if isinstance(nested, dict) else {}
        nested_headers = (
            nested.get("headers") if isinstance(nested.get("headers"), dict) else {}
        )
        nested_headers = {
            str(key).lower(): str(item or "").strip()
            for key, item in nested_headers.items()
        }
        token = str(
            data.get("challengeSolverToken")
            or data.get("challenge_solver_token")
            or data.get("sentinelToken")
            or data.get("checkoutSentinelToken")
            or data.get("checkout_sentinel_token")
            or nested.get("challengeSolverToken")
            or nested.get("challenge_solver_token")
            or nested.get("sentinelToken")
            or nested_headers.get("x-vendor-challenge-token")
            or headers.get("x-vendor-challenge-token")
            or ""
        ).strip()
        telemetry = str(
            data.get("vendorTelemetry")
            or data.get("vendor_telemetry")
            or data.get("telemetry")
            or data.get("checkoutTelemetry")
            or data.get("checkout_telemetry")
            or nested.get("vendorTelemetry")
            or nested.get("vendor_telemetry")
            or nested.get("telemetry")
            or nested_headers.get("x-vendor-telemetry")
            or headers.get("x-vendor-telemetry")
            or ""
        ).strip()
        return token, telemetry

    @classmethod
    def _normalize_fingerprint_profile(cls, value: Any) -> dict[str, str]:
        raw: Any = value
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except (TypeError, ValueError):
                raw = {}
        if isinstance(raw, dict) and isinstance(raw.get("profile"), (dict, str)):
            nested = raw.get("profile")
            if isinstance(nested, str):
                try:
                    nested = json.loads(nested)
                except (TypeError, ValueError):
                    nested = {}
            raw = nested
        if not isinstance(raw, dict):
            return {}

        def first_text(*items: Any) -> str:
            for item in items:
                if item is None:
                    continue
                text = str(item).strip()
                if text:
                    return text
            return ""

        aliases = {
            "ua": ("ua", "user_agent"),
            "major": ("major", "chrome_major", "browser_major"),
            "full": ("full", "chrome_full_version", "browser_full_version"),
            "platform": ("platform", "platform_os", "platform_name"),
            "platform_version": ("platform_version",),
            "arch": ("arch", "architecture"),
            "bitness": ("bitness",),
            "sec_ch_ua": ("sec_ch_ua",),
            "sec_ch_ua_full_version_list": ("sec_ch_ua_full_version_list",),
            "accept_language": ("accept_language", "locale"),
            "oai_language": ("oai_language", "language"),
            "tls_impersonate": ("tls_impersonate", "tls_client_identifier"),
            "timezone": ("timezone", "timezone_id"),
        }
        normalized: dict[str, str] = {}
        for target, names in aliases.items():
            value_text = first_text(*(raw.get(name) for name in names))
            if value_text:
                normalized[target] = value_text
        mobile = raw.get("mobile")
        if mobile is not None:
            normalized["mobile"] = "?1" if bool(mobile) else "?0"
        return normalized

    @classmethod
    def _session_runtime_context(
        cls,
        value: Any,
        token: str,
        account_id: str,
    ) -> dict[str, Any]:
        data = cls._session_data(value) if value is not None else {}
        raw_headers = data.get("headers") if isinstance(data.get("headers"), dict) else {}
        headers = {str(key).lower(): str(item or "").strip() for key, item in raw_headers.items()}
        nested_context = data.get("checkoutContext") or data.get("checkout_context")
        nested_context = nested_context if isinstance(nested_context, dict) else {}
        nested_headers = (
            nested_context.get("headers")
            if isinstance(nested_context.get("headers"), dict)
            else {}
        )
        nested_headers = {
            str(key).lower(): str(item or "").strip()
            for key, item in nested_headers.items()
        }
        raw_cookies = data.get("cookies")
        cookies: list[dict[str, str]] = []
        if isinstance(raw_cookies, list):
            cookies = [dict(item) for item in raw_cookies if isinstance(item, dict)]
        elif isinstance(raw_cookies, dict):
            cookies = [
                {"name": str(key), "value": str(item or "")}
                for key, item in raw_cookies.items()
                if str(key).strip()
            ]
        cookie_header = headers.get("cookie", "")
        if not cookie_header and isinstance(data.get("cookie"), str):
            cookie_header = str(data.get("cookie") or "").strip()
        if cookie_header:
            existing = {str(item.get("name") or "") for item in cookies}
            for part in cookie_header.split(";"):
                name, separator, cookie_value = part.strip().partition("=")
                if separator and name and name not in existing:
                    cookies.append({"name": name, "value": cookie_value})
                    existing.add(name)

        cookie_values = {
            str(item.get("name") or "").strip(): str(item.get("value") or "").strip()
            for item in cookies
            if str(item.get("name") or "").strip()
            and str(item.get("value") or "").strip()
        }
        auth_cookie_bases = (
            "__Secure-platform.session-token",
            "next-auth.session-token",
            "__Secure-authjs.session-token",
            "authjs.session-token",
        )

        def joined_auth_cookie() -> str:
            for base in auth_cookie_bases:
                exact = cookie_values.get(base, "")
                if exact:
                    return exact
                chunks: list[tuple[int, str]] = []
                prefix = f"{base}."
                for name, cookie_value in cookie_values.items():
                    if not name.startswith(prefix):
                        continue
                    try:
                        index = int(name[len(prefix):])
                    except ValueError:
                        continue
                    chunks.append((index, cookie_value))
                if chunks:
                    chunks.sort(key=lambda item: item[0])
                    if [index for index, _value in chunks] == list(range(len(chunks))):
                        return "".join(value for _index, value in chunks)
            return ""

        def first_text(*items: Any) -> str:
            for item in items:
                text = str(item or "").strip()
                if text:
                    return text
            return ""

        session_token = first_text(
            data.get("sessionToken"),
            data.get("session_token"),
            data.get("sessionCookie"),
            data.get("session_cookie"),
            data.get("sessionToken(cookie)"),
            *(data.get(name) for name in auth_cookie_bases),
            joined_auth_cookie(),
        )
        device_id = first_text(
            data.get("vendorDeviceId"),
            data.get("vendor_device_id"),
            data.get("deviceId"),
            data.get("device_id"),
            headers.get("x-vendor-device-id"),
            next(
                (
                    item.get("value")
                    for item in cookies
                    if str(item.get("name") or "") in {"x-vendor-did", "x-vendor-device-id"}
                ),
                "",
            ),
        )
        if not device_id:
            stable_seed = account_id or hashlib.sha256(token.encode("utf-8")).hexdigest()
            device_id = str(uuid.uuid5(uuid.NAMESPACE_URL, f"checkout-server:{stable_seed}"))
        fingerprint = cls._normalize_fingerprint_profile(
            data.get("fingerprintProfile")
            or data.get("fingerprint_profile")
            or data.get("fingerprint")
            or {}
        )
        return {
            "session_token": session_token,
            "cookies": cookies,
            "device_id": device_id,
            "fingerprint_profile": dict(fingerprint),
            "client_build_number": first_text(
                data.get("clientBuildNumber"),
                data.get("client_build_number"),
                nested_context.get("clientBuildNumber"),
                nested_context.get("client_build_number"),
                nested_headers.get("x-vendor-client-build-number"),
                headers.get("x-vendor-client-build-number"),
            ),
            "client_version": first_text(
                data.get("clientVersion"),
                data.get("client_version"),
                nested_context.get("clientVersion"),
                nested_context.get("client_version"),
                nested_headers.get("x-vendor-client-version"),
                headers.get("x-vendor-client-version"),
            ),
            "vendor_session_id": first_text(
                data.get("vendorSessionId"),
                data.get("vendor_session_id"),
                nested_context.get("vendorSessionId"),
                nested_context.get("vendor_session_id"),
                nested_headers.get("x-vendor-session-id"),
                headers.get("x-vendor-session-id"),
            ),
            "web_deployment_attestation": first_text(
                data.get("webDeploymentAttestation"),
                data.get("web_deployment_attestation"),
                nested_context.get("webDeploymentAttestation"),
                nested_context.get("web_deployment_attestation"),
                nested_headers.get("x-vendor-web-deployment-attestation"),
                headers.get("x-vendor-web-deployment-attestation"),
            ),
        }

    @staticmethod
    def _apply_account_context(http_session: Any, account_id: str) -> None:
        headers = getattr(http_session, "headers", None)
        if headers is not None and str(account_id or "").strip():
            headers["platform-account-id"] = str(account_id).strip()

    @staticmethod
    def _amount_minor(module: Any, payload: dict[str, Any]) -> int | None:
        strict_reader = getattr(module, "_checkout_amount_minor", None)
        if callable(strict_reader):
            return strict_reader(payload)
        try:
            value = module._find_key(payload, ("amount_minor", "amountMinor"))
            if value:
                return int(value)
            value = module._find_key(payload, ("amount", "total", "amount_due_cents", "amount_due", "total_amount"))
            if value and re.fullmatch(r"\d+", str(value)):
                return int(value)
        except (TypeError, ValueError):
            return None
        return None

    def _config(self, module: Any, token: str, account_id: str, billing: dict[str, Any] | None = None, **kwargs: Any) -> Any:
        # Recovery only reads Checkout/Plus state and has no card/tax mutation;
        # do not make an old recovery record depend on a fresh billing profile.
        billing_data = self.normalize_billing(billing) if billing is not None else {}
        session_value = kwargs.pop("session_value", None)
        runtime_context = self._session_runtime_context(
            session_value, token, account_id
        ) if session_value is not None else {}
        config_country = str(kwargs.pop("country", self.country) or self.country).upper()
        config_currency = str(kwargs.pop("currency", self.currency) or self.currency).upper()
        runtime = self._stripe_runtime()
        kwargs.setdefault("stripe_runtime_version", runtime.get("version", ""))
        kwargs.setdefault("stripe_js_checksum", runtime.get("js_checksum", ""))
        kwargs.setdefault("stripe_rv_timestamp", runtime.get("rv_timestamp", ""))
        kwargs.setdefault("stripe_browser_runner_url", self.stripe_browser_runner_url)
        kwargs.setdefault("stripe_browser_executable", self.stripe_browser_executable)
        kwargs.setdefault("confirmation_token_mode", self.confirmation_token_mode)
        kwargs.setdefault("stripe_runtime_update", self._update_stripe_runtime)
        for key, value in runtime_context.items():
            kwargs.setdefault(key, value)
        return module.CardPaymentConfig(
            token=token,
            account_id=account_id,
            country=config_country,
            currency=config_currency,
            promo_campaign="",
            billing={str(key): str(value or "") for key, value in billing_data.items()},
            timeout=self.timeout,
            fast_verify=False,
            strong_bind_direct=False,
            **kwargs,
        )

    def _stripe_runtime(self) -> dict[str, str]:
        path = self.project_root / "config" / "stripe_runtime.json"
        try:
            mtime_ns = path.stat().st_mtime_ns
        except OSError:
            mtime_ns = -1
        if (
            self._stripe_runtime_cache is not None
            and mtime_ns == self._stripe_runtime_mtime_ns
        ):
            return dict(self._stripe_runtime_cache)
        runtime: dict[str, str] = {}
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            source = payload.get("runtime") if isinstance(payload, dict) else {}
            if isinstance(source, dict):
                runtime = {
                    key: str(source.get(key) or "").strip()
                    for key in ("version", "js_checksum", "rv_timestamp")
                }
        except (OSError, ValueError, TypeError):
            runtime = {}
        self._stripe_runtime_cache = runtime
        self._stripe_runtime_mtime_ns = mtime_ns
        return dict(runtime)

    def _update_stripe_runtime(self, values: dict[str, str]) -> None:
        """Atomically merge runtime hints captured before the payment mutation."""
        allowed = {"version", "js_checksum", "rv_timestamp"}
        updates = {
            key: str(value or "").strip()
            for key, value in dict(values or {}).items()
            if key in allowed and str(value or "").strip()
        }
        updates = {
            key: value
            for key, value in updates.items()
            if len(value) <= 4096 and "\n" not in value and "\r" not in value
        }
        if not updates:
            return
        path = self.project_root / "config" / "stripe_runtime.json"
        with self._stripe_runtime_lock:
            current = self._stripe_runtime()
            merged = {**current, **updates}
            if merged == current:
                return
            payload: dict[str, Any] = {}
            try:
                loaded = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    payload = loaded
            except (OSError, ValueError, TypeError):
                payload = {}
            payload["runtime"] = {
                key: merged.get(key, "")
                for key in ("version", "js_checksum", "rv_timestamp")
            }
            path.parent.mkdir(parents=True, exist_ok=True)
            temporary = path.with_suffix(path.suffix + ".tmp")
            temporary.write_text(
                json.dumps(payload, ensure_ascii=True, indent=2) + "\n",
                encoding="utf-8",
            )
            temporary.replace(path)
            self._stripe_runtime_cache = dict(merged)
            try:
                self._stripe_runtime_mtime_ns = path.stat().st_mtime_ns
            except OSError:
                self._stripe_runtime_mtime_ns = -1

    def _stripe_runtime_status(self) -> dict[str, Any]:
        runtime = self._stripe_runtime()
        try:
            from .stripe_browser import stripe_browser_runtime_status

            browser_runtime = stripe_browser_runtime_status()
        except Exception:
            browser_runtime = {
                "warm": False,
                "workerAlive": False,
                "completed": 0,
                "queueDepth": 0,
                "error": "",
            }
        fields = {
            "version": bool(runtime.get("version")),
            "jsChecksum": bool(runtime.get("js_checksum")),
            "rvTimestamp": bool(runtime.get("rv_timestamp")),
        }
        return {
            "configured": all(fields.values()),
            "source": "config/stripe_runtime.json",
            "fields": fields,
            "inlineApiReady": all(fields.values()),
            "browser": browser_runtime,
        }

    def normalize_billing(self, value: Any) -> dict[str, str]:
        source = value if isinstance(value, dict) else {}
        fields = {
            key: str(source.get(key) or "").strip()[:200]
            for key in ("name", "email", "line1", "city", "state", "postal_code", "country")
        }
        fields["country"] = (fields["country"] or self.billing_country).upper()
        required = {
            "name": "持卡人姓名",
            "email": "邮箱",
            "line1": "账单地址",
            "city": "城市",
            "state": "州",
            "postal_code": "邮编",
            "country": "国家/地区",
        }
        missing = [label for key, label in required.items() if not fields[key]]
        if missing:
            raise CheckoutError("账单信息缺少：" + "、".join(missing))
        if fields["country"] != self.billing_country:
            raise CheckoutError(f"账单国家必须是 {self.billing_country}")
        if not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+", fields["email"]):
            raise CheckoutError("账单邮箱格式无效")
        if not re.fullmatch(r"[A-Z]{2}", fields["country"]):
            raise CheckoutError("账单国家必须是两位国家代码")
        return {key: value for key, value in fields.items() if value}

    @staticmethod
    def normalize_card(value: Any) -> dict[str, str]:
        source = value if isinstance(value, dict) else {}
        number = re.sub(r"\D", "", str(source.get("number") or source.get("card_number") or ""))
        exp_month = re.sub(r"\D", "", str(source.get("expMonth") or source.get("exp_month") or source.get("month") or ""))
        exp_year = re.sub(r"\D", "", str(source.get("expYear") or source.get("exp_year") or source.get("year") or ""))
        cvc = re.sub(r"\D", "", str(source.get("cvc") or source.get("cvv") or ""))
        if len(exp_year) == 2:
            exp_year = f"20{exp_year}"
        if not re.fullmatch(r"\d{12,19}", number):
            raise CheckoutError("银行卡号必须为 12-19 位数字")
        if not re.fullmatch(r"\d{1,2}", exp_month) or not 1 <= int(exp_month) <= 12:
            raise CheckoutError("有效期月份必须为 01-12")
        if not re.fullmatch(r"\d{4}", exp_year):
            raise CheckoutError("有效期年份必须为 2 位或 4 位数字")
        now = datetime.now(timezone.utc)
        if int(exp_year) < now.year or (int(exp_year) == now.year and int(exp_month) < now.month):
            raise CheckoutError("银行卡有效期已过期")
        if not re.fullmatch(r"\d{3,4}", cvc):
            raise CheckoutError("CVC 必须为 3-4 位数字")
        return {
            "card_number": number,
            "exp_month": exp_month.zfill(2),
            "exp_year": exp_year,
            "cvc": cvc,
        }

    def _next_proxy(self) -> str:
        proxy = self.proxy_pool.next()
        if self.require_proxy and not proxy:
            raise CheckoutError("Platform Checkout 需要 Platform 工作代理")
        return proxy

    def _next_stripe_proxy(self) -> str:
        proxy = self.stripe_proxy_pool.next()
        if self.require_stripe_proxy and not proxy:
            raise CheckoutError("Platform Checkout 需要 Stripe API 工作代理")
        return proxy

    @staticmethod
    def _routed_session(
        module: Any,
        config: Any,
        platform_proxy: str,
        stripe_proxy: str,
    ) -> _DomainProxySession:
        return _DomainProxySession(
            module._new_session(config, platform_proxy),
            platform_proxy,
            stripe_proxy,
        )

    def _proxy_for_checkout(self, checkout_id: str) -> str:
        with self._proxy_lock:
            return self._checkout_proxies.get(checkout_id, "")

    def _stripe_proxy_for_checkout(self, checkout_id: str) -> str:
        with self._proxy_lock:
            return self._checkout_stripe_proxies.get(checkout_id, "")

    def _remember_proxy(self, checkout_id: str, proxy: str, stripe_proxy: str = "") -> None:
        if checkout_id and (proxy or stripe_proxy):
            with self._proxy_lock:
                if proxy:
                    self._checkout_proxies[checkout_id] = proxy
                if stripe_proxy:
                    self._checkout_stripe_proxies[checkout_id] = stripe_proxy

    @staticmethod
    def _token_fingerprint(token: str) -> str:
        return hashlib.sha256(str(token or "").encode("utf-8")).hexdigest()

    def _remember_checkout_runtime(
        self,
        checkout_id: str,
        token: str,
        account_id: str,
        config: Any,
    ) -> None:
        checkout_key = str(checkout_id or "").strip()
        token_key = self._token_fingerprint(token)
        if not checkout_key or not token_key:
            return
        values = {
            key: str(getattr(config, key, "") or "").strip()
            for key in (
                "client_build_number",
                "client_version",
                "vendor_session_id",
                "web_deployment_attestation",
                "sentinel_token",
                "telemetry",
            )
        }
        if not any(values.values()):
            return
        with self._checkout_runtime_cache_lock:
            self._checkout_runtime_cache[checkout_key] = (
                time.monotonic(),
                token_key,
                str(account_id or "").strip(),
                values,
            )

    def _checkout_runtime(
        self,
        checkout_id: str,
        token: str,
        account_id: str,
    ) -> dict[str, str]:
        checkout_key = str(checkout_id or "").strip()
        token_key = self._token_fingerprint(token)
        if not checkout_key or not token_key or self.checkout_runtime_cache_ttl <= 0:
            return {}
        now = time.monotonic()
        with self._checkout_runtime_cache_lock:
            expired = [
                key
                for key, (created_at, _token, _account, _values)
                in self._checkout_runtime_cache.items()
                if now - created_at >= self.checkout_runtime_cache_ttl
            ]
            for key in expired:
                self._checkout_runtime_cache.pop(key, None)
            entry = self._checkout_runtime_cache.get(checkout_key)
            if not entry:
                return {}
            _created_at, saved_token, saved_account, values = entry
            if saved_token != token_key:
                return {}
            if saved_account and str(account_id or "").strip() != saved_account:
                return {}
            return {**values, "_cache_hit": "1"}

    @staticmethod
    def _close_http_session(session: Any) -> None:
        close = getattr(session, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                pass

    def _remember_checkout_http_session(
        self,
        checkout_id: str,
        token: str,
        account_id: str,
        proxy: str,
        stripe_proxy: str,
        session: Any,
    ) -> None:
        checkout_key = str(checkout_id or "").strip()
        if not checkout_key or session is None:
            return
        now = time.monotonic()
        discarded: list[Any] = []
        with self._checkout_http_sessions_lock:
            for key, entry in list(self._checkout_http_sessions.items()):
                if now - entry[0] >= self.checkout_runtime_cache_ttl:
                    discarded.append(entry[-1])
                    self._checkout_http_sessions.pop(key, None)
            previous = self._checkout_http_sessions.pop(checkout_key, None)
            if previous:
                discarded.append(previous[-1])
            self._checkout_http_sessions[checkout_key] = (
                now,
                self._token_fingerprint(token),
                str(account_id or "").strip(),
                str(proxy or "").strip(),
                str(stripe_proxy or "").strip(),
                session,
            )
            while len(self._checkout_http_sessions) > 64:
                oldest_key = min(
                    self._checkout_http_sessions,
                    key=lambda key: self._checkout_http_sessions[key][0],
                )
                discarded.append(self._checkout_http_sessions.pop(oldest_key)[-1])
        for item in discarded:
            self._close_http_session(item)

    def _take_checkout_http_session(
        self,
        checkout_id: str,
        token: str,
        account_id: str,
        proxy: str,
        stripe_proxy: str,
    ) -> Any | None:
        checkout_key = str(checkout_id or "").strip()
        if not checkout_key:
            return None
        with self._checkout_http_sessions_lock:
            entry = self._checkout_http_sessions.pop(checkout_key, None)
        if not entry:
            return None
        created_at, saved_token, saved_account, saved_proxy, saved_stripe_proxy, session = entry
        valid = bool(
            time.monotonic() - created_at < self.checkout_runtime_cache_ttl
            and saved_token == self._token_fingerprint(token)
            and (not saved_account or saved_account == str(account_id or "").strip())
            and saved_proxy == str(proxy or "").strip()
            and saved_stripe_proxy == str(stripe_proxy or "").strip()
        )
        if valid:
            return session
        self._close_http_session(session)
        return None

    def _discard_checkout_http_session(self, checkout_id: str) -> None:
        checkout_key = str(checkout_id or "").strip()
        with self._checkout_http_sessions_lock:
            entry = self._checkout_http_sessions.pop(checkout_key, None)
        if entry:
            self._close_http_session(entry[-1])

    def _forget_proxy(self, checkout_id: str) -> None:
        with self._proxy_lock:
            self._checkout_proxies.pop(checkout_id, None)
            self._checkout_stripe_proxies.pop(checkout_id, None)

    def release_checkout_context(self, checkout_id: str) -> None:
        """Discard the in-memory proxy affinity after a terminal checkout state."""
        checkout_key = str(checkout_id or "").strip()
        self._forget_proxy(checkout_key)
        with self._checkout_runtime_cache_lock:
            self._checkout_runtime_cache.pop(checkout_key, None)
        self._discard_checkout_http_session(checkout_key)

    @staticmethod
    def _is_transport_error(error: Exception) -> bool:
        text = str(error).lower()
        return any(
            marker in text
            for marker in (
                "proxy", "connect", "connection", "timed out", "timeout",
                "tls", "ssl", "reset", "curl: (5)", "curl: (6)",
                "curl: (7)", "curl: (28)", "curl: (35)", "curl: (56)",
            )
        )

    @staticmethod
    def _is_stripe_transport_error(error: Exception) -> bool:
        text = str(error).lower()
        return any(
            marker in text
            for marker in (
                "stripe", "payment page", "elements session", "confirmation token",
                "api.stripe.com", "payment_intent", "setup_intent",
            )
        )

    def _record_proxy_success(self, proxy: str, stripe_proxy: str) -> None:
        self.proxy_pool.record_success(proxy)
        self.stripe_proxy_pool.record_success(stripe_proxy)

    def _record_proxy_failure(self, proxy: str, stripe_proxy: str, error: Exception) -> None:
        if not self._is_transport_error(error):
            return
        if self._is_stripe_transport_error(error):
            self.stripe_proxy_pool.record_failure(stripe_proxy)
        else:
            self.proxy_pool.record_failure(proxy)

    @staticmethod
    def checkout_regions() -> list[dict[str, str]]:
        return [dict(item) for item in PLATFORM_CHECKOUT_REGIONS]

    def bootstrap_stripe_elements(self, session: Any) -> dict[str, Any]:
        """Read the account Stripe key without creating a Checkout or card object."""
        token, account_id = self._token_and_account(session, require_account=False)
        cache_key = self._stripe_bootstrap_cache_key(token, account_id)
        cached = self._cached_stripe_bootstrap(cache_key)
        if cached is not None:
            return cached
        first = self._next_proxy()
        candidates = [first]
        candidates.extend(self.proxy_pool.candidates(exclude=first, limit=3))
        last_error: Exception | None = None
        for proxy in candidates or [""]:
            try:
                result = self._bootstrap_stripe_elements_once(session, proxy)
                safe_result = {
                    "publishable_key": str(result.get("publishable_key") or ""),
                    "account_id": str(result.get("account_id") or account_id or ""),
                }
                self._remember_stripe_bootstrap(cache_key, safe_result)
                resolved_account = str(safe_result.get("account_id") or "").strip()
                if resolved_account and resolved_account != account_id:
                    self._remember_stripe_bootstrap(
                        self._stripe_bootstrap_cache_key(token, resolved_account),
                        safe_result,
                    )
                return {**result, "cache_hit": False}
            except CheckoutError as exc:
                last_error = exc
                if not self._is_transport_error(exc):
                    raise
        raise CheckoutError(str(last_error or "Stripe Elements 初始化代理池已耗尽")[:500])

    @staticmethod
    def _stripe_bootstrap_cache_key(token: str, account_id: str = "") -> str:
        account = str(account_id or "").strip()
        if account:
            return f"account:{account}"
        digest = hashlib.sha256(str(token or "").encode("utf-8")).hexdigest()
        return f"token:{digest}"

    def _cached_stripe_bootstrap(self, cache_key: str) -> dict[str, Any] | None:
        if self.stripe_bootstrap_cache_ttl <= 0:
            return None
        now = time.monotonic()
        with self._stripe_bootstrap_cache_lock:
            expired = [
                key
                for key, (created_at, _value) in self._stripe_bootstrap_cache.items()
                if now - created_at >= self.stripe_bootstrap_cache_ttl
            ]
            for key in expired:
                self._stripe_bootstrap_cache.pop(key, None)
            entry = self._stripe_bootstrap_cache.get(cache_key)
            if not entry:
                return None
            _created_at, value = entry
            return {**value, "cache_hit": True, "proxy": "", "stripe_proxy": ""}

    def _remember_stripe_bootstrap(
        self, cache_key: str, value: dict[str, str]
    ) -> None:
        if self.stripe_bootstrap_cache_ttl <= 0:
            return
        safe_value = {
            "publishable_key": str(value.get("publishable_key") or ""),
            "account_id": str(value.get("account_id") or ""),
        }
        if not safe_value["publishable_key"] or not cache_key:
            return
        with self._stripe_bootstrap_cache_lock:
            self._stripe_bootstrap_cache[cache_key] = (time.monotonic(), safe_value)

    def _bootstrap_stripe_elements_once(
        self, session: Any, proxy: str
    ) -> dict[str, Any]:
        module = self._load()
        token, account_id = self._token_and_account(session, require_account=False)
        sentinel_token, telemetry = self._sentinel_context(session)
        config = self._config(
            module,
            token,
            account_id,
            session_value=session,
            sentinel_token=sentinel_token,
            telemetry=telemetry,
        )
        stripe_proxy = self._next_stripe_proxy()
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        try:
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(http_session, config, lambda _message: None)
            module._ensure_sentinel_context(
                http_session, config, flow="platform_checkout"
            )
            publishable_key = module._stripe_client_bootstrap(http_session, config)
            self._record_proxy_success(proxy, stripe_proxy)
            return {
                "publishable_key": publishable_key,
                "account_id": account_id,
                "proxy": mask_proxy(proxy),
                "stripe_proxy": mask_proxy(stripe_proxy),
            }
        except CheckoutError as exc:
            self._record_proxy_failure(proxy, stripe_proxy, exc)
            raise
        except Exception as exc:
            self._record_proxy_failure(proxy, stripe_proxy, exc)
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            close = getattr(http_session, "close", None)
            if callable(close):
                close()

    def normalize_checkout_region(
        self, country: Any = "", currency: Any = ""
    ) -> tuple[str, str]:
        code = str(country or self.country).strip().upper()
        requested_currency = str(currency or "").strip().upper()
        if not re.fullmatch(r"[A-Z]{2}", code):
            raise CheckoutError("Checkout 国家/地区代码必须是两位字母")
        region = _PLATFORM_CHECKOUT_REGION_MAP.get(code)
        if region is None:
            if code == self.country and re.fullmatch(r"[A-Z]{3}", requested_currency or self.currency):
                return code, requested_currency or self.currency
            raise CheckoutError("Checkout 暂不支持所选国家/地区")
        selected_currency = requested_currency or (
            self.currency if code == self.country else region["currency"]
        )
        if selected_currency != region["currency"]:
            raise CheckoutError("所选国家/地区与币种不匹配")
        return code, selected_currency

    @staticmethod
    def _remote_pricing_config(
        http_session: Any,
        module: Any,
        country: str,
        fallback_currency: str,
        timeout: int,
    ) -> tuple[str, str]:
        """Use Platform's read-only pricing config as the currency authority."""
        response = module._get_app(
            http_session,
            f"{module.APP_BASE}/api/v1/payments/checkout/pricing_config",
            params={"country": country.upper()},
            referer=f"{module.APP_BASE}/",
            route="/api/v1/payments/checkout/pricing_config",
            timeout=timeout,
        )
        status = int(getattr(response, "status_code", 0) or 0)
        if status >= 400:
            raise CheckoutError(f"pricing_config failed: HTTP {status}")
        payload = module._response_json(response)
        currency = str(
            module._find_key(payload, ("currency", "billing_currency", "billingCurrency"))
            or fallback_currency
        ).strip().upper()
        if not re.fullmatch(r"[A-Z]{3}", currency):
            raise CheckoutError("pricing_config returned invalid currency")
        return country.upper(), currency

    def preflight(
        self,
        session: Any,
        billing: dict[str, Any] | None = None,
        *,
        country: Any = "",
        currency: Any = "",
        plan_type: Any = "plus",
    ) -> dict[str, Any]:
        normalized_plan = str(plan_type or "plus").strip().lower()
        plan_name = checkout_plan_name(normalized_plan)
        checkout_country, checkout_currency = self.normalize_checkout_region(country, currency)
        first = self._next_proxy()
        candidates = [first]
        candidates.extend(self.proxy_pool.candidates(exclude=first, limit=3))
        stripe_first = self._next_stripe_proxy()
        stripe_candidates = [stripe_first]
        stripe_candidates.extend(
            self.stripe_proxy_pool.candidates(exclude=stripe_first, limit=3)
        )
        last_error: Exception | None = None
        attempt_count = max(len(candidates), len(stripe_candidates), 1)
        for attempt in range(attempt_count):
            proxy = candidates[min(attempt, len(candidates) - 1)] if candidates else ""
            stripe_proxy = (
                stripe_candidates[min(attempt, len(stripe_candidates) - 1)]
                if stripe_candidates else ""
            )
            try:
                result = self._preflight_once(
                    session,
                    billing,
                    proxy,
                    stripe_proxy,
                    country=checkout_country,
                    currency=checkout_currency,
                    plan_type=normalized_plan,
                    plan_name=plan_name,
                )
                self._record_proxy_success(proxy, stripe_proxy)
                return result
            except CheckoutError as exc:
                last_error = exc
                self._record_proxy_failure(proxy, stripe_proxy, exc)
                if not self._is_transport_error(exc):
                    raise
        raise CheckoutError(str(last_error or "Platform Checkout 代理池已耗尽")[:500])

    def _preflight_once_legacy(
        self,
        session: Any,
        billing: dict[str, Any] | None,
        proxy: str,
        *,
        country: str = "",
        currency: str = "",
        plan_type: str = "plus",
        plan_name: str = "basic_plan",
    ) -> dict[str, Any]:
        module = self._load()
        token, account_id = self._token_and_account(session, require_account=False)
        sentinel_token, telemetry = self._sentinel_context(session)
        config = self._config(
            module,
            token,
            account_id,
            billing,
            session_value=session,
            sentinel_token=sentinel_token,
            telemetry=telemetry,
            country=country,
            currency=currency,
            checkout_plan_type=plan_type,
            checkout_plan_name=plan_name,
        )
        stripe_proxy = self._next_stripe_proxy()
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        diagnostics: list[dict[str, Any]] = []

        def record(key: str, label: str, started: float, detail: str = "") -> None:
            diagnostics.append({
                "key": key,
                "label": label,
                "status": "succeeded",
                "durationMs": round((time.perf_counter() - started) * 1000),
                "detail": detail,
            })

        try:
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(http_session, config, lambda _message: None)
            module._ensure_sentinel_context(
                http_session, config, flow="platform_checkout"
            )
            stage_started = time.perf_counter()
            checkout = module._checkout_create(
                http_session,
                config,
                country=config.country,
                currency=config.currency,
                promo_campaign="",
                
            )
            record("checkout", "创建 Platform Checkout", stage_started, f"{config.country}/{config.currency}")
            checkout_id = module._checkout_id(checkout)
            processor = module._processor_entity(checkout, config.country)
            stage_started = time.perf_counter()
            publishable_key = module._find_key(checkout, ("publishable_key", "publishableKey"))
            key_source = "checkout"
            if not publishable_key:
                publishable_key = module._find_identifier(checkout, ("pk_live_", "pk_test_"))
            if not publishable_key:
                key_source = "payment_method"
                prepared = module._post_json(
                    http_session,
                    f"{module.APP_BASE}/api/v1/payments/payment_method",
                    {"account_id": account_id},
                    timeout=self.timeout,
                    stage="payment method prepare",
                    route="/api/v1/payments/payment_method",
                )
                secret = module._find_client_secret(prepared)
                publishable_key = module._publishable_key_for_setup(secret)
            if not checkout_id.startswith("oaics_"):
                raise CheckoutError("Platform Checkout 未返回 oaics Checkout ID")
            if not publishable_key.startswith(("pk_live_", "pk_test_")):
                raise CheckoutError("Platform Checkout 未返回 Stripe publishable key")
            account_publishable_key = module._stripe_client_bootstrap(http_session, config)
            if account_publishable_key != publishable_key:
                raise CheckoutError("Stripe 商户公钥不一致，请重新生成 Checkout")
            config.payment_method_publishable_key = account_publishable_key
            record("stripe_key", "获取 Stripe Checkout 公钥", stage_started, key_source)
            stage_started = time.perf_counter()
            taxes = module._update_checkout_taxes(
                http_session,
                config,
                checkout_id,
                processor,
            )
            record("taxes", "更新 Checkout Taxes", stage_started, f"{self.billing_country}/{config.currency}")
            amount_minor = self._amount_minor(module, taxes)
            if amount_minor is None:
                amount_minor = self._amount_minor(module, checkout)
            self._remember_proxy(checkout_id, proxy, stripe_proxy)
            return {
                "checkout_id": checkout_id,
                "checkout_url": f"{module.APP_BASE}/checkout/{processor}/{checkout_id}",
                "processor_entity": processor,
                "publishable_key": publishable_key,
                "payment_method_publishable_key": account_publishable_key,
                "account_id": account_id,
                "currency": config.currency,
                "amount_minor": amount_minor,
                "card_input_modes": ["api_card", "stripe_elements"],
                "country": config.country,
                "billing_country": self.billing_country,
                "proxy": mask_proxy(proxy),
                "stripe_proxy": mask_proxy(stripe_proxy),
                "stripe_runtime_status": self._stripe_runtime_status(),
                "diagnostics": diagnostics,
            }
        except CheckoutError:
            raise
        except Exception as exc:
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            self._close_http_session(http_session)

    def _preflight_once(
        self,
        session: Any,
        billing: dict[str, Any] | None,
        proxy: str,
        stripe_proxy: str | None = None,
        *,
        country: str = "",
        currency: str = "",
        plan_type: str = "plus",
        plan_name: str = "basic_plan",
    ) -> dict[str, Any]:
        """Create and fully initialize the Stripe Payment Page used for charge."""
        module = self._load()
        token, account_id = self._token_and_account(session, require_account=False)
        sentinel_token, telemetry = self._sentinel_context(session)
        config = self._config(
            module,
            token,
            account_id,
            billing,
            session_value=session,
            sentinel_token=sentinel_token,
            telemetry=telemetry,
            country=country,
            currency=currency,
            checkout_plan_type=plan_type,
            checkout_plan_name=plan_name,
        )
        stripe_proxy = (
            self._next_stripe_proxy() if stripe_proxy is None else str(stripe_proxy or "")
        )
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        session_retained = False
        diagnostics: list[dict[str, Any]] = []

        def record(key: str, label: str, started: float, detail: str = "") -> None:
            diagnostics.append({
                "key": key,
                "label": label,
                "status": "succeeded",
                "durationMs": round((time.perf_counter() - started) * 1000),
                "detail": detail,
            })

        try:
            account_snapshot = self._account_snapshot(http_session, module, self.timeout)
            if not account_id:
                account_id = str(account_snapshot.get("account_id") or "").strip()
                config.account_id = account_id
            pricing_source = "static_fallback"
            pricing_error = ""
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(http_session, config, lambda _message: None)
            module._ensure_sentinel_context(
                http_session, config, flow="platform_checkout"
            )
            pricing_started = time.perf_counter()
            try:
                config.country, config.currency = self._remote_pricing_config(
                    http_session,
                    module,
                    config.country,
                    config.currency,
                    self.timeout,
                )
                pricing_source = "remote"
                record(
                    "pricing_config",
                    "读取 Platform Pricing Config",
                    pricing_started,
                    f"{config.country}/{config.currency}",
                )
            except CheckoutError as exc:
                pricing_error = str(exc)[:240]
                record(
                    "pricing_config",
                    "Pricing Config 回退静态区域表",
                    pricing_started,
                    pricing_error,
                )
            requested_checkout_mode, currency_route_reason = self._select_checkout_mode(
                config.currency,
                account_snapshot.get("billing_currency"),
            )
            checkout_mode = requested_checkout_mode
            upgraded_from_oaics = False

            def create_checkout(selected_mode: str) -> dict[str, Any]:
                creator_name = (
                    "_checkout_create_cs_live"
                    if selected_mode == "hosted"
                    else "_checkout_create_custom"
                )
                creator = getattr(module, creator_name, None)
                if callable(creator):
                    return creator(
                        http_session,
                        config,
                        country=config.country,
                        currency=config.currency,
                        promo_campaign="",
                    )
                return module._checkout_create(
                    http_session,
                    config,
                    country=config.country,
                    currency=config.currency,
                    promo_campaign="",
                    mode=selected_mode,
                )

            started = time.perf_counter()
            try:
                checkout_payload = create_checkout(checkout_mode)
            except Exception as exc:
                if (
                    checkout_mode == "custom"
                    and self._is_currency_incompatible_error(exc)
                ):
                    diagnostics.append({
                        "key": "checkout_mode_upgrade",
                        "label": "Checkout currency incompatible; upgrade to hosted",
                        "status": "succeeded",
                        "durationMs": round(
                            (time.perf_counter() - started) * 1000
                        ),
                        "detail": "custom->hosted",
                    })
                    checkout_mode = "hosted"
                    currency_route_reason = "currency_incompatible_fallback"
                    upgraded_from_oaics = True
                    started = time.perf_counter()
                    checkout_payload = create_checkout(checkout_mode)
                else:
                    raise
            checkout_id = module._checkout_id(checkout_payload)
            if not checkout_id.startswith(("oaics_", "cs_live_", "cs_test_", "cs_")):
                raise CheckoutError("Platform Checkout 未返回有效 Checkout ID")
            processor = module._processor_entity(checkout_payload, config.country)
            config.checkout_id = checkout_id
            config.processor_entity = processor
            self._remember_checkout_runtime(
                checkout_id, token, account_id, config
            )
            record("checkout", "创建 Platform Checkout", started, f"{config.country}/{config.currency}")

            diagnostics.append({
                "key": "checkout_mode",
                "label": "Select Checkout protocol mode",
                "status": "succeeded",
                "durationMs": 0,
                "detail": (
                    f"requested={requested_checkout_mode} selected={checkout_mode} "
                    f"reason={currency_route_reason}"
                ),
            })
            started = time.perf_counter()
            context_response = module._get_app(
                http_session,
                f"{module.APP_BASE}/api/v1/payments/checkout/{processor}/{checkout_id}",
                referer=f"{module.APP_BASE}/checkout/{processor}/{checkout_id}",
                route="/api/v1/payments/checkout/{processor_entity}/{checkout_session_id}",
                timeout=self.timeout,
            )
            if int(getattr(context_response, "status_code", 0) or 0) >= 400:
                raise CheckoutError("Platform Checkout 上下文读取失败")
            checkout_context = module._response_json(context_response)
            combined = {"checkout": checkout_payload, "context": checkout_context}
            is_oaics = checkout_id.startswith("oaics_")
            actual_checkout_mode = "custom" if is_oaics else "hosted"
            payment_page_id = "" if is_oaics else module._payment_page_id(combined, checkout_id)
            if not is_oaics and not payment_page_id:
                raise CheckoutError("Stripe Checkout 未返回 Payment Page ID")
            config.payment_page_id = payment_page_id
            publishable_key = module._discover_publishable_key(
                http_session,
                config,
                combined,
                checkout_id,
                processor,
            )
            account_publishable_key = module._stripe_client_bootstrap(http_session, config)
            if account_publishable_key != publishable_key:
                raise CheckoutError(
                    "Stripe 商户公钥不一致：Checkout 与当前 Platform 账号不属于同一商户"
                )
            config.publishable_key = publishable_key
            config.payment_method_publishable_key = account_publishable_key
            payment_contract = (
                "oaics_confirmation_token" if is_oaics else "stripe_payment_page"
            )
            record("stripe_key", "获取 Stripe Checkout 公钥", started, payment_contract)
            record("merchant_key", "校验账号 Stripe 商户", started, "matched")

            started = time.perf_counter()
            taxes_payload = module._update_checkout_taxes(
                http_session,
                config,
                checkout_id,
                processor,
            )
            record("taxes", "更新 Platform Checkout Taxes", started, f"{self.billing_country}/{config.currency}")

            started = time.perf_counter()
            if is_oaics:
                amount_minor = module._checkout_amount_minor(
                    taxes_payload,
                    checkout_context,
                    checkout_payload,
                )
                currency = module._checkout_currency(
                    taxes_payload,
                    checkout_context,
                    checkout_payload,
                    fallback=config.currency,
                )
                record(
                    "oaics_ready",
                    "准备 Vendor API Checkout",
                    started,
                    f"{currency} {amount_minor if amount_minor is not None else '动态金额'}",
                )
            else:
                # Payment Page init is a one-shot transition for some hosted
                # Checkout sessions. Preflight therefore stops at the
                # Platform/merchant contract and defers Stripe init, Elements,
                # address update and amount resolution to the charge request.
                amount_minor = None
                currency = module._checkout_currency(
                    taxes_payload,
                    checkout_context,
                    checkout_payload,
                    fallback=config.currency,
                )
                record(
                    "stripe_deferred",
                    "Stripe Payment Page 初始化延后到开始充值",
                    started,
                    f"{currency} 动态金额",
                )
            self._remember_proxy(checkout_id, proxy, stripe_proxy)
            # Hosted Checkout obtains runtime/checksum immediately after the
            # user starts payment, so API-card support does not require a
            # one-shot Stripe init during preflight.
            inline_api_ready = True
            result = {
                "checkout_id": checkout_id,
                "plan_type": plan_type,
                "plan_name": plan_name,
                "payment_page_id": payment_page_id,
                "checkout_provider": "oaics" if is_oaics else "stripe",
                "payment_contract": payment_contract,
                "requested_checkout_mode": requested_checkout_mode,
                "selected_checkout_mode": checkout_mode,
                "actual_checkout_mode": actual_checkout_mode,
                "currency_route_reason": currency_route_reason,
                "account_billing_currency": str(
                    account_snapshot.get("billing_currency") or ""
                ).strip().upper(),
                "upgraded_from_oaics": upgraded_from_oaics,
                "checkout_url": f"{module.APP_BASE}/checkout/{processor}/{checkout_id}",
                "processor_entity": processor,
                "publishable_key": publishable_key,
                "payment_method_publishable_key": account_publishable_key,
                "account_id": account_id,
                "account_snapshot": {
                    **account_snapshot,
                    "same_plan_active": bool(
                        account_snapshot.get("has_active_subscription")
                        and subscription_matches_plan(
                            plan_type, account_snapshot.get("subscription_plan")
                        )
                    ),
                },
                "pricing_source": pricing_source,
                "pricing_error": pricing_error,
                "currency": currency,
                "amount_minor": amount_minor,
                "amount_known": amount_minor is not None,
                "card_input_modes": (
                    ["api_card", "stripe_elements"]
                    if inline_api_ready
                    else ["stripe_elements"]
                ),
                "country": config.country,
                "billing_country": self.billing_country,
                "proxy": mask_proxy(proxy),
                "stripe_proxy": mask_proxy(stripe_proxy),
                "stripe_runtime_status": self._stripe_runtime_status(),
                "diagnostics": diagnostics,
            }
            self._remember_checkout_http_session(
                checkout_id,
                token,
                account_id,
                proxy,
                stripe_proxy,
                http_session,
            )
            session_retained = True
            return result
        except CheckoutError:
            raise
        except Exception as exc:
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            if not session_retained:
                self._close_http_session(http_session)

    def verify_subscription_legacy(self, session: Any, checkout: dict[str, Any]) -> dict[str, Any]:
        module = self._load()
        token, account_id = self._token_and_account(
            session,
            str(checkout.get("account_id") or checkout.get("accountId") or ""),
            require_account=False,
        )
        checkout_id = str(checkout.get("checkout_id") or checkout.get("checkoutId") or "").strip()
        target_plan_type = str(
            checkout.get("plan_type") or checkout.get("planType") or "plus"
        ).strip().lower()
        checkout_plan_type = str(
            checkout.get("plan_type") or checkout.get("planType") or "plus"
        ).strip().lower()
        target_plan_name = str(
            checkout.get("plan_name") or checkout.get("planName") or ""
        ).strip() or checkout_plan_name(checkout_plan_type)
        processor = str(checkout.get("processor_entity") or checkout.get("processorEntity") or "vendor_ie").strip()
        if not checkout_id.startswith(("oaics_", "cs_live_", "cs_test_", "cs_")):
            raise CheckoutError("Checkout ID 无效")
        proxy = self._proxy_for_checkout(checkout_id) or self._next_proxy()
        stripe_proxy = self._stripe_proxy_for_checkout(checkout_id) or self._next_stripe_proxy()
        config = self._config(
            module,
            token,
            account_id,
            session_value=session,
            checkout_plan_type=checkout_plan_type,
            checkout_plan_name=target_plan_name,
        )
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        try:
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(http_session, config, lambda _message: None)
            checkout_response = module._get_app(
                http_session,
                f"{module.APP_BASE}/api/v1/payments/checkout/{processor}/{checkout_id}",
                referer=f"{module.APP_BASE}/checkout/{processor}/{checkout_id}",
                route="/api/v1/payments/checkout/{processor_entity}/{checkout_session_id}",
                timeout=self.timeout,
            )
            if int(getattr(checkout_response, "status_code", 0) or 0) >= 400:
                raise CheckoutError("Checkout 状态查询失败")
            subscription = module._get_app(
                http_session,
                f"{module.APP_BASE}/api/v1/subscriptions",
                params={"account_id": account_id},
                referer=f"{module.APP_BASE}/",
                route="/api/v1/subscriptions",
                timeout=self.timeout,
            )
            if int(getattr(subscription, "status_code", 0) or 0) >= 400:
                raise CheckoutError("订阅状态查询失败")
            payload = module._response_json(subscription)
            plan_type = str(payload.get("plan_type") or "").lower()
            return {
                "active": subscription_matches_plan(checkout_plan_type, plan_type),
                "plan": plan_type,
                "checkoutStatus": int(getattr(checkout_response, "status_code", 0) or 0),
                "subscriptionStatus": int(getattr(subscription, "status_code", 0) or 0),
                "proxy": mask_proxy(proxy),
                "stripeProxy": mask_proxy(stripe_proxy),
            }
        except CheckoutError:
            raise
        except Exception as exc:
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            close = getattr(http_session, "close", None)
            if callable(close):
                close()

    def _verify_subscription_protocol(
        self, session: Any, checkout: dict[str, Any]
    ) -> dict[str, Any]:
        """Recover a charged Checkout using read-only protocol requests.

        Recovery never creates a PaymentMethod, confirms an Intent, rotates a
        proxy after a mutation, or opens a browser Checkout.  It only restores
        the return context and verifies the remote terminal/subscription state.
        """
        module = self._load()
        token, account_id = self._token_and_account(
            session,
            str(checkout.get("account_id") or checkout.get("accountId") or ""),
            require_account=False,
        )
        checkout_id = str(
            checkout.get("checkout_id") or checkout.get("checkoutId") or ""
        ).strip()
        target_plan_type = str(
            checkout.get("plan_type") or checkout.get("planType") or "plus"
        ).strip().lower()
        if checkout_id.startswith("oaics_"):
            checkout_provider = "oaics"
            payment_page_id = ""
        elif checkout_id.startswith(("cs_live_", "cs_test_", "cs_")):
            checkout_provider = "stripe"
            payment_page_id = str(
                checkout.get("payment_page_id")
                or checkout.get("paymentPageId")
                or checkout_id
            ).strip()
        else:
            raise CheckoutError("Checkout ID invalid")
        processor = str(
            checkout.get("processor_entity")
            or checkout.get("processorEntity")
            or "vendor_ie"
        ).strip()
        publishable_key = str(
            checkout.get("publishable_key")
            or checkout.get("publishableKey")
            or ""
        ).strip()
        if checkout_provider == "stripe" and not payment_page_id.startswith(
            ("cs_live_", "cs_test_", "cs_")
        ):
            raise CheckoutError("Stripe Payment Page ID invalid")
        if checkout_provider == "stripe" and not publishable_key.startswith(
            ("pk_live_", "pk_test_")
        ):
            raise CheckoutError("Stripe publishable key invalid")

        proxy = self._proxy_for_checkout(checkout_id) or self._next_proxy()
        stripe_proxy = self._stripe_proxy_for_checkout(checkout_id)
        if checkout_provider == "stripe" and not stripe_proxy:
            stripe_proxy = self._next_stripe_proxy()
        config = self._config(
            module,
            token,
            account_id,
            session_value=session,
            publishable_key=publishable_key,
            checkout_id=checkout_id,
            payment_page_id=payment_page_id,
            processor_entity=processor,
            checkout_plan_type=target_plan_type,
            checkout_plan_name=checkout_plan_name(target_plan_type),
            poll_attempts=12,
            poll_interval=1.0,
        )
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        try:
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(
                http_session, config, lambda _message: None
            )
            module._ensure_sentinel_context(
                http_session, config, flow="checkout_session_approval"
            )

            poll_state = ""
            poll_payload: dict[str, Any] = {}
            observed_return_url = ""
            if checkout_provider == "stripe":
                poll_attempts = max(1, min(12, int(config.poll_attempts or 1)))
                for poll_attempt in range(poll_attempts):
                    if poll_attempt and config.poll_interval:
                        time.sleep(max(0.0, float(config.poll_interval)))
                    poll_response = http_session.get(
                        f"{module.STRIPE_BASE}/v1/payment_pages/{payment_page_id}/poll",
                        params={
                            "key": publishable_key,
                            "_stripe_version": module.STRIPE_BETAS,
                        },
                        headers=module._stripe_headers(
                            publishable_key, "https://js.stripe.com/"
                        ),
                        timeout=self.timeout,
                    )
                    poll_status = int(getattr(poll_response, "status_code", 0) or 0)
                    if poll_status >= 400:
                        if poll_status in {404, 409, 425, 429} or poll_status >= 500:
                            if poll_attempt + 1 < poll_attempts:
                                continue
                        raise CheckoutError("Stripe Payment Page status query failed")
                    poll_payload = module._response_json(poll_response)
                    poll_state = module._payment_page_state(poll_payload)
                    if poll_state in {"succeeded", "failed", "expired", "canceled", "requires_payment_method", "requires_action"}:
                        break
                observed_return_url = str(
                    poll_payload.get("return_url") or ""
                ).strip()
                if poll_state in {
                    "failed",
                    "expired",
                    "canceled",
                    "cancelled",
                    "requires_payment_method",
                }:
                    return {
                        "active": False,
                        "pending": False,
                        "terminalFailure": True,
                        "paymentTerminal": False,
                        "pollState": poll_state,
                        "plan": "",
                        "proxy": mask_proxy(proxy),
                        "stripeProxy": mask_proxy(stripe_proxy),
                    }
                if poll_state != "succeeded":
                    action_details: dict[str, Any] = {}
                    action_builder = getattr(
                        module, "_payment_page_action_details", None
                    )
                    if callable(action_builder):
                        raw_amount = checkout.get("amount_minor")
                        if raw_amount is None:
                            raw_amount = checkout.get("amountMinor")
                        try:
                            expected_amount = (
                                int(raw_amount) if raw_amount is not None else None
                            )
                        except (TypeError, ValueError):
                            expected_amount = None
                        action_details = action_builder(
                            poll_payload,
                            checkout_id=checkout_id,
                            payment_page_id=payment_page_id,
                            expected_amount=expected_amount,
                            currency=str(checkout.get("currency") or ""),
                        )
                    if not isinstance(action_details, dict):
                        action_details = {}
                    action_details["payment_stage"] = "payment_page_poll"
                    action_details["stripe_poll_response"] = poll_payload
                    return {
                        "active": False,
                        "pending": True,
                        "terminalFailure": False,
                        "paymentTerminal": False,
                        "pollState": poll_state,
                        "actionRequired": poll_state == "requires_action",
                        "actionDetails": action_details,
                        "paymentActionUrl": str(
                            action_details.get("next_action_url") or ""
                        ),
                        "plan": "",
                        "proxy": mask_proxy(proxy),
                        "stripeProxy": mask_proxy(stripe_proxy),
                    }

            def complete_for_entity(entity: str) -> dict[str, Any]:
                return_url = str(
                    checkout.get("confirm_return_url")
                    or checkout.get("confirmReturnUrl")
                    or observed_return_url
                    or (
                        f"{module.APP_BASE}/checkout/verify?stripe_session_id={checkout_id}"
                        f"&processor_entity={entity}&plan_type={target_plan_type}"
                    )
                ).strip()
                intent_id = module._find_identifier(
                    poll_payload, ("pi_", "seti_")
                )
                intent_type = "setup_intent" if intent_id.startswith("seti_") else (
                    "payment_intent" if intent_id.startswith("pi_") else ""
                )
                return module._complete_vendor_checkout_return(
                    http_session,
                    config,
                    checkout_id,
                    entity,
                    return_url,
                    intent_payload=poll_payload,
                    intent_type=intent_type,
                )

            try:
                finalized = complete_for_entity(processor)
            except Exception:
                if checkout_provider != "oaics" or processor not in {
                    "vendor_ie",
                    "vendor_entity",
                }:
                    raise
                alternate_processor = (
                    "vendor_entity" if processor == "vendor_ie" else "vendor_ie"
                )
                try:
                    finalized = complete_for_entity(alternate_processor)
                except Exception as alternate_error:
                    raise CheckoutError(
                        f"Checkout state lookup failed: {processor} then "
                        f"{alternate_processor}: {alternate_error}"
                    ) from alternate_error
                processor = alternate_processor

            return_status = int(finalized.get("return_url_status") or 0)
            checkout_status = int(finalized.get("checkout_status") or 0)
            checkout_payload = finalized.get("checkout_payload") or {}
            checkout_state = _checkout_terminal_state(checkout_payload)
            if checkout_state in {
                "failed",
                "expired",
                "canceled",
                "cancelled",
                "requires_payment_method",
            }:
                return {
                    "active": False,
                    "pending": False,
                    "terminalFailure": True,
                    "paymentTerminal": poll_state == "succeeded",
                    "pollState": poll_state,
                    "checkoutState": checkout_state,
                    "plan": "",
                    "returnUrlStatus": return_status,
                    "processorEntity": processor,
                    "proxy": mask_proxy(proxy),
                    "stripeProxy": mask_proxy(stripe_proxy),
                }

            payment_method_id = module._find_identifier(
                {"poll": poll_payload, "checkout": checkout_payload}, ("pm_",)
            )
            payment_methods_status = 0
            payment_method_payload: dict[str, Any] = {}
            if payment_method_id:
                payment_methods_status, payment_method_payload = (
                    module._verify_payment_method_sync(
                        http_session, config, payment_method_id, None
                    )
                )
            subscription, plan_type = module._verify_plus_subscription(
                http_session, config, account_id, None
            )
            payment_terminal = (
                poll_state == "succeeded"
                if checkout_provider == "stripe"
                else (
                    str(checkout.get("paymentTerminalStatus") or "").lower()
                    == "succeeded"
                    or checkout_state == "succeeded"
                )
            )
            return {
                "active": subscription_matches_plan(target_plan_type, plan_type),
                "pending": not subscription_matches_plan(target_plan_type, plan_type),
                "terminalFailure": False,
                "paymentTerminal": payment_terminal,
                "paymentContract": (
                    "stripe_payment_page"
                    if checkout_provider == "stripe"
                    else "oaics_confirmation_token"
                ),
                "plan": plan_type,
                "pollState": poll_state,
                "checkoutState": checkout_state,
                "checkoutStatus": checkout_status,
                "subscriptionStatus": int(
                    getattr(subscription, "status_code", 0) or 0
                ),
                "returnUrlStatus": return_status,
                "successDataStatus": int(
                    finalized.get("success_data_status") or 0
                ),
                "authSessionStatus": int(
                    finalized.get("auth_session_status") or 0
                ),
                "authSessionUpdated": bool(
                    finalized.get("auth_session_updated")
                ),
                "paymentMethodId": payment_method_id,
                "paymentMethodsStatus": payment_methods_status,
                "defaultPaymentMethodId": payment_method_payload.get(
                    "_xy_default_payment_method_id", ""
                ),
                "isDefaultPaymentMethod": payment_method_payload.get(
                    "_xy_is_default_payment_method"
                ),
                "paymentMethodDetails": payment_method_payload.get(
                    "_checkout_serverment_method", {}
                ),
                "checkoutPollAttempts": int(
                    finalized.get("checkout_poll_attempts") or 0
                ),
                "processorEntity": processor,
                "proxy": mask_proxy(proxy),
                "stripeProxy": mask_proxy(stripe_proxy),
            }
        except CheckoutError:
            raise
        except Exception as exc:
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            close = getattr(http_session, "close", None)
            if callable(close):
                close()

    def _verify_subscription_pre_upgrade(
        self, session: Any, checkout: dict[str, Any]
    ) -> dict[str, Any]:
        """Verify this Checkout's Stripe terminal state before reading the plan."""
        module = self._load()
        token, account_id = self._token_and_account(
            session,
            str(checkout.get("account_id") or checkout.get("accountId") or ""),
            require_account=False,
        )
        checkout_id = str(checkout.get("checkout_id") or checkout.get("checkoutId") or "").strip()
        target_plan_type = str(
            checkout.get("plan_type") or checkout.get("planType") or "plus"
        ).strip().lower()
        if checkout_id.startswith("oaics_"):
            checkout_provider = "oaics"
            payment_page_id = ""
        elif checkout_id.startswith(("cs_live_", "cs_test_", "cs_")):
            checkout_provider = "stripe"
            payment_page_id = str(
                checkout.get("payment_page_id") or checkout.get("paymentPageId") or checkout_id
            ).strip()
        else:
            raise CheckoutError("Checkout ID 无效")
        processor = str(
            checkout.get("processor_entity") or checkout.get("processorEntity") or "vendor_ie"
        ).strip()
        publishable_key = str(
            checkout.get("publishable_key") or checkout.get("publishableKey") or ""
        ).strip()
        if checkout_provider == "stripe" and not payment_page_id.startswith(("cs_live_", "cs_test_", "cs_")):
            raise CheckoutError("Stripe Payment Page ID 无效")
        if checkout_provider == "stripe" and not publishable_key.startswith(("pk_live_", "pk_test_")):
            raise CheckoutError("Stripe publishable key 无效")
        proxy = self._proxy_for_checkout(checkout_id) or self._next_proxy()
        stripe_proxy = self._stripe_proxy_for_checkout(checkout_id)
        if checkout_provider == "stripe" and not stripe_proxy:
            stripe_proxy = self._next_stripe_proxy()
        config = self._config(
            module,
            token,
            account_id,
            session_value=session,
            publishable_key=publishable_key,
            checkout_id=checkout_id,
            payment_page_id=payment_page_id,
            processor_entity=processor,
        )
        http_session = self._routed_session(module, config, proxy, stripe_proxy)
        try:
            if not account_id:
                account_id = self._resolve_account_id(http_session, module, self.timeout)
                config.account_id = account_id
            self._apply_account_context(http_session, account_id)
            module._hydrate_payment_metadata(http_session, config, lambda _message: None)
            poll_state = ""
            return_status = 0
            observed_return_url = ""
            if checkout_provider == "stripe":
                poll_response = http_session.get(
                    f"{module.STRIPE_BASE}/v1/payment_pages/{payment_page_id}/poll",
                    params={"key": publishable_key, "_stripe_version": module.STRIPE_BETAS},
                    headers=module._stripe_headers(publishable_key, "https://js.stripe.com/"),
                    timeout=self.timeout,
                )
                if int(getattr(poll_response, "status_code", 0) or 0) >= 400:
                    raise CheckoutError("Stripe Payment Page 状态查询失败")
                poll_payload = module._response_json(poll_response)
                poll_state = str(poll_payload.get("state") or "unknown").lower()
                observed_return_url = str(poll_payload.get("return_url") or "").strip()
                if poll_state in {"failed", "expired", "canceled"}:
                    return {
                        "active": False,
                        "pending": False,
                        "terminalFailure": True,
                        "paymentTerminal": False,
                        "pollState": poll_state,
                        "plan": "",
                        "proxy": mask_proxy(proxy),
                        "stripeProxy": mask_proxy(stripe_proxy),
                    }
                if poll_state != "succeeded":
                    return {
                        "active": False,
                        "pending": True,
                        "terminalFailure": False,
                        "paymentTerminal": False,
                        "pollState": poll_state,
                        "plan": "",
                        "proxy": mask_proxy(proxy),
                        "stripeProxy": mask_proxy(stripe_proxy),
                    }

            def finalize_and_read(entity: str) -> tuple[Any, int]:
                return_url = str(
                    checkout.get("confirm_return_url")
                    or checkout.get("confirmReturnUrl")
                    or observed_return_url
                    or (
                        f"{module.APP_BASE}/checkout/verify?stripe_session_id={checkout_id}"
                        f"&processor_entity={entity}&plan_type={target_plan_type}"
                    )
                ).strip()
                parsed = urlsplit(return_url)
                hostname = str(parsed.hostname or "").lower()
                if parsed.scheme != "https" or not (hostname == "platform.example.com" or hostname.endswith(".platform.example.com")):
                    raise CheckoutError("Vendor Checkout return URL is invalid")
                if parsed.path == "/checkout/verify":
                    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
                    query["stripe_session_id"] = checkout_id
                    query["processor_entity"] = entity
                    query.setdefault("plan_type", target_plan_type)
                    return_url = urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(query), parsed.fragment))
                finalize_response = module._get_app(
                    http_session,
                    return_url,
                    referer=f"{module.APP_BASE}/checkout/{entity}/{checkout_id}",
                    navigation=True,
                    timeout=self.timeout,
                )
                finalize_status = int(getattr(finalize_response, "status_code", 0) or 0)
                checkout_response = module._get_app(
                    http_session,
                    f"{module.APP_BASE}/api/v1/payments/checkout/{entity}/{checkout_id}",
                    referer=f"{module.APP_BASE}/checkout/{entity}/{checkout_id}",
                    route="/api/v1/payments/checkout/{processor_entity}/{checkout_session_id}",
                    timeout=self.timeout,
                )
                return checkout_response, finalize_status

            if checkout_provider != "stripe":
                checkout_response, return_status = finalize_and_read(processor)
                checkout_status = int(getattr(checkout_response, "status_code", 0) or 0)
                # Historical oaics_ orders did not persist their processor entity.
                # Any upstream error may be an vendor_ie/vendor_entity reconstruction
                # mismatch, including the 500 currently returned for old orders.
                if (return_status >= 400 or checkout_status >= 400) and processor in {"vendor_ie", "vendor_entity"}:
                    original_processor = processor
                    original_return_status = return_status
                    original_status = checkout_status
                    alternate_processor = "vendor_entity" if processor == "vendor_ie" else "vendor_ie"
                    alternate_response, alternate_return_status = finalize_and_read(alternate_processor)
                    alternate_status = int(getattr(alternate_response, "status_code", 0) or 0)
                    if alternate_return_status < 400 and alternate_status < 400:
                        processor = alternate_processor
                        checkout_response = alternate_response
                        checkout_status = alternate_status
                        return_status = alternate_return_status
                    else:
                        raise CheckoutError(
                            "Checkout state lookup failed: "
                            f"{original_processor}=return {original_return_status}/checkout {original_status}, "
                            f"{alternate_processor}=return {alternate_return_status}/checkout {alternate_status}"
                        )
            else:
                checkout_response, return_status = finalize_and_read(processor)
                checkout_status = int(getattr(checkout_response, "status_code", 0) or 0)
                if return_status >= 400:
                    raise CheckoutError(f"Vendor Checkout return completion failed: HTTP {return_status}")
            if checkout_status >= 400:
                raise CheckoutError(f"Checkout state lookup failed: HTTP {checkout_status}")
            checkout_payload = module._response_json(checkout_response)
            checkout_state = _checkout_terminal_state(checkout_payload)
            terminal_failures = {"failed", "expired", "canceled", "cancelled", "requires_payment_method"}
            if checkout_state in terminal_failures:
                return {
                    "active": False,
                    "pending": False,
                    "terminalFailure": True,
                    "paymentTerminal": poll_state == "succeeded",
                    "pollState": poll_state,
                    "checkoutState": checkout_state,
                    "plan": "",
                    "returnUrlStatus": return_status,
                    "processorEntity": processor,
                    "proxy": mask_proxy(proxy),
                    "stripeProxy": mask_proxy(stripe_proxy),
                }
            subscription = None
            plan_type = ""
            subscription_status = 0
            for attempt in range(12):
                subscription = module._get_app(
                    http_session,
                    f"{module.APP_BASE}/api/v1/subscriptions",
                    params={"account_id": account_id},
                    referer=f"{module.APP_BASE}/",
                    route="/api/v1/subscriptions",
                    timeout=self.timeout,
                )
                subscription_status = int(getattr(subscription, "status_code", 0) or 0)
                if subscription_status == 404:
                    if attempt < 11:
                        time.sleep(1)
                    continue
                if subscription_status >= 400:
                    raise CheckoutError("订阅状态查询失败")
                payload = module._response_json(subscription)
                plan_type = str(payload.get("plan_type") or "").lower()
                if subscription_matches_plan(target_plan_type, plan_type):
                    break
                if attempt < 11:
                    time.sleep(1)
            return {
                "active": subscription_matches_plan(target_plan_type, plan_type),
                "pending": not subscription_matches_plan(target_plan_type, plan_type),
                "terminalFailure": False,
                "paymentTerminal": (
                    poll_state == "succeeded"
                    if checkout_provider == "stripe"
                    else (
                        str(checkout.get("paymentTerminalStatus") or "").lower() == "succeeded"
                        or checkout_state == "succeeded"
                    )
                ),
                "paymentContract": (
                    "stripe_payment_page" if checkout_provider == "stripe" else "oaics_confirmation_token"
                ),
                "plan": plan_type,
                "pollState": poll_state,
                "checkoutState": checkout_state,
                "checkoutStatus": checkout_status,
                "subscriptionStatus": subscription_status,
                "returnUrlStatus": return_status,
                "processorEntity": processor,
                "proxy": mask_proxy(proxy),
                "stripeProxy": mask_proxy(stripe_proxy),
            }
        except CheckoutError:
            raise
        except Exception as exc:
            raise CheckoutError(str(exc)[:500]) from exc
        finally:
            close = getattr(http_session, "close", None)
            if callable(close):
                close()

    def verify_subscription(
        self, session: Any, checkout: dict[str, Any]
    ) -> dict[str, Any]:
        result = self._verify_subscription_protocol(session, checkout)
        if result.get("terminalFailure") or (
            result.get("active") and result.get("paymentTerminal")
        ):
            self._forget_proxy(
                str(checkout.get("checkout_id") or checkout.get("checkoutId") or "")
            )
        return result

    def charge(
        self,
        session: Any,
        payment_method_id: str,
        checkout: dict[str, Any],
        billing: dict[str, Any] | None = None,
        card: dict[str, Any] | None = None,
        card_last4: str = "",
        logger: Callable[[str], None] | None = None,
    ) -> dict[str, Any]:
        external_payment_method = str(payment_method_id or "").strip()
        supplied_card = bool(card)
        if external_payment_method and supplied_card:
            raise CheckoutError("支付输入只能选择 PaymentMethod 或后端卡片字段之一")
        if external_payment_method:
            if not re.fullmatch(r"pm_[A-Za-z0-9_-]+", external_payment_method):
                raise CheckoutError("PaymentMethod ID 无效")
            normalized_card: dict[str, str] = {}
        elif supplied_card:
            normalized_card = self.normalize_card(card)
            card_last4 = normalized_card["card_number"][-4:]
        else:
            raise CheckoutError("缺少 PaymentMethod 或后端卡片字段")
        module = self._load()
        token, account_id = self._token_and_account(session, require_account=False)
        sentinel_token, telemetry = self._sentinel_context(session)
        checkout_id = str(checkout.get("checkout_id") or checkout.get("checkoutId") or "").strip()
        checkout_plan_type = str(
            checkout.get("plan_type") or checkout.get("planType") or "plus"
        ).strip().lower()
        target_plan_name = str(
            checkout.get("plan_name") or checkout.get("planName") or ""
        ).strip() or checkout_plan_name(checkout_plan_type)
        is_oaics = checkout_id.startswith("oaics_")
        payment_page_id = str(
            ""
            if is_oaics
            else checkout.get("payment_page_id") or checkout.get("paymentPageId") or checkout_id
        ).strip()
        processor = str(checkout.get("processor_entity") or checkout.get("processorEntity") or "").strip()
        publishable_key = str(checkout.get("publishable_key") or checkout.get("publishableKey") or "").strip()
        payment_method_publishable_key = str(
            checkout.get("payment_method_publishable_key")
            or checkout.get("paymentMethodPublishableKey")
            or publishable_key
        ).strip()
        account_id = account_id or str(
            checkout.get("account_id") or checkout.get("accountId") or ""
        ).strip()
        checkout_country, checkout_currency = self.normalize_checkout_region(
            checkout.get("country") or checkout.get("checkoutCountry") or self.country,
            checkout.get("currency") or self.currency,
        )
        if not checkout_id.startswith(("oaics_", "cs_live_", "cs_test_", "cs_")):
            raise CheckoutError("Checkout ID 无效或已过期，请重新预检")
        if not publishable_key.startswith(("pk_live_", "pk_test_")):
            raise CheckoutError("Checkout publishable key 无效，请重新预检")
        if not is_oaics and not payment_page_id.startswith(("cs_live_", "cs_test_", "cs_")):
            raise CheckoutError("Stripe Payment Page ID 无效，请重新预检")
        raw_amount = checkout.get("amount_minor")
        if raw_amount is None:
            raw_amount = checkout.get("amountMinor")
        expected_amount: int | None = None
        if raw_amount is not None:
            try:
                expected_amount = int(raw_amount)
            except (TypeError, ValueError) as exc:
                raise CheckoutError("Checkout 应付金额格式无效") from exc
        if expected_amount is not None and expected_amount < 0:
            raise CheckoutError("Checkout 应付金额无效")
        reserved_proxy = self._proxy_for_checkout(checkout_id)
        reserved_stripe_proxy = self._stripe_proxy_for_checkout(checkout_id)
        candidates = [reserved_proxy] if reserved_proxy else [self._next_proxy()]
        candidates.extend(self.proxy_pool.candidates(exclude=reserved_proxy, limit=3))
        stripe_candidates = [reserved_stripe_proxy] if reserved_stripe_proxy else [self._next_stripe_proxy()]
        stripe_candidates.extend(
            self.stripe_proxy_pool.candidates(exclude=reserved_stripe_proxy, limit=3)
        )
        if not account_id:
            resolve_proxy = candidates[0] if candidates else ""
            resolve_stripe_proxy = stripe_candidates[0] if stripe_candidates else ""
            resolve_config = self._config(
                module,
                token,
                "",
                billing,
                session_value=session,
                sentinel_token=sentinel_token,
                telemetry=telemetry,
                country=checkout_country,
                currency=checkout_currency,
                checkout_plan_type=checkout_plan_type,
                checkout_plan_name=target_plan_name,
            )
            resolve_session = self._routed_session(
                module, resolve_config, resolve_proxy, resolve_stripe_proxy
            )
            try:
                account_id = self._resolve_account_id(resolve_session, module, self.timeout)
            finally:
                resolve_session.close()
        attempt_count = max(len(candidates), len(stripe_candidates), 1)
        last_error: Exception | None = None
        preserve_proxy = False
        cached_runtime = self._checkout_runtime(checkout_id, token, account_id)
        if cached_runtime and logger:
            logger("FLOW_STEP:prepare_checkout:runtime_cache:hit: short-lived context")
        cached_http_session = self._take_checkout_http_session(
            checkout_id,
            token,
            account_id,
            candidates[0] if candidates else "",
            stripe_candidates[0] if stripe_candidates else "",
        )
        if cached_http_session is not None and logger:
            logger("FLOW_STEP:prepare_checkout:http_session_cache:hit: preflight connection")
        cached_sentinel = str(cached_runtime.get("sentinel_token") or sentinel_token)
        cached_telemetry = str(cached_runtime.get("telemetry") or telemetry)
        try:
            for attempt in range(attempt_count):
                proxy = candidates[min(attempt, len(candidates) - 1)] if candidates else ""
                stripe_proxy = (
                    stripe_candidates[min(attempt, len(stripe_candidates) - 1)]
                    if stripe_candidates else ""
                )
                config = self._config(
                    module,
                    token,
                    account_id,
                    billing,
                    session_value=session,
                    payment_method_id=external_payment_method,
                    card=normalized_card,
                    card_last4=str(card_last4 or ""),
                    checkout_id=checkout_id,
                    payment_page_id=payment_page_id,
                    processor_entity=processor,
                    publishable_key=publishable_key,
                    payment_method_publishable_key=payment_method_publishable_key,
                    stripe_proxy=stripe_proxy,
                    expected_amount=expected_amount,
                    sentinel_token=cached_sentinel,
                    telemetry=cached_telemetry,
                    checkout_runtime_cache_hit=bool(cached_runtime.get("_cache_hit")),
                    **{
                        key: value
                        for key, value in cached_runtime.items()
                        if not key.startswith("_")
                        and key not in {"sentinel_token", "telemetry"}
                        and value
                    },
                    country=checkout_country,
                    currency=checkout_currency,
                    checkout_plan_type=checkout_plan_type,
                    checkout_plan_name=target_plan_name,
                )
                self._remember_proxy(checkout_id, proxy, stripe_proxy)
                attempt_http_session = cached_http_session if attempt == 0 else None
                if attempt == 0:
                    cached_http_session = None

                def payment_session_factory(
                    route_config: Any, _runtime_proxy: str
                ) -> Any:
                    nonlocal attempt_http_session
                    if attempt_http_session is not None:
                        retained = attempt_http_session
                        attempt_http_session = None
                        return retained
                    return self._routed_session(
                        module, route_config, proxy, stripe_proxy
                    )

                try:
                    try:
                        result = module.run_card_payment(
                            config,
                            proxy=stripe_proxy,
                            logger=logger,
                            session_factory=payment_session_factory,
                            refresh_checkout=None,
                        )
                    finally:
                        if attempt_http_session is not None:
                            self._close_http_session(attempt_http_session)
                            attempt_http_session = None
                    contract = str(result.get("payment_contract") or "stripe_payment_page")
                    if contract == "oaics_confirmation_token":
                        if str(result.get("intent_status") or "").lower() != "succeeded":
                            raise CheckoutError("Vendor API Checkout 的 Stripe Intent 未确认成功")
                    elif str(result.get("poll_state") or "").lower() != "succeeded":
                        raise CheckoutError("Stripe Payment Page Poll 未确认当前 Checkout 成功")
                    if not result.get("ok") or not subscription_matches_plan(
                        checkout_plan_type, result.get("subscription_plan")
                    ):
                        raise CheckoutError("Platform Checkout 未验证 Plus 订阅状态")
                    self._record_proxy_success(proxy, stripe_proxy)
                    refreshed_token = str(
                        result.pop("_renewal_access_token", "") or ""
                    ).strip()
                    if refreshed_token:
                        if isinstance(session, dict):
                            session["accessToken"] = refreshed_token
                            session["_xyTokenRefreshedAfterPayment"] = True
                        elif isinstance(session, str):
                            try:
                                session_data = json.loads(session)
                            except (TypeError, json.JSONDecodeError):
                                session_data = None
                            if isinstance(session_data, dict):
                                session_data["accessToken"] = refreshed_token
                                session_data["_xyTokenRefreshedAfterPayment"] = True
                                result["_renewal_session"] = json.dumps(
                                    session_data, ensure_ascii=False
                                )
                    return result
                except Exception as exc:
                    last_error = exc
                    proxy_retry_safe = bool(getattr(exc, "proxy_retry_safe", True))
                    if proxy_retry_safe:
                        self._record_proxy_failure(proxy, stripe_proxy, exc)
                    action_required = str(getattr(exc, "action_required", "") or "").strip()
                    renewal_session: Any = None
                    refreshed_token = str(getattr(config, "token", "") or "").strip()
                    if refreshed_token and refreshed_token != token:
                        if isinstance(session, dict):
                            session["accessToken"] = refreshed_token
                            session["_xyTokenRefreshedAfterPayment"] = True
                            renewal_session = session
                        elif isinstance(session, str):
                            try:
                                refreshed_session = json.loads(session)
                            except (TypeError, json.JSONDecodeError):
                                refreshed_session = None
                            if isinstance(refreshed_session, dict):
                                refreshed_session["accessToken"] = refreshed_token
                                refreshed_session["_xyTokenRefreshedAfterPayment"] = True
                                renewal_session = json.dumps(
                                    refreshed_session, ensure_ascii=False
                                )
                    if action_required or not proxy_retry_safe or not self._is_transport_error(exc):
                        error_text = str(exc).lower()
                        preserve_proxy = bool(action_required) or any(
                            marker in error_text
                            for marker in (
                                "subscription pending",
                                "processing timeout",
                                "post-mutation transport failure",
                                "payment terminal succeeded",
                            )
                        )
                        action_details = getattr(exc, "details", {})
                        if not isinstance(action_details, dict):
                            action_details = {}
                        diagnostic = {
                            "missing_context": action_details.get("missing_context", []),
                            "context_diagnostics": action_details.get("context_diagnostics", {}),
                            "sentinel_refresh": action_details.get("sentinel_refresh", ""),
                        }
                        if diagnostic["missing_context"] or diagnostic["context_diagnostics"]:
                            try:
                                logger(
                                    "FLOW_ERROR:checkout_context: "
                                    + json.dumps(diagnostic, ensure_ascii=False, separators=(",", ":"))
                                )
                            except Exception:
                                pass
                        raise CheckoutError(
                            str(exc)[:500],
                            proxy_retry_safe=proxy_retry_safe,
                            action_required=action_required,
                            checkout_link=str(getattr(exc, "checkout_link", "") or "")[:1000],
                            checkout_id=str(getattr(exc, "checkout_id", "") or checkout_id),
                            processor_entity=str(
                                getattr(exc, "processor_entity", "") or processor
                            ),
                            action_details=action_details,
                            renewal_session=renewal_session,
                        ) from exc
            raise CheckoutError(
                str(last_error or "Platform Checkout 代理池已耗尽")[:500],
                proxy_retry_safe=bool(getattr(last_error, "proxy_retry_safe", True)),
                action_details=(
                    dict(getattr(last_error, "details", {}) or {})
                    if isinstance(getattr(last_error, "details", {}), dict)
                    else {}
                ),
                renewal_session=getattr(last_error, "renewal_session", None),
            )
        finally:
            if cached_http_session is not None:
                self._close_http_session(cached_http_session)
            if not preserve_proxy:
                self.release_checkout_context(checkout_id)
            normalized_card.clear()
