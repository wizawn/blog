from __future__ import annotations

import importlib.util
import json
from pathlib import Path
from types import ModuleType
from typing import Any


class RenewalError(RuntimeError):
    def __init__(self, message: str, *, credential_error: bool = False):
        super().__init__(message)
        self.credential_error = bool(credential_error)


class PlatformRenewalAdapter:
    """In-memory bridge to Checkout Server's bundled renewal cancellation script."""

    def __init__(self, project_root: Path):
        self.script_path = Path(project_root) / "cancel_renewal.py"
        self.session_util_path = Path(project_root) / "session_util.py"
        self._module: ModuleType | None = None
        self._session_util: ModuleType | None = None

    def _load(self) -> ModuleType:
        if self._module is not None:
            return self._module
        if not self.script_path.is_file():
            raise RenewalError("cancel_renewal.py 不存在")
        spec = importlib.util.spec_from_file_location("xy_cancel_renewal", self.script_path)
        if not spec or not spec.loader:
            raise RenewalError("无法加载 cancel_renewal.py")
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except SystemExit as exc:
            raise RenewalError("cancel_renewal.py 依赖未安装") from exc
        except Exception as exc:
            raise RenewalError("cancel_renewal.py 加载失败") from exc
        self._module = module
        return module

    def _load_session_util(self) -> ModuleType:
        if self._session_util is not None:
            return self._session_util
        if not self.session_util_path.is_file():
            raise RenewalError("session_util.py 不存在")
        spec = importlib.util.spec_from_file_location(
            "xy_session_util", self.session_util_path
        )
        if not spec or not spec.loader:
            raise RenewalError("无法加载 session_util.py")
        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)
        except Exception as exc:
            raise RenewalError("session_util.py 加载失败") from exc
        self._session_util = module
        return module

    def cancel(self, session: Any, account_id: str = "") -> dict[str, Any]:
        module = self._load()
        session_util = self._load_session_util()
        if isinstance(session, str):
            raw = session
            try:
                session_payload = json.loads(session)
            except (TypeError, json.JSONDecodeError):
                session_payload = {}
        else:
            raw = json.dumps(session, ensure_ascii=False)
            session_payload = session if isinstance(session, dict) else {}
        sess = module._session()
        try:
            parsed_credentials = session_util.parse_credentials(raw)
            # A successful payment can rotate the account accessToken.  When
            # the Auth.js Session Cookie is available, refresh proactively
            # before both subscription lookup and cancellation instead of
            # waiting for the old bearer to fail with HTTP 401.
            token, credentials = session_util.ensure_access_token(
                sess,
                raw,
                force_refresh=bool(
                    parsed_credentials.get("session_cookie")
                    and not session_payload.get(
                        "_xyTokenRefreshedAfterPayment"
                    )
                ),
            )
            resolved_account_id = str(account_id or "").strip() or module.resolve_account_id(sess, token)
            try:
                result = module.cancel_renewal(sess, token, resolved_account_id)
            except Exception as exc:
                if not session_util.is_credential_failure_message(str(exc)):
                    raise
                if not credentials.get("session_cookie"):
                    raise RenewalError(
                        "Platform accessToken 已失效，当前 Session 没有可用于刷新的 Session Cookie",
                        credential_error=True,
                    ) from exc
                token, _credentials = session_util.ensure_access_token(
                    sess, raw, force_refresh=True
                )
                result = module.cancel_renewal(sess, token, resolved_account_id)
        except RenewalError:
            raise
        except Exception as exc:
            message = str(exc)[:500]
            raise RenewalError(
                message,
                credential_error=session_util.is_credential_failure_message(message),
            ) from exc
        if not result.get("cancelled") or result.get("will_renew") is True:
            raise RenewalError("续费取消接口返回后仍然会续费")
        return result
