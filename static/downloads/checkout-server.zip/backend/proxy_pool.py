from __future__ import annotations

import re
import threading
import time
from datetime import datetime, timezone
from urllib.parse import urlsplit, urlunsplit
from typing import Any

try:
    from curl_cffi import requests as curl_requests
except ImportError:  # pragma: no cover - surfaced by probe result
    curl_requests = None


def normalize_proxy(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw or raw.startswith("#"):
        return ""
    parsed = urlsplit(raw)
    scheme = parsed.scheme.lower()
    if (
        scheme != "socks5h"
        or not parsed.hostname
        or not parsed.username
        or not parsed.password
        or parsed.path
        or parsed.query
        or parsed.fragment
    ):
        return ""
    try:
        port = parsed.port
    except ValueError:
        return ""
    if port is None:
        return ""
    routing = f"{parsed.username}_{parsed.password}"
    if not re.search(r"(?:^|_)country-[a-z]{2}(?:_|$)", routing, re.IGNORECASE):
        return ""
    return urlunsplit((scheme, parsed.netloc, "", "", ""))


def mask_proxy(value: str) -> str:
    parsed = urlsplit(value)
    if not parsed.hostname:
        return ""
    host = parsed.hostname
    if len(host) > 12:
        host = f"{host[:5]}...{host[-4:]}"
    auth = "***@" if parsed.username else ""
    return f"{parsed.scheme}://{auth}{host}:{parsed.port or ''}"


def _proxy_values(payload: Any) -> list[str]:
    if isinstance(payload, str):
        candidates = [item for item in payload.replace("\r", "\n").replace(",", "\n").split("\n")]
    elif isinstance(payload, list):
        candidates = payload
    elif isinstance(payload, dict):
        candidates = []
        for key in ("proxy", "proxy_url", "proxyUrl", "url"):
            if payload.get(key):
                candidates.append(payload[key])
        for key in ("proxies", "results", "data"):
            if key in payload:
                candidates.extend(_proxy_values(payload[key]))
    else:
        candidates = []
    output: list[str] = []
    for item in candidates:
        normalized = normalize_proxy(item)
        if normalized and normalized not in output:
            output.append(normalized)
    return output


class ProxyPool:
    """Round-robin pool with short-lived circuit breaking."""

    FAILURE_LIMIT = 3
    COOLDOWN_SECONDS = 90.0

    def __init__(
        self,
        values: str | list[str] | None = None,
        *,
        timeout: float = 12.0,
    ):
        self._values = _proxy_values(values or [])
        self.timeout = max(2.0, min(60.0, float(timeout)))
        self._index = 0
        self._lock = threading.Lock()
        self._updated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self._failures: dict[str, int] = {}
        self._cooldown_until: dict[str, float] = {}

    @property
    def configured(self) -> bool:
        return bool(self._values)

    @property
    def rotation(self) -> str:
        return "round_robin"

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            return {
                "proxies": list(self._values),
            }

    def _healthy_locked(self, value: str, now: float) -> bool:
        until = float(self._cooldown_until.get(value) or 0.0)
        if until and now >= until:
            self._cooldown_until.pop(value, None)
            self._failures.pop(value, None)
            until = 0.0
        return until <= now

    def status(self) -> dict[str, Any]:
        with self._lock:
            values = list(self._values)
            updated_at = self._updated_at
            now = time.time()
            descriptors = [
                {
                    **self._describe(item),
                    "healthy": self._healthy_locked(item, now),
                    "failureCount": int(self._failures.get(item) or 0),
                    "cooldownUntil": (
                        datetime.fromtimestamp(
                            float(self._cooldown_until[item]), timezone.utc
                        ).isoformat(timespec="seconds")
                        if item in self._cooldown_until
                        else ""
                    ),
                }
                for item in values
            ]
        countries = sorted({item["country"] for item in descriptors if item["country"]})
        lifetimes = sorted({item["lifetime"] for item in descriptors if item["lifetime"]})
        return {
            "configured": bool(values),
            "count": len(values),
            "rotation": "round_robin",
            "proxies": descriptors,
            "countries": countries,
            "lifetimes": lifetimes,
            "updatedAt": updated_at,
        }

    def replace(self, values: str | list[str]) -> dict[str, Any]:
        normalized = _proxy_values(values)
        if not normalized:
            raise ValueError("至少需要一条 socks5h://USER:PASSWORD_country-us@HOST:PORT 格式的代理地址")
        with self._lock:
            self._values = normalized
            self._index = 0
            self._updated_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
            self._failures.clear()
            self._cooldown_until.clear()
        return self.status()

    def record_success(self, value: str) -> None:
        key = str(value or "").strip()
        if not key:
            return
        with self._lock:
            self._failures.pop(key, None)
            self._cooldown_until.pop(key, None)

    def record_failure(self, value: str) -> None:
        key = str(value or "").strip()
        if not key:
            return
        with self._lock:
            if key not in self._values:
                return
            failures = int(self._failures.get(key) or 0) + 1
            self._failures[key] = failures
            if failures >= self.FAILURE_LIMIT:
                self._cooldown_until[key] = time.time() + self.COOLDOWN_SECONDS

    def probe(self, targets: tuple[str, ...] = ("platform", "stripe")) -> dict[str, Any]:
        proxy = self.next()
        if not proxy:
            return {"ok": False, "error": "代理池为空"}
        masked = mask_proxy(proxy)
        if curl_requests is None:
            return {"ok": False, "proxy": masked, "error": "curl_cffi 未安装"}
        started = time.perf_counter()

        def target_probe(name: str, url: str) -> dict[str, Any]:
            target_started = time.perf_counter()
            try:
                response = curl_requests.get(
                    url,
                    proxies={"http": proxy, "https": proxy},
                    timeout=self.timeout,
                    impersonate="chrome",
                    headers={"Accept": "*/*", "User-Agent": "CheckoutServer/3.0"},
                )
                status_code = int(getattr(response, "status_code", 0) or 0)
                return {
                    "ok": 0 < status_code < 500,
                    "status": status_code,
                    "latencyMs": round((time.perf_counter() - target_started) * 1000),
                }
            except Exception as exc:
                message = str(exc).replace(proxy, masked)
                message = re.sub(r"//[^/@\s]+@", "//***@", message)
                return {
                    "ok": False,
                    "status": 0,
                    "latencyMs": round((time.perf_counter() - target_started) * 1000),
                    "error": message[:260],
                }

        try:
            response = curl_requests.get(
                "https://ipwho.is/",
                proxies={"http": proxy, "https": proxy},
                timeout=self.timeout,
                impersonate="chrome",
                headers={"Accept": "application/json", "User-Agent": "CheckoutServer/3.0"},
            )
            status_code = int(getattr(response, "status_code", 0) or 0)
            payload = response.json() if status_code < 500 else {}
            if not isinstance(payload, dict):
                payload = {}
            country_code = str(payload.get("country_code") or "").upper()
            identity_ok = status_code < 400 and payload.get("success") is not False and bool(payload.get("ip"))
            target_urls = {
                "platform": "https://platform.example.com/cdn-cgi/trace",
                "stripe": "https://api.stripe.com/v1/tokens",
            }
            selected = tuple(name for name in targets if name in target_urls)
            if not selected:
                selected = tuple(target_urls)
            target_results = {
                name: target_probe(name, target_urls[name])
                for name in selected
            }
            success = identity_ok and all(item["ok"] for item in target_results.values())
            result = {
                "ok": success,
                "proxy": masked,
                "httpStatus": status_code,
                "ip": str(payload.get("ip") or ""),
                "country": country_code,
                "countryName": str(payload.get("country") or ""),
                "city": str(payload.get("city") or ""),
                "latencyMs": round((time.perf_counter() - started) * 1000),
                "targets": target_results,
            }
            if not success:
                failures: list[str] = []
                if not identity_ok:
                    failures.append(str(payload.get("message") or "出口 IP 查询失败"))
                for name, item in target_results.items():
                    if not item["ok"]:
                        label = "Platform" if name == "platform" else "Stripe API"
                        failures.append(f"{label} 不可达：{item.get('error') or ('HTTP ' + str(item.get('status') or 0))}")
                result["error"] = "；".join(failures)[:500]
            if success:
                self.record_success(proxy)
            else:
                self.record_failure(proxy)
            return result
        except Exception as exc:
            self.record_failure(proxy)
            message = str(exc).replace(proxy, masked)
            return {
                "ok": False,
                "proxy": masked,
                "latencyMs": round((time.perf_counter() - started) * 1000),
                "error": message[:300],
            }

    @staticmethod
    def _describe(value: str) -> dict[str, str | int]:
        parsed = urlsplit(value)
        routing = f"{parsed.username or ''}_{parsed.password or ''}"
        country_match = re.search(r"(?:^|_)country-([a-z]{2})(?:_|$)", routing, re.IGNORECASE)
        lifetime_match = re.search(r"(?:^|_)lifetime-([^_]+)(?:_|$)", routing, re.IGNORECASE)
        return {
            "masked": mask_proxy(value),
            "scheme": parsed.scheme,
            "host": parsed.hostname or "",
            "port": parsed.port or 0,
            "country": country_match.group(1).upper() if country_match else "",
            "lifetime": lifetime_match.group(1) if lifetime_match else "",
        }

    def next(self) -> str:
        with self._lock:
            if not self._values:
                return ""
            now = time.time()
            for offset in range(len(self._values)):
                index = (self._index + offset) % len(self._values)
                value = self._values[index]
                if self._healthy_locked(value, now):
                    self._index = (index + 1) % len(self._values)
                    return value
            return ""

    def candidates(self, exclude: str = "", limit: int = 4) -> list[str]:
        with self._lock:
            values = list(self._values)
            if not values:
                return []
            now = time.time()
            start = self._index % len(values)
            ordered = values[start:] + values[:start]
            self._index = (start + 1) % len(values)
            healthy = [
                item for item in ordered
                if item != exclude and self._healthy_locked(item, now)
            ]
        return healthy[: max(0, int(limit))]
