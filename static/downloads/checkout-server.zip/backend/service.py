from __future__ import annotations

import hashlib
import json
import queue
import re
import secrets
import threading
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit
from urllib.request import Request, urlopen

from .adapters import AdapterError, SandboxAdapter
from .platform_checkout import (
    PLATFORM_CHECKOUT_REGIONS,
    PLATFORM_CHECKOUT_PLAN_NAMES,
    PlatformCheckoutAdapter,
    CheckoutError,
    subscription_matches_plan,
)
from .platform_renewal import PlatformRenewalAdapter, RenewalError
from .database import Database, utc_now
from .security import (
    create_admin_token,
    create_managed_api_key,
    hash_password,
    key_fingerprint,
    token_hash,
    verify_password,
)
from .session_info import SessionValidationError, summarize_session
from .stripe_gateway import StripeError, StripeGateway


PLANS = {
    "plus": {
        "type": "plus",
        "name": "Plus",
        "checkout_plan_name": PLATFORM_CHECKOUT_PLAN_NAMES["plus"],
        "amount_minor": 0,
        "currency": "PHP",
    },
    "pro5": {
        "type": "pro5",
        "name": "Pro 5X",
        "checkout_plan_name": PLATFORM_CHECKOUT_PLAN_NAMES["pro5"],
        "amount_minor": 10000,
        "currency": "USD",
    },
    "pro20": {
        "type": "pro20",
        "name": "Pro 20X",
        "checkout_plan_name": PLATFORM_CHECKOUT_PLAN_NAMES["pro20"],
        "amount_minor": 20000,
        "currency": "USD",
    },
}

PAYMENT_FIXTURES = {
    "test_visa": {"key": "test_visa", "label": "Visa 测试支付", "last4": "4242"},
    "test_mastercard": {"key": "test_mastercard", "label": "Mastercard 测试支付", "last4": "4444"},
    "test_3ds": {"key": "test_3ds", "label": "3DS 测试支付", "last4": "3220"},
    "test_declined": {"key": "test_declined", "label": "拒绝场景测试", "last4": "0002"},
}

API_KEY_RE = re.compile(r"^[A-Za-z0-9_-]{50,128}$")
RENEWAL_MAX_ATTEMPTS = 3
CHECKOUT_RECOVERY_MAX_ATTEMPTS = 12
CHECKOUT_RECOVERY_INTERVAL = 5.0
CHECKOUT_PREFLIGHT_TTL = 15 * 60.0
DEFAULT_ADDRESS_API_URL = "https://address-api.example.com/api/v1/address?country_code=us&area_code=DE"
CHECKOUT_REGION_MAP = {item["code"]: item for item in PLATFORM_CHECKOUT_REGIONS}
PAYMENT_ACTION_ERROR_CODES = {
    "payment_confirmation_required",
    "checkout_session_confirmation_required",
    "stripe_action_required",
    "payment_processing",
    "payment_recovery_required",
    "payment_recovery_exhausted",
}
CHECKOUT_RECOVERY_ERROR_CODES = PAYMENT_ACTION_ERROR_CODES | {
    "subscription_pending",
    "auth_refresh_required",
    "payment_terminal_unverified",
    "subscription_recovery_exhausted",
}

US_STATE_NAMES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas",
    "CA": "California", "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware",
    "FL": "Florida", "GA": "Georgia", "HI": "Hawaii", "ID": "Idaho",
    "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
    "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
    "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York",
    "NC": "North Carolina", "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma",
    "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island", "SC": "South Carolina",
    "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah",
    "VT": "Vermont", "VA": "Virginia", "WA": "Washington", "WV": "West Virginia",
    "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
}

STEP_LABELS = {
    "queued": "等待处理",
    "awaiting_payment": "等待支付确认",
    "validate_session": "校验账户",
    "prepare_checkout": "准备结算",
    "create_payment_method": "创建支付方式",
    "confirm_payment": "确认支付",
    "verify_result": "核验结果",
    "completed": "处理完成",
    "failed": "处理失败",
}


class ServiceError(ValueError):
    def __init__(self, code: str, message: str, status: int = 400, details: dict[str, Any] | None = None):
        super().__init__(message)
        self.code = code
        self.status = status
        self.details = details or {}


def validate_api_key(value: Any) -> str:
    key = str(value or "").strip()
    if not API_KEY_RE.fullmatch(key):
        raise ServiceError("invalid_api_key", "API Key 必须为 50-128 位字母、数字、下划线或连字符")
    return key


def hash_api_key(key: str) -> str:
    return hashlib.sha256(key.encode("utf-8")).hexdigest()


def _sanitize_action_value(value: Any, *, depth: int = 0) -> Any:
    """Preserve Stripe's action object exactly for local diagnostics."""
    return value


def _safe_action_payload(details: dict[str, Any]) -> str | None:
    if not isinstance(details, dict) or not details:
        return None
    try:
        encoded = json.dumps(details, ensure_ascii=False, separators=(",", ":"), default=str)
    except (TypeError, ValueError):
        return None
    return encoded


def _action_url(value: Any) -> str:
    if isinstance(value, dict):
        for key, item in value.items():
            if str(key).lower() in {"url", "redirect_url", "acs_url", "source_url"}:
                candidate = str(item or "").strip()
                if candidate.startswith("https://"):
                    return candidate[:1000]
            found = _action_url(item)
            if found:
                return found
    elif isinstance(value, (list, tuple)):
        for item in value:
            found = _action_url(item)
            if found:
                return found
    return ""


class OrderService:
    def __init__(
        self,
        database_path: Path,
        project_root: Path,
        step_delay: float = 0.55,
        *,
        stripe_gateway: StripeGateway | None = None,
        platform_checkout: PlatformCheckoutAdapter | None = None,
        require_managed_keys: bool = False,
        renewal_adapter: PlatformRenewalAdapter | None = None,
    ):
        self.database = Database(database_path)
        self.project_root = Path(project_root)
        self.billing_profiles = self._load_billing_profiles()
        self.adapters = {"sandbox": SandboxAdapter(step_delay)}
        self.stripe_gateway = stripe_gateway
        self.platform_checkout = platform_checkout
        self._initialize_proxy_storage()
        self.renewal_adapter = renewal_adapter or PlatformRenewalAdapter(self.project_root)
        self._pending_renewals: dict[int, tuple[Any, str]] = {}
        self._pending_checkout_context: dict[int, dict[str, Any]] = {}
        self._renewal_in_progress: set[int] = set()
        self._checkout_sync_in_progress: set[str] = set()
        self._renewal_lock = threading.Lock()
        self._checkout_lock = threading.Lock()
        self._checkout_billing: dict[str, dict[str, str]] = {}
        self._checkout_region: dict[str, dict[str, str]] = {}
        self._checkout_contexts: dict[str, tuple[float, dict[str, Any]]] = {}
        self._checkout_sync_lock = threading.Lock()
        self._recovery_wakeup = threading.Event()
        self.require_managed_keys = require_managed_keys
        self.queue: queue.Queue[int | None] = queue.Queue()
        self._stopping = threading.Event()
        self._worker = threading.Thread(target=self._worker_loop, name="xy-order-worker", daemon=True)
        self._worker.start()
        self._recovery_worker = threading.Thread(
            target=self._checkout_recovery_loop,
            name="xy-checkout-recovery",
            daemon=True,
        )
        self._recovery_worker.start()
        for order_id in self.database.recover_incomplete():
            self.queue.put(order_id)
        for order in self.database.pending_renewal_orders():
            if order.get("status") == "awaiting_payment":
                self.database.update_order(
                    int(order["id"]),
                    renewal_cancel_status="pending",
                    renewal_cancel_message=(
                        "等待同账号新 Session 完成 Checkout/Plus 恢复后自动取消续费"
                    ),
                )
            else:
                self.database.update_order(
                    int(order["id"]),
                    renewal_cancel_status="unavailable",
                    renewal_cancel_message="服务重启后内存 Session 已释放，无法执行续费取消。",
                )

    def close(self) -> None:
        if self._stopping.is_set():
            return
        self._stopping.set()
        self._recovery_wakeup.set()
        self.queue.put(None)
        self._worker.join(timeout=3)
        self._recovery_worker.join(timeout=3)
        with self._renewal_lock:
            self._pending_renewals.clear()
            self._pending_checkout_context.clear()
            self._renewal_in_progress.clear()
        with self._checkout_sync_lock:
            self._checkout_sync_in_progress.clear()
        with self._checkout_lock:
            self._checkout_billing.clear()
            self._checkout_region.clear()
            self._checkout_contexts.clear()

    def _load_billing_profiles(self) -> list[dict[str, str]]:
        path = self.project_root / "fixtures" / "billing_profiles.json"
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError, json.JSONDecodeError):
            return []
        profiles = payload.get("profiles") if isinstance(payload, dict) else None
        if not isinstance(profiles, list):
            return []
        fields = ("name", "line1", "city", "state", "postal_code", "country")
        result: list[dict[str, str]] = []
        for item in profiles:
            if not isinstance(item, dict):
                continue
            profile = {key: str(item.get(key) or "").strip() for key in fields}
            if all(profile.values()) and profile["country"].upper() == "US":
                profile["country"] = "US"
                result.append(profile)
        return result

    def _new_checkout_billing(self, session: dict[str, Any]) -> dict[str, str]:
        configuration = self.database.billing_configuration()
        source = str(configuration.get("source") or "billing_profiles_json")
        if source == "remote_address_api":
            profile = self._fetch_remote_billing(
                str(configuration.get("address_api_url") or DEFAULT_ADDRESS_API_URL)
            )
        else:
            if not self.billing_profiles:
                raise ServiceError(
                    "billing_profiles_unavailable",
                    "账单资料池为空或格式无效",
                    503,
                )
            profile = dict(secrets.choice(self.billing_profiles))
        return {
            **profile,
            "email": str(session.get("email") or "").strip(),
        }

    @staticmethod
    def _normalize_address_api_url(value: Any) -> str:
        url = str(value or DEFAULT_ADDRESS_API_URL).strip()
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname != "address-api.example.com" or parsed.path != "/api/v1/address":
            raise ServiceError("invalid_address_api", "地址接口必须使用 address-api.example.com 的 HTTPS API")
        query = parse_qs(parsed.query)
        country = str((query.get("country_code") or [""])[0]).lower()
        area = str((query.get("area_code") or [""])[0]).upper()
        if country != "us" or not re.fullmatch(r"[A-Z]{2}", area):
            raise ServiceError("invalid_address_api", "地址接口必须指定 country_code=us 和两位 area_code")
        return url

    def _fetch_remote_billing(self, endpoint: str) -> dict[str, str]:
        endpoint = self._normalize_address_api_url(endpoint)
        request = Request(
            endpoint,
            headers={"Accept": "application/json", "User-Agent": "checkout-server-address/1.0"},
        )
        try:
            with urlopen(request, timeout=15) as response:  # noqa: S310 - strict allowlist above
                payload = json.loads(response.read().decode("utf-8"))
        except Exception as exc:
            raise ServiceError("address_api_unavailable", f"远程地址接口请求失败：{str(exc)[:240]}", 502) from exc
        data = payload.get("data") if isinstance(payload, dict) else None
        address = data.get("address") if isinstance(data, dict) else None
        if not isinstance(data, dict) or not isinstance(address, dict):
            raise ServiceError("invalid_address_api_response", "远程地址接口返回字段不完整", 502)
        state_code = str(address.get("area_code") or "").strip().upper()
        profile = {
            "name": f"{str(data.get('firstname') or '').strip()} {str(data.get('lastname') or '').strip()}".strip(),
            "line1": str(address.get("street") or "").strip(),
            "city": str(address.get("city") or "").strip(),
            "state": US_STATE_NAMES.get(state_code, state_code),
            "postal_code": str(address.get("zipcode") or "").strip(),
            "country": str(address.get("country_code") or "US").strip().upper(),
        }
        if not all(profile.values()) or profile["country"] != "US":
            raise ServiceError("invalid_address_api_response", "远程地址接口没有返回完整美国账单资料", 502)
        return profile

    def billing_admin_status(self, token: str) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        config = self.database.billing_configuration()
        return {
            "source": config["source"],
            "addressApiUrl": config["address_api_url"],
            "localProfileCount": len(self.billing_profiles),
            "updatedAt": config["updated_at"],
        }

    def configure_billing(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        source = str(payload.get("source") or "").strip()
        endpoint = self._normalize_address_api_url(payload.get("addressApiUrl"))
        if source not in {"billing_profiles_json", "remote_address_api"}:
            raise ServiceError("invalid_billing_source", "账单来源只能选择本地 JSON 或远程地址 API")
        self.database.save_billing_configuration(source, endpoint)
        return self.billing_admin_status(token)

    def probe_billing(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        source = str(payload.get("source") or self.database.billing_configuration()["source"])
        if source == "remote_address_api":
            billing = self._fetch_remote_billing(payload.get("addressApiUrl") or DEFAULT_ADDRESS_API_URL)
        else:
            if not self.billing_profiles:
                raise ServiceError("billing_profiles_unavailable", "账单资料池为空或格式无效", 503)
            billing = dict(secrets.choice(self.billing_profiles))
        return {"source": source, "billing": billing}

    def _billing_for_checkout(self, checkout_id: str, session: dict[str, Any]) -> dict[str, str]:
        with self._checkout_lock:
            selected = self._checkout_billing.get(checkout_id)
        billing = dict(selected) if selected else self._new_checkout_billing(session)
        billing["email"] = str(session.get("email") or "").strip()
        return billing

    @staticmethod
    def _utc_after(seconds: float) -> str:
        return (datetime.now(timezone.utc) + timedelta(seconds=max(0.0, seconds))).isoformat(timespec="seconds")

    @staticmethod
    def _payment_evidence(
        message: str, details: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        source = dict(details or {})
        text = str(message or "")

        intent_id = str(
            source.get("intent_id") or source.get("intentId") or ""
        ).strip()
        if not re.fullmatch(r"(?:pi|seti)_[A-Za-z0-9_]+", intent_id):
            match = re.search(r"intent_id=((?:pi|seti)_[A-Za-z0-9_]+)", text)
            intent_id = match.group(1) if match else ""

        intent_type = str(
            source.get("intent_type") or source.get("intentType") or ""
        ).strip().lower()
        if not intent_type:
            match = re.search(r"intent_type=([A-Za-z0-9_]+)", text)
            intent_type = match.group(1).lower() if match else ""
        if not intent_type:
            if intent_id.startswith("pi_"):
                intent_type = "payment_intent"
            elif intent_id.startswith("seti_"):
                intent_type = "setup_intent"
        if intent_type not in {"payment_intent", "setup_intent"}:
            intent_type = ""

        intent_status = str(
            source.get("intent_status")
            or source.get("intentStatus")
            or ""
        ).strip().lower()
        raw_terminal = source.get("payment_terminal")
        terminal_claim = raw_terminal is True or (
            isinstance(raw_terminal, str)
            and raw_terminal.strip().lower() == "true"
        ) or (
            intent_status == "succeeded"
        )
        if (
            "payment terminal succeeded; subscription pending" in text.lower()
            and intent_id
            and intent_type
        ):
            terminal_claim = True
            intent_status = intent_status or "succeeded"
        payment_terminal = bool(terminal_claim and intent_id and intent_type)

        result: dict[str, Any] = {
            "intent_id": intent_id,
            "intent_type": intent_type,
            "intent_status": intent_status,
            "payment_terminal": payment_terminal,
            "payment_stage": str(
                source.get("payment_stage") or source.get("paymentStage") or ""
            ).strip().lower(),
        }
        for source_key, result_key in (
            ("amount_minor", "amount_minor"),
            ("return_url_status", "return_url_status"),
            ("checkout_status", "checkout_status"),
        ):
            value = source.get(source_key)
            if value is None:
                match = re.search(rf"{source_key}=(\d+)", text)
                value = match.group(1) if match else None
            if value is not None:
                try:
                    normalized = int(value)
                except (TypeError, ValueError):
                    continue
                if normalized >= 0:
                    result[result_key] = normalized
        checkout_state = str(source.get("checkout_state") or "").strip().lower()
        if checkout_state:
            result["checkout_state"] = checkout_state
        return result

    @staticmethod
    def _order_has_payment_terminal(order: dict[str, Any]) -> bool:
        if str(order.get("payment_terminal_status") or "").lower() != "succeeded":
            return False
        if str(order.get("status") or "").lower() == "succeeded":
            return True
        if str(order.get("error_code") or "").lower() == "auth_refresh_required":
            # This state is written only after the Stripe Intent has returned
            # succeeded and the subsequent Platform token rotation failed.
            return True
        if str(order.get("payment_contract") or "") == "stripe_payment_page":
            return True
        intent_id = str(order.get("confirmation_ref") or "")
        intent_type = str(order.get("intent_type") or "").lower()
        intent_evidence = bool(
            re.fullmatch(r"(?:pi|seti)_[A-Za-z0-9_]+", intent_id)
            and intent_type in {"payment_intent", "setup_intent"}
        )
        checkout_state = str(order.get("checkout_terminal_status") or "").lower()
        checkout_evidence = checkout_state in {
            "succeeded", "complete", "completed", "paid", "active"
        }
        return intent_evidence or checkout_evidence

    @staticmethod
    def _proxy_source(snapshot: dict[str, Any]) -> str:
        values = snapshot.get("proxies") if isinstance(snapshot.get("proxies"), list) else []
        return "\n".join(str(value).strip() for value in values if str(value).strip())

    def _proxy_pool_for_role(self, role: str) -> Any:
        if not self.platform_checkout:
            return None
        return getattr(
            self.platform_checkout,
            "proxy_pool" if role == "platform" else "stripe_proxy_pool",
            None,
        )

    def _save_proxy_role(self, role: str) -> None:
        pool = self._proxy_pool_for_role(role)
        if pool is None:
            return
        snapshot = pool.snapshot()
        self.database.save_proxy_configuration(
            role,
            self._proxy_source(snapshot),
        )

    def _initialize_proxy_storage(self) -> None:
        if not self.platform_checkout or not callable(getattr(self.platform_checkout, "configure_proxy", None)):
            return
        stored = self.database.proxy_configurations()
        for role in ("platform", "stripe"):
            config = stored.get(role)
            if config:
                self.platform_checkout.configure_proxy(
                    str(config.get("proxies") or ""),
                    role=role,
                )
                continue
            pool = self._proxy_pool_for_role(role)
            snapshot = pool.snapshot() if pool is not None else {}
            if self._proxy_source(snapshot):
                self._save_proxy_role(role)

    def _proxy_status_with_storage(self, status: dict[str, Any] | None = None) -> dict[str, Any]:
        result = dict(status or (self.platform_checkout.proxy_status() if self.platform_checkout else {}))
        persisted = self.database.proxy_configurations()
        for role in ("platform", "stripe"):
            route = result.get(role) if isinstance(result.get(role), dict) else {}
            pool = self._proxy_pool_for_role(role)
            snapshot = pool.snapshot() if pool is not None and callable(getattr(pool, "snapshot", None)) else {}
            result[role] = {
                **route,
                "rawProxies": list(snapshot.get("proxies") or []),
            }
        result["storage"] = "database"
        result["persisted"] = {
            role: {
                "configured": role in persisted,
                "updatedAt": persisted.get(role, {}).get("updated_at"),
            }
            for role in ("platform", "stripe")
        }
        return result

    def metadata(self) -> dict[str, Any]:
        checkout_enabled = bool(self.platform_checkout and self.platform_checkout.enabled)
        stripe_enabled = bool(self.stripe_gateway and self.stripe_gateway.enabled)
        billing_configuration = self.database.billing_configuration()
        proxy_status = self.platform_checkout.proxy_status() if self.platform_checkout and hasattr(self.platform_checkout, "proxy_status") else {
            "configured": False,
            "count": 0,
            "rotation": "round_robin",
            "countries": [],
            "lifetimes": [],
        }
        platform_proxy_status = proxy_status.get("platform") if isinstance(proxy_status.get("platform"), dict) else proxy_status
        stripe_proxy_status = proxy_status.get("stripe") if isinstance(proxy_status.get("stripe"), dict) else proxy_status
        integrations = [{
            "key": "platform_checkout",
            "label": "Platform Checkout / Server Card",
            "available": checkout_enabled,
            "enabled": checkout_enabled,
            "status": "ready" if checkout_enabled else "staged",
        }]
        return {
            "environment": "local-test",
            "managedKeysRequired": self.require_managed_keys,
            "plans": list(PLANS.values()),
            "payment_fixtures": list(PAYMENT_FIXTURES.values()),
            "stripe": {
                "enabled": checkout_enabled or stripe_enabled,
                "cardFieldsEnabled": bool(
                    checkout_enabled
                    or (
                        self.stripe_gateway
                        and self.stripe_gateway.enabled
                        and self.stripe_gateway.settings.publishable_key
                    )
                ),
                "publishableKey": (
                    self.stripe_gateway.settings.publishable_key
                    if self.stripe_gateway and self.stripe_gateway.settings.publishable_key
                    else ""
                ),
                "mode": "platform_checkout" if checkout_enabled else "merchant_payment_intent",
                "dynamicPublishableKey": checkout_enabled,
                "cardFieldsSource": "checkout_preflight" if checkout_enabled else "environment",
                "cardInputModes": ["api_card", "stripe_elements"],
            },
            "platformCheckout": {
                "enabled": checkout_enabled,
                "requiresSessionPreflight": True,
                "paymentFlow": "protocol_api_dual_contract",
                "country": getattr(self.platform_checkout, "country", "PH") if self.platform_checkout else "PH",
                "currency": getattr(self.platform_checkout, "currency", "PHP") if self.platform_checkout else "PHP",
                "billingCountry": getattr(self.platform_checkout, "billing_country", "US") if self.platform_checkout else "US",
                "regions": [dict(item) for item in PLATFORM_CHECKOUT_REGIONS],
                "billingSource": billing_configuration["source"],
                "localBillingProfiles": len(self.billing_profiles),
                "stripeRuntime": (
                    self.platform_checkout._stripe_runtime_status()
                    if self.platform_checkout
                    and callable(
                        getattr(self.platform_checkout, "_stripe_runtime_status", None)
                    )
                    else {"configured": False, "inlineApiReady": False}
                ),
                "stripeBootstrapCacheTtl": float(
                    getattr(self.platform_checkout, "stripe_bootstrap_cache_ttl", 0.0)
                    if self.platform_checkout
                    else 0.0
                ),
                "fullVerification": True,
                "multiAccountBatchFrontend": False,
                "proxy": {
                    "configured": proxy_status.get("configured", False),
                    "count": proxy_status.get("count", 0),
                    "rotation": proxy_status.get("rotation", "round_robin"),
                    "countries": proxy_status.get("countries", []),
                    "lifetimes": proxy_status.get("lifetimes", []),
                    "required": bool(
                        self.platform_checkout
                        and (
                            getattr(self.platform_checkout, "require_proxy", False)
                            or getattr(self.platform_checkout, "require_stripe_proxy", False)
                        )
                    ),
                    "split": bool(proxy_status.get("split")),
                    "platform": {
                        "configured": platform_proxy_status.get("configured", False),
                        "count": platform_proxy_status.get("count", 0),
                        "rotation": platform_proxy_status.get("rotation", "round_robin"),
                        "countries": platform_proxy_status.get("countries", []),
                        "lifetimes": platform_proxy_status.get("lifetimes", []),
                        "required": bool(platform_proxy_status.get("required")),
                    },
                    "stripe": {
                        "configured": stripe_proxy_status.get("configured", False),
                        "count": stripe_proxy_status.get("count", 0),
                        "rotation": stripe_proxy_status.get("rotation", "round_robin"),
                        "countries": stripe_proxy_status.get("countries", []),
                        "lifetimes": stripe_proxy_status.get("lifetimes", []),
                        "required": bool(stripe_proxy_status.get("required")),
                    },
                },
            },
            "renewal": {
                "mandatoryAfterSuccess": True,
                "scriptAvailable": self.renewal_adapter.script_path.is_file(),
                "sessionStorage": "memory_only",
                "encryptionRequired": False,
                "maxAttempts": RENEWAL_MAX_ATTEMPTS,
            },
            "integrations": integrations,
            "stats": self.database.stats(),
        }

    def validate_session(self, value: Any) -> dict[str, Any]:
        try:
            return summarize_session(value)
        except SessionValidationError as exc:
            raise ServiceError("invalid_session", str(exc)) from exc

    def create_order(self, payload: dict[str, Any]) -> dict[str, Any]:
        api_key = self._validate_access_key(payload.get("apiKey"))
        plan_type = str(payload.get("planType") or "").strip()
        payment_fixture = str(payload.get("paymentFixture") or "").strip()
        provider = str(payload.get("provider") or "sandbox").strip()
        if plan_type not in PLANS:
            raise ServiceError("invalid_plan", "套餐类型无效")
        if payment_fixture not in PAYMENT_FIXTURES:
            raise ServiceError("invalid_payment_fixture", "测试支付方式无效")
        if provider not in self.adapters:
            raise ServiceError("provider_not_enabled", "该执行引擎尚未启用，请使用 Stripe 准备接口")

        summary = self.validate_session(payload.get("session"))
        if summary["expired"]:
            raise ServiceError("session_expired", "Session 已过期")

        plan = PLANS[plan_type]
        fixture = PAYMENT_FIXTURES[payment_fixture]
        order = self.database.create_order(
            {
                "order_key": f"XY-{secrets.token_hex(6).upper()}",
                "api_key_hash": hash_api_key(api_key),
                "api_key_prefix": f"{api_key[:6]}...",
                "plan_type": plan_type,
                "plan_name": plan["name"],
                "amount_minor": plan["amount_minor"],
                "currency": plan["currency"],
                "email": summary["email"],
                "account_ref": summary["account_ref"],
                "session_fingerprint": summary["fingerprint"],
                "provider": provider,
                "payment_fixture": payment_fixture,
                "payment_last4": fixture["last4"],
            }
        )
        self.queue.put(int(order["id"]))
        return self.public_order(order)

    def _normalize_checkout_region(self, country: Any = "", currency: Any = "") -> tuple[str, str]:
        default_country = str(getattr(self.platform_checkout, "country", "PH") or "PH").upper()
        default_currency = str(getattr(self.platform_checkout, "currency", "PHP") or "PHP").upper()
        code = str(country or default_country).strip().upper()
        requested_currency = str(currency or "").strip().upper()
        if not re.fullmatch(r"[A-Z]{2}", code):
            raise ServiceError("invalid_checkout_country", "Checkout country code must contain two letters")
        region = CHECKOUT_REGION_MAP.get(code)
        if region is None:
            if code == default_country and re.fullmatch(r"[A-Z]{3}", requested_currency or default_currency):
                return code, requested_currency or default_currency
            raise ServiceError("unsupported_checkout_country", "Checkout country is not supported")
        selected_currency = requested_currency or (
            default_currency if code == default_country else region["currency"]
        )
        if selected_currency != region["currency"]:
            raise ServiceError("checkout_currency_mismatch", "Checkout country and currency do not match")
        return code, selected_currency

    @staticmethod
    def _checkout_contract(checkout_id: Any) -> tuple[str, str]:
        """Derive the payment contract from the Checkout ID issued upstream."""
        value = str(checkout_id or "").strip()
        if value.startswith("oaics_"):
            return "oaics", "oaics_confirmation_token"
        if value.startswith(("cs_live_", "cs_test_", "cs_")):
            return "stripe", "stripe_payment_page"
        raise ServiceError("invalid_checkout", "Checkout ID is invalid", 502)

    def _remember_checkout_context(self, checkout: dict[str, Any]) -> dict[str, Any]:
        """Cache the server-created Checkout contract for its immediate charge."""
        checkout_id = str(checkout.get("checkoutId") or checkout.get("checkout_id") or "").strip()
        provider, contract = self._checkout_contract(checkout_id)
        supplied_provider = str(
            checkout.get("checkoutProvider") or checkout.get("checkout_provider") or ""
        ).strip().lower()
        supplied_contract = str(
            checkout.get("paymentContract") or checkout.get("payment_contract") or ""
        ).strip()
        if supplied_provider and supplied_provider != provider:
            raise ServiceError("checkout_contract_mismatch", "Checkout provider does not match its ID", 502)
        if supplied_contract and supplied_contract != contract:
            raise ServiceError("checkout_contract_mismatch", "Checkout contract does not match its ID", 502)

        checkout_plan_type = str(
            checkout.get("planType") or checkout.get("plan_type") or "plus"
        ).strip().lower()
        if checkout_plan_type not in PLATFORM_CHECKOUT_PLAN_NAMES:
            raise ServiceError("platform_plan_not_supported", "Platform Checkout 套餐不支持", 502)

        payment_page_id = str(
            checkout.get("paymentPageId") or checkout.get("payment_page_id") or ""
        ).strip()
        if provider == "stripe":
            if not payment_page_id.startswith(("cs_live_", "cs_test_", "cs_")):
                raise ServiceError("invalid_payment_page", "Stripe Payment Page ID is invalid", 502)
        else:
            payment_page_id = ""

        canonical = {
            **checkout,
            "checkoutId": checkout_id,
            "checkoutProvider": provider,
            "paymentContract": contract,
            "paymentPageId": payment_page_id,
            "planType": str(checkout.get("planType") or checkout.get("plan_type") or "plus").strip().lower(),
            "planName": str(checkout.get("planName") or checkout.get("plan_name") or "").strip(),
            "cardInputModes": (
                ["api_card", "stripe_elements"]
                if provider == "oaics" or "api_card" in list(checkout.get("cardInputModes") or [])
                else ["stripe_elements"]
            ),
            "defaultCardInputMode": "api_card" if provider == "oaics" or "api_card" in list(checkout.get("cardInputModes") or []) else "stripe_elements",
        }
        now = time.monotonic()
        with self._checkout_lock:
            expired = [
                key for key, (created_at, _context) in self._checkout_contexts.items()
                if now - created_at > CHECKOUT_PREFLIGHT_TTL
            ]
            for key in expired:
                self._checkout_contexts.pop(key, None)
            self._checkout_contexts[checkout_id] = (now, dict(canonical))
        return canonical

    def _cached_checkout_context(self, checkout_id: Any) -> dict[str, Any]:
        value = str(checkout_id or "").strip()
        if not value:
            return {}
        now = time.monotonic()
        with self._checkout_lock:
            entry = self._checkout_contexts.get(value)
            if not entry:
                return {}
            created_at, context = entry
            if now - created_at > CHECKOUT_PREFLIGHT_TTL:
                self._checkout_contexts.pop(value, None)
                return {}
            return dict(context)

    def preflight_platform_checkout(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.platform_checkout or not self.platform_checkout.enabled:
            raise ServiceError("platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503)
        self._validate_access_key(payload.get("apiKey"), require_managed=True)
        plan_type = str(payload.get("planType") or "plus").strip().lower()
        plan = PLANS.get(plan_type)
        if not plan or plan_type not in PLATFORM_CHECKOUT_PLAN_NAMES:
            raise ServiceError("platform_plan_not_supported", "Platform Checkout 套餐不支持")
        summary = self.validate_session(payload.get("session"))
        if summary["expired"]:
            raise ServiceError("session_expired", "Session 已过期")
        if not summary["has_access_token"]:
            raise ServiceError("session_token_required", "Platform Checkout 需要 accessToken")
        checkout_country, checkout_currency = self._normalize_checkout_region(
            payload.get("country") or payload.get("checkoutCountry"),
            payload.get("currency"),
        )
        try:
            billing = self.platform_checkout.normalize_billing(self._new_checkout_billing(summary))
        except CheckoutError as exc:
            raise ServiceError("invalid_billing", str(exc)) from exc
        try:
            preflight_kwargs: dict[str, str] = {}
            default_country = str(getattr(self.platform_checkout, "country", "PH") or "PH").upper()
            default_currency = str(getattr(self.platform_checkout, "currency", "PHP") or "PHP").upper()
            if checkout_country != default_country or checkout_currency != default_currency:
                preflight_kwargs = {
                    "country": checkout_country,
                    "currency": checkout_currency,
                }
            try:
                checkout = self.platform_checkout.preflight(
                    payload.get("session"),
                    billing,
                    plan_type=plan_type,
                    **preflight_kwargs,
                )
            except TypeError as exc:
                # Keep compatibility with injected test/legacy adapters that
                # predate plan-aware Checkout creation.
                if "plan_type" not in str(exc):
                    raise
                checkout = self.platform_checkout.preflight(
                    payload.get("session"), billing, **preflight_kwargs
                )
        except CheckoutError as exc:
            raise ServiceError("platform_checkout_preflight_failed", str(exc), 502) from exc
        checkout_id = str(checkout["checkout_id"])
        checkout_provider, payment_contract = self._checkout_contract(checkout_id)
        resolved_account_id = str(checkout.get("account_id") or "").strip()
        if resolved_account_id:
            summary = {
                **summary,
                "account_id": resolved_account_id,
                "account_ref": hashlib.sha256(resolved_account_id.encode("utf-8")).hexdigest()[:12],
            }
        with self._checkout_lock:
            self._checkout_billing[checkout_id] = dict(billing)
            self._checkout_region[checkout_id] = {
                "country": str(checkout.get("country") or checkout_country).upper(),
                "currency": str(checkout.get("currency") or checkout_currency).upper(),
            }
        result = {
            "session": summary,
            "billing": billing,
            "checkout": {
                "checkoutId": checkout["checkout_id"],
                "planType": plan_type,
                "planName": checkout.get("plan_name") or plan["checkout_plan_name"],
                "paymentPageId": checkout.get("payment_page_id") or "",
                "checkoutProvider": checkout_provider,
                "paymentContract": payment_contract,
                "requestedCheckoutMode": checkout.get("requested_checkout_mode") or "custom",
                "selectedCheckoutMode": checkout.get("selected_checkout_mode") or "custom",
                "actualCheckoutMode": checkout.get("actual_checkout_mode") or (
                    "custom" if checkout_provider == "oaics" else "hosted"
                ),
                "currencyRouteReason": checkout.get("currency_route_reason") or "",
                "accountBillingCurrency": checkout.get("account_billing_currency") or "",
                "upgradedFromOaics": bool(checkout.get("upgraded_from_oaics")),
                "checkoutUrl": checkout.get("checkout_url") or f"https://platform.example.com/checkout/{checkout['processor_entity']}/{checkout['checkout_id']}",
                "processorEntity": checkout["processor_entity"],
                "publishableKey": checkout["publishable_key"],
                "paymentMethodPublishableKey": (
                    checkout.get("payment_method_publishable_key")
                    or checkout["publishable_key"]
                ),
                "accountId": checkout.get("account_id") or "",
                "accountSnapshot": checkout.get("account_snapshot") or {},
                "pricingSource": checkout.get("pricing_source") or "static_fallback",
                "pricingError": checkout.get("pricing_error") or "",
                "country": checkout.get("country") or (getattr(self.platform_checkout, "country", "PH") if self.platform_checkout else "PH"),
                "currency": checkout.get("currency") or (getattr(self.platform_checkout, "currency", "PHP") if self.platform_checkout else "PHP"),
                "billingCountry": checkout.get("billing_country") or (getattr(self.platform_checkout, "billing_country", "US") if self.platform_checkout else "US"),
                "amountMinor": checkout.get("amount_minor"),
                "amountKnown": checkout.get("amount_minor") is not None,
                "cardInputModes": (
                    checkout.get("card_input_modes")
                    or ["stripe_elements", "api_card"]
                ),
                "defaultCardInputMode": "api_card",
                "proxy": checkout.get("proxy") or "",
                "stripeProxy": checkout.get("stripe_proxy") or "",
                "runtimeStatus": checkout.get("stripe_runtime_status") or {},
                "diagnostics": checkout.get("diagnostics") or [],
            },
        }
        result["checkout"] = self._remember_checkout_context(result["checkout"])
        return result

    def bootstrap_platform_stripe_elements(
        self, payload: dict[str, Any]
    ) -> dict[str, Any]:
        if not self.platform_checkout or not self.platform_checkout.enabled:
            raise ServiceError(
                "platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503
            )
        self._validate_access_key(payload.get("apiKey"), require_managed=True)
        summary = self.validate_session(payload.get("session"))
        if summary["expired"]:
            raise ServiceError("session_expired", "Session 已过期")
        if not summary["has_access_token"]:
            raise ServiceError(
                "session_token_required", "Stripe Elements 初始化需要 accessToken"
            )
        try:
            bootstrap = self.platform_checkout.bootstrap_stripe_elements(
                payload.get("session")
            )
        except CheckoutError as exc:
            raise ServiceError(
                "stripe_elements_bootstrap_failed", str(exc), 502
            ) from exc
        account_id = str(bootstrap.get("account_id") or "").strip()
        if account_id:
            summary = {
                **summary,
                "account_id": account_id,
                "account_ref": hashlib.sha256(account_id.encode("utf-8")).hexdigest()[:12],
            }
        return {
            "session": summary,
            "stripe": {
                "publishableKey": str(bootstrap.get("publishable_key") or ""),
                "accountId": account_id,
                "cardInputModes": ["stripe_elements"],
                "proxy": str(bootstrap.get("proxy") or ""),
                "stripeProxy": str(bootstrap.get("stripe_proxy") or ""),
                "cacheHit": bool(bootstrap.get("cache_hit")),
            },
        }

    def charge_platform_checkout_order(self, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.platform_checkout or not self.platform_checkout.enabled:
            raise ServiceError("platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503)
        api_key = self._validate_access_key(payload.get("apiKey"), require_managed=True)
        plan_type = str(payload.get("planType") or "plus").strip().lower()
        plan = PLANS.get(plan_type)
        if not plan or plan_type not in PLATFORM_CHECKOUT_PLAN_NAMES:
            raise ServiceError("platform_plan_not_supported", "Platform Checkout 套餐不支持")
        payment_mode = str(payload.get("paymentMode") or "").strip().lower()
        payment_method = str(payload.get("paymentMethodId") or "").strip()
        if not payment_mode:
            payment_mode = "stripe_elements" if payment_method else "api_card"
        if payment_mode not in {"stripe_elements", "api_card"}:
            raise ServiceError("invalid_payment_mode", "银行卡处理模式无效")
        card: dict[str, str] = {}
        if payment_mode == "stripe_elements":
            if not re.fullmatch(r"pm_[A-Za-z0-9_-]+", payment_method):
                raise ServiceError("invalid_payment_method", "Stripe Elements 模式需要有效的 PaymentMethod ID")
            if payload.get("card"):
                raise ServiceError("ambiguous_payment_input", "Stripe Elements 模式不接收后端卡片字段")
        else:
            if payment_method:
                raise ServiceError("ambiguous_payment_input", "后端 API 模式不接收 PaymentMethod ID")
            try:
                card = self.platform_checkout.normalize_card(payload.get("card"))
            except CheckoutError as exc:
                raise ServiceError("invalid_card", str(exc)) from exc
        summary = self.validate_session(payload.get("session"))
        if summary["expired"]:
            raise ServiceError("session_expired", "Session 已过期")
        if not summary["has_access_token"]:
            raise ServiceError("session_token_required", "Platform Checkout 需要 accessToken")
        checkout = payload.get("checkout") if isinstance(payload.get("checkout"), dict) else {
            "checkoutId": payload.get("checkoutId"),
            "paymentPageId": payload.get("paymentPageId"),
            "processorEntity": payload.get("processorEntity"),
            "publishableKey": payload.get("publishableKey"),
            "amountMinor": payload.get("amountMinor"),
            "currency": payload.get("currency"),
            "country": payload.get("country") or payload.get("checkoutCountry"),
        }
        checkout_id = str(checkout.get("checkoutId") or checkout.get("checkout_id") or "").strip()
        try:
            self._checkout_contract(checkout_id)
        except ServiceError:
            checkout_id = ""
        if checkout_id:
            cached_checkout = self._cached_checkout_context(checkout_id)
            if cached_checkout:
                checkout = cached_checkout
            else:
                existing = self.database.get_order_by_provider_ref("platform_checkout", checkout_id)
                checkout = self._checkout_context_for_order(existing) if existing else {}
            checkout_id = str(checkout.get("checkoutId") or checkout.get("checkout_id") or "").strip()
        if not checkout_id:
            prepared = self.preflight_platform_checkout(
                {
                    "apiKey": api_key,
                    "session": payload.get("session"),
                    "planType": plan_type,
                    "country": payload.get("country") or payload.get("checkoutCountry"),
                    "currency": payload.get("currency"),
                }
            )
            checkout = dict(prepared["checkout"])
            checkout_id = str(checkout.get("checkoutId") or "").strip()
        bound_plan_type = str(
            checkout.get("planType") or checkout.get("plan_type") or ""
        ).strip().lower()
        if bound_plan_type and bound_plan_type != plan_type:
            raise ServiceError("checkout_plan_mismatch", "Checkout 套餐与当前订单选择不一致", 409)
        try:
            self._checkout_contract(checkout_id)
        except ServiceError as exc:
            raise ServiceError("invalid_checkout", "后端未能准备有效的 Checkout", 502)
        with self._checkout_lock:
            bound_region = dict(self._checkout_region.get(checkout_id) or {})
        if bound_region:
            checkout = {
                **checkout,
                "country": bound_region["country"],
                "currency": bound_region["currency"],
            }
        resolved_account_id = str(
            checkout.get("accountId") or checkout.get("account_id") or ""
        ).strip()
        if resolved_account_id:
            summary = {
                **summary,
                "account_id": resolved_account_id,
                "account_ref": hashlib.sha256(resolved_account_id.encode("utf-8")).hexdigest()[:12],
            }
        try:
            billing = self.platform_checkout.normalize_billing(
                self._billing_for_checkout(checkout_id, summary)
            )
        except CheckoutError as exc:
            raise ServiceError("invalid_billing", str(exc)) from exc
        is_oaics = checkout_id.startswith("oaics_")
        checkout_provider = "oaics" if is_oaics else "stripe"
        payment_contract = "oaics_confirmation_token" if is_oaics else "stripe_payment_page"
        declared_card_modes = list(
            checkout.get("cardInputModes") or checkout.get("card_input_modes") or []
        )
        if not is_oaics and payment_mode == "api_card" and "api_card" not in declared_card_modes:
            card.clear()
            raise ServiceError(
                "checkout_payment_mode_unavailable",
                "This Stripe Payment Page did not advertise inline card support",
            )
        processor_entity = str(
            checkout.get("processorEntity") or checkout.get("processor_entity") or "vendor_ie"
        ).strip()
        publishable_key = str(
            checkout.get("publishableKey") or checkout.get("publishable_key") or ""
        ).strip()
        payment_page_id = str(
            checkout.get("paymentPageId") or checkout.get("payment_page_id") or ("" if is_oaics else checkout_id)
        ).strip()
        if not is_oaics and not payment_page_id.startswith(("cs_live_", "cs_test_", "cs_")):
            raise ServiceError("invalid_payment_page", "Stripe Payment Page ID 无效，请重新预检")
        confirm_return_url = str(
            checkout.get("confirmReturnUrl")
            or checkout.get("confirm_return_url")
            or (
                f"https://platform.example.com/checkout/verify?stripe_session_id={checkout_id}"
                f"&processor_entity={processor_entity}&plan_type=plus"
            )
        ).strip()
        confirm_return_url = confirm_return_url.replace(
            "plan_type=plus", f"plan_type={plan_type}"
        )
        plan = PLANS[plan_type]
        checkout_amount = checkout.get("amountMinor")
        if checkout_amount is None:
            checkout_amount = checkout.get("amount_minor")
        if checkout_amount is None:
            # Both oaics_ and hosted Stripe Checkout may defer amount discovery
            # until the user starts payment. Keep an internal sentinel until
            # the Stripe/Vendor preparation response supplies the exact total.
            order_amount = -1
        else:
            try:
                order_amount = int(checkout_amount)
            except (TypeError, ValueError) as exc:
                raise ServiceError(
                    "checkout_amount_unavailable",
                    "Stripe Payment Page 未返回明确应付金额，请重新预检",
                    502,
                ) from exc
        order_currency = str(
            checkout.get("currency")
            or (getattr(self.platform_checkout, "currency", plan["currency"]) if self.platform_checkout else plan["currency"])
        ).upper()
        last4 = card["card_number"][-4:] if card else re.sub(r"\D", "", str(payload.get("cardLast4") or ""))[-4:]
        api_key_hash = key_fingerprint(api_key)
        with self._checkout_lock:
            existing = self.database.get_order_by_provider_ref("platform_checkout", checkout_id)
            if existing:
                card.clear()
                if existing["api_key_hash"] != api_key_hash:
                    raise ServiceError("checkout_already_used", "该 Checkout 已绑定其他订单", 409)
                if existing.get("account_ref") != summary["account_ref"]:
                    raise ServiceError("session_account_mismatch", "当前 Session 不属于该订单账户", 409)
                existing_id = int(existing["id"])
                with self._renewal_lock:
                    self._pending_renewals[existing_id] = (
                        payload.get("session"),
                        resolved_account_id or str(payload.get("accountId") or ""),
                    )
                    self._pending_checkout_context[existing_id] = self._checkout_context_for_order(existing)
                if existing.get("status") == "succeeded":
                    if existing.get("renewal_cancel_status") == "unavailable":
                        existing = self.database.update_order(
                            existing_id,
                            renewal_cancel_status="pending",
                            renewal_cancel_message=None,
                        ) or existing
                    self._maybe_cancel_renewal(existing_id)
                    existing = self.database.get_order_by_id(existing_id) or existing
                return {
                    "order": self.public_order(existing),
                    "checkoutStatus": existing["status"],
                    "subscriptionPlan": plan_type if existing["status"] == "succeeded" else "",
                    "actionRequired": existing["status"] == "awaiting_payment",
                    "idempotent": True,
                }
            order = self.database.create_order({
                "order_key": f"XY-{secrets.token_hex(6).upper()}",
                "api_key_hash": api_key_hash,
                "api_key_prefix": f"{api_key[:6]}...",
                "plan_type": plan_type,
                "plan_name": plan["name"],
                "amount_minor": order_amount,
                "currency": order_currency,
                "email": summary["email"],
                "account_ref": summary["account_ref"],
                "session_fingerprint": summary["fingerprint"],
                "provider": "platform_checkout",
                "provider_ref": checkout_id,
                "checkout_provider": checkout_provider,
                "checkout_country": str(
                    checkout.get("country")
                    or getattr(self.platform_checkout, "country", "PH")
                ).upper(),
                "payment_page_id": payment_page_id or None,
                "processor_entity": processor_entity,
                "payment_contract": payment_contract,
                "checkout_publishable_key": publishable_key or None,
                "confirm_return_url": confirm_return_url,
                "intent_type": None,
                "payment_terminal_status": None,
                "checkout_terminal_status": None,
                "return_url_status": None,
                "recovery_attempts": 0,
                "recovery_last_at": None,
                "recovery_next_at": None,
                "payment_fixture": f"platform_checkout_{payment_mode}",
                "payment_last4": last4 if len(last4) == 4 else "----",
                "renewal_cancel_requested": 1,
                "renewal_cancel_status": "pending",
                "_status": "running",
                "_step": "prepare_checkout",
                "_progress": 20,
            })
        order_id = int(order["id"])
        flow_started = time.perf_counter()
        self.database.add_order_event(
            order_id,
            "order_created",
            "Platform Checkout payment started",
            0,
        )
        with self._renewal_lock:
            self._pending_renewals[order_id] = (
                payload.get("session"),
                resolved_account_id or str(payload.get("accountId") or ""),
            )
            self._pending_checkout_context[order_id] = dict(checkout)

        def checkout_logger(message: Any) -> None:
            text = str(message)[:500]
            lowered_log = text.lower()
            event_stage = "checkout"
            if lowered_log.startswith("flow_step:"):
                parts = text.split(":", 3)
                if len(parts) >= 3:
                    event_stage = f"{parts[1]}:{parts[2]}"[:80]
            elif lowered_log.startswith("flow_error:"):
                event_stage = "checkout:error"
            self.database.add_order_event(
                order_id,
                event_stage,
                text,
                int((time.perf_counter() - flow_started) * 1000),
            )
            step = "prepare_checkout"
            progress = 30
            if "flow_step:confirm_payment" in lowered_log:
                step, progress = "confirm_payment", 65
            elif "flow_step:verify_result" in lowered_log:
                step, progress = "verify_result", 85
            elif "payment method" in lowered_log or "inline_payment_method_data" in lowered_log:
                step, progress = "create_payment_method", 45
            self.database.update_order(
                order_id,
                step=step,
                progress=progress,
                error_message=text,
            )

        try:
            result = self.platform_checkout.charge(
                payload.get("session"),
                payment_method,
                checkout,
                billing,
                card=card,
                card_last4=last4,
                logger=checkout_logger,
            )
        except CheckoutError as exc:
            message = str(exc)[:500]
            lowered = message.lower()
            action_type = str(getattr(exc, "action_required", "") or "").strip()
            action_required = bool(action_type) or "requires_action" in lowered or "3ds" in lowered
            self.database.add_order_event(
                order_id,
                "payment_action_required" if action_required else "checkout_failed",
                message,
                int((time.perf_counter() - flow_started) * 1000),
            )
            action_url = str(getattr(exc, "checkout_link", "") or "").strip()
            action_details = getattr(exc, "action_details", {})
            if not isinstance(action_details, dict):
                action_details = {}
            refreshed_renewal_session = getattr(exc, "renewal_session", None)
            if refreshed_renewal_session is not None:
                with self._renewal_lock:
                    pending_renewal = self._pending_renewals.get(order_id)
                    if pending_renewal is not None:
                        self._pending_renewals[order_id] = (
                            refreshed_renewal_session,
                            pending_renewal[1],
                        )
            if not action_url:
                action_url = str(checkout.get("checkoutUrl") or "").strip()
            action_url = (
                str(action_details.get("next_action_url") or "").strip()
                or action_url
            )
            evidence = self._payment_evidence(message, action_details)
            intent_status = str(evidence.get("intent_status") or "").lower()
            processing = (
                "processing timeout" in lowered
                or intent_status in {"processing", "requires_confirmation"}
            )
            subscription_marker = (
                "payment terminal succeeded; subscription pending" in lowered
            )
            post_payment_failure = bool(
                evidence.get("payment_terminal")
                and not action_required
                and evidence.get("payment_stage") in {
                    "checkout_finalize",
                    "subscription_verify",
                    "payment_method_sync",
                }
            )
            subscription_pending = bool(
                evidence.get("payment_terminal")
                and (subscription_marker or post_payment_failure)
            )
            terminal_unverified = bool(subscription_marker and not subscription_pending)
            auth_refresh_required = bool(
                subscription_pending
                and any(
                    marker in lowered
                    for marker in (
                        "token_expired",
                        "token expired",
                        "authentication token is expired",
                        "http 401",
                    )
                )
            )
            normalized_action_type = action_type or (
                "stripe_3ds" if action_required else "payment_processing" if processing else ""
            )
            action_payload = _safe_action_payload(action_details)
            missing_context = action_details.get("missing_context")
            context_diagnostics = action_details.get("context_diagnostics")
            if missing_context or context_diagnostics:
                message = (
                    f"{message} | missing_context={json.dumps(missing_context or [], ensure_ascii=False)} "
                    f"context_diagnostics={json.dumps(context_diagnostics or {}, ensure_ascii=False)}"
                )[:500]
            if (
                action_required
                or processing
                or subscription_marker
                or subscription_pending
                or terminal_unverified
            ):
                if action_type == "checkout_session_confirmation":
                    pending_step = "confirm_payment"
                    pending_progress = 75
                    pending_code = "checkout_session_confirmation_required"
                elif action_required:
                    pending_step = "confirm_payment"
                    pending_progress = 72
                    pending_code = "stripe_action_required"
                elif processing:
                    pending_step = "confirm_payment"
                    pending_progress = 72
                    pending_code = "payment_processing"
                elif subscription_pending:
                    pending_step = "verify_result"
                    pending_progress = 90
                    pending_code = (
                        "auth_refresh_required"
                        if auth_refresh_required
                        else "subscription_pending"
                    )
                else:
                    pending_step = "confirm_payment"
                    pending_progress = 70
                    pending_code = "payment_terminal_unverified"

                pending_updates: dict[str, Any] = {
                    "recovery_next_at": self._utc_after(CHECKOUT_RECOVERY_INTERVAL),
                    "completed_at": None,
                }
                if evidence.get("intent_id"):
                    pending_updates["confirmation_ref"] = evidence["intent_id"]
                if evidence.get("intent_type"):
                    pending_updates["intent_type"] = evidence["intent_type"]
                if intent_status:
                    pending_updates["payment_terminal_status"] = (
                        "succeeded"
                        if evidence.get("payment_terminal")
                        else intent_status
                    )
                if evidence.get("return_url_status") is not None:
                    pending_updates["return_url_status"] = evidence["return_url_status"]
                if evidence.get("checkout_state"):
                    pending_updates["checkout_terminal_status"] = evidence["checkout_state"]
                elif evidence.get("checkout_status") is not None:
                    pending_updates["checkout_terminal_status"] = str(
                        evidence["checkout_status"]
                    )
                if evidence.get("amount_minor") is not None:
                    pending_updates["amount_minor"] = evidence["amount_minor"]
                if normalized_action_type:
                    pending_updates["payment_action_type"] = normalized_action_type
                pending_updates["payment_action_payload"] = action_payload
                latest = self.database.update_order(
                    order_id,
                    status="awaiting_payment",
                    step=pending_step,
                    progress=pending_progress,
                    error_code=pending_code,
                    error_message=message,
                    payment_action_url=(
                        None
                        if subscription_pending or terminal_unverified
                        else action_url[:1000] or None
                    ),
                    **pending_updates,
                ) or order
                return {
                    "order": self.public_order(latest),
                    "checkoutStatus": (
                        "auth_refresh_required"
                        if auth_refresh_required
                        else "subscription_pending" if subscription_pending
                        else "payment_terminal_unverified"
                        if terminal_unverified
                        else "requires_action" if action_required else "processing"
                    ),
                    "subscriptionPlan": "",
                    "actionRequired": action_required,
                    "actionType": normalized_action_type,
                    "checkoutLink": action_url,
                    "actionDetails": action_details,
                    "idempotent": False,
                }
            with self._renewal_lock:
                self._pending_renewals.pop(order_id, None)
                self._pending_checkout_context.pop(order_id, None)
            failure_code = "platform_checkout_failed"
            failure_step = "failed"
            failure_progress = 100
            for marker, code in (
                ("unsupported for publishable key tokenization", "publishable_key_tokenization_unsupported"),
                ("card_declined", "card_declined"),
                ("requires_payment_method", "requires_payment_method"),
                ("payment page poll: failed", "payment_page_failed"),
                ("payment page poll: expired", "payment_page_expired"),
                ("payment page poll: canceled", "payment_page_canceled"),
                ("processing timeout", "payment_processing_timeout"),
                ("checkout amount unavailable", "checkout_amount_unavailable"),
                ("api.stripe.com", "stripe_proxy_unavailable"),
            ):
                if marker in lowered:
                    failure_code = code
                    break
            if (
                "payment method" in lowered
                or "inline card" in lowered
                or failure_code == "publishable_key_tokenization_unsupported"
            ):
                failure_step, failure_progress = "create_payment_method", 45
            elif "confirm" in lowered or "confirmation token" in lowered or "intent" in lowered:
                failure_step, failure_progress = "confirm_payment", 70
            elif "subscription" in lowered or "plus" in lowered or "poll" in lowered:
                failure_step, failure_progress = "verify_result", 90
            latest = self.database.update_order(
                order_id,
                status="failed",
                step=failure_step,
                progress=failure_progress,
                error_code=failure_code,
                error_message=message,
                completed_at=utc_now(),
                renewal_cancel_status="not_required",
            ) or order
            raise ServiceError(
                failure_code,
                message,
                502,
                {"order": self.public_order(latest)},
            ) from exc
        finally:
            card.clear()
        payment_contract = str(result.get("payment_contract") or "stripe_payment_page")
        result_intent_id = str(result.get("intent_id") or "").strip()
        result_intent_type = str(result.get("intent_type") or "").strip().lower()
        payment_terminal = (
            str(result.get("intent_status") or "").lower() == "succeeded"
            and bool(
                re.fullmatch(r"(?:pi|seti)_[A-Za-z0-9_]+", result_intent_id)
                and result_intent_type in {"payment_intent", "setup_intent"}
            )
            if payment_contract == "oaics_confirmation_token"
            else str(result.get("poll_state") or "").lower() == "succeeded"
        )
        subscription_active = subscription_matches_plan(
            plan_type, result.get("subscription_plan")
        )
        if result.get("ok") and payment_terminal and not subscription_active:
            pending_updates: dict[str, Any] = {
                "status": "awaiting_payment",
                "step": "verify_result",
                "progress": 90,
                "error_code": "subscription_pending",
                "error_message": "支付终态已确认，Vendor Checkout 或 Plus 仍在同步",
                "payment_terminal_status": "succeeded",
                "checkout_terminal_status": str(
                    result.get("checkout_state")
                    or result.get("poll_state")
                    or result.get("checkout_verify_status")
                    or "pending"
                ),
                "intent_type": str(result.get("intent_type") or "") or None,
                "payment_action_type": None,
                "completed_at": None,
                "recovery_next_at": self._utc_after(CHECKOUT_RECOVERY_INTERVAL),
            }
            if result.get("intent_id"):
                pending_updates["confirmation_ref"] = str(result.get("intent_id"))
            if result.get("return_url_status") is not None:
                pending_updates["return_url_status"] = int(result["return_url_status"])
            if result.get("confirm_return_url"):
                pending_updates["confirm_return_url"] = str(result["confirm_return_url"])
            latest = self.database.update_order(order_id, **pending_updates) or order
            return {
                "order": self.public_order(latest),
                "checkoutStatus": "subscription_pending",
                "subscriptionPlan": "",
                "actionRequired": False,
                "idempotent": False,
            }
        if not result.get("ok") or not payment_terminal:
            with self._renewal_lock:
                self._pending_renewals.pop(order_id, None)
                self._pending_checkout_context.pop(order_id, None)
            latest = self.database.update_order(
                order_id,
                status="failed",
                step="failed",
                progress=100,
                error_code="checkout_verification_failed",
                error_message="当前 Checkout 未同时通过支付终态和 Platform Plus 核验",
                completed_at=utc_now(),
                renewal_cancel_status="not_required",
            ) or order
            raise ServiceError(
                "checkout_verification_failed",
                "当前 Checkout 未同时通过支付终态和 Platform Plus 核验",
                502,
                {"order": self.public_order(latest)},
            )
        result_last4 = re.sub(r"\D", "", str(result.get("card_last4") or last4))[-4:]
        success_updates = {
            "provider_ref": checkout_id or None,
            "payment_last4": result_last4 if len(result_last4) == 4 else "----",
            "status": "succeeded",
            "step": "completed",
            "progress": 100,
            "confirmation_ref": checkout_id or order["order_key"],
            "completed_at": utc_now(),
            "error_code": None,
            "error_message": None,
            "payment_action_url": None,
            "payment_action_type": None,
            "recovery_next_at": None,
            "payment_terminal_status": str(result.get("intent_status") or result.get("payment_status") or "succeeded"),
            "checkout_terminal_status": str(
                result.get("checkout_state")
                or result.get("poll_state")
                or result.get("checkout_verify_status")
                or "succeeded"
            ),
            "intent_type": str(result.get("intent_type") or "") or None,
            "processor_entity": str(result.get("processor_entity") or processor_entity),
            "payment_contract": payment_contract,
        }
        if result.get("intent_id"):
            success_updates["confirmation_ref"] = str(result.get("intent_id"))
        if result.get("return_url_status") is not None:
            success_updates["return_url_status"] = int(result["return_url_status"])
        if result.get("confirm_return_url"):
            success_updates["confirm_return_url"] = str(result["confirm_return_url"])
        renewal_session = result.pop("_renewal_session", None)
        if renewal_session:
            with self._renewal_lock:
                pending_renewal = self._pending_renewals.get(order_id)
                if pending_renewal:
                    self._pending_renewals[order_id] = (
                        renewal_session,
                        pending_renewal[1],
                    )
        result_amount = result.get("amount_minor")
        if result_amount is not None:
            try:
                normalized_result_amount = int(result_amount)
            except (TypeError, ValueError):
                normalized_result_amount = -1
            if normalized_result_amount >= 0:
                success_updates["amount_minor"] = normalized_result_amount
        self.database.update_order(
            order_id,
            **success_updates,
        )
        self.database.add_order_event(
            order_id,
            "order_completed",
            "Checkout、Stripe Intent、Plus 和 PaymentMethod 核验完成",
            int((time.perf_counter() - flow_started) * 1000),
        )
        self._maybe_cancel_renewal(order_id)
        latest = self.database.get_order_by_id(order_id) or order
        self.database.add_order_event(
            order_id,
            "renewal_cancel",
            str(
                latest.get("renewal_cancel_message")
                or latest.get("renewal_cancel_status")
                or "renewal cancellation finished"
            ),
            int((time.perf_counter() - flow_started) * 1000),
        )
        return {
            "order": self.public_order(latest),
            "checkoutStatus": result.get("checkout_status") or "succeeded",
            "paymentContract": payment_contract,
            "pollState": result.get("poll_state") or "",
            "intentStatus": result.get("intent_status") or "",
            "subscriptionPlan": result.get("subscription_plan") or plan_type,
            "paymentMethodDetails": {
                "brand": result.get("card_brand") or "",
                "last4": result.get("card_last4") or "",
                "expMonth": result.get("card_exp_month") or "",
                "expYear": result.get("card_exp_year") or "",
                "isDefault": result.get("payment_method_is_default"),
            },
            "actionRequired": False,
            "idempotent": False,
        }

    def charge_stripe_order(self, payload: dict[str, Any]) -> dict[str, Any]:
        if self.platform_checkout and self.platform_checkout.enabled:
            return self.charge_platform_checkout_order(payload)
        if not self.stripe_gateway or not self.stripe_gateway.enabled:
            raise ServiceError("stripe_not_configured", "Stripe 测试配置未启用")
        api_key = self._validate_access_key(payload.get("apiKey"), require_managed=True)
        plan_type = str(payload.get("planType") or "").strip()
        payment_method = str(payload.get("paymentMethodId") or "").strip()
        if plan_type not in PLANS:
            raise ServiceError("invalid_plan", "套餐类型无效")
        if not re.fullmatch(r"pm_[A-Za-z0-9_]+", payment_method):
            raise ServiceError("invalid_payment_method", "PaymentMethod ID 必须是 pm_ 开头的 Stripe 标识")
        summary = self.validate_session(payload.get("session"))
        if summary["expired"]:
            raise ServiceError("session_expired", "Session 已过期")
        if not summary["has_access_token"]:
            raise ServiceError("session_token_required", "自动取消续费需要 Session JSON 中包含 accessToken")
        plan = PLANS[plan_type]
        order = self.database.create_order(
            {
                "order_key": f"XY-{secrets.token_hex(6).upper()}",
                "api_key_hash": key_fingerprint(api_key),
                "api_key_prefix": f"{api_key[:6]}...",
                "plan_type": plan_type,
                "plan_name": plan["name"],
                "amount_minor": plan["amount_minor"],
                "currency": plan["currency"],
                "email": summary["email"],
                "account_ref": summary["account_ref"],
                "session_fingerprint": summary["fingerprint"],
                "provider": "stripe",
                "payment_fixture": "stripe_api",
                "payment_last4": "----",
                "renewal_cancel_requested": 1,
                "renewal_cancel_status": "pending",
                "_status": "queued",
                "_step": "confirm_payment",
                "_progress": 12,
            }
        )
        with self._renewal_lock:
            self._pending_renewals[int(order["id"])] = (payload.get("session"), str(payload.get("accountId") or ""))
        try:
            intent = self.stripe_gateway.create_payment_intent(
                amount_minor=plan["amount_minor"],
                currency=plan["currency"],
                order_key=order["order_key"],
                plan_type=plan_type,
                payment_method=payment_method,
                confirm=True,
            )
        except StripeError as exc:
            with self._renewal_lock:
                self._pending_renewals.pop(int(order["id"]), None)
            self.database.update_order(
                int(order["id"]),
                status="failed",
                step="failed",
                progress=100,
                error_code="stripe_charge_failed",
                error_message=str(exc)[:500],
                completed_at=utc_now(),
                renewal_cancel_status="not_required",
            )
            raise ServiceError("stripe_charge_failed", str(exc), 502) from exc
        intent_id = str(intent.get("id") or "")
        if not intent_id:
            raise ServiceError("stripe_invalid_response", "Stripe 未返回 PaymentIntent 信息", 502)
        order = self.database.update_order(int(order["id"]), provider_ref=intent_id) or order
        self._apply_stripe_intent(intent, order)
        self._maybe_cancel_renewal(int(order["id"]))
        order = self.database.get_order_by_id(int(order["id"])) or order
        return {
            "order": self.public_order(order),
            "stripeStatus": intent.get("status"),
            "actionRequired": intent.get("status") in {"requires_action", "requires_confirmation"},
        }

    def sync_stripe_order(self, payload: dict[str, Any]) -> dict[str, Any]:
        api_key = self._validate_access_key(payload.get("apiKey"), require_managed=True)
        order_key = str(payload.get("orderKey") or "").strip().upper()
        order = self.database.get_order(order_key, key_fingerprint(api_key))
        if not order:
            raise ServiceError("order_not_found", "订单不存在", 404)
        with self._checkout_sync_lock:
            if order_key in self._checkout_sync_in_progress:
                return self.public_order(order)
            self._checkout_sync_in_progress.add(order_key)
        try:
            return self._sync_stripe_order_unlocked(payload, api_key=api_key, order=order)
        finally:
            with self._checkout_sync_lock:
                self._checkout_sync_in_progress.discard(order_key)

    def _sync_stripe_order_unlocked(
        self,
        payload: dict[str, Any],
        *,
        api_key: str,
        order: dict[str, Any],
    ) -> dict[str, Any]:
        if self.platform_checkout and self.platform_checkout.enabled:
            if order["provider"] == "platform_checkout":
                order_id = int(order["id"])
                supplied_session = payload.get("session")
                recoverable_checkout = bool(
                    order.get("status") in {"failed", "awaiting_payment"}
                    and (
                        order.get("error_code") in CHECKOUT_RECOVERY_ERROR_CODES
                        or order.get("step") in {"confirm_payment", "verify_result"}
                        or "subscription verify" in str(order.get("error_message") or "").lower()
                    )
                )
                if supplied_session and recoverable_checkout:
                    summary = self.validate_session(supplied_session)
                    if summary["expired"]:
                        raise ServiceError("session_expired", "Session 已过期")
                    if summary["account_ref"] != order.get("account_ref"):
                        raise ServiceError("session_account_mismatch", "当前 Session 不属于该订单账户", 409)
                    checkout_context = self._checkout_context_for_order(order)
                    with self._renewal_lock:
                        self._pending_renewals[order_id] = (supplied_session, "")
                        self._pending_checkout_context[order_id] = checkout_context
                    resume_updates: dict[str, Any] = {
                        "status": "awaiting_payment",
                        "completed_at": None,
                        "renewal_cancel_status": "pending",
                        "renewal_cancel_message": None,
                        "recovery_attempts": 0,
                        "recovery_next_at": utc_now(),
                    }
                    if order.get("error_code") not in CHECKOUT_RECOVERY_ERROR_CODES:
                        if self._order_has_payment_terminal(order):
                            resume_updates.update(
                                step="verify_result",
                                progress=90,
                                error_code="subscription_pending",
                                error_message="支付终态已确认，正在继续核验 Checkout 与 Plus",
                            )
                        else:
                            resume_updates.update(
                                step="confirm_payment",
                                progress=70,
                                error_code="payment_recovery_required",
                                error_message="正在使用原账号 Session 核验支付确认状态",
                            )
                    order = self.database.update_order(
                        order_id,
                        **resume_updates,
                    ) or order
                if order["status"] == "awaiting_payment":
                    with self._renewal_lock:
                        pending = self._pending_renewals.get(order_id)
                        checkout_context = dict(self._pending_checkout_context.get(order_id) or {})
                    if pending and checkout_context:
                        try:
                            verified = self.platform_checkout.verify_subscription(pending[0], checkout_context)
                        except CheckoutError as exc:
                            verification_updates: dict[str, Any] = {
                                "status": "awaiting_payment",
                                "completed_at": None,
                                "recovery_next_at": self._utc_after(CHECKOUT_RECOVERY_INTERVAL),
                            }
                            if (
                                self._order_has_payment_terminal(order)
                                and order.get("error_code") not in PAYMENT_ACTION_ERROR_CODES
                            ):
                                verification_updates.update(
                                    step="verify_result",
                                    progress=90,
                                    error_code="subscription_pending",
                                    error_message=str(exc)[:500],
                                )
                            self.database.update_order(order_id, **verification_updates)
                        else:
                            verified_payment_terminal = bool(
                                verified.get("paymentTerminal")
                                or verified.get("pollState") == "succeeded"
                                or self._order_has_payment_terminal(order)
                            )
                            if verified.get("terminalFailure"):
                                self.database.update_order(
                                    order_id,
                                    status="failed",
                                    step="failed",
                                    progress=100,
                                    error_code=f"payment_page_{verified.get('pollState') or 'failed'}",
                                    error_message=f"Stripe Payment Page 终态：{verified.get('pollState') or 'failed'}",
                                    completed_at=utc_now(),
                                    renewal_cancel_status="not_required",
                                    payment_action_url=None,
                                    payment_action_type=None,
                                    recovery_next_at=None,
                                )
                                with self._renewal_lock:
                                    self._pending_renewals.pop(order_id, None)
                                    self._pending_checkout_context.pop(order_id, None)
                                release_context = getattr(
                                    self.platform_checkout,
                                    "release_checkout_context",
                                    None,
                                )
                                if callable(release_context):
                                    release_context(str(order.get("provider_ref") or ""))
                            elif verified.get("active") and verified_payment_terminal:
                                self.database.update_order(
                                    order_id,
                                    status="succeeded",
                                    step="completed",
                                    progress=100,
                                    confirmation_ref=(
                                        order.get("confirmation_ref")
                                        or order.get("provider_ref")
                                        or order["order_key"]
                                    ),
                                    completed_at=utc_now(),
                                    error_code=None,
                                    error_message=None,
                                    payment_action_url=None,
                                    payment_action_type=None,
                                    payment_terminal_status="succeeded",
                                    checkout_terminal_status=str(
                                        verified.get("checkoutState")
                                        or verified.get("pollState")
                                        or "succeeded"
                                    ),
                                    processor_entity=str(verified.get("processorEntity") or order.get("processor_entity") or ""),
                                    return_url_status=verified.get("returnUrlStatus"),
                                    recovery_next_at=None,
                                )
                            elif verified.get("active"):
                                active_updates: dict[str, Any] = {
                                    "status": "awaiting_payment",
                                    "step": "confirm_payment",
                                    "progress": 70,
                                    "completed_at": None,
                                    "checkout_terminal_status": str(
                                        verified.get("checkoutState")
                                        or order.get("checkout_terminal_status")
                                        or "unknown"
                                    ),
                                    "processor_entity": str(
                                        verified.get("processorEntity")
                                        or order.get("processor_entity")
                                        or ""
                                    ),
                                    "return_url_status": verified.get("returnUrlStatus"),
                                    "recovery_next_at": self._utc_after(CHECKOUT_RECOVERY_INTERVAL),
                                }
                                if order.get("error_code") in PAYMENT_ACTION_ERROR_CODES:
                                    active_updates.update(
                                        progress=int(order.get("progress") or 72),
                                        error_code=order.get("error_code"),
                                        error_message=order.get("error_message"),
                                    )
                                else:
                                    active_updates.update(
                                        error_code="payment_terminal_unverified",
                                        error_message=(
                                            "账号已有 Plus，但尚未取得本订单的 "
                                            "Stripe/Checkout 支付终态证据"
                                        ),
                                    )
                                self.database.update_order(order_id, **active_updates)
                            elif verified.get("pending"):
                                pending_updates: dict[str, Any] = {
                                    "status": "awaiting_payment",
                                    "completed_at": None,
                                    "recovery_next_at": self._utc_after(CHECKOUT_RECOVERY_INTERVAL),
                                    "checkout_terminal_status": str(
                                        verified.get("checkoutState")
                                        or verified.get("pollState")
                                        or order.get("checkout_terminal_status")
                                        or "pending"
                                    ),
                                    "processor_entity": str(
                                        verified.get("processorEntity")
                                        or order.get("processor_entity")
                                        or ""
                                    ),
                                    "return_url_status": verified.get("returnUrlStatus"),
                                }
                                verified_action_details = verified.get("actionDetails")
                                if isinstance(verified_action_details, dict) and verified_action_details:
                                    action_evidence = self._payment_evidence(
                                        "", verified_action_details
                                    )
                                    pending_updates["payment_action_payload"] = (
                                        _safe_action_payload(verified_action_details)
                                    )
                                    polled_action_url = str(
                                        verified.get("paymentActionUrl")
                                        or verified_action_details.get("next_action_url")
                                        or _action_url(
                                            verified_action_details.get("next_action")
                                        )
                                        or order.get("payment_action_url")
                                        or ""
                                    ).strip()
                                    if polled_action_url:
                                        pending_updates["payment_action_url"] = (
                                            polled_action_url[:1000]
                                        )
                                    pending_updates["payment_action_type"] = str(
                                        verified_action_details.get("next_action_type")
                                        or order.get("payment_action_type")
                                        or "stripe_3ds"
                                    )
                                    if action_evidence.get("intent_id"):
                                        pending_updates["confirmation_ref"] = (
                                            action_evidence["intent_id"]
                                        )
                                    if action_evidence.get("intent_type"):
                                        pending_updates["intent_type"] = (
                                            action_evidence["intent_type"]
                                        )
                                    if action_evidence.get("intent_status"):
                                        pending_updates["payment_terminal_status"] = (
                                            action_evidence["intent_status"]
                                        )
                                if verified.get("actionRequired"):
                                    pending_updates.update(
                                        step="confirm_payment",
                                        progress=72,
                                        error_code="stripe_action_required",
                                        error_message=(
                                            "Stripe Intent 正在等待 3DS 或发卡行验证；"
                                            "验证入口和完整动作数据已保留"
                                        ),
                                    )
                                if verified_payment_terminal:
                                    pending_updates.update(
                                        step="verify_result",
                                        progress=90,
                                        error_code="subscription_pending",
                                        error_message=(
                                            "Stripe/Checkout 支付终态已确认，Plus 仍在同步；"
                                            f"订阅接口 HTTP {verified.get('subscriptionStatus') or 0}"
                                        ),
                                        payment_terminal_status="succeeded",
                                        payment_action_url=None,
                                        payment_action_type=None,
                                    )
                                elif (
                                    not verified.get("actionRequired")
                                    and order.get("error_code")
                                    not in PAYMENT_ACTION_ERROR_CODES
                                ):
                                    pending_updates.update(
                                        step="confirm_payment",
                                        progress=70,
                                        error_code="payment_terminal_unverified",
                                        error_message="尚未取得当前 Stripe Intent 的支付成功终态",
                                    )
                                self.database.update_order(order_id, **pending_updates)
                self._maybe_cancel_renewal(int(order["id"]))
                latest = self.database.get_order_by_id(int(order["id"])) or order
                return self.public_order(latest)
        if not self.stripe_gateway or not self.stripe_gateway.enabled:
            raise ServiceError("stripe_not_configured", "Stripe 测试配置未启用")
        if order["provider"] != "stripe" or not order.get("provider_ref"):
            raise ServiceError("not_stripe_order", "订单不是 Stripe 支付订单")
        try:
            intent = self.stripe_gateway.retrieve_payment_intent(order["provider_ref"])
        except StripeError as exc:
            raise ServiceError("stripe_sync_failed", str(exc), 502) from exc
        self._apply_stripe_intent(intent, order)
        self._maybe_cancel_renewal(int(order["id"]))
        latest = self.database.get_order_by_id(int(order["id"]))
        return self.public_order(latest or order)

    def handle_stripe_webhook(self, event: dict[str, Any]) -> bool:
        event_type = str(event.get("type") or "")
        data = event.get("data") if isinstance(event.get("data"), dict) else {}
        intent = data.get("object") if isinstance(data.get("object"), dict) else {}
        if not event_type.startswith("payment_intent."):
            return False
        metadata = intent.get("metadata") if isinstance(intent.get("metadata"), dict) else {}
        order_key = str(metadata.get("order_key") or "").upper()
        if not order_key:
            return False
        order = self.database.get_order_by_key(order_key)
        if not order or order["provider"] != "stripe":
            return False
        self._apply_stripe_intent(intent, order)
        self._maybe_cancel_renewal(int(order["id"]))
        return True

    def order_status(self, payload: dict[str, Any]) -> dict[str, Any]:
        api_key = self._validate_access_key(payload.get("apiKey"))
        order_key = str(payload.get("orderKey") or "").strip().upper()
        if not order_key:
            raise ServiceError("missing_order_key", "缺少订单号")
        order = self.database.get_order(order_key, hash_api_key(api_key))
        if not order:
            raise ServiceError("order_not_found", "订单不存在", 404)
        return self.public_order(order, include_timeline=True)

    def list_orders(self, payload: dict[str, Any]) -> dict[str, Any]:
        api_key = self._validate_access_key(payload.get("apiKey"))
        try:
            page = max(1, int(payload.get("page") or 1))
            page_size = min(50, max(1, int(payload.get("pageSize") or 20)))
        except (TypeError, ValueError) as exc:
            raise ServiceError("invalid_pagination", "分页参数无效") from exc
        rows, total = self.database.list_orders(hash_api_key(api_key), page, page_size)
        return {
            "items": [self.public_order(row) for row in rows],
            "total": total,
            "page": page,
            "pageSize": page_size,
        }

    def retry_order(self, order_key: str, payload: dict[str, Any]) -> dict[str, Any]:
        api_key = self._validate_access_key(payload.get("apiKey"))
        order = self.database.get_order(order_key.upper(), hash_api_key(api_key))
        if not order:
            raise ServiceError("order_not_found", "订单不存在", 404)
        if order["provider"] != "sandbox":
            raise ServiceError("order_not_retryable", "Stripe 订单请从支付页面重新确认", 409)
        retried = self.database.retry_order(int(order["id"]))
        if not retried:
            raise ServiceError("order_not_retryable", "只有失败订单可以重试", 409)
        self.queue.put(int(retried["id"]))
        return self.public_order(retried)

    def public_order(
        self, order: dict[str, Any], *, include_timeline: bool = False
    ) -> dict[str, Any]:
        try:
            stored_amount = int(order["amount_minor"])
        except (TypeError, ValueError):
            stored_amount = -1
        action_details: Any = None
        raw_action_payload = order.get("payment_action_payload")
        if raw_action_payload:
            try:
                action_details = json.loads(str(raw_action_payload))
            except (TypeError, ValueError):
                action_details = str(raw_action_payload)
        timeline = []
        if include_timeline and order.get("id") is not None:
            timeline = [
                {
                    "stage": event.get("stage"),
                    "message": event.get("message"),
                    "elapsedMs": int(event.get("elapsed_ms") or 0),
                    "createdAt": event.get("created_at"),
                }
                for event in self.database.order_events(int(order["id"]))
            ]
        return {
            "orderKey": order["order_key"],
            "cardKey": order.get("card_key"),
            "apiKeyPrefix": order["api_key_prefix"],
            "planType": order["plan_type"],
            "planName": order["plan_name"],
            "amountMinor": stored_amount if stored_amount >= 0 else None,
            "amountKnown": stored_amount >= 0,
            "currency": order["currency"],
            "email": order["email"],
            "accountRef": order["account_ref"],
            "provider": order["provider"],
            "paymentLast4": order["payment_last4"],
            "providerRef": order.get("provider_ref"),
            "checkoutProvider": order.get("checkout_provider"),
            "checkoutCountry": order.get("checkout_country"),
            "paymentPageId": order.get("payment_page_id"),
            "processorEntity": order.get("processor_entity"),
            "paymentContract": order.get("payment_contract"),
            "intentType": order.get("intent_type"),
            "paymentTerminalStatus": order.get("payment_terminal_status"),
            "checkoutTerminalStatus": order.get("checkout_terminal_status"),
            "returnUrlStatus": order.get("return_url_status"),
            "recoveryAttempts": int(order.get("recovery_attempts") or 0),
            "recoveryNextAt": order.get("recovery_next_at"),
            "status": order["status"],
            "step": order["step"],
            "stepLabel": STEP_LABELS.get(order["step"], order["step"]),
            "progress": order["progress"],
            "retryCount": order["retry_count"],
            "confirmationRef": order["confirmation_ref"],
            "errorCode": order["error_code"],
            "errorMessage": order["error_message"],
            "paymentActionUrl": order.get("payment_action_url"),
            "paymentActionType": order.get("payment_action_type"),
            "paymentActionDetails": action_details,
            "createdAt": order["created_at"],
            "updatedAt": order["updated_at"],
            "completedAt": order["completed_at"],
            "timeline": timeline,
            "renewal": {
                "requested": bool(order.get("renewal_cancel_requested")),
                "status": order.get("renewal_cancel_status") or "not_required",
                "message": order.get("renewal_cancel_message"),
                "activeUntil": order.get("renewal_active_until"),
                "cancelledAt": order.get("renewal_cancelled_at"),
                "retryCount": int(order.get("renewal_retry_count") or 0),
            },
        }

    @staticmethod
    def _checkout_context_for_order(order: dict[str, Any]) -> dict[str, Any]:
        checkout_id = str(order.get("provider_ref") or "").strip()
        if checkout_id.startswith("oaics_"):
            checkout_provider = "oaics"
            payment_contract = "oaics_confirmation_token"
            payment_page_id = ""
        elif checkout_id.startswith(("cs_live_", "cs_test_", "cs_")):
            checkout_provider = "stripe"
            payment_contract = "stripe_payment_page"
            payment_page_id = str(order.get("payment_page_id") or checkout_id)
        else:
            raise ServiceError("invalid_checkout", "Stored Checkout ID is invalid", 502)
        processor = str(order.get("processor_entity") or "vendor_ie").strip()
        return {
            "checkoutId": checkout_id,
            "planType": str(order.get("plan_type") or "plus").strip().lower(),
            "planName": str(order.get("plan_name") or "").strip(),
            "checkoutProvider": checkout_provider,
            "country": str(order.get("checkout_country") or "PH").upper(),
            "currency": str(order.get("currency") or "PHP").upper(),
            "paymentPageId": payment_page_id,
            "paymentContract": payment_contract,
            "cardInputModes": ["api_card", "stripe_elements"],
            "defaultCardInputMode": "api_card",
            "processorEntity": processor,
            "publishableKey": str(order.get("checkout_publishable_key") or ""),
            "confirmReturnUrl": str(order.get("confirm_return_url") or ""),
            "paymentTerminalStatus": str(order.get("payment_terminal_status") or ""),
            "checkoutTerminalStatus": str(order.get("checkout_terminal_status") or ""),
            "intentType": str(order.get("intent_type") or ""),
            "intentId": str(order.get("confirmation_ref") or ""),
        }

    def setup_admin(self, payload: dict[str, Any]) -> dict[str, str]:
        if self.database.admin_count():
            raise ServiceError("admin_already_setup", "管理员已经完成初始化", 409)
        username = str(payload.get("username") or "").strip()
        password = str(payload.get("password") or "")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username):
            raise ServiceError("invalid_admin_username", "管理员用户名需为 3-32 位字母、数字、点、下划线或连字符")
        try:
            password_hash = hash_password(password)
        except ValueError as exc:
            raise ServiceError("invalid_admin_password", str(exc)) from exc
        self.database.create_admin(username, password_hash)
        token = create_admin_token()
        self.database.create_admin_session(token_hash(token), username, 8 * 3600)
        return {"username": username, "token": token}

    def login_admin(self, payload: dict[str, Any]) -> dict[str, str]:
        username = str(payload.get("username") or "").strip()
        password = str(payload.get("password") or "")
        admin = self.database.get_admin(username)
        if not admin or not verify_password(password, admin["password_hash"]):
            raise ServiceError("admin_login_failed", "管理员用户名或密码错误", 401)
        token = create_admin_token()
        self.database.create_admin_session(token_hash(token), username, 8 * 3600)
        return {"username": username, "token": token}

    def admin_identity(self, token: str) -> str | None:
        return self.database.lookup_admin_session(token_hash(token)) if token else None

    def logout_admin(self, token: str) -> None:
        if token:
            self.database.delete_admin_session(token_hash(token))

    def create_managed_key(self, token: str, label: str) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        label = str(label or "未命名 Key").strip()[:80] or "未命名 Key"
        plaintext = create_managed_api_key()
        row = self.database.create_api_key(key_fingerprint(plaintext), f"{plaintext[:12]}...", label)
        return {"key": plaintext, "record": self.public_api_key(row)}

    def list_managed_keys(self, token: str) -> list[dict[str, Any]]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        return [self.public_api_key(row) for row in self.database.list_api_keys()]

    def revoke_managed_key(self, token: str, key_id: int) -> None:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        if not self.database.revoke_api_key(key_id):
            raise ServiceError("api_key_not_found", "API Key 不存在或已经吊销", 404)

    def proxy_admin_status(self, token: str) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        if not self.platform_checkout:
            raise ServiceError("platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503)
        return self._proxy_status_with_storage()

    def configure_proxy(self, token: str, payload: dict[str, Any]) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        if not self.platform_checkout:
            raise ServiceError("platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503)
        values = payload.get("proxies") if payload.get("proxies") is not None else payload.get("proxy")
        role = str(payload.get("role") or "both").strip().lower()
        try:
            status = self.platform_checkout.configure_proxy(
                values,
                role=role,
            )
            for proxy_role in (("platform", "stripe") if role == "both" else (role,)):
                self._save_proxy_role(proxy_role)
            return self._proxy_status_with_storage(status)
        except CheckoutError as exc:
            raise ServiceError("invalid_proxy_configuration", str(exc)) from exc

    def probe_proxy(self, token: str) -> dict[str, Any]:
        if not self.admin_identity(token):
            raise ServiceError("admin_unauthorized", "需要管理员登录", 401)
        if not self.platform_checkout:
            raise ServiceError("platform_checkout_unavailable", "Platform Checkout 适配器未加载", 503)
        return self.platform_checkout.probe_proxy()

    @staticmethod
    def public_api_key(row: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": row["id"],
            "prefix": row["key_prefix"],
            "label": row["label"],
            "status": row["status"],
            "createdAt": row["created_at"],
            "lastUsedAt": row["last_used_at"],
            "revokedAt": row["revoked_at"],
        }

    def _validate_access_key(self, value: Any, require_managed: bool = False) -> str:
        key = validate_api_key(value)
        managed = self.database.get_active_api_key(key_fingerprint(key))
        if require_managed or self.require_managed_keys:
            if not managed:
                raise ServiceError("api_key_not_registered", "API Key 未在管理后台登记或已经吊销", 403)
        if managed:
            self.database.touch_api_key(key_fingerprint(key))
        return key

    def _maybe_cancel_renewal(self, order_id: int) -> None:
        order = self.database.get_order_by_id(order_id)
        if not order or not order.get("renewal_cancel_requested"):
            return
        if order.get("status") != "succeeded":
            if order.get("status") == "failed":
                with self._renewal_lock:
                    self._pending_renewals.pop(order_id, None)
                    self._pending_checkout_context.pop(order_id, None)
                self.database.update_order(order_id, renewal_cancel_status="not_required")
            return
        if order.get("renewal_cancel_status") in {"succeeded", "failed"}:
            return
        with self._renewal_lock:
            if order_id in self._renewal_in_progress:
                return
            pending = self._pending_renewals.get(order_id)
            if pending is not None:
                self._renewal_in_progress.add(order_id)
        if pending is None:
            self.database.update_order(
                order_id,
                renewal_cancel_status="unavailable",
                renewal_cancel_message="支付已完成，但当前进程没有保留续费取消所需的 Session。",
            )
            return
        session, account_id = pending
        attempts = int(order.get("renewal_retry_count") or 0)
        completed = False
        try:
            while attempts < RENEWAL_MAX_ATTEMPTS:
                attempts += 1
                self.database.update_order(
                    order_id,
                    renewal_cancel_status="running",
                    renewal_cancel_message=None,
                    renewal_retry_count=attempts,
                )
                try:
                    result = self.renewal_adapter.cancel(session, account_id)
                except RenewalError as exc:
                    if getattr(exc, "credential_error", False):
                        self.database.update_order(
                            order_id,
                            renewal_cancel_status="failed",
                            renewal_cancel_message=(
                                "自动取消续费需要新的 Platform Session："
                                f"{str(exc)[:380]}"
                            ),
                        )
                        completed = True
                        break
                    if attempts >= RENEWAL_MAX_ATTEMPTS:
                        self.database.update_order(
                            order_id,
                            renewal_cancel_status="failed",
                            renewal_cancel_message=f"自动重试 {attempts} 次后失败：{str(exc)[:420]}",
                        )
                        completed = True
                    else:
                        self.database.update_order(
                            order_id,
                            renewal_cancel_status="pending",
                            renewal_cancel_message=f"第 {attempts} 次取消失败，准备重试",
                        )
                        time.sleep(0.2 * attempts)
                    continue
                self.database.update_order(
                    order_id,
                    renewal_cancel_status="succeeded",
                    renewal_cancel_message="Platform 自动续费已取消",
                    renewal_active_until=str(result.get("active_until") or "") or None,
                    renewal_cancelled_at=utc_now(),
                )
                completed = True
                break
        finally:
            with self._renewal_lock:
                self._renewal_in_progress.discard(order_id)
                if completed:
                    self._pending_renewals.pop(order_id, None)
                    self._pending_checkout_context.pop(order_id, None)

    def _apply_stripe_intent(self, intent: dict[str, Any], order: dict[str, Any]) -> None:
        intent_id = str(intent.get("id") or order.get("provider_ref") or "")
        status = str(intent.get("status") or "")
        payment_method = intent.get("payment_method") if isinstance(intent.get("payment_method"), dict) else {}
        card = payment_method.get("card") if isinstance(payment_method.get("card"), dict) else {}
        updates: dict[str, Any] = {"provider_ref": intent_id}
        next_action = intent.get("next_action")
        if next_action is not None:
            action_details = {
                "payment_stage": "intent_sync",
                "intent_id": intent_id,
                "intent_status": status.lower(),
                "next_action": next_action,
                "next_action_type": (
                    next_action.get("type") if isinstance(next_action, dict) else ""
                ),
            }
            updates["payment_action_payload"] = _safe_action_payload(action_details)
            updates["payment_action_type"] = str(
                action_details.get("next_action_type") or "stripe_action"
            )
            updates["payment_action_url"] = _action_url(next_action) or None
        if card.get("last4"):
            updates["payment_last4"] = str(card["last4"])
        if status == "succeeded":
            updates.update(status="succeeded", step="completed", progress=100, confirmation_ref=intent_id, completed_at=utc_now())
        elif status == "processing":
            updates.update(status="running", step="confirm_payment", progress=85)
        elif status in {"requires_action", "requires_confirmation"}:
            updates.update(
                status="awaiting_payment",
                step="confirm_payment",
                progress=72,
                error_code="stripe_action_required",
                error_message="Stripe Intent 需要完成 3DS 或发卡行验证；验证入口和状态已保留",
                completed_at=None,
                recovery_next_at=None,
                renewal_cancel_status="pending",
            )
        elif status == "requires_payment_method":
            last_error = intent.get("last_payment_error") if isinstance(intent.get("last_payment_error"), dict) else {}
            if last_error:
                updates.update(
                    status="failed",
                    step="failed",
                    progress=100,
                    error_code=str(last_error.get("code") or "payment_method_rejected"),
                    error_message=str(last_error.get("message") or "Stripe PaymentMethod 被拒绝")[:500],
                    completed_at=utc_now(),
                )
            else:
                updates.update(status="awaiting_payment", step="confirm_payment", progress=8)
        elif status == "canceled":
            updates.update(status="failed", step="failed", progress=100, error_code="stripe_canceled", error_message="Stripe PaymentIntent 已取消", completed_at=utc_now())
        self.database.update_order(int(order["id"]), **updates)

    def _checkout_recovery_loop(self) -> None:
        while not self._stopping.is_set():
            self._recovery_wakeup.wait(CHECKOUT_RECOVERY_INTERVAL)
            self._recovery_wakeup.clear()
            if self._stopping.is_set():
                return
            self._run_checkout_recoveries()

    def _run_checkout_recoveries(self) -> None:
        if not self.platform_checkout or not self.platform_checkout.enabled:
            return
        for order in self.database.pending_checkout_recoveries(
            utc_now(), CHECKOUT_RECOVERY_MAX_ATTEMPTS
        ):
            order_key = str(order.get("order_key") or "").upper()
            order_id = int(order["id"])
            with self._renewal_lock:
                pending = self._pending_renewals.get(order_id)
                checkout_context = dict(self._pending_checkout_context.get(order_id) or {})
            if not pending or not checkout_context:
                continue
            with self._checkout_sync_lock:
                if order_key in self._checkout_sync_in_progress:
                    continue
                self._checkout_sync_in_progress.add(order_key)
            attempts = int(order.get("recovery_attempts") or 0) + 1
            try:
                self.database.update_order(
                    order_id,
                    recovery_attempts=attempts,
                    recovery_last_at=utc_now(),
                    recovery_next_at=self._utc_after(min(60.0, 2.0 ** min(attempts, 5))),
                )
                self._sync_stripe_order_unlocked({}, api_key="", order=order)
                latest = self.database.get_order_by_id(order_id)
                if (
                    latest
                    and latest.get("status") == "awaiting_payment"
                    and latest.get("error_code")
                    in {"stripe_action_required", "checkout_session_confirmation_required"}
                    and attempts >= CHECKOUT_RECOVERY_MAX_ATTEMPTS
                ):
                    self.database.update_order(
                        order_id,
                        recovery_next_at=None,
                        completed_at=None,
                    )
                    self.database.add_order_event(
                        order_id,
                        "payment_action_waiting",
                        "自动状态查询已暂停；订单继续等待持卡人完成 3DS 或发卡行验证",
                        0,
                    )
                    continue
                if (
                    latest
                    and latest.get("status") == "awaiting_payment"
                    and attempts >= CHECKOUT_RECOVERY_MAX_ATTEMPTS
                ):
                    subscription_stage = bool(
                        self._order_has_payment_terminal(latest)
                        and latest.get("error_code") not in PAYMENT_ACTION_ERROR_CODES
                    )
                    self.database.update_order(
                        order_id,
                        step="verify_result" if subscription_stage else "confirm_payment",
                        progress=90 if subscription_stage else 70,
                        error_code=(
                            "subscription_recovery_exhausted"
                            if subscription_stage
                            else "payment_recovery_exhausted"
                        ),
                        error_message=(
                            "已自动完成多次 Checkout/Plus 核验，订阅仍未同步"
                            if subscription_stage
                            else "已自动完成多次状态核验，支付或 Checkout 确认仍未完成"
                        ),
                        recovery_next_at=None,
                    )
                    release_context = getattr(
                        self.platform_checkout, "release_checkout_context", None
                    )
                    if callable(release_context):
                        release_context(str(order.get("provider_ref") or ""))
            except Exception as exc:
                latest = self.database.get_order_by_id(order_id) or order
                subscription_stage = bool(
                    self._order_has_payment_terminal(latest)
                    and latest.get("error_code") not in PAYMENT_ACTION_ERROR_CODES
                )
                action_waiting = bool(
                    latest.get("error_code")
                    in {"stripe_action_required", "checkout_session_confirmation_required"}
                )
                recovery_updates: dict[str, Any] = {
                    "status": "awaiting_payment",
                    "recovery_next_at": (
                        None
                        if attempts >= CHECKOUT_RECOVERY_MAX_ATTEMPTS
                        else self._utc_after(min(60.0, 2.0 ** min(attempts, 5)))
                    ),
                }
                if subscription_stage:
                    recovery_updates.update(
                        step="verify_result",
                        progress=90,
                        error_code=(
                            "subscription_recovery_exhausted"
                            if attempts >= CHECKOUT_RECOVERY_MAX_ATTEMPTS
                            else "subscription_pending"
                        ),
                        error_message=str(exc)[:500],
                    )
                elif action_waiting:
                    recovery_updates.update(
                        step="confirm_payment",
                        progress=72,
                        completed_at=None,
                    )
                elif attempts >= CHECKOUT_RECOVERY_MAX_ATTEMPTS:
                    recovery_updates.update(
                        step="confirm_payment",
                        progress=70,
                        error_code="payment_recovery_exhausted",
                        error_message="状态核验达到重试上限，支付或 Checkout 确认仍未完成",
                    )
                self.database.update_order(order_id, **recovery_updates)
            finally:
                with self._checkout_sync_lock:
                    self._checkout_sync_in_progress.discard(order_key)

    def _worker_loop(self) -> None:
        while not self._stopping.is_set():
            order_id = self.queue.get()
            if order_id is None:
                self.queue.task_done()
                return
            try:
                self._process_order(order_id)
            finally:
                self.queue.task_done()

    def _process_order(self, order_id: int) -> None:
        order = self.database.get_order_by_id(order_id)
        if not order or order["status"] != "queued":
            return
        self.database.update_order(order_id, status="running", step="validate_session", progress=8)
        adapter = self.adapters.get(order["provider"])
        if not adapter:
            self.database.update_order(
                order_id,
                status="failed",
                step="failed",
                progress=100,
                error_code="provider_unavailable",
                error_message="执行引擎未启用",
                completed_at=utc_now(),
            )
            return

        def progress(step: str, percent: int) -> None:
            self.database.update_order(order_id, step=step, progress=percent)

        try:
            result = adapter.process(order, progress)
        except AdapterError as exc:
            self.database.update_order(
                order_id,
                status="failed",
                step="failed",
                progress=100,
                error_code=exc.code,
                error_message=str(exc),
                completed_at=utc_now(),
            )
        except Exception:
            self.database.update_order(
                order_id,
                status="failed",
                step="failed",
                progress=100,
                error_code="internal_error",
                error_message="本地任务执行异常",
                completed_at=utc_now(),
            )
        else:
            self.database.update_order(
                order_id,
                status="succeeded",
                step="completed",
                progress=100,
                confirmation_ref=result.confirmation_ref,
                completed_at=utc_now(),
            )
