from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from typing import Any


class SessionValidationError(ValueError):
    pass


_SESSION_COOKIE_NAMES = {
    "sessionToken",
    "session_token",
    "sessionCookie",
    "session_cookie",
    "__Secure-platform.session-token",
    "next-auth.session-token",
    "__Secure-authjs.session-token",
    "authjs.session-token",
}


def _is_session_cookie_name(value: Any) -> bool:
    name = str(value or "")
    return name in _SESSION_COOKIE_NAMES or any(
        name.startswith(f"{base}.")
        for base in (
            "__Secure-platform.session-token",
            "next-auth.session-token",
            "__Secure-authjs.session-token",
            "authjs.session-token",
        )
    )


def _decode_jwt_payload(token: str) -> dict[str, Any]:
    try:
        part = token.split(".")[1]
        part += "=" * (-len(part) % 4)
        return json.loads(base64.urlsafe_b64decode(part.encode("ascii")))
    except (IndexError, ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return {}


def _first_text(*values: Any) -> str:
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _parse_expiry(value: Any) -> tuple[str, bool]:
    if not isinstance(value, str) or not value.strip():
        return "", False
    text = value.strip().replace("Z", "+00:00")
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return value.strip(), False
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.isoformat(timespec="seconds"), parsed <= datetime.now(timezone.utc)


def _has_session_cookie(data: dict[str, Any]) -> bool:
    for name in _SESSION_COOKIE_NAMES:
        if _first_text(data.get(name)):
            return True

    cookies = data.get("cookies")
    if isinstance(cookies, dict):
        for name, value in cookies.items():
            if _is_session_cookie_name(name) and _first_text(value):
                return True
    elif isinstance(cookies, list):
        for item in cookies:
            if not isinstance(item, dict):
                continue
            if _is_session_cookie_name(item.get("name")) and _first_text(
                item.get("value")
            ):
                return True

    headers = data.get("headers")
    if isinstance(headers, dict):
        cookie_header = next(
            (
                str(value or "")
                for key, value in headers.items()
                if str(key).lower() == "cookie"
            ),
            "",
        )
        for part in cookie_header.split(";"):
            name, separator, value = part.strip().partition("=")
            if separator and _is_session_cookie_name(name) and value.strip():
                return True
    return False


def summarize_session(value: Any) -> dict[str, Any]:
    if isinstance(value, str):
        if len(value.encode("utf-8")) > 128 * 1024:
            raise SessionValidationError("Session JSON 超过 128 KB")
        try:
            data = json.loads(value)
        except json.JSONDecodeError as exc:
            raise SessionValidationError("Session JSON 格式错误") from exc
    elif isinstance(value, dict):
        data = value
    else:
        raise SessionValidationError("Session 必须是完整 JSON 对象")

    if not isinstance(data, dict):
        raise SessionValidationError("Session 顶层必须是 JSON 对象")

    token = _first_text(data.get("accessToken"), data.get("access_token"))
    claims = _decode_jwt_payload(token) if token else {}
    profile = claims.get("https://api.vendor.com/profile") or {}
    auth = claims.get("https://api.vendor.com/auth") or {}
    user = data.get("user") if isinstance(data.get("user"), dict) else {}

    email = _first_text(
        user.get("email"),
        data.get("email"),
        profile.get("email") if isinstance(profile, dict) else "",
        claims.get("email"),
    )
    if not email or "@" not in email:
        raise SessionValidationError("Session 中未找到有效邮箱")

    account_id = _first_text(
        auth.get("platform_account_id") if isinstance(auth, dict) else "",
        auth.get("account_id") if isinstance(auth, dict) else "",
        claims.get("platform_account_id"),
        claims.get("account_id"),
        data.get("account_id"),
    )
    canonical = json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    fingerprint = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
    account_source = account_id or email.lower()
    account_ref = hashlib.sha256(account_source.encode("utf-8")).hexdigest()[:12]
    expiry, expired = _parse_expiry(data.get("expires"))
    token_expired = False
    token_exp = claims.get("exp")
    if isinstance(token_exp, (int, float)):
        token_expired = float(token_exp) <= datetime.now(timezone.utc).timestamp()
    expired = bool(expired or token_expired)

    return {
        "email": email,
        "account_ref": account_ref,
        "fingerprint": fingerprint,
        "expires": expiry,
        "expired": expired,
        "has_access_token": bool(token),
        "has_session_cookie": _has_session_cookie(data),
    }
