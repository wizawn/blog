from __future__ import annotations

import atexit
import os
import queue
import re
import select
import socket
import socketserver
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Any
from urllib.parse import unquote, urlsplit


class StripeBrowserError(RuntimeError):
    pass


_DEFAULT_EXECUTABLES = tuple(
    Path(p) for p in filter(None, [
        os.environ.get("BROWSER_EXECUTABLE", ""),
    ])
)


def _browser_executable(configured: str = "") -> str:
    candidates = []
    if str(configured or "").strip():
        candidates.append(Path(str(configured).strip()))
    environment = os.environ.get("CS_STRIPE_BROWSER_EXECUTABLE", "").strip()
    if environment:
        candidates.append(Path(environment))
    candidates.extend(_DEFAULT_EXECUTABLES)
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    raise StripeBrowserError("Stripe.js browser runtime: Chrome/Edge executable not found")


def _proxy_settings(value: str) -> dict[str, str] | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    normalized = re.sub(r"^socks5h://", "socks5://", raw, flags=re.IGNORECASE)
    parsed = urlsplit(normalized)
    if parsed.scheme.lower() not in {"http", "https", "socks5"}:
        raise StripeBrowserError("Stripe.js browser runtime: unsupported proxy scheme")
    if not parsed.hostname or not parsed.port:
        raise StripeBrowserError("Stripe.js browser runtime: invalid proxy address")
    proxy = {
        "server": f"{parsed.scheme.lower()}://{parsed.hostname}:{parsed.port}",
        "bypass": "127.0.0.1,localhost",
    }
    if parsed.username:
        proxy["username"] = unquote(parsed.username)
    if parsed.password:
        proxy["password"] = unquote(parsed.password)
    return proxy


def _recv_exact(connection: socket.socket, length: int) -> bytes:
    chunks = bytearray()
    while len(chunks) < length:
        chunk = connection.recv(length - len(chunks))
        if not chunk:
            raise OSError("SOCKS5 connection closed")
        chunks.extend(chunk)
    return bytes(chunks)


def _read_socks_address(connection: socket.socket, address_type: int) -> bytes:
    if address_type == 1:
        return _recv_exact(connection, 4)
    if address_type == 4:
        return _recv_exact(connection, 16)
    if address_type == 3:
        length = _recv_exact(connection, 1)
        return length + _recv_exact(connection, length[0])
    raise OSError("unsupported SOCKS5 address type")


class _Socks5BridgeHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        client = self.request
        client.settimeout(30)
        upstream = None
        try:
            version, count = _recv_exact(client, 2)
            methods = _recv_exact(client, count)
            if version != 5 or 0 not in methods:
                client.sendall(b"\x05\xff")
                return
            client.sendall(b"\x05\x00")
            version, command, reserved, address_type = _recv_exact(client, 4)
            if version != 5 or command != 1 or reserved != 0:
                client.sendall(b"\x05\x07\x00\x01\x00\x00\x00\x00\x00\x00")
                return
            address = _read_socks_address(client, address_type)
            port = _recv_exact(client, 2)

            server = self.server
            upstream = socket.create_connection(
                (server.upstream_host, server.upstream_port), timeout=30
            )
            upstream.settimeout(30)
            if server.username or server.password:
                upstream.sendall(b"\x05\x01\x02")
                selected = _recv_exact(upstream, 2)
                if selected != b"\x05\x02":
                    raise OSError("upstream SOCKS5 authentication method rejected")
                username = server.username.encode("utf-8")
                password = server.password.encode("utf-8")
                if len(username) > 255 or len(password) > 255:
                    raise OSError("upstream SOCKS5 credentials are too long")
                upstream.sendall(
                    b"\x01"
                    + bytes((len(username),))
                    + username
                    + bytes((len(password),))
                    + password
                )
                if _recv_exact(upstream, 2) != b"\x01\x00":
                    raise OSError("upstream SOCKS5 authentication failed")
            else:
                upstream.sendall(b"\x05\x01\x00")
                if _recv_exact(upstream, 2) != b"\x05\x00":
                    raise OSError("upstream SOCKS5 no-auth method rejected")

            upstream.sendall(
                bytes((5, command, 0, address_type)) + address + port
            )
            response_header = _recv_exact(upstream, 4)
            response_address = _read_socks_address(upstream, response_header[3])
            response_port = _recv_exact(upstream, 2)
            client.sendall(response_header + response_address + response_port)
            if response_header[1] != 0:
                return

            client.settimeout(None)
            upstream.settimeout(None)
            while True:
                readable, _, _ = select.select((client, upstream), (), (), 60)
                if not readable:
                    continue
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    (upstream if source is client else client).sendall(data)
        except (OSError, ValueError):
            try:
                client.sendall(b"\x05\x01\x00\x01\x00\x00\x00\x00\x00\x00")
            except OSError:
                pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


class _Socks5BridgeServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def __init__(
        self,
        upstream_host: str,
        upstream_port: int,
        username: str,
        password: str,
    ):
        self.upstream_host = upstream_host
        self.upstream_port = int(upstream_port)
        self.username = username
        self.password = password
        super().__init__(("127.0.0.1", 0), _Socks5BridgeHandler)


@contextmanager
def _browser_proxy(value: str):
    raw = str(value or "").strip()
    if not raw:
        yield None
        return
    normalized = re.sub(r"^socks5h://", "socks5://", raw, flags=re.IGNORECASE)
    parsed = urlsplit(normalized)
    if parsed.scheme.lower() != "socks5" or not (parsed.username or parsed.password):
        yield _proxy_settings(raw)
        return
    if not parsed.hostname or not parsed.port:
        raise StripeBrowserError("Stripe.js browser runtime: invalid SOCKS5 proxy")
    bridge = _Socks5BridgeServer(
        parsed.hostname,
        parsed.port,
        unquote(parsed.username or ""),
        unquote(parsed.password or ""),
    )
    thread = threading.Thread(target=bridge.serve_forever, daemon=True)
    thread.start()
    try:
        yield {
            "server": f"socks5://127.0.0.1:{bridge.server_address[1]}",
            "bypass": "127.0.0.1,localhost",
        }
    finally:
        bridge.shutdown()
        bridge.server_close()
        thread.join(timeout=2)


def _card_fields(card: dict[str, Any]) -> dict[str, str]:
    number = re.sub(r"\D", "", str(card.get("card_number") or card.get("number") or ""))
    month = re.sub(r"\D", "", str(card.get("exp_month") or card.get("expMonth") or "")).zfill(2)
    year = re.sub(r"\D", "", str(card.get("exp_year") or card.get("expYear") or ""))
    cvc = re.sub(r"\D", "", str(card.get("cvc") or card.get("cvv") or ""))
    if len(year) == 4:
        year = year[-2:]
    if not re.fullmatch(r"\d{12,19}", number):
        raise StripeBrowserError("Stripe.js browser runtime: invalid card number")
    if not re.fullmatch(r"(?:0[1-9]|1[0-2])", month):
        raise StripeBrowserError("Stripe.js browser runtime: invalid expiry month")
    if not re.fullmatch(r"\d{2}", year):
        raise StripeBrowserError("Stripe.js browser runtime: invalid expiry year")
    if not re.fullmatch(r"\d{3,4}", cvc):
        raise StripeBrowserError("Stripe.js browser runtime: invalid CVC")
    return {"number": number, "expiry": f"{month}{year}", "cvc": cvc}


def _billing_fields(billing: dict[str, Any]) -> dict[str, Any]:
    source = {str(key): str(value or "").strip() for key, value in dict(billing or {}).items()}
    return {
        "name": source.get("name", ""),
        "email": source.get("email", ""),
        "address": {
            "line1": source.get("line1", ""),
            "city": source.get("city", ""),
            "state": source.get("state", ""),
            "postal_code": source.get("postal_code", ""),
            "country": source.get("country", "").upper(),
        },
    }


class _BrowserTask:
    def __init__(self, values: dict[str, Any]):
        self.values = values
        self.done = threading.Event()
        self.result: dict[str, Any] | None = None
        self.error: Exception | None = None


class _StripeBrowserRuntime:
    """Own one warm Chromium process on a dedicated Playwright thread."""

    def __init__(self) -> None:
        self._queue: queue.Queue[_BrowserTask | None] = queue.Queue()
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._browser: Any = None
        self._executable = ""
        self._fatal_error = ""
        self._completed = 0

    def _ensure_thread(self) -> None:
        with self._lock:
            if self._thread is not None and self._thread.is_alive():
                return
            self._fatal_error = ""
            self._thread = threading.Thread(
                target=self._run,
                name="xy-stripe-browser",
                daemon=True,
            )
            self._thread.start()

    def submit(self, values: dict[str, Any], timeout: int) -> dict[str, Any]:
        task = _BrowserTask(values)
        self._queue.put(task)
        self._ensure_thread()
        wait_seconds = max(35, min(210, int(timeout) + 30))
        if not task.done.wait(wait_seconds):
            raise StripeBrowserError("Stripe.js browser runtime worker timed out")
        if task.error is not None:
            if isinstance(task.error, StripeBrowserError):
                raise task.error
            raise StripeBrowserError(
                f"Stripe.js browser runtime: {str(task.error)[:300]}"
            ) from task.error
        if not isinstance(task.result, dict):
            raise StripeBrowserError("Stripe.js browser runtime: missing worker result")
        return task.result

    def prewarm(self, executable: str) -> None:
        self._queue.put(
            _BrowserTask({"warm_only": True, "executable": executable})
        )
        self._ensure_thread()

    def _launch(self, playwright: Any, executable: str) -> Any:
        if self._browser is not None:
            try:
                self._browser.close()
            except Exception:
                pass
        self._browser = playwright.chromium.launch(
            executable_path=executable,
            headless=True,
            chromium_sandbox=False,
            args=[
                "--disable-background-networking",
                "--disable-component-update",
                "--disable-default-apps",
                "--disable-sync",
                "--no-first-run",
            ],
        )
        self._executable = executable
        return self._browser

    def _execute(
        self,
        browser: Any,
        values: dict[str, Any],
        playwright_timeout_error: type[BaseException],
        playwright_error: type[BaseException],
    ) -> dict[str, Any]:
        context = None
        normalized_card = values["card"]
        try:
            with _browser_proxy(values["proxy"]) as browser_proxy:
                context_options: dict[str, Any] = {
                    "locale": "en-US",
                    "timezone_id": "America/New_York",
                    "ignore_https_errors": False,
                }
                if browser_proxy:
                    # Context-level proxy preserves per-order proxy affinity
                    # while the Chromium process remains warm.
                    context_options["proxy"] = browser_proxy
                context = browser.new_context(**context_options)
                page = context.new_page()
                page.set_default_timeout(values["timeout_ms"])
                runner_source = (
                    Path(__file__).resolve().parents[1]
                    / "static"
                    / "stripe-runner.html"
                ).read_text(encoding="utf-8")
                page.route(
                    values["runner_url"],
                    lambda route: route.fulfill(
                        status=200,
                        content_type="text/html; charset=utf-8",
                        body=runner_source,
                    ),
                )
                page.goto(
                    values["runner_url"],
                    wait_until="domcontentloaded",
                    timeout=values["timeout_ms"],
                )
                page.wait_for_function(
                    "typeof window.Stripe === 'function'",
                    timeout=values["timeout_ms"],
                )
                initialized = page.evaluate(
                    "async (key) => window.xyStripeRunner.init(key)",
                    values["key"],
                )
                if not initialized or not initialized.get("ok"):
                    message = str(
                        (initialized or {}).get("error") or "initialization failed"
                    )
                    raise StripeBrowserError(f"Stripe.js initialization: {message}")
                page.frame_locator('iframe[title*="card number" i]').locator(
                    'input[name="cardnumber"]'
                ).fill(normalized_card["number"])
                page.frame_locator('iframe[title*="expiration" i]').locator(
                    'input[name="exp-date"]'
                ).fill(normalized_card["expiry"])
                page.frame_locator('iframe[title*="CVC" i]').locator(
                    'input[name="cvc"]'
                ).fill(normalized_card["cvc"])
                page.wait_for_function(
                    "window.xyStripeRunner.cardComplete()",
                    timeout=values["timeout_ms"],
                )
                result = page.evaluate(
                    "async (details) => window.xyStripeRunner.createPaymentMethod(details)",
                    values["billing"],
                )
                if not isinstance(result, dict) or not result.get("ok"):
                    error = result.get("error") if isinstance(result, dict) else {}
                    error = error if isinstance(error, dict) else {}
                    code = str(
                        error.get("code") or error.get("type") or "stripe_js_error"
                    )
                    message = str(
                        error.get("message")
                        or "Stripe.js PaymentMethod creation failed"
                    )
                    raise StripeBrowserError(
                        f"Stripe.js payment method: {code} {message}"
                    )
                payment_method = result.get("paymentMethod")
                if not isinstance(payment_method, dict):
                    raise StripeBrowserError(
                        "Stripe.js payment method: missing response"
                    )
                payment_method_id = str(payment_method.get("id") or "").strip()
                if not re.fullmatch(r"pm_[A-Za-z0-9_-]+", payment_method_id):
                    raise StripeBrowserError(
                        "Stripe.js payment method: invalid PaymentMethod ID"
                    )
                card_summary = payment_method.get("card")
                card_summary = card_summary if isinstance(card_summary, dict) else {}
                return {
                    "id": payment_method_id,
                    "card": {
                        "brand": str(card_summary.get("brand") or ""),
                        "last4": re.sub(
                            r"\D", "", str(card_summary.get("last4") or "")
                        )[-4:],
                        "exp_month": str(card_summary.get("exp_month") or ""),
                        "exp_year": str(card_summary.get("exp_year") or ""),
                    },
                }
        except StripeBrowserError:
            raise
        except playwright_timeout_error as exc:
            raise StripeBrowserError("Stripe.js browser runtime timed out") from exc
        except playwright_error as exc:
            raise StripeBrowserError(
                f"Stripe.js browser runtime: {str(exc)[:300]}"
            ) from exc
        finally:
            normalized_card.clear()
            if context is not None:
                try:
                    context.close()
                except Exception:
                    pass

    def _fail_queued(self, error: Exception) -> None:
        while True:
            try:
                task = self._queue.get_nowait()
            except queue.Empty:
                return
            if task is None:
                return
            task.error = error
            task.done.set()

    def _run(self) -> None:
        try:
            from playwright.sync_api import Error as PlaywrightError
            from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            error = StripeBrowserError(
                "Stripe.js browser runtime: Playwright is not installed"
            )
            self._fatal_error = str(error)
            self._fail_queued(error)
            return
        try:
            with sync_playwright() as playwright:
                while True:
                    task = self._queue.get()
                    if task is None:
                        return
                    try:
                        executable = task.values["executable"]
                        connected = bool(
                            self._browser is not None
                            and getattr(self._browser, "is_connected", lambda: True)()
                        )
                        if not connected or executable != self._executable:
                            self._launch(playwright, executable)
                        if task.values.get("warm_only"):
                            task.result = {"warm": True}
                        else:
                            task.result = self._execute(
                                self._browser,
                                task.values,
                                PlaywrightTimeoutError,
                                PlaywrightError,
                            )
                            self._completed += 1
                    except Exception as exc:
                        task.error = exc
                        if task.values.get("warm_only"):
                            self._fatal_error = str(exc)[:300]
                        if isinstance(exc, PlaywrightError):
                            try:
                                self._browser.close()
                            except Exception:
                                pass
                            self._browser = None
                    finally:
                        task.done.set()
        except Exception as exc:
            error = StripeBrowserError(
                f"Stripe.js browser runtime worker stopped: {str(exc)[:300]}"
            )
            self._fatal_error = str(error)
            self._fail_queued(error)
        finally:
            if self._browser is not None:
                try:
                    self._browser.close()
                except Exception:
                    pass
            self._browser = None
            self._executable = ""

    def status(self) -> dict[str, Any]:
        thread = self._thread
        return {
            "warm": bool(
                thread is not None
                and thread.is_alive()
                and self._browser is not None
            ),
            "workerAlive": bool(thread is not None and thread.is_alive()),
            "completed": self._completed,
            "queueDepth": self._queue.qsize(),
            "error": self._fatal_error,
        }

    def close(self) -> None:
        with self._lock:
            thread = self._thread
            if thread is None or not thread.is_alive():
                return
            self._queue.put(None)
        thread.join(timeout=5)


_BROWSER_RUNTIME = _StripeBrowserRuntime()
atexit.register(_BROWSER_RUNTIME.close)


def stripe_browser_runtime_status() -> dict[str, Any]:
    return _BROWSER_RUNTIME.status()


def prewarm_stripe_browser_runtime(executable_path: str = "") -> None:
    _BROWSER_RUNTIME.prewarm(_browser_executable(executable_path))


def shutdown_stripe_browser_runtime() -> None:
    _BROWSER_RUNTIME.close()


def create_payment_method_with_stripe_js(
    *,
    publishable_key: str,
    card: dict[str, Any],
    billing: dict[str, Any],
    proxy: str = "",
    runner_url: str = "http://127.0.0.1:5602/static/stripe-runner.html",
    executable_path: str = "",
    timeout: int = 90,
) -> dict[str, Any]:
    key = str(publishable_key or "").strip()
    if not key.startswith(("pk_live_", "pk_test_")):
        raise StripeBrowserError("Stripe.js browser runtime: invalid publishable key")
    normalized_card = _card_fields(card)
    values = {
        "key": key,
        "card": normalized_card,
        "billing": _billing_fields(billing),
        "proxy": str(proxy or "").strip(),
        "runner_url": str(runner_url or "").strip(),
        "executable": _browser_executable(executable_path),
        "timeout_ms": max(30, min(180, int(timeout))) * 1000,
    }
    try:
        return _BROWSER_RUNTIME.submit(values, timeout)
    finally:
        # The worker also clears its copy after use.  Clearing here covers
        # validation/queue failures without retaining raw card fields.
        normalized_card.clear()
