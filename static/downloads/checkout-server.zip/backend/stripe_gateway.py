from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen


class StripeError(RuntimeError):
    pass


class WebhookSignatureError(ValueError):
    pass


@dataclass(frozen=True)
class StripeSettings:
    secret_key: str = ""
    publishable_key: str = ""
    webhook_secret: str = ""
    api_base: str = "https://api.stripe.com"

    @property
    def enabled(self) -> bool:
        return bool(self.secret_key)


class StripeGateway:
    def __init__(self, settings: StripeSettings, timeout: float = 20.0):
        self.settings = settings
        self.timeout = timeout

    @property
    def enabled(self) -> bool:
        return self.settings.enabled

    def create_payment_intent(
        self,
        *,
        amount_minor: int,
        currency: str,
        order_key: str,
        plan_type: str,
        payment_method: str,
        confirm: bool = True,
    ) -> dict[str, Any]:
        if not self.enabled:
            raise StripeError("Stripe 测试配置未启用")
        return self._request(
            "POST",
            "/v1/payment_intents",
            {
                "amount": str(amount_minor),
                "currency": currency.lower(),
                "payment_method": payment_method,
                "confirm": "true" if confirm else "false",
                "expand[]": "payment_method",
                "metadata[order_key]": order_key,
                "metadata[plan_type]": plan_type,
                "description": f"Checkout Server {plan_type} {order_key}",
            },
            idempotency_key=f"xy-order-{order_key}",
        )

    def retrieve_payment_intent(self, intent_id: str) -> dict[str, Any]:
        if not self.enabled:
            raise StripeError("Stripe 测试配置未启用")
        return self._request("GET", f"/v1/payment_intents/{intent_id}?expand[]=payment_method")

    def _request(
        self,
        method: str,
        path: str,
        form: dict[str, str] | None = None,
        idempotency_key: str = "",
    ) -> dict[str, Any]:
        url = self.settings.api_base.rstrip("/") + path
        body = urlencode(form).encode("utf-8") if form is not None else None
        headers = {
            "Authorization": f"Bearer {self.settings.secret_key}",
            "Accept": "application/json",
            "User-Agent": "XY-Pay/2.0",
        }
        if body is not None:
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        if idempotency_key:
            headers["Idempotency-Key"] = idempotency_key
        request = Request(url, data=body, headers=headers, method=method)
        try:
            with urlopen(request, timeout=self.timeout) as response:
                raw = response.read()
        except HTTPError as exc:
            try:
                error_payload = json.loads(exc.read().decode("utf-8"))
                message = error_payload.get("error", {}).get("message") or str(exc)
            except (UnicodeDecodeError, json.JSONDecodeError):
                message = str(exc)
            raise StripeError(message) from exc
        except URLError as exc:
            raise StripeError(f"Stripe 网络请求失败：{exc.reason}") from exc
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise StripeError("Stripe 返回了无效 JSON") from exc
        if not isinstance(payload, dict):
            raise StripeError("Stripe 返回格式错误")
        return payload

    def verify_webhook(self, raw_body: bytes, signature_header: str, tolerance: int = 300) -> dict[str, Any]:
        secret = self.settings.webhook_secret
        if not secret:
            raise WebhookSignatureError("Webhook secret 未配置")
        parts: dict[str, list[str]] = {}
        for item in signature_header.split(","):
            if "=" not in item:
                continue
            key, value = item.split("=", 1)
            parts.setdefault(key.strip(), []).append(value.strip())
        try:
            timestamp = int((parts.get("t") or [""])[0])
        except ValueError as exc:
            raise WebhookSignatureError("Stripe-Signature 时间戳无效") from exc
        if abs(time.time() - timestamp) > tolerance:
            raise WebhookSignatureError("Webhook 签名已过期")
        signed_payload = f"{timestamp}.".encode("utf-8") + raw_body
        expected = hmac.new(secret.encode("utf-8"), signed_payload, hashlib.sha256).hexdigest()
        if not any(hmac.compare_digest(expected, value) for value in parts.get("v1", [])):
            raise WebhookSignatureError("Webhook 签名不匹配")
        try:
            payload = json.loads(raw_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise WebhookSignatureError("Webhook JSON 无效") from exc
        if not isinstance(payload, dict):
            raise WebhookSignatureError("Webhook 顶层必须是 JSON 对象")
        return payload
