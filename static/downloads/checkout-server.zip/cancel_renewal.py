#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Platform 取消自动续费（独立脚本，移植自 cardplatform GPT 小助手的 GPTCancelRenewal）。

取消后会员权益保留到本期到期日（active_until），到期不再扣款（will_renew=false）。

原理：platform.example.com/backend-api 在 Cloudflare 后面，普通 requests 会被挑战(403)。
     用 curl_cffi 伪装 Chrome 的 TLS/JA3 指纹绕过（对应 Go 版的 bogdanfinn/tls-client）。

依赖：pip install curl_cffi

用法：
  # 传 session JSON（https://platform.example.com/api/auth/session 的完整内容）或裸 accessToken
  python3 tools/cancel_renewal.py '<session JSON 或 accessToken>'
  # 或从文件读
  python3 tools/cancel_renewal.py -f session.json
  # 或从标准输入
  cat session.json | python3 tools/cancel_renewal.py
  # 已知 account_id 可直接指定（跳过自动解析）
  python3 tools/cancel_renewal.py '<token>' --account-id <uuid>
  # 只查订阅状态、不取消
  python3 tools/cancel_renewal.py '<token>' --check
"""
import argparse
import json
import sys

try:
    from curl_cffi import requests as cffi_requests
except ImportError:
    sys.exit("缺少依赖：请先 pip install curl_cffi")

CHECK_V4_URL = "https://platform.example.com/api/v1/accounts/check/v4-2023-04-27?timezone_offset_min=-540"
CANCEL_URL = "https://platform.example.com/api/v1/subscriptions/cancel"
SUBS_URL = "https://platform.example.com/api/v1/subscriptions?account_id="
UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
IMPERSONATE = "chrome131"  # curl_cffi 指纹；版本不支持时回退见 _session()


def _session():
    """带 Chrome 指纹的会话；当前 curl_cffi 不识别 chrome131 时回退到 chrome120。"""
    try:
        return cffi_requests.Session(impersonate=IMPERSONATE)
    except Exception:
        return cffi_requests.Session(impersonate="chrome120")


def parse_token(raw: str) -> str:
    """接受 session JSON(含 accessToken) 或裸 accessToken，返回 accessToken。"""
    v = (raw or "").strip()
    if not v:
        raise ValueError("请输入 session JSON 或 accessToken")
    if v.startswith("{"):
        data = json.loads(v)
        token = (data.get("accessToken") or "").strip()
        if not token:
            raise ValueError("session JSON 中未找到 accessToken")
        return token
    return v


def _default_account(data: dict) -> dict:
    accounts = data.get("accounts") or {}
    if not isinstance(accounts, dict) or not accounts:
        return {}
    if isinstance(accounts.get("default"), dict):
        return accounts["default"]
    for v in accounts.values():
        if isinstance(v, dict):
            return v
    return {}


def _headers(token: str, post: bool = False) -> dict:
    h = {
        "Authorization": "Bearer " + token,
        "Accept": "*/*" if post else "application/json",
        "User-Agent": UA,
        "Referer": "https://platform.example.com/",
    }
    if post:
        h["Content-Type"] = "application/json"
        h["Origin"] = "https://platform.example.com"
    return h


def resolve_account_id(sess, token: str) -> str:
    """用 accessToken 调 check/v4 取默认账号的 account_id。"""
    r = sess.get(CHECK_V4_URL, headers=_headers(token), timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"获取账号信息失败(token 可能已失效) HTTP {r.status_code}")
    acc = _default_account(r.json()).get("account") or {}
    aid = (acc.get("account_id") or acc.get("id") or "").strip()
    if not aid:
        raise RuntimeError("未找到 account_id")
    return aid


def subscription_state(sess, token: str, account_id: str):
    """查订阅当前续费状态（取消后回查确认用）。"""
    r = sess.get(SUBS_URL + account_id, headers=_headers(token), timeout=30)
    if r.status_code != 200:
        return None
    try:
        return r.json()
    except Exception:
        return None


def cancel_renewal(sess, token: str, account_id: str) -> dict:
    """POST /subscriptions/cancel 取消自动续费，回查确认 will_renew=false。"""
    r = sess.post(CANCEL_URL, headers=_headers(token, post=True),
                  data=json.dumps({"account_id": account_id}), timeout=30)
    if r.status_code != 200:
        body = ""
        try:
            body = r.text[:300]
        except Exception:
            pass
        raise RuntimeError(f"取消失败 HTTP {r.status_code}（token 失效或非订阅持有者）{body}")
    out = {"account_id": account_id, "cancelled": True}
    st = subscription_state(sess, token, account_id)
    if st:
        out["will_renew"] = st.get("will_renew")
        out["active_until"] = st.get("active_until")
        out["cancellation_outcome"] = st.get("cancellation_outcome")
        out["plan_type"] = st.get("plan_type")
        if st.get("will_renew") is True:
            out["cancelled"] = False  # 上游返回 200 但仍续费 → 视为未成功
    return out


def main():
    ap = argparse.ArgumentParser(description="Platform 取消自动续费")
    ap.add_argument("token", nargs="?", help="session JSON 或 accessToken")
    ap.add_argument("-f", "--file", help="从文件读取 session JSON / token")
    ap.add_argument("--account-id", help="已知 account_id（跳过自动解析）")
    ap.add_argument("--check", action="store_true", help="只查订阅状态、不取消")
    args = ap.parse_args()

    raw = args.token
    if args.file:
        with open(args.file, encoding="utf-8") as fh:
            raw = fh.read()
    if not raw and not sys.stdin.isatty():
        raw = sys.stdin.read()
    if not raw:
        ap.error("需要提供 session JSON 或 accessToken（参数 / -f 文件 / stdin）")

    try:
        token = parse_token(raw)
    except Exception as e:
        sys.exit(f"✗ token 解析失败: {e}")

    sess = _session()
    account_id = (args.account_id or "").strip()
    if not account_id:
        try:
            account_id = resolve_account_id(sess, token)
        except Exception as e:
            sys.exit(f"✗ {e}")
    print(f"account_id = {account_id}")

    if args.check:
        st = subscription_state(sess, token, account_id) or {}
        print("订阅状态:")
        print(json.dumps({
            "plan_type": st.get("plan_type"),
            "will_renew": st.get("will_renew"),
            "active_until": st.get("active_until"),
            "cancellation_outcome": st.get("cancellation_outcome"),
        }, ensure_ascii=False, indent=2))
        return

    try:
        res = cancel_renewal(sess, token, account_id)
    except Exception as e:
        sys.exit(f"✗ {e}")

    if res.get("cancelled"):
        until = res.get("active_until") or "本期到期日"
        print(f"✓ 已取消自动续费。会员权益保留至 {until}，到期不再扣款。")
    else:
        print("⚠ 未取消成功（该账号可能已是不续费，或 token 失效）。")
    print(json.dumps(res, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
