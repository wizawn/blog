@echo off
cd /d "%~dp0"
"C:\Users\26787\AppData\Local\Programs\Python\Python313\python.exe" -u "D:\ky\xy\server.py" >> server.task.stdout.log 2>> server.task.stderr.log
