from __future__ import annotations

import argparse
import json
import mimetypes
import re
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from backend.config import ROOT, Settings
from backend.platform_checkout import PlatformCheckoutAdapter
from backend.proxy_pool import ProxyPool
from backend.service import OrderService, ServiceError
from backend.stripe_browser import (
    prewarm_stripe_browser_runtime,
    shutdown_stripe_browser_runtime,
)
from backend.stripe_gateway import StripeGateway, StripeSettings, WebhookSignatureError


MAX_BODY_BYTES = 256 * 1024
RETRY_PATH_RE = re.compile(r"^/api/orders/([A-Za-z0-9-]+)/retry$")
ADMIN_REVOKE_PATH_RE = re.compile(r"^/api/admin/api-keys/(\d+)/revoke$")
ADMIN_COOKIE = "cs_admin"


class Application:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.stripe_gateway = StripeGateway(
            StripeSettings(
                secret_key=settings.stripe_secret_key,
                publishable_key=settings.stripe_publishable_key,
                webhook_secret=settings.stripe_webhook_secret,
                api_base=settings.stripe_api_base,
            )
        )
        self.platform_checkout = PlatformCheckoutAdapter(
            ROOT,
            country=settings.platform_country,
            currency=settings.platform_currency,
            billing_country=settings.platform_billing_country,
            proxy_pool=ProxyPool(
                settings.platform_proxy_pool,
                timeout=settings.platform_proxy_timeout,
            ),
            stripe_proxy_pool=ProxyPool(
                settings.stripe_proxy_pool,
                timeout=settings.stripe_proxy_timeout,
            ),
            require_proxy=settings.platform_require_proxy,
            require_stripe_proxy=settings.stripe_require_proxy,
            stripe_browser_runner_url=(
                f"http://127.0.0.1:{settings.port}/static/stripe-runner.html"
            ),
            stripe_browser_executable=settings.stripe_browser_executable,
            confirmation_token_mode=settings.confirmation_token_mode,
        )
        self.service = OrderService(
            settings.database_path,
            ROOT,
            step_delay=settings.worker_step_delay,
            stripe_gateway=self.stripe_gateway,
            platform_checkout=self.platform_checkout,
            require_managed_keys=settings.require_managed_keys,
        )
        try:
            prewarm_stripe_browser_runtime(settings.stripe_browser_executable)
        except Exception:
            # Runtime status exposes the warm-up error; the first payment may
            # still retry browser launch after configuration is corrected.
            pass

    def close(self) -> None:
        self.service.close()
        shutdown_stripe_browser_runtime()


class CheckoutHTTPServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address: tuple[str, int], app: Application):
        self.app = app
        super().__init__(address, RequestHandler)


class RequestHandler(BaseHTTPRequestHandler):
    server: CheckoutHTTPServer

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[http] {self.address_string()} {fmt % args}")

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        super().end_headers()

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(HTTPStatus.NO_CONTENT)
        self.send_header("Allow", "GET, POST, OPTIONS")
        self.end_headers()

    def do_GET(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path in {"/health", "/api/health"}:
            self._json(
                HTTPStatus.OK,
                {
                    "ok": True,
                    "service": "checkout-server-v3",
                    "environment": "local-test",
                    "stats": self.server.app.service.database.stats(),
                },
            )
            return
        if path == "/api/meta":
            self._json(HTTPStatus.OK, {"ok": True, **self.server.app.service.metadata()})
            return
        if path == "/favicon.ico":
            self.send_response(HTTPStatus.NO_CONTENT)
            self.send_header("Cache-Control", "public, max-age=86400")
            self.end_headers()
            return
        if path == "/admin":
            self._file(self.server.app.settings.static_dir / "admin.html")
            return
        if path == "/api/admin/state":
            token = self._admin_token()
            self._json(
                HTTPStatus.OK,
                {
                    "ok": True,
                    "setupRequired": self.server.app.service.database.admin_count() == 0,
                    "authenticated": bool(self.server.app.service.admin_identity(token)),
                    "username": self.server.app.service.admin_identity(token),
                },
            )
            return
        if path == "/api/admin/api-keys":
            try:
                items = self.server.app.service.list_managed_keys(self._admin_token())
            except ServiceError as exc:
                self._error(exc.status, exc.code, str(exc))
            else:
                self._json(HTTPStatus.OK, {"ok": True, "items": items})
            return
        if path == "/api/admin/proxy":
            try:
                result = self.server.app.service.proxy_admin_status(self._admin_token())
            except ServiceError as exc:
                self._error(exc.status, exc.code, str(exc))
            else:
                self._json(HTTPStatus.OK, {"ok": True, "proxy": result})
            return
        if path == "/api/admin/billing":
            try:
                result = self.server.app.service.billing_admin_status(self._admin_token())
            except ServiceError as exc:
                self._error(exc.status, exc.code, str(exc))
            else:
                self._json(HTTPStatus.OK, {"ok": True, "billing": result})
            return
        if path == "/":
            self._file(self.server.app.settings.static_dir / "index.html")
            return
        if path.startswith("/static/"):
            relative = path.removeprefix("/static/")
            self._static_file(relative)
            return
        self._error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在")

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        try:
            if path == "/api/stripe/webhook":
                raw_body = self._read_body()
                try:
                    event = self.server.app.stripe_gateway.verify_webhook(
                        raw_body, self.headers.get("Stripe-Signature", "")
                    )
                except WebhookSignatureError as exc:
                    self._error(HTTPStatus.BAD_REQUEST, "invalid_webhook", str(exc))
                    return
                self.server.app.service.handle_stripe_webhook(event)
                self._json(HTTPStatus.OK, {"ok": True})
                return
            payload = self._read_json()
            if path == "/api/session/validate":
                summary = self.server.app.service.validate_session(payload.get("session"))
                self._json(HTTPStatus.OK, {"ok": True, "session": summary})
                return
            if path == "/api/platform/stripe/bootstrap":
                result = self.server.app.service.bootstrap_platform_stripe_elements(payload)
                self._json(HTTPStatus.OK, {"ok": True, **result})
                return
            if path == "/api/platform/checkout/preflight":
                result = self.server.app.service.preflight_platform_checkout(payload)
                self._json(HTTPStatus.OK, {"ok": True, **result})
                return
            if path == "/api/orders":
                order = self.server.app.service.create_order(payload)
                self._json(HTTPStatus.CREATED, {"ok": True, "order": order})
                return
            if path == "/api/orders/status":
                order = self.server.app.service.order_status(payload)
                self._json(HTTPStatus.OK, {"ok": True, "order": order})
                return
            if path == "/api/orders/query":
                result = self.server.app.service.list_orders(payload)
                self._json(HTTPStatus.OK, {"ok": True, **result})
                return
            if path in {"/api/stripe/charge", "/api/stripe/prepare", "/api/platform/checkout/charge"}:
                result = self.server.app.service.charge_stripe_order(payload)
                self._json(HTTPStatus.CREATED, {"ok": True, **result})
                return
            if path in {"/api/stripe/sync", "/api/platform/checkout/sync"}:
                order = self.server.app.service.sync_stripe_order(payload)
                self._json(HTTPStatus.OK, {"ok": True, "order": order})
                return
            if path == "/api/admin/setup":
                if self.client_address[0] not in {"127.0.0.1", "::1", "localhost"}:
                    raise ServiceError("admin_setup_local_only", "管理员首次初始化仅允许本机访问", 403)
                result = self.server.app.service.setup_admin(payload)
                self._json(HTTPStatus.CREATED, {"ok": True, "username": result["username"]}, f"Set-Cookie: {self._admin_cookie(result['token'])}")
                return
            if path == "/api/admin/login":
                result = self.server.app.service.login_admin(payload)
                self._json(HTTPStatus.OK, {"ok": True, "username": result["username"]}, f"Set-Cookie: {self._admin_cookie(result['token'])}")
                return
            if path == "/api/admin/logout":
                self.server.app.service.logout_admin(self._admin_token())
                self._json(HTTPStatus.OK, {"ok": True}, f"Set-Cookie: {self._admin_cookie('', clear=True)}")
                return
            if path == "/api/admin/api-keys":
                result = self.server.app.service.create_managed_key(self._admin_token(), payload.get("label", ""))
                self._json(HTTPStatus.CREATED, {"ok": True, **result})
                return
            if path == "/api/admin/proxy":
                result = self.server.app.service.configure_proxy(self._admin_token(), payload)
                self._json(HTTPStatus.OK, {"ok": True, "proxy": result})
                return
            if path == "/api/admin/proxy/test":
                result = self.server.app.service.probe_proxy(self._admin_token())
                self._json(HTTPStatus.OK, {"ok": True, "result": result})
                return
            if path == "/api/admin/billing":
                result = self.server.app.service.configure_billing(self._admin_token(), payload)
                self._json(HTTPStatus.OK, {"ok": True, "billing": result})
                return
            if path == "/api/admin/billing/test":
                result = self.server.app.service.probe_billing(self._admin_token(), payload)
                self._json(HTTPStatus.OK, {"ok": True, "result": result})
                return
            revoke_match = ADMIN_REVOKE_PATH_RE.fullmatch(path)
            if revoke_match:
                self.server.app.service.revoke_managed_key(self._admin_token(), int(revoke_match.group(1)))
                self._json(HTTPStatus.OK, {"ok": True})
                return
            retry_match = RETRY_PATH_RE.fullmatch(path)
            if retry_match:
                order = self.server.app.service.retry_order(retry_match.group(1), payload)
                self._json(HTTPStatus.OK, {"ok": True, "order": order})
                return
            self._error(HTTPStatus.NOT_FOUND, "not_found", "接口不存在")
        except ServiceError as exc:
            self._error(exc.status, exc.code, str(exc), exc.details)
        except ValueError as exc:
            self._error(HTTPStatus.BAD_REQUEST, "invalid_request", str(exc))
        except Exception:
            self._error(HTTPStatus.INTERNAL_SERVER_ERROR, "internal_error", "服务处理异常")

    def _read_json(self) -> dict[str, Any]:
        raw = self._read_body()
        if not raw:
            return {}
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError("请求体不是有效 JSON") from exc
        if not isinstance(payload, dict):
            raise ValueError("请求体顶层必须是 JSON 对象")
        return payload

    def _read_body(self) -> bytes:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise ValueError("Content-Length 无效") from exc
        if length <= 0:
            return {}
        if length > MAX_BODY_BYTES:
            raise ValueError("请求体超过 256 KB")
        return self.rfile.read(length)

    def _admin_token(self) -> str:
        cookie_header = self.headers.get("Cookie", "")
        for item in cookie_header.split(";"):
            name, separator, value = item.strip().partition("=")
            if separator and name == ADMIN_COOKIE:
                return value
        return ""

    @staticmethod
    def _admin_cookie(token: str, clear: bool = False) -> str:
        if clear:
            return f"{ADMIN_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Strict"
        return f"{ADMIN_COOKIE}={token}; Path=/; Max-Age={8 * 3600}; HttpOnly; SameSite=Strict"

    def _static_file(self, relative: str) -> None:
        root = self.server.app.settings.static_dir.resolve()
        candidate = (root / relative).resolve()
        if not candidate.is_relative_to(root):
            self._error(HTTPStatus.NOT_FOUND, "not_found", "文件不存在")
            return
        self._file(candidate)

    def _file(self, path: Path) -> None:
        if not path.is_file():
            self._error(HTTPStatus.NOT_FOUND, "not_found", "文件不存在")
            return
        content = path.read_bytes()
        content_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "application/json"}:
            content_type = f"{content_type}; charset=utf-8"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(content)

    def _json(self, status: int, payload: dict[str, Any], extra_headers: str = "") -> None:
        body = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if extra_headers:
            header_name, separator, header_value = extra_headers.partition(":")
            if separator:
                self.send_header(header_name.strip(), header_value.strip())
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status: int, code: str, message: str, details: dict[str, Any] | None = None) -> None:
        payload: dict[str, Any] = {"ok": False, "error": {"code": code, "message": message}}
        if details:
            payload.update(details)
        self._json(status, payload)


def parse_args() -> argparse.Namespace:
    defaults = Settings()
    parser = argparse.ArgumentParser(description="Checkout Server local order console")
    parser.add_argument("--host", default=defaults.host)
    parser.add_argument("--port", type=int, default=defaults.port)
    parser.add_argument("--data-dir", type=Path, default=defaults.data_dir)
    parser.add_argument("--step-delay", type=float, default=defaults.worker_step_delay)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    settings = Settings(
        host=args.host,
        port=args.port,
        data_dir=args.data_dir,
        worker_step_delay=args.step_delay,
    )
    app = Application(settings)
    server = CheckoutHTTPServer((settings.host, settings.port), app)
    print(f"Checkout Server v1: http://{settings.host}:{settings.port}")
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        app.close()


if __name__ == "__main__":
    main()
