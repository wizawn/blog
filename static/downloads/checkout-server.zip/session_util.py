from __future__ import annotations

import base64
import json
import re
import time
from typing import Any


SESSION_URL = "https://platform.example.com/api/auth/session"
SESSION_COOKIE_CHUNK_LENGTH = 3933
COOKIE_NAMES = (
    "__Secure-platform.session-token",
    "next-auth.session-token",
    "__Secure-authjs.session-token",
    "authjs.session-token",
)
UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"
)


def normalize_credential(raw: str) -> str:
    value = str(raw or "").strip()
    if value.startswith("```"):
        value = re.sub(r"^```[a-zA-Z]*\s*\n?", "", value)
        value = re.sub(r"\n?```\s*$", "", value).strip()
    value = re.sub(r"^Bearer\s+", "", value, flags=re.IGNORECASE).strip()
    if not value.startswith("{"):
        value = re.sub(r"\s+", "", value)
    return value


def looks_like_jwt(value: str) -> bool:
    parts = str(value or "").split(".")
    return len(parts) == 3 and value.startswith("eyJ") and all(parts)


def looks_like_compact_jwe(value: str) -> bool:
    parts = str(value or "").split(".")
    return len(parts) == 5 and value.startswith("eyJ") and bool(parts[0])


def jwt_expired(value: str, leeway_seconds: int = 30) -> bool:
    if not looks_like_jwt(value):
        return False
    try:
        payload = value.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        claims = json.loads(base64.urlsafe_b64decode(payload.encode("ascii")))
        expires_at = float(claims.get("exp"))
    except (ValueError, TypeError, KeyError, json.JSONDecodeError):
        return False
    return expires_at <= time.time() + max(0, int(leeway_seconds))


def join_session_cookie_parts(values: dict[str, str]) -> str:
    for base in COOKIE_NAMES:
        exact = str(values.get(base) or "").strip()
        if exact:
            return exact
        prefix = f"{base}."
        chunks: list[tuple[int, str]] = []
        for name, value in values.items():
            if not str(name).startswith(prefix):
                continue
            try:
                index = int(str(name)[len(prefix):])
            except ValueError:
                continue
            chunks.append((index, str(value or "").strip()))
        chunks.sort(key=lambda item: item[0])
        if chunks and [index for index, _value in chunks] == list(range(len(chunks))):
            return "".join(value for _index, value in chunks)
    return ""


def session_token_from_cookie_header(header: str) -> str:
    values: dict[str, str] = {}
    for part in str(header or "").split(";"):
        name, separator, value = part.strip().partition("=")
        if separator and name:
            values[name] = value
    return join_session_cookie_parts(values)


def build_session_cookie_header(cookie_name: str, session_cookie: str) -> str:
    value = str(session_cookie or "").strip()
    name = str(cookie_name or COOKIE_NAMES[0])
    if len(value) <= SESSION_COOKIE_CHUNK_LENGTH:
        return f"{name}={value}" if value else ""
    return "; ".join(
        f"{name}.{index}={value[offset:offset + SESSION_COOKIE_CHUNK_LENGTH]}"
        for index, offset in enumerate(range(0, len(value), SESSION_COOKIE_CHUNK_LENGTH))
    )


def _cookie_values(data: dict[str, Any]) -> dict[str, str]:
    values: dict[str, str] = {}
    cookies = data.get("cookies")
    if isinstance(cookies, dict):
        values.update({str(key): str(value or "") for key, value in cookies.items()})
    elif isinstance(cookies, list):
        for item in cookies:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name") or "").strip()
            if name:
                values[name] = str(item.get("value") or "")
    headers = data.get("headers") if isinstance(data.get("headers"), dict) else {}
    for key, value in headers.items():
        if str(key).lower() == "cookie":
            for part in str(value or "").split(";"):
                name, separator, cookie_value = part.strip().partition("=")
                if separator and name:
                    values.setdefault(name, cookie_value)
    return values


def extract_session_token_from_obj(data: dict[str, Any]) -> str:
    for key in (
        "sessionToken", "session_token", "sessionCookie", "session_cookie",
        "__Secure-platform.session-token", "next-auth.session-token",
        "__Secure-authjs.session-token", "authjs.session-token",
    ):
        value = normalize_credential(str(data.get(key) or ""))
        if looks_like_compact_jwe(value):
            return value
    return join_session_cookie_parts(_cookie_values(data))


def parse_credentials(raw: str) -> dict[str, str]:
    source = str(raw or "").strip()
    if not source:
        raise ValueError("missing Session JSON, accessToken, or Session Cookie")
    if source.startswith("{"):
        data = json.loads(source)
        if not isinstance(data, dict):
            raise ValueError("Session JSON root must be an object")
        token = normalize_credential(str(
            data.get("accessToken")
            or data.get("access_token")
            or (data.get("account") or {}).get("accessToken")
            if isinstance(data.get("account"), dict)
            else data.get("accessToken") or data.get("access_token") or ""
        ))
        session_cookie = normalize_credential(extract_session_token_from_obj(data))
        email = str(
            (data.get("user") or {}).get("email")
            if isinstance(data.get("user"), dict)
            else data.get("email") or ""
        ).strip()
        if token and not looks_like_jwt(token):
            token = ""
        if session_cookie and not looks_like_compact_jwe(session_cookie):
            session_cookie = ""
        if token or session_cookie:
            return {
                "access_token": token,
                "session_cookie": session_cookie,
                "email": email,
                "input_type": "session_json",
            }
        raise ValueError("Session JSON has no usable accessToken or Session Cookie")
    value = normalize_credential(source)
    if looks_like_jwt(value):
        return {"access_token": value, "session_cookie": "", "email": "", "input_type": "access_token"}
    if looks_like_compact_jwe(value):
        return {"access_token": "", "session_cookie": value, "email": "", "input_type": "session_cookie"}
    if "session-token" in source.lower() and "=" in source:
        cookie = session_token_from_cookie_header(source)
        if looks_like_compact_jwe(cookie):
            return {"access_token": "", "session_cookie": cookie, "email": "", "input_type": "session_cookie"}
    raise ValueError("unsupported Session credential format")


def is_credential_failure_message(message: str) -> bool:
    value = str(message or "").lower()
    return any(marker in value for marker in (
        "http 401", "http 403", "token_expired", "token expired",
        "token is expired", "unauthorized", "forbidden", "invalid token",
    ))


def exchange_session_cookie(session: Any, session_cookie: str, force_refresh: bool = False) -> str:
    cookie = str(session_cookie or "").strip()
    if not looks_like_compact_jwe(cookie):
        raise RuntimeError("Session Cookie must be a compact JWE")
    url = SESSION_URL
    if force_refresh:
        url += "?refresh=true&reason=token_expired"
    last_status = 0
    last_error = ""
    for name in COOKIE_NAMES:
        headers = {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": UA,
            "Referer": "https://platform.example.com/",
            "Cookie": build_session_cookie_header(name, cookie),
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }
        try:
            response = session.get(url, headers=headers, timeout=30)
        except Exception as exc:
            last_error = str(exc)
            continue
        last_status = int(getattr(response, "status_code", 0) or 0)
        if last_status != 200:
            last_error = f"HTTP {last_status}"
            continue
        try:
            token = str((response.json() or {}).get("accessToken") or "").strip()
        except Exception:
            token = ""
        if looks_like_jwt(token) and not jwt_expired(token):
            return token
        last_error = "Session endpoint returned an invalid or expired accessToken"
    raise RuntimeError(
        f"Session Cookie could not be exchanged for an accessToken ({last_status} {last_error})"
    )


def ensure_access_token(
    session: Any, raw: str, force_refresh: bool = False
) -> tuple[str, dict[str, str]]:
    credentials = parse_credentials(raw)
    token = credentials.get("access_token") or ""
    session_cookie = credentials.get("session_cookie") or ""
    refresh_needed = force_refresh or (bool(token) and jwt_expired(token))
    if token and not refresh_needed:
        return token, credentials
    if session_cookie:
        token = exchange_session_cookie(
            session, session_cookie, force_refresh=refresh_needed or not token
        )
        credentials = dict(credentials)
        credentials["access_token"] = token
        credentials["refreshed"] = "1"
        return token, credentials
    if token:
        raise RuntimeError("accessToken is expired and no Session Cookie is available")
    raise RuntimeError("missing accessToken and Session Cookie")
