(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  let setupRequired = false;
  let toastTimer = 0;

  async function request(path, options = {}) {
    const response = await fetch(path, {
      method: options.method || 'GET',
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.ok === false) throw new Error(payload.error?.message || `HTTP ${response.status}`);
    return payload;
  }

  function toast(message, error = false) {
    const node = $('adminToast');
    node.textContent = message;
    node.className = `toast is-visible${error ? ' is-error' : ''}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { node.className = 'toast'; }, 2600);
  }

  function formatDate(value) {
    if (!value) return '-';
    const date = new Date(typeof value === 'number' ? value * 1000 : value);
    return Number.isNaN(date.getTime()) ? '-' : date.toLocaleString('zh-CN', { hour12: false });
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
  }

  function setAuthMode(setup) {
    setupRequired = setup;
    $('authTitle').textContent = setup ? '初始化管理员' : '管理员登录';
    $('authIntro').textContent = setup ? '首次访问先创建管理员账户。' : '登录后管理受管 API Key。';
    $('authSubmit').textContent = setup ? '创建并登录' : '登录';
    $('adminPassword').autocomplete = setup ? 'new-password' : 'current-password';
  }

  function showDashboard(username) {
    $('authPanel').hidden = true;
    $('dashboardPanel').hidden = false;
    $('keyLabel').placeholder = `${username || '管理员'} 的环境 Key`;
    loadKeys();
    loadProxy();
    loadBilling();
  }

  function showAuth() {
    $('authPanel').hidden = false;
    $('dashboardPanel').hidden = true;
  }

  async function loadState() {
    try {
      const state = await request('/api/admin/state');
      setAuthMode(state.setupRequired);
      if (state.authenticated) showDashboard(state.username);
      else showAuth();
    } catch (error) {
      $('authNotice').hidden = false;
      $('authNotice').textContent = error.message;
    }
  }

  async function submitAuth(event) {
    event.preventDefault();
    const button = $('authSubmit');
    button.disabled = true;
    try {
      const path = setupRequired ? '/api/admin/setup' : '/api/admin/login';
      const payload = await request(path, { method: 'POST', body: { username: $('adminUsername').value.trim(), password: $('adminPassword').value } });
      $('authNotice').hidden = true;
      showDashboard(payload.username);
      toast(setupRequired ? '管理员初始化完成' : '登录成功');
      $('adminPassword').value = '';
    } catch (error) {
      $('authNotice').hidden = false;
      $('authNotice').textContent = error.message;
    } finally {
      button.disabled = false;
    }
  }

  async function loadKeys() {
    try {
      const payload = await request('/api/admin/api-keys');
      const items = payload.items || [];
      $('keysEmpty').hidden = items.length > 0;
      $('keysBody').innerHTML = items.map((item) => `<tr>
        <td class="order-key">${escapeHtml(item.prefix)}</td>
        <td>${escapeHtml(item.label)}</td>
        <td><span class="${item.status === 'active' ? 'status-active' : 'status-revoked'}">${item.status === 'active' ? '启用' : '已吊销'}</span></td>
        <td>${escapeHtml(formatDate(item.createdAt))}</td>
        <td>${escapeHtml(formatDate(item.lastUsedAt))}</td>
        <td>${item.status === 'active' ? `<button class="danger-action" type="button" data-revoke="${item.id}">吊销</button>` : ''}</td>
      </tr>`).join('');
    } catch (error) {
      toast(error.message, true);
    }
  }

  async function createKey() {
    const button = $('createKeyButton');
    button.disabled = true;
    try {
      const payload = await request('/api/admin/api-keys', { method: 'POST', body: { label: $('keyLabel').value.trim() } });
      $('newKeyBox').hidden = false;
      $('newKeyValue').textContent = payload.key;
      $('keyLabel').value = '';
      await loadKeys();
      toast('API Key 已生成，请立即复制');
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }

  async function revokeKey(id) {
    if (!window.confirm('确认吊销这个 API Key？')) return;
    try {
      await request(`/api/admin/api-keys/${id}/revoke`, { method: 'POST', body: {} });
      await loadKeys();
      toast('API Key 已吊销');
    } catch (error) {
      toast(error.message, true);
    }
  }

  function renderProxyRoute(route, statusId, summaryId) {
    const items = route?.proxies || [];
    $(statusId).textContent = route?.configured ? `${route.count || items.length} 条 · ${route.rotation || 'round_robin'}` : '未配置';
    $(statusId).className = `runtime-state${route?.configured ? ' is-ready' : ''}`;
    $(summaryId).innerHTML = items.length
      ? items.map((item) => `<span>${escapeHtml(item.masked)}${item.country ? ` · ${escapeHtml(item.country)}` : ''}${item.lifetime ? ` · ${escapeHtml(item.lifetime)}` : ''}</span>`).join('')
      : '<span>EMPTY</span>';
  }

  function renderProxy(proxy) {
    const platform = proxy?.platform || proxy || {};
    const stripe = proxy?.stripe || proxy || {};
    $('proxyStatus').textContent = proxy?.configured ? '双代理已就绪' : '等待完整配置';
    $('proxyStatus').className = `runtime-state${proxy?.configured ? ' is-ready' : ''}`;
    renderProxyRoute(platform, 'platformProxyStatus', 'platformProxySummary');
    renderProxyRoute(stripe, 'stripeProxyStatus', 'stripeProxySummary');
    $('platformProxyValues').value = (platform.rawProxies || []).join('\n');
    $('stripeProxyValues').value = (stripe.rawProxies || []).join('\n');
  }

  async function loadProxy() {
    try {
      const payload = await request('/api/admin/proxy');
      renderProxy(payload.proxy);
    } catch (error) {
      toast(error.message, true);
    }
  }

  async function saveProxy(role) {
    const isStripe = role === 'stripe';
    const button = $(isStripe ? 'saveStripeProxy' : 'savePlatformProxy');
    const input = $(isStripe ? 'stripeProxyValues' : 'platformProxyValues');
    button.disabled = true;
    try {
      const payload = await request('/api/admin/proxy', {
        method: 'POST',
        body: {
          role,
          proxies: input.value.trim(),
        },
      });
      renderProxy(payload.proxy);
      toast(`${isStripe ? 'Stripe' : 'Platform'} 代理池已保存到数据库`);
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }

  async function testProxy() {
    const button = $('testProxy');
    button.disabled = true;
    try {
      const payload = await request('/api/admin/proxy/test', { method: 'POST', body: {} });
      const result = payload.result || {};
      $('proxyProbe').hidden = false;
      $('proxyProbe').className = `proxy-probe${result.ok ? '' : ' is-error'}`;
      const targets = result.targets || {};
      const targetText = `Platform ${targets.platform?.ok ? 'OK' : 'FAIL'} · Stripe ${targets.stripe?.ok ? 'OK' : 'FAIL'}`;
      const routes = result.routes || {};
      const routeText = `Platform ${routes.platform?.ip || '-'} / ${routes.platform?.country || '-'} · Stripe ${routes.stripe?.ip || '-'} / ${routes.stripe?.country || '-'}`;
      $('proxyProbe').textContent = result.ok
        ? `${targetText} · ${routeText}`
        : `${targetText} · ${routeText} · ${result.error || '代理出口检测失败'}`;
    } catch (error) {
      $('proxyProbe').hidden = false;
      $('proxyProbe').className = 'proxy-probe is-error';
      $('proxyProbe').textContent = error.message;
    } finally {
      button.disabled = false;
    }
  }

  function renderBilling(billing) {
    const source = billing?.source || 'billing_profiles_json';
    $('billingSource').value = source;
    $('addressApiUrl').value = billing?.addressApiUrl || 'https://address-api.example.com/api/v1/address?country_code=us&area_code=DE';
    $('addressApiLabel').hidden = source !== 'remote_address_api';
    $('billingStatus').textContent = source === 'remote_address_api'
      ? '远程 API'
      : `本地 JSON · ${billing?.localProfileCount || 0} 条`;
    $('billingStatus').className = 'runtime-state is-ready';
  }

  async function loadBilling() {
    try {
      const payload = await request('/api/admin/billing');
      renderBilling(payload.billing);
    } catch (error) {
      toast(error.message, true);
    }
  }

  async function saveBilling() {
    const button = $('saveBilling');
    button.disabled = true;
    try {
      const payload = await request('/api/admin/billing', {
        method: 'POST',
        body: {
          source: $('billingSource').value,
          addressApiUrl: $('addressApiUrl').value.trim(),
        },
      });
      renderBilling(payload.billing);
      toast('账单地址来源已保存到数据库');
    } catch (error) {
      toast(error.message, true);
    } finally {
      button.disabled = false;
    }
  }

  async function testBilling() {
    const button = $('testBilling');
    button.disabled = true;
    try {
      const payload = await request('/api/admin/billing/test', {
        method: 'POST',
        body: {
          source: $('billingSource').value,
          addressApiUrl: $('addressApiUrl').value.trim(),
        },
      });
      const billing = payload.result?.billing || {};
      $('billingProbe').hidden = false;
      $('billingProbe').className = 'proxy-probe';
      $('billingProbe').textContent = [billing.name, billing.line1, billing.city, billing.state, billing.postal_code, billing.country].filter(Boolean).join(' · ');
    } catch (error) {
      $('billingProbe').hidden = false;
      $('billingProbe').className = 'proxy-probe is-error';
      $('billingProbe').textContent = error.message;
    } finally {
      button.disabled = false;
    }
  }

  function bind() {
    $('authForm').addEventListener('submit', submitAuth);
    $('createKeyButton').addEventListener('click', createKey);
    $('refreshKeys').addEventListener('click', loadKeys);
    $('savePlatformProxy').addEventListener('click', () => saveProxy('platform'));
    $('saveStripeProxy').addEventListener('click', () => saveProxy('stripe'));
    $('testProxy').addEventListener('click', testProxy);
    $('billingSource').addEventListener('change', () => {
      $('addressApiLabel').hidden = $('billingSource').value !== 'remote_address_api';
    });
    $('saveBilling').addEventListener('click', saveBilling);
    $('testBilling').addEventListener('click', testBilling);
    $('logoutButton').addEventListener('click', async () => {
      await request('/api/admin/logout', { method: 'POST', body: {} });
      showAuth();
      setAuthMode(false);
      toast('已退出登录');
    });
    $('copyNewKey').addEventListener('click', async () => {
      try { await navigator.clipboard.writeText($('newKeyValue').textContent); toast('API Key 已复制'); }
      catch (_) { toast('浏览器未授予剪贴板权限', true); }
    });
    $('keysBody').addEventListener('click', (event) => {
      const button = event.target.closest('[data-revoke]');
      if (button) revokeKey(button.dataset.revoke);
    });
  }

  bind();
  loadState();
}());
