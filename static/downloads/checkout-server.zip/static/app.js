(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const STORAGE_KEY = 'checkout-server:api-key:v2';
  const POLL_MS = 3000;
  const TITLES = { workspace: '直接充值', orders: '历史订单', 'order-detail': '订单详情', integrations: '适配器状态' };
  const STATUS = {
    queued: { label: '排队中', code: 'QUEUED' },
    running: { label: '处理中', code: 'RUNNING' },
    awaiting_payment: { label: '等待验证', code: 'VERIFY' },
    succeeded: { label: '已完成', code: 'SUCCESS' },
    failed: { label: '失败', code: 'FAILED' },
  };
  const FALLBACK_CHECKOUT_REGIONS = [
    { code: 'PH', name: 'Philippines', currency: 'PHP' },
    { code: 'US', name: 'United States', currency: 'USD' },
    { code: 'CA', name: 'Canada', currency: 'CAD' },
    { code: 'GB', name: 'United Kingdom', currency: 'GBP' },
    { code: 'AU', name: 'Australia', currency: 'AUD' },
    { code: 'NZ', name: 'New Zealand', currency: 'NZD' },
    { code: 'SG', name: 'Singapore', currency: 'SGD' },
    { code: 'HK', name: 'Hong Kong', currency: 'HKD' },
    { code: 'JP', name: 'Japan', currency: 'JPY' },
    { code: 'DE', name: 'Germany', currency: 'EUR' },
    { code: 'FR', name: 'France', currency: 'EUR' },
    { code: 'IE', name: 'Ireland', currency: 'EUR' },
  ];
  const state = {
    view: 'workspace',
    planType: 'plus',
    metadata: null,
    sessionSummary: null,
    sessionValidation: { touched: false, valid: false, message: '' },
    checkout: null,
    workspaceOrder: null,
    detailOrder: null,
    pollTimer: null,
    syncInFlight: false,
    historyPage: 1,
    historyPages: 1,
    toastTimer: null,
    submitting: false,
    billing: null,
    checkoutCountry: 'PH',
    checkoutCurrency: 'PHP',
    checkoutRegions: FALLBACK_CHECKOUT_REGIONS,
  };

  function randomApiKey() {
    const bytes = new Uint8Array(32);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
  }

  function apiKey() { return $('apiKey').value.trim(); }

  function setApiKey(value) {
    $('apiKey').value = value;
    $('apiKeyCount').textContent = `${value.length} / 128`;
    $('historyKeyPrefix').textContent = value ? `API Key ${value.slice(0, 6)}...` : 'API Key -';
    localStorage.setItem(STORAGE_KEY, value);
  }

  async function request(path, options = {}) {
    const response = await fetch(path, {
      method: options.method || 'GET',
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      body: options.body === undefined ? undefined : JSON.stringify(options.body),
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || payload.ok === false) {
      const error = new Error(payload.error?.message || `HTTP ${response.status}`);
      error.payload = payload;
      error.code = payload.error?.code || '';
      throw error;
    }
    return payload;
  }

  function showToast(message, error = false) {
    const toast = $('toast');
    toast.textContent = message;
    toast.className = `toast is-visible${error ? ' is-error' : ''}`;
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => { toast.className = 'toast'; }, 2800);
  }

  async function copyText(text, label) {
    try {
      await navigator.clipboard.writeText(text);
      showToast(`${label}已复制`);
    } catch (_) {
      showToast('浏览器未授予剪贴板权限', true);
    }
  }

  function money(amountMinor, currency = 'USD') {
    if (!Number.isInteger(amountMinor) || amountMinor < 0) return '动态金额';
    return new Intl.NumberFormat('zh-CN', { style: 'currency', currency }).format(amountMinor / 100);
  }

  function dateTime(value) {
    if (!value) return '-';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? value : date.toLocaleString('zh-CN', { hour12: false });
  }

  function duration(value) {
    const milliseconds = Math.max(0, Number(value) || 0);
    if (milliseconds < 1000) return `${Math.round(milliseconds)} ms`;
    return `${(milliseconds / 1000).toFixed(milliseconds < 10000 ? 2 : 1)} s`;
  }

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
  }

  function statusInfo(status) {
    return STATUS[status] || { label: status || '未知', code: String(status || 'UNKNOWN').toUpperCase() };
  }

  function renewalLabel(renewal) {
    const labels = {
      pending: '等待支付',
      running: '正在取消',
      succeeded: '已取消',
      failed: '取消失败',
      unavailable: '缺少 Session',
      not_required: '未执行',
    };
    return labels[renewal?.status] || '等待支付';
  }

  function switchView(view) {
    if (!TITLES[view]) return;
    state.view = view;
    const tabView = view === 'order-detail' ? 'orders' : view;
    document.querySelectorAll('.tab-button').forEach((node) => node.classList.toggle('is-active', node.dataset.view === tabView));
    document.querySelectorAll('.view-section').forEach((node) => node.classList.toggle('is-active', node.id === `${view}View`));
    $('pageTitle').textContent = TITLES[view];
    if (view === 'orders') loadOrders();
    const activeOrder = view === 'workspace' ? state.workspaceOrder : view === 'order-detail' ? state.detailOrder : null;
    if (activeOrder && ['running', 'awaiting_payment'].includes(activeOrder.status)) startPolling();
    else stopPolling();
    history.replaceState(null, '', `#${view}`);
  }

  function renderCheckoutRegions(payload, firstLoad = false) {
    const checkout = payload?.platformCheckout || {};
    const configuredRegions = Array.isArray(checkout.regions) ? checkout.regions : [];
    const regions = configuredRegions.filter((region) => (
      region && /^[A-Z]{2}$/.test(String(region.code || '').toUpperCase())
      && /^[A-Z]{3}$/.test(String(region.currency || '').toUpperCase())
    )).map((region) => ({
      code: String(region.code).toUpperCase(),
      name: String(region.name || region.code),
      currency: String(region.currency).toUpperCase(),
    }));
    state.checkoutRegions = regions.length ? regions : FALLBACK_CHECKOUT_REGIONS;

    const configuredCountry = String(checkout.country || 'PH').toUpperCase();
    const current = state.checkoutRegions.find((region) => region.code === state.checkoutCountry);
    if (!current || firstLoad) state.checkoutCountry = configuredCountry;
    const selected = state.checkoutRegions.find((region) => region.code === state.checkoutCountry)
      || state.checkoutRegions[0];
    state.checkoutCountry = selected.code;
    state.checkoutCurrency = selected.currency;

    const select = $('checkoutCountry');
    select.innerHTML = state.checkoutRegions.map((region) => (
      `<option value="${escapeHtml(region.code)}" data-currency="${escapeHtml(region.currency)}">${escapeHtml(region.name)} (${escapeHtml(region.currency)})</option>`
    )).join('');
    renderCheckoutRegionDisplay();
  }

  function renderCheckoutRegionDisplay() {
    const select = $('checkoutCountry');
    select.value = state.checkoutCountry;
    $('checkoutCurrency').textContent = state.checkoutCurrency;
    $('checkoutRegionBadge').textContent = `PLATFORM CHECKOUT / ${state.checkoutCountry}/${state.checkoutCurrency}`;
    $('checkoutRegionBadgeShort').textContent = `${state.checkoutCountry}/${state.checkoutCurrency}`;
  }

  function renderMetadata(payload) {
    const firstLoad = state.metadata === null;
    state.metadata = payload;
    renderCheckoutRegions(payload, firstLoad);
    const stats = payload.stats || {};
    $('metricTotal').textContent = stats.total || 0;
    $('metricActive').textContent = (stats.queued || 0) + (stats.running || 0) + (stats.awaiting_payment || 0);
    $('metricSucceeded').textContent = stats.succeeded || 0;
    $('metricFailed').textContent = stats.failed || 0;
    for (const plan of payload.plans || []) {
      const button = document.querySelector(`[data-plan="${plan.type}"]`);
      if (button) button.querySelector('span').textContent = plan.amount_minor ? money(plan.amount_minor, plan.currency).replace('.00', '') : '动态金额';
    }
    document.querySelectorAll('[data-plan]').forEach((button) => {
      button.hidden = false;
    });
    renderIntegrations(payload.integrations || []);
    if (firstLoad) {
      updateSubmitAmount();
      invalidateCheckout();
      if (payload.platformCheckout?.enabled) {
        const proxy = payload.platformCheckout.proxy || {};
        const proxyBlocked = (proxy.platform?.required && !proxy.platform?.configured)
          || (proxy.stripe?.required && !proxy.stripe?.configured);
        $('stripeCardState').textContent = proxy.platform?.required && !proxy.platform?.configured
          ? '请先配置 Platform 工作代理'
          : proxy.stripe?.required && !proxy.stripe?.configured
            ? '请先配置 Stripe API 工作代理'
            : '填写银行卡后点击开始支付';
        $('stripeCardState').className = 'field-state';
        $('createOrder').disabled = true;
        $('createOrder').querySelector('span').textContent = '立即支付';
      } else {
        $('stripeCardState').textContent = 'Platform Checkout 适配器不可用';
        $('stripeCardState').className = 'field-state is-invalid';
        $('createOrder').disabled = true;
        $('createOrder').querySelector('span').textContent = 'Checkout 未配置';
      }
    }
    updatePaymentReadiness();
  }

  function renderIntegrations(items) {
    const statusLabel = { ready: '已就绪', staged: '待配置', missing: '未找到' };
    $('integrationList').innerHTML = items.map((item) => `
      <div class="integration-row">
        <div class="integration-code">${escapeHtml(item.key.slice(0, 4))}</div>
        <div class="integration-copy"><b>${escapeHtml(item.label)}</b><span>${item.enabled ? '当前可用' : '等待配置'}</span></div>
        <span class="integration-state ${escapeHtml(item.status)}">${statusLabel[item.status] || escapeHtml(item.status)}</span>
      </div>
    `).join('');
  }

  async function loadMetadata() {
    try {
      const payload = await request('/api/meta');
      renderMetadata(payload);
      $('healthText').textContent = '服务正常';
      $('healthText').parentElement.className = 'environment is-online';
    } catch (error) {
      $('healthText').textContent = '服务断开';
      $('healthText').parentElement.className = 'environment is-offline';
      showToast(error.message, true);
    }
  }

  function checkoutProxyBlocked() {
    const proxy = state.metadata?.platformCheckout?.proxy || {};
    return (proxy.platform?.required && !proxy.platform?.configured)
      || (proxy.stripe?.required && !proxy.stripe?.configured);
  }

  function cardDetails() {
    const number = $('cardNumber').value.replace(/\D/g, '');
    const expiry = $('cardExpiry').value.replace(/\D/g, '');
    const cvc = $('cardCvc').value.replace(/\D/g, '');
    const expMonth = expiry.slice(0, 2);
    const expYear = expiry.slice(2);
    return {
      number,
      expMonth,
      expYear: expYear.length === 2 ? `20${expYear}` : expYear,
      cvc,
    };
  }

  function cardValidation() {
    const card = cardDetails();
    if (!/^\d{12,19}$/.test(card.number)) return { valid: false, message: '卡号必须为 12-19 位数字' };
    if (!/^\d{2}$/.test(card.expMonth) || Number(card.expMonth) < 1 || Number(card.expMonth) > 12) {
      return { valid: false, message: '有效期月份必须为 01-12' };
    }
    if (!/^\d{4}$/.test(card.expYear)) return { valid: false, message: '有效期格式必须为 MM/YY' };
    const now = new Date();
    const year = Number(card.expYear);
    const month = Number(card.expMonth);
    if (year < now.getFullYear() || (year === now.getFullYear() && month < now.getMonth() + 1)) {
      return { valid: false, message: '银行卡有效期已过期' };
    }
    if (!/^\d{3,4}$/.test(card.cvc)) return { valid: false, message: 'CVC 必须为 3-4 位数字' };
    return { valid: true, message: '', card };
  }

  function cardDetailsComplete() {
    return cardValidation().valid;
  }

  function renderCardState() {
    const sourceStarted = Boolean(
      $('cardNumber').value || $('cardExpiry').value || $('cardCvc').value,
    );
    const result = cardValidation();
    $('stripeCardState').textContent = result.valid
      ? '银行卡已填写'
      : sourceStarted ? result.message : '填写银行卡后点击开始支付';
    $('stripeCardState').className = `field-state${result.valid ? ' is-valid' : sourceStarted ? ' is-invalid' : ''}`;
  }

  function updatePaymentReadiness() {
    const checkoutEnabled = Boolean(state.metadata?.platformCheckout?.enabled);
    const ready = checkoutEnabled
      && !checkoutProxyBlocked()
      && state.sessionValidation.valid
      && cardDetailsComplete()
      && !state.submitting;
    $('createOrder').disabled = !ready;
    if (!state.submitting) $('createOrder').querySelector('span').textContent = '立即支付';
  }

  function clearCardFields() {
    $('cardNumber').value = '';
    $('cardExpiry').value = '';
    $('cardCvc').value = '';
    renderCardState();
    updatePaymentReadiness();
  }

  function selectedPlan() {
    return state.metadata?.plans?.find((item) => item.type === state.planType)
      || { amount_minor: state.planType === 'plus' ? 0 : state.planType === 'pro5' ? 10000 : 20000, currency: state.planType === 'plus' ? 'PHP' : 'USD' };
  }

  function updateSubmitAmount() {
    const plan = selectedPlan();
    $('submitAmount').textContent = plan.amount_minor ? money(plan.amount_minor, plan.currency) : '支付时获取金额';
  }

  function billingDetails() {
    return {
      ...(state.billing || {}),
      email: state.sessionValidation.valid ? state.sessionValidation.email : '',
    };
  }

  function requireBillingDetails() {
    const billing = billingDetails();
    const missing = [
      ['name', '持卡人姓名'],
      ['email', '邮箱'],
      ['line1', '账单地址'],
      ['city', '城市'],
      ['state', '州'],
      ['postal_code', '邮编'],
      ['country', '国家/地区'],
    ].filter(([key]) => !billing[key]).map(([, label]) => label);
    if (missing.length) throw new Error(`请填写账单信息：${missing.join('、')}`);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(billing.email)) throw new Error('账单邮箱格式无效');
    if (!/^[A-Z]{2}$/.test(billing.country)) throw new Error('国家/地区必须是两位代码');
    return billing;
  }

  function decodeJwtPayload(token) {
    const part = String(token || '').split('.')[1];
    if (!part) return null;
    try {
      const normalized = part.replace(/-/g, '+').replace(/_/g, '/');
      const binary = atob(normalized.padEnd(normalized.length + ((4 - normalized.length % 4) % 4), '='));
      const bytes = Uint8Array.from(binary, (char) => char.charCodeAt(0));
      const payload = JSON.parse(new TextDecoder().decode(bytes));
      return payload && typeof payload === 'object' && !Array.isArray(payload) ? payload : null;
    } catch (_) {
      return null;
    }
  }

  function inspectSessionInput() {
    const source = $('sessionJson').value.trim();
    if (!source) return { touched: false, valid: false, email: '', message: '请粘贴 Token JSON' };
    let data;
    try {
      data = JSON.parse(source);
    } catch (_) {
      return { touched: true, valid: false, email: '', message: 'Token 信息不是有效 JSON' };
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) {
      return { touched: true, valid: false, email: '', message: 'Token 信息必须是完整 JSON 对象' };
    }
    const email = typeof data.user?.email === 'string'
      ? data.user.email.trim()
      : typeof data.profile?.email === 'string' ? data.profile.email.trim() : '';
    if (!email || !email.includes('@')) {
      return { touched: true, valid: false, email: '', message: 'Token 信息缺少用户邮箱' };
    }
    const token = typeof data.accessToken === 'string'
      ? data.accessToken.trim()
      : typeof data.access_token === 'string' ? data.access_token.trim() : '';
    if (!token) return { touched: true, valid: false, email, message: 'Token 信息缺少 accessToken' };
    const expiresAt = decodeJwtPayload(token)?.exp;
    if (!Number.isFinite(expiresAt)) {
      return { touched: true, valid: false, email, message: 'accessToken 缺少有效期信息' };
    }
    if (Date.now() >= expiresAt * 1000) {
      return { touched: true, valid: false, email, message: 'Token 已过期，请重新获取 Platform Session' };
    }
    return { touched: true, valid: true, email, message: '' };
  }

  function validateSessionLocally() {
    const result = inspectSessionInput();
    state.sessionValidation = result;
    state.sessionSummary = result.valid ? { email: result.email, expired: false, has_access_token: true } : null;
    $('sessionState').textContent = result.touched ? (result.valid ? '会话有效' : '会话无效') : '等待输入';
    $('sessionState').className = `field-state${result.touched ? (result.valid ? ' is-valid' : ' is-invalid') : ''}`;
    $('sessionSummary').hidden = !result.touched;
    $('sessionSummary').innerHTML = result.valid
      ? `<span>账户邮箱</span><b>${escapeHtml(result.email)}</b><span>校验方式</span><b>本地即时校验</b>`
      : `<span>校验结果</span><b>${escapeHtml(result.message)}</b>`;
    if (!result.valid) state.billing = null;
    return result;
  }

  function invalidateCheckout(message = '') {
    state.checkout = null;
    state.billing = null;
    $('submitAmount').textContent = '支付时获取金额';
    if (message) {
      $('stripeCardState').textContent = message;
      $('stripeCardState').className = 'field-state';
    }
    updatePaymentReadiness();
  }

  async function preparePlatformCheckout(summary) {
    if (!summary || summary.expired) throw new Error('Session 无效或已过期');
    const payload = await request('/api/platform/checkout/preflight', {
      method: 'POST',
      body: {
        apiKey: apiKey(),
        session: $('sessionJson').value,
        planType: state.planType,
        country: state.checkoutCountry,
        currency: state.checkoutCurrency,
      },
    });
    if (payload.checkout?.checkoutProvider === 'stripe' && !payload.checkout.paymentPageId) {
      throw new Error('Stripe Checkout 未返回 Payment Page ID');
    }
    state.checkout = payload.checkout;
    state.checkoutCountry = String(payload.checkout.country || state.checkoutCountry).toUpperCase();
    state.checkoutCurrency = String(payload.checkout.currency || state.checkoutCurrency).toUpperCase();
    renderCheckoutRegionDisplay();
    state.billing = payload.billing || null;
    $('submitAmount').textContent = payload.checkout.amountMinor !== null && payload.checkout.amountMinor !== undefined
      ? money(payload.checkout.amountMinor, payload.checkout.currency || 'USD')
      : '金额待支付确认';
    return payload.checkout;
  }

  function renderCurrentOrder(order) {
    state.workspaceOrder = order;
    $('liveEmpty').hidden = true;
    $('liveOrder').hidden = false;
    $('liveOrderKey').textContent = order.orderKey;
    $('liveEmail').textContent = order.email;
    $('livePlan').textContent = `${order.planName} · ${money(order.amountMinor, order.currency)}`;
    $('liveCardKey').textContent = order.cardKey || '-';
    $('liveCardKey').title = order.cardKey || '';
    $('liveCard').textContent = order.paymentLast4 === '----' ? 'Stripe PaymentMethod' : `···· ${order.paymentLast4}`;
    $('liveRetries').textContent = order.retryCount;
    $('liveRenewal').textContent = `${renewalLabel(order.renewal)}${order.renewal?.retryCount ? ` · ${order.renewal.retryCount} 次` : ''}`;
    $('liveStepLabel').textContent = order.stepLabel;
    $('liveProgressValue').textContent = `${order.progress}%`;
    $('liveProgressBar').style.width = `${order.progress}%`;
    const info = statusInfo(order.status);
    $('liveStatusBadge').textContent = info.code;
    $('liveStatusBadge').className = `status-badge status-${order.status}`;
    document.querySelectorAll('#stepList li').forEach((node) => {
      const minimum = Number(node.dataset.min);
      node.className = '';
      if (order.status === 'failed' && order.progress >= minimum && order.progress < minimum + 25) node.classList.add('is-error');
      else if (order.progress >= minimum + 20 || order.status === 'succeeded') node.classList.add('is-done');
      else if (order.progress >= minimum) node.classList.add('is-active');
    });
    const result = $('liveResult');
    const retry = $('retryCurrent');
    const actionLink = $('liveActionLink');
    const verifyAction = $('liveVerifyAction');
    actionLink.hidden = true;
    actionLink.removeAttribute('href');
    verifyAction.hidden = true;
    if (order.status === 'succeeded') {
      result.hidden = false;
      result.className = 'live-result';
      result.textContent = order.renewal?.status === 'succeeded'
        ? `支付终态已确认；确认编号 ${order.confirmationRef}；Platform 自动续费已取消${order.renewal.activeUntil ? `，权益保留至 ${order.renewal.activeUntil}` : ''}`
        : `确认编号 ${order.confirmationRef}；续费取消状态：${renewalLabel(order.renewal)}`;
      retry.hidden = true;
    } else if (order.status === 'failed') {
      result.hidden = false;
      result.className = 'live-result is-error';
      result.textContent = order.errorMessage || '订单处理失败';
      retry.hidden = ['stripe', 'platform_checkout'].includes(order.provider);
    } else if (order.status === 'awaiting_payment') {
      result.hidden = false;
      result.className = ['subscription_recovery_exhausted', 'payment_recovery_exhausted'].includes(order.errorCode)
        ? 'live-result is-error'
        : 'live-result';
      result.textContent = order.errorCode === 'payment_processing'
        ? 'Stripe Intent 仍在 processing；系统会继续核验当前 Checkout。'
        : order.errorCode === 'checkout_session_confirmation_required'
          ? '当前 Checkout 需要浏览器会话继续确认；订单和 Checkout 链接已保留。'
        : order.errorCode === 'stripe_action_required'
          ? 'Stripe Intent 正在等待 3DS 验证；完成后系统将继续核验。'
        : order.errorCode === 'payment_confirmation_required'
          ? '该历史订单仍需完成支付确认；当前记录没有可核验的 Intent 成功终态。'
        : order.errorCode === 'payment_terminal_unverified'
          ? '尚未取得当前 Stripe Intent 的支付成功终态。'
        : order.errorCode === 'payment_recovery_exhausted'
          ? '状态核验已达到重试上限，支付或 Checkout 确认仍未完成。'
        : order.errorCode === 'subscription_recovery_exhausted'
          ? '自动恢复已达到重试上限；请重新填写原账号 Session 后进行一次恢复核验。'
        : order.errorCode === 'subscription_pending'
          ? 'Stripe/Checkout 已处理，系统正在完成 Vendor 回跳并等待 Plus 同步，请保留当前 Session。'
          : '正在核验当前 Checkout 的支付状态。';
      if (order.paymentActionUrl) {
        actionLink.href = order.paymentActionUrl;
        actionLink.hidden = false;
      }
      verifyAction.hidden = !['stripe_action_required', 'checkout_session_confirmation_required'].includes(order.errorCode || '');
      retry.hidden = true;
    } else {
      result.hidden = true;
      retry.hidden = true;
    }
    if (['running', 'awaiting_payment'].includes(order.status)) startPolling();
    else stopPolling();
  }

  function renderOrderDetail(order) {
    state.detailOrder = order;
    const info = statusInfo(order.status);
    $('detailOrderKey').textContent = order.orderKey;
    $('detailCardKey').textContent = order.cardKey || '-';
    $('detailCardKey').title = order.cardKey || '';
    $('detailEmail').textContent = order.email || '-';
    $('detailPlan').textContent = order.planName || '-';
    $('detailCard').textContent = order.paymentLast4 === '----' ? 'Stripe PaymentMethod' : `···· ${order.paymentLast4}`;
    $('detailAmount').textContent = money(order.amountMinor, order.currency);
    $('detailStep').textContent = order.stepLabel || order.step || '-';
    $('detailRenewal').textContent = `${renewalLabel(order.renewal)}${order.renewal?.retryCount ? ` · ${order.renewal.retryCount} 次` : ''}`;
    $('detailRetries').textContent = order.retryCount;
    $('detailConfirmation').textContent = order.confirmationRef || '-';
    $('detailPaymentStatus').textContent = order.paymentTerminalStatus || order.checkoutTerminalStatus || '-';
    $('detailCreatedAt').textContent = dateTime(order.createdAt);
    $('detailCompletedAt').textContent = dateTime(order.completedAt);
    $('detailStatusBadge').textContent = info.code;
    $('detailStatusBadge').className = `status-badge status-${order.status}`;
    $('detailProgressValue').textContent = `${order.progress}%`;
    $('detailProgressBar').style.width = `${order.progress}%`;
    const message = $('detailMessage');
    message.hidden = false;
    message.className = `live-result${order.status === 'failed' ? ' is-error' : ''}`;
    message.textContent = order.errorMessage
      || (order.status === 'succeeded'
        ? `支付已完成；${renewalLabel(order.renewal)}`
        : order.status === 'awaiting_payment'
          ? '订单正在等待 Checkout 与 Plus 状态同步。'
          : '订单正在处理中。');
    const actionLink = $('detailActionLink');
    actionLink.hidden = !order.paymentActionUrl;
    if (order.paymentActionUrl) actionLink.href = order.paymentActionUrl;
    else actionLink.removeAttribute('href');
    $('detailVerifyAction').hidden = !(
      order.status === 'awaiting_payment'
      && ['stripe_action_required', 'checkout_session_confirmation_required'].includes(order.errorCode || '')
    );
    if (order.paymentActionDetails) {
      message.title = JSON.stringify(order.paymentActionDetails);
    } else {
      message.removeAttribute('title');
    }
    const timeline = Array.isArray(order.timeline) ? order.timeline : [];
    const timelinePanel = $('detailTimelinePanel');
    timelinePanel.hidden = timeline.length === 0;
    $('detailTotalDuration').textContent = timeline.length
      ? duration(timeline[timeline.length - 1]?.elapsedMs)
      : '-';
    $('detailTimeline').innerHTML = timeline.map((event) => (
      `<li><span class="detail-timeline-stage">${escapeHtml(event.stage || 'event')}</span>`
      + `<span class="detail-timeline-time">+${escapeHtml(duration(event.elapsedMs))}</span>`
      + `<span class="detail-timeline-message">${escapeHtml(event.message || '')}</span></li>`
    )).join('');
    if (['running', 'awaiting_payment'].includes(order.status)) startPolling();
    else stopPolling();
  }

  function startPolling() {
    if (state.pollTimer) return;
    state.pollTimer = window.setInterval(pollOrder, POLL_MS);
  }

  function stopPolling() {
    window.clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  async function pollOrder() {
    const detailView = state.view === 'order-detail';
    const currentOrder = detailView ? state.detailOrder : state.workspaceOrder;
    if (!currentOrder || state.syncInFlight) return;
    state.syncInFlight = true;
    try {
      const syncable = !detailView && ['platform_checkout', 'stripe'].includes(currentOrder.provider);
      const payload = await request(syncable ? '/api/platform/checkout/sync' : '/api/orders/status', {
        method: 'POST',
        body: {
          apiKey: apiKey(),
          orderKey: currentOrder.orderKey,
          ...(syncable ? { session: $('sessionJson').value.trim() || undefined } : {}),
        },
      });
      const previousStatus = currentOrder.status;
      if (detailView) renderOrderDetail(payload.order);
      else renderCurrentOrder(payload.order);
      if (previousStatus !== payload.order.status && ['succeeded', 'failed'].includes(payload.order.status)) {
        showToast(payload.order.status === 'succeeded' ? '订单处理完成' : '订单处理失败', payload.order.status === 'failed');
        await Promise.all([loadOrders(), loadMetadata()]);
      }
    } catch (error) {
      stopPolling();
      showToast(error.message, true);
    } finally {
      state.syncInFlight = false;
    }
  }

  async function verifyPaymentAction(detailView = false) {
    const currentOrder = detailView ? state.detailOrder : state.workspaceOrder;
    if (!currentOrder || state.syncInFlight) return;
    state.syncInFlight = true;
    try {
      const session = detailView ? '' : $('sessionJson').value.trim();
      const payload = await request('/api/platform/checkout/sync', {
        method: 'POST',
        body: {
          apiKey: apiKey(),
          orderKey: currentOrder.orderKey,
          ...(session ? { session } : {}),
        },
      });
      if (detailView) renderOrderDetail(payload.order);
      else renderCurrentOrder(payload.order);
      if (payload.order.status === 'succeeded') {
        showToast('验证成功，Checkout 与 Plus 状态已确认');
      } else if (payload.order.status === 'failed') {
        showToast(payload.order.errorMessage || '支付验证失败', true);
      } else {
        showToast('发卡行验证尚未完成，验证入口和订单状态继续保留');
      }
      await Promise.all([loadOrders(), loadMetadata()]);
    } catch (error) {
      showToast(error.message, true);
    } finally {
      state.syncInFlight = false;
    }
  }

  async function createOrder(event) {
    event.preventDefault();
    const button = $('createOrder');
    if (!/^[A-Za-z0-9_-]{50,128}$/.test(apiKey())) {
      showToast('请填写管理员生成的 API Key', true);
      return;
    }
    const session = validateSessionLocally();
    if (!session.valid) {
      showToast(session.message, true);
      return;
    }
    const cardResult = cardValidation();
    if (!cardResult.valid) {
      showToast(cardResult.message, true);
      return;
    }
    state.submitting = true;
    button.disabled = true;
    button.querySelector('span').textContent = '正在创建 Checkout';
    $('stripeCardState').textContent = '正在创建 Checkout 并获取金额';
    $('stripeCardState').className = 'field-state';
    let phase = 'checkout';
    try {
      if (!state.checkout) await preparePlatformCheckout(state.sessionSummary);
      const billing = requireBillingDetails();
      phase = 'payment_method';
      button.querySelector('span').textContent = '正在提交银行卡';
      const paymentInput = {
        paymentMode: 'api_card',
        card: cardResult.card,
        cardLast4: cardResult.card.number.slice(-4),
      };
      phase = 'charge';
      button.querySelector('span').textContent = '正在确认支付';
      const payload = await request('/api/platform/checkout/charge', {
        method: 'POST',
        body: {
          apiKey: apiKey(),
          session: $('sessionJson').value,
          planType: state.planType,
          country: state.checkoutCountry,
          currency: state.checkoutCurrency,
          checkout: state.checkout,
          billing,
          ...paymentInput,
        },
      });
      if (payload.order.amountKnown) {
        $('submitAmount').textContent = money(payload.order.amountMinor, payload.order.currency);
      }
      state.checkout = null;
      state.billing = null;
      clearCardFields();
      $('stripeCardState').textContent = '订单已提交';
      $('stripeCardState').className = 'field-state is-valid';
      renderCurrentOrder(payload.order);
      showToast(payload.actionRequired ? 'Stripe 需要额外验证' : '订单已提交');
      await Promise.all([loadOrders(), loadMetadata()]);
    } catch (error) {
      if (phase === 'checkout') {
        state.checkout = null;
        state.billing = null;
        $('stripeCardState').textContent = cardDetailsComplete()
          ? '银行卡已填写，Checkout 准备失败'
          : 'Checkout 准备失败';
        $('stripeCardState').className = 'field-state is-invalid';
        $('submitAmount').textContent = '点击立即支付重试';
      } else if (!error.payload?.order) {
        $('stripeCardState').textContent = phase === 'payment_method'
          ? '银行卡提交失败，请检查错误详情'
          : '支付确认未完成，请查看错误提示';
        $('stripeCardState').className = 'field-state is-invalid';
      }
      if (error.payload?.order) {
        state.checkout = null;
        state.billing = null;
        clearCardFields();
        renderCurrentOrder(error.payload.order);
        await loadOrders().catch(() => {});
      }
      showToast(error.message, true);
    } finally {
      state.submitting = false;
      updatePaymentReadiness();
    }
  }

  async function retryOrder(orderKey) {
    try {
      const payload = await request(`/api/orders/${encodeURIComponent(orderKey)}/retry`, { method: 'POST', body: { apiKey: apiKey() } });
      renderCurrentOrder(payload.order);
      switchView('workspace');
      showToast('订单已重新排队');
      await loadOrders();
    } catch (error) { showToast(error.message, true); }
  }

  async function loadOrders() {
    const key = apiKey();
    if (!/^[A-Za-z0-9_-]{50,128}$/.test(key)) return;
    try {
      const payload = await request('/api/orders/query', { method: 'POST', body: { apiKey: key, page: state.historyPage, pageSize: 20 } });
      state.historyPages = Math.max(1, Math.ceil(payload.total / payload.pageSize));
      renderOrders(payload.items);
      $('pageLabel').textContent = `第 ${state.historyPage} / ${state.historyPages} 页`;
      $('previousPage').disabled = state.historyPage <= 1;
      $('nextPage').disabled = state.historyPage >= state.historyPages;
    } catch (error) { showToast(error.message, true); }
  }

  function renderOrders(items) {
    $('ordersEmpty').hidden = items.length > 0;
    $('ordersBody').innerHTML = items.map((order) => {
      const info = statusInfo(order.status);
      const recoverableCheckout = order.provider === 'platform_checkout'
        && (order.status === 'awaiting_payment' || order.status === 'failed')
        && ['subscription_pending', 'auth_refresh_required', 'payment_terminal_unverified', 'payment_recovery_required', 'subscription_recovery_exhausted'].includes(order.errorCode || '');
      const action = recoverableCheckout
        ? `<button class="row-action" type="button" data-open="${escapeHtml(order.orderKey)}">查看</button>`
        : order.status === 'failed' && order.provider === 'sandbox'
        ? `<button class="row-action" type="button" data-retry="${escapeHtml(order.orderKey)}">重试</button>`
        : `<button class="row-action" type="button" data-open="${escapeHtml(order.orderKey)}">查看</button>`;
      return `<tr><td class="order-key">${escapeHtml(order.orderKey)}</td><td>${escapeHtml(order.email)}</td><td>${escapeHtml(order.planName)}</td><td>${order.paymentLast4 === '----' ? 'Stripe' : `···· ${escapeHtml(order.paymentLast4)}`}</td><td>${escapeHtml(money(order.amountMinor, order.currency))}</td><td><span class="table-status status-${escapeHtml(order.status)}">${escapeHtml(info.label)}</span></td><td>${escapeHtml(renewalLabel(order.renewal))}</td><td>${order.retryCount}</td><td>${escapeHtml(dateTime(order.createdAt))}</td><td>${escapeHtml(dateTime(order.completedAt))}</td><td>${action}</td></tr>`;
    }).join('');
  }

  async function openOrder(orderKey) {
    try {
      const payload = await request('/api/orders/status', {
        method: 'POST',
        body: { apiKey: apiKey(), orderKey },
      });
      switchView('order-detail');
      renderOrderDetail(payload.order);
      showToast(payload.order.status === 'succeeded' ? 'Checkout 与 Plus 核验成功' : '已刷新订单状态');
    } catch (error) { showToast(error.message, true); }
  }

  function bindEvents() {
    document.querySelectorAll('.tab-button').forEach((node) => node.addEventListener('click', () => switchView(node.dataset.view)));
    $('orderForm').addEventListener('submit', createOrder);
    $('apiKey').addEventListener('input', () => {
      setApiKey($('apiKey').value.trim());
      state.historyPage = 1;
      invalidateCheckout('');
      updatePaymentReadiness();
    });
    $('generateApiKey').addEventListener('click', () => {
      setApiKey(randomApiKey());
      state.historyPage = 1;
      invalidateCheckout('');
      updatePaymentReadiness();
      showToast('请在管理后台生成受管 API Key');
    });
    $('copyApiKey').addEventListener('click', () => copyText(apiKey(), 'API Key'));
    $('copyOrderKey').addEventListener('click', () => state.workspaceOrder && copyText(state.workspaceOrder.orderKey, '订单号'));
    document.querySelectorAll('[data-plan]').forEach((button) => button.addEventListener('click', () => {
      state.planType = button.dataset.plan;
      document.querySelectorAll('[data-plan]').forEach((node) => node.classList.toggle('is-selected', node === button));
      updateSubmitAmount();
      invalidateCheckout('');
    }));
    $('checkoutCountry').addEventListener('change', () => {
      const region = state.checkoutRegions.find((item) => item.code === $('checkoutCountry').value);
      if (!region) return;
      state.checkoutCountry = region.code;
      state.checkoutCurrency = region.currency;
      renderCheckoutRegionDisplay();
      invalidateCheckout('');
    });
    $('sessionJson').addEventListener('input', () => {
      invalidateCheckout('');
      validateSessionLocally();
      renderCardState();
      updatePaymentReadiness();
    });
    $('fillFixture').addEventListener('click', () => {
      $('sessionJson').value = JSON.stringify({ user: { email: 'fixture@example.test' }, expires: '2099-01-01T00:00:00Z', accessToken: 'eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJleHAiOjQwNzA5MDg4MDB9.fixture' }, null, 2);
      invalidateCheckout('');
      validateSessionLocally();
      renderCardState();
      updatePaymentReadiness();
    });
    ['cardNumber', 'cardExpiry', 'cardCvc'].forEach((id) => {
      $(id).addEventListener('input', () => {
        renderCardState();
        updatePaymentReadiness();
      });
    });
    $('retryCurrent').addEventListener('click', () => state.workspaceOrder && retryOrder(state.workspaceOrder.orderKey));
    $('liveVerifyAction').addEventListener('click', () => verifyPaymentAction(false));
    $('detailVerifyAction').addEventListener('click', () => verifyPaymentAction(true));
    $('refreshOrders').addEventListener('click', loadOrders);
    $('previousPage').addEventListener('click', () => { if (state.historyPage > 1) { state.historyPage -= 1; loadOrders(); } });
    $('nextPage').addEventListener('click', () => { if (state.historyPage < state.historyPages) { state.historyPage += 1; loadOrders(); } });
    $('ordersBody').addEventListener('click', (event) => { const retry = event.target.closest('[data-retry]'); const open = event.target.closest('[data-open]'); if (retry) retryOrder(retry.dataset.retry); else if (open) openOrder(open.dataset.open); });
    $('backToOrders').addEventListener('click', () => switchView('orders'));
    $('refreshOrderDetail').addEventListener('click', () => state.detailOrder && openOrder(state.detailOrder.orderKey));
    window.addEventListener('hashchange', () => {
      const requested = location.hash.slice(1) || 'workspace';
      switchView(requested === 'order-detail' && !state.detailOrder ? 'orders' : requested);
    });
  }

  async function init() {
    bindEvents();
    const stored = localStorage.getItem(STORAGE_KEY);
    setApiKey(stored && /^[A-Za-z0-9_-]{50,128}$/.test(stored) ? stored : randomApiKey());
    const requestedView = location.hash.slice(1);
    if (TITLES[requestedView]) switchView(requestedView === 'order-detail' ? 'orders' : requestedView);
    await Promise.all([loadMetadata(), loadOrders()]);
  }

  init();
}());
