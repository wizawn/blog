"""Tests for Checkout Server v1."""
