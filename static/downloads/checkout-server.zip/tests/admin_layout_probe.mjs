import fs from 'node:fs';

const [url, output] = process.argv.slice(2);
const pages = await fetch('http://127.0.0.1:9222/json/list').then((response) => response.json());
const page = pages.find((item) => item.type === 'page');
if (!page) throw new Error('Chrome DevTools page target not found');

const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener('open', resolve, { once: true });
  socket.addEventListener('error', reject, { once: true });
});

let sequence = 0;
const pending = new Map();
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (!message.id || !pending.has(message.id)) return;
  const pair = pending.get(message.id);
  pending.delete(message.id);
  if (message.error) pair.reject(new Error(message.error.message));
  else pair.resolve(message.result || {});
});

function command(method, params = {}) {
  const id = ++sequence;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

await command('Page.enable');
await command('Emulation.setDeviceMetricsOverride', {
  width: 390, height: 844, deviceScaleFactor: 1, mobile: true, screenWidth: 390, screenHeight: 844,
});
await command('Page.navigate', { url });
await new Promise((resolve) => setTimeout(resolve, 1000));
await command('Runtime.evaluate', {
  awaitPromise: true,
  expression: `fetch('/api/admin/setup', {
    method: 'POST', headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({username: 'layout-admin', password: 'layout-test-password'})
  }).then((response) => response.status)`,
});
await command('Page.reload');
await new Promise((resolve) => setTimeout(resolve, 1600));

const metrics = await command('Runtime.evaluate', {
  returnByValue: true,
  expression: `(() => {
    const section = document.querySelector('.runtime-section')?.getBoundingClientRect();
    return {
      innerWidth: window.innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
      dashboardVisible: !document.querySelector('#dashboardPanel')?.hidden,
      proxyControls: [
        'platformProxyValues', 'savePlatformProxy',
        'stripeProxyValues', 'saveStripeProxy',
        'testProxy', 'proxyStatus',
      ].every((id) => Boolean(document.getElementById(id))),
      billingControls: [
        'billingSource', 'addressApiUrl', 'saveBilling', 'testBilling', 'billingStatus',
      ].every((id) => Boolean(document.getElementById(id))),
      runtimeSection: section ? {left: section.left, right: section.right, width: section.width} : null,
    };
  })()`,
});

if (output) {
  const screenshot = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  fs.writeFileSync(output, Buffer.from(screenshot.data, 'base64'));
}
process.stdout.write(JSON.stringify(metrics.result.value));
socket.close();
