import fs from 'node:fs';

const [url, widthText, heightText, output] = process.argv.slice(2);
const width = Number(widthText || 390);
const height = Number(heightText || 844);

const pages = await fetch('http://127.0.0.1:9222/json/list').then((response) => response.json());
const page = pages.find((item) => item.type === 'page');
if (!page) throw new Error('Chrome DevTools page target not found');

const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener('open', resolve, { once: true });
  socket.addEventListener('error', reject, { once: true });
});

let sequence = 0;
const pending = new Map();
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (!message.id || !pending.has(message.id)) return;
  const { resolve, reject } = pending.get(message.id);
  pending.delete(message.id);
  if (message.error) reject(new Error(message.error.message));
  else resolve(message.result || {});
});

function command(method, params = {}) {
  const id = ++sequence;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

await command('Page.enable');
await command('Emulation.setDeviceMetricsOverride', {
  width,
  height,
  deviceScaleFactor: 1,
  mobile: width <= 500,
  screenWidth: width,
  screenHeight: height,
});
await command('Page.navigate', { url });
await new Promise((resolve) => setTimeout(resolve, 1800));

const metrics = await command('Runtime.evaluate', {
  returnByValue: true,
  expression: `(() => {
    const rect = (selector) => {
      const node = document.querySelector(selector);
      if (!node) return null;
      const value = node.getBoundingClientRect();
      return { left: value.left, right: value.right, width: value.width };
    };
    return {
      innerWidth: window.innerWidth,
      scrollWidth: document.documentElement.scrollWidth,
      bodyScrollWidth: document.body.scrollWidth,
      app: rect('.app-shell'),
      form: rect('.order-form'),
      nav: rect('.primary-tabs'),
      modeBadge: rect('.mode-badge'),
      billingFields: document.querySelectorAll('[data-billing]').length,
    };
  })()`,
});

if (output) {
  const screenshot = await command('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  fs.writeFileSync(output, Buffer.from(screenshot.data, 'base64'));
}

process.stdout.write(JSON.stringify(metrics.result.value));
socket.close();
