from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from backend.service import OrderService


class BillingProfileFixtureTests(unittest.TestCase):
    def test_profiles_match_billing_form_and_use_full_state_names(self) -> None:
        path = Path(__file__).parents[1] / "fixtures" / "billing_profiles.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        profiles = payload["profiles"]
        expected_keys = {"name", "line1", "city", "state", "postal_code", "country"}
        expected_states = {"Alaska", "Delaware", "Montana", "New Hampshire", "Oregon"}

        self.assertEqual(len(profiles), 200)
        self.assertEqual(payload["states"], {"AK": 40, "DE": 40, "MT": 40, "NH": 40, "OR": 40})
        self.assertTrue(all(set(profile) == expected_keys for profile in profiles))
        self.assertTrue(all(profile["country"] == "US" for profile in profiles))
        self.assertEqual({profile["state"] for profile in profiles}, expected_states)
        self.assertNotIn("email", json.dumps(payload).lower())

    def test_backend_adds_session_email_to_random_profile(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service = OrderService(Path(directory) / "test.db", Path(__file__).parents[1])
            try:
                billing = service._new_checkout_billing({"email": "session@example.test"})
            finally:
                service.close()
        self.assertEqual(billing["email"], "session@example.test")
        self.assertEqual(billing["country"], "US")
        self.assertIn(billing["state"], {"Alaska", "Delaware", "Montana", "New Hampshire", "Oregon"})
        self.assertEqual(
            set(billing) - {"email"},
            {"name", "line1", "city", "state", "postal_code", "country"},
        )

    def test_billing_source_is_persisted_in_database(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            database_path = Path(directory) / "test.db"
            service = OrderService(database_path, Path(__file__).parents[1])
            try:
                setup = service.setup_admin({
                    "username": "billing-admin",
                    "password": "long-test-password",
                })
                configured = service.configure_billing(setup["token"], {
                    "source": "remote_address_api",
                    "addressApiUrl": (
                        "https://address-api.example.com/api/v1/address?"
                        "country_code=us&area_code=DE"
                    ),
                })
                self.assertEqual(configured["source"], "remote_address_api")
            finally:
                service.close()
            reopened = OrderService(database_path, Path(__file__).parents[1])
            try:
                self.assertEqual(
                    reopened.database.billing_configuration()["source"],
                    "remote_address_api",
                )
            finally:
                reopened.close()

    def test_remote_address_api_is_normalized_and_session_email_is_added(self) -> None:
        payload = {
            "data": {
                "firstname": "Taylor",
                "lastname": "Morgan",
                "address": {
                    "street": "100 Market Street",
                    "city": "Wilmington",
                    "area_code": "DE",
                    "zipcode": "19801",
                    "country_code": "US",
                },
            }
        }

        class Response:
            def __enter__(self):
                return self

            def __exit__(self, *_args):
                return False

            def read(self):
                return json.dumps(payload).encode("utf-8")

        with tempfile.TemporaryDirectory() as directory:
            service = OrderService(Path(directory) / "test.db", Path(__file__).parents[1])
            try:
                service.database.save_billing_configuration(
                    "remote_address_api",
                    "https://address-api.example.com/api/v1/address?country_code=us&area_code=DE",
                )
                with patch("backend.service.urlopen", return_value=Response()):
                    billing = service._new_checkout_billing({"email": "session@example.test"})
            finally:
                service.close()
        self.assertEqual(billing, {
            "name": "Taylor Morgan",
            "line1": "100 Market Street",
            "city": "Wilmington",
            "state": "Delaware",
            "postal_code": "19801",
            "country": "US",
            "email": "session@example.test",
        })

    def test_address_api_rejects_non_allowlisted_host(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            service = OrderService(Path(directory) / "test.db", Path(__file__).parents[1])
            try:
                with self.assertRaisesRegex(Exception, "address-api.example.com"):
                    service._normalize_address_api_url(
                        "https://example.test/api/v1/address?country_code=us&area_code=DE"
                    )
            finally:
                service.close()


if __name__ == "__main__":
    unittest.main()
