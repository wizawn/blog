from __future__ import annotations

import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

from backend.platform_checkout import PlatformCheckoutAdapter, CheckoutError
from backend.proxy_pool import ProxyPool
from backend.vendor import card_payment


BILLING = {
    "name": "Fixture User",
    "email": "fixture@example.test",
    "line1": "100 Market Street",
    "city": "Wilmington",
    "state": "Delaware",
    "postal_code": "19801",
    "country": "US",
}


class Response:
    def __init__(self, payload, status_code=200):
        self.payload = payload
        self.status_code = status_code
        self.text = ""

    def json(self):
        return self.payload


class CheckoutCoreFeatureTests(unittest.TestCase):
    def test_checkout_http_session_cache_is_single_use_and_scoped(self) -> None:
        adapter = PlatformCheckoutAdapter(Path(__file__).parents[1])
        retained = Mock()
        adapter._remember_checkout_http_session(
            "oaics_fixture",
            "token_fixture",
            "account_fixture",
            "socks5://platform",
            "socks5://stripe",
            retained,
        )
        result = adapter._take_checkout_http_session(
            "oaics_fixture",
            "token_fixture",
            "account_fixture",
            "socks5://platform",
            "socks5://stripe",
        )
        self.assertIs(result, retained)
        retained.close.assert_not_called()
        self.assertIsNone(
            adapter._take_checkout_http_session(
                "oaics_fixture",
                "token_fixture",
                "account_fixture",
                "socks5://platform",
                "socks5://stripe",
            )
        )

        rejected = Mock()
        adapter._remember_checkout_http_session(
            "oaics_other", "token_fixture", "account_fixture", "", "", rejected
        )
        self.assertIsNone(
            adapter._take_checkout_http_session(
                "oaics_other", "other_token", "account_fixture", "", ""
            )
        )
        rejected.close.assert_called_once()

    def test_runtime_cache_reuses_verified_account_publishable_key(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_runtime_cache_hit=True,
            payment_method_publishable_key="pk_test_fixture",
        )
        logs: list[str] = []
        with patch.object(card_payment, "_stripe_client_bootstrap") as bootstrap:
            result = card_payment._verified_account_publishable_key(
                Mock(), config, "pk_test_fixture", logs.append
            )
        self.assertEqual(result, "pk_test_fixture")
        bootstrap.assert_not_called()
        self.assertTrue(any("stripe_key_cache:hit" in item for item in logs))

    def test_runtime_cache_rejects_checkout_merchant_mismatch(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_runtime_cache_hit=True,
            payment_method_publishable_key="pk_test_account",
        )
        with self.assertRaises(card_payment.CardPaymentError):
            card_payment._verified_account_publishable_key(
                Mock(), config, "pk_test_checkout"
            )

    def test_checkout_runtime_cache_is_session_scoped_and_released(self) -> None:
        adapter = PlatformCheckoutAdapter(Path(__file__).parents[1])
        runtime = SimpleNamespace(
            client_build_number="build_fixture",
            client_version="version_fixture",
            vendor_session_id="session_fixture",
            web_deployment_attestation="attestation_fixture",
            sentinel_token="sentinel_fixture",
            telemetry="[1,null]",
        )
        adapter._remember_checkout_runtime(
            "oaics_fixture", "token_fixture", "account_fixture", runtime
        )
        self.assertTrue(
            adapter._checkout_runtime(
                "oaics_fixture", "token_fixture", "account_fixture"
            ).get("_cache_hit")
        )
        self.assertEqual(
            adapter._checkout_runtime(
                "oaics_fixture", "other_token", "account_fixture"
            ),
            {},
        )
        self.assertEqual(
            adapter._checkout_runtime(
                "oaics_fixture", "token_fixture", "other_account"
            ),
            {},
        )
        adapter.release_checkout_context("oaics_fixture")
        self.assertEqual(
            adapter._checkout_runtime(
                "oaics_fixture", "token_fixture", "account_fixture"
            ),
            {},
        )

    def test_post_payment_reads_run_in_parallel_on_isolated_session(self) -> None:
        payment_method_started = threading.Event()
        release_payment_method = threading.Event()
        worker_session = Mock()

        def payment_method_sync(*_args, **_kwargs):
            payment_method_started.set()
            self.assertTrue(release_payment_method.wait(2))
            return 200, {"_checkout_serverment_method": {"last4": "4242"}}

        def subscription_sync(*_args, **_kwargs):
            self.assertTrue(payment_method_started.wait(2))
            release_payment_method.set()
            return Response({"plan_type": "plus"}), "plus"

        config = card_payment.CardPaymentConfig(
            token="token_fixture", account_id="account_fixture"
        )
        with (
            patch.object(
                card_payment,
                "_verify_payment_method_sync",
                side_effect=payment_method_sync,
            ),
            patch.object(
                card_payment,
                "_verify_plus_subscription",
                side_effect=subscription_sync,
            ),
        ):
            result = card_payment._verify_plus_and_payment_method_parallel(
                Mock(),
                config,
                "account_fixture",
                "pm_fixture",
                None,
                proxy="",
                session_factory=lambda *_args: worker_session,
            )
        self.assertEqual(result[1], "plus")
        self.assertEqual(result[2], 200)
        worker_session.close.assert_called_once()

    def test_frontend_uses_server_card_fields_without_stripe_js(self) -> None:
        root = Path(__file__).parents[1]
        app_source = (root / "static" / "app.js").read_text(encoding="utf-8")
        html_source = (root / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn("paymentMode: 'api_card'", app_source)
        self.assertIn('id="cardNumber"', html_source)
        self.assertIn('id="cardExpiry"', html_source)
        self.assertIn('id="cardCvc"', html_source)
        self.assertNotIn("https://js.stripe.com/v3/", app_source)

    def test_frontend_collects_card_before_one_click_payment_chain(self) -> None:
        root = Path(__file__).parents[1]
        app_source = (root / "static" / "app.js").read_text(encoding="utf-8")
        html_source = (root / "static" / "index.html").read_text(encoding="utf-8")
        self.assertNotIn("/api/platform/stripe/bootstrap", app_source)
        self.assertIn('<div id="stripeCardFields" class="card-input-panel">', html_source)
        self.assertIn("<span>立即支付</span>", html_source)
        self.assertNotIn("preparedNow", app_source)
        create_order = app_source[app_source.index("async function createOrder"):]
        checkout_position = create_order.index("preparePlatformCheckout")
        payment_method_position = create_order.index("paymentMode: 'api_card'")
        charge_position = create_order.index("/api/platform/checkout/charge")
        self.assertLess(checkout_position, payment_method_position)
        self.assertLess(payment_method_position, charge_position)

    def test_frontend_keeps_3ds_order_open_and_exposes_manual_sync(self) -> None:
        root = Path(__file__).parents[1]
        app_source = (root / "static" / "app.js").read_text(encoding="utf-8")
        html_source = (root / "static" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="liveActionLink"', html_source)
        self.assertIn('id="detailActionLink"', html_source)
        self.assertIn('id="liveVerifyAction"', html_source)
        self.assertIn('id="detailVerifyAction"', html_source)
        self.assertIn("async function verifyPaymentAction", app_source)
        self.assertIn("'/api/platform/checkout/sync'", app_source)
        self.assertIn("stripe_action_required", app_source)

    def test_readme_does_not_pair_oaics_with_inline_card_mode(self) -> None:
        root = Path(__file__).parents[1]
        readme = (root / "README.md").read_text(encoding="utf-8")
        self.assertNotIn('"checkoutId": "oaics_CHECKOUT_ID"', readme)
        self.assertIn('"checkoutId": "cs_CHECKOUT_ID"', readme)
        self.assertIn("后台 Stripe.js Elements → pm_", readme)

    def test_global_metadata_advertises_server_card_input(self) -> None:
        root = Path(__file__).parents[1]
        service_source = (root / "backend" / "service.py").read_text(encoding="utf-8")
        self.assertIn('"cardInputModes": ["api_card", "stripe_elements"]', service_source)

    def test_bootstrap_cache_is_short_lived_and_does_not_store_session(self) -> None:
        root = Path(__file__).parents[1]
        service_source = (root / "backend" / "platform_checkout.py").read_text(encoding="utf-8")
        self.assertIn("stripe_bootstrap_cache_ttl", service_source)
        self.assertIn("_stripe_bootstrap_cache_key", service_source)
        self.assertIn("publishable_key", service_source)
        self.assertNotIn("session_json", service_source)

    def test_oaics_core_accepts_server_card_fields(self) -> None:
        session_factory = Mock()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
        )
        with patch.object(card_payment, "_run_oaics_card_payment", return_value={"ok": True}) as run:
            self.assertEqual(card_payment.run_card_payment(config, session_factory=session_factory), {"ok": True})
        run.assert_called_once()
        self.assertEqual(run.call_args.args[0].card["number"], "4242424242424242")

    def test_legacy_bind_requires_browser_payment_method_before_network(self) -> None:
        session_factory = Mock()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            stop_after_bind=True,
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
        )
        with self.assertRaisesRegex(
            card_payment.CardPaymentError, "browser-created PaymentMethod"
        ):
            card_payment.run_card_payment(config, session_factory=session_factory)
        session_factory.assert_not_called()

    def test_complete_verification_is_the_adapter_default(self) -> None:
        adapter = PlatformCheckoutAdapter(Path(__file__).parents[1])
        config = adapter._config(
            adapter._load(), "token_fixture", "account_fixture", BILLING
        )
        self.assertFalse(config.fast_verify)

    def test_payment_method_must_sync_to_platform_account(self) -> None:
        session = Mock()
        session.get.return_value = Response({"items": [{"id": "pm_fixture"}]})
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            payment_method_poll_delays=(0.0,),
        )
        status, payload = card_payment._verify_payment_method_sync(
            session, config, "pm_fixture", None
        )
        self.assertEqual(status, 200)
        self.assertEqual(payload["items"][0]["id"], "pm_fixture")

    def test_missing_payment_method_sync_is_not_success(self) -> None:
        session = Mock()
        session.get.return_value = Response({"items": []})
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            payment_method_poll_delays=(0.0,),
        )
        with self.assertRaisesRegex(
            card_payment.CardPaymentError, "not visible in Platform account"
        ):
            card_payment._verify_payment_method_sync(
                session, config, "pm_fixture", None
            )

    def test_post_mutation_transport_error_does_not_rotate_proxy(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            proxy_pool=ProxyPool([
                "socks5h://user:pass_country-us@one:8080",
                "socks5h://user:pass_country-us@two:8080",
            ]),
            stripe_proxy_pool=ProxyPool([
                "socks5h://user:pass_country-us@stripe-one:8080",
                "socks5h://user:pass_country-us@stripe-two:8080",
            ]),
        )
        module = adapter._load()
        error = card_payment.CardPaymentError(
            "post-mutation transport failure: timeout",
            proxy_retry_safe=False,
            action_required="checkout_session_confirmation",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            checkout_link="https://platform.example.com/checkout/vendor_ie/oaics_fixture",
            details={"poll_state": "processing", "attempts": 3},
        )
        with patch.object(module, "run_card_payment", side_effect=error) as run:
            with self.assertRaises(CheckoutError) as raised:
                adapter.charge(
                    {"accessToken": "token_fixture", "account_id": "account_fixture"},
                    "pm_fixture",
                    {
                        "checkoutId": "oaics_fixture",
                        "processorEntity": "vendor_ie",
                        "publishableKey": "pk_test_fixture",
                        "paymentMethodPublishableKey": "pk_test_fixture",
                        "accountId": "account_fixture",
                    },
                    BILLING,
                    card_last4="4242",
                )
        self.assertEqual(run.call_count, 1)
        self.assertFalse(raised.exception.proxy_retry_safe)
        self.assertEqual(
            raised.exception.action_required, "checkout_session_confirmation"
        )
        self.assertEqual(
            raised.exception.action_details,
            {"poll_state": "processing", "attempts": 3},
        )
        self.assertTrue(raised.exception.checkout_link.endswith("oaics_fixture"))
        self.assertIn("@one:8080", adapter._proxy_for_checkout("oaics_fixture"))
        self.assertIn("@stripe-one:8080", adapter._stripe_proxy_for_checkout("oaics_fixture"))

    def test_missing_sentinel_returns_context_diagnostic_without_confirm(self) -> None:
        session = Mock()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
        )
        with self.assertRaises(card_payment.CardPaymentError) as raised:
            card_payment._confirm_oaics_checkout(
                session, config, "oaics_fixture", "ctoken_fixture"
            )
        self.assertTrue(raised.exception.proxy_retry_safe)
        self.assertEqual(raised.exception.action_required, "")
        self.assertIn("Vendor-Sentinel-Token", raised.exception.details["missing_context"])
        confirm_calls = [
            call for call in session.post.call_args_list
            if "/api/v1/payments/checkout/confirm" in str(call)
        ]
        self.assertEqual(confirm_calls, [])

    def test_missing_attestation_is_forwarded_to_upstream_confirm(self) -> None:
        session = Mock()
        session.headers = {}
        session._oai_sentinel_token = "sentinel-fixture"
        session._vendor_telemetry = "[1,null]"
        session._oai_payment_attestation = ""
        session.post.return_value = Response(
            {"type": "payment_intent", "status": "requires_confirmation"}
        )
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
        )
        with patch.object(
            card_payment, "_warm_oaics_checkout_context", return_value={}
        ):
            payload = card_payment._confirm_oaics_checkout(
                session, config, "oaics_fixture", "ctoken_fixture"
            )
        self.assertEqual(payload["type"], "payment_intent")
        confirm_call = session.post.call_args
        self.assertIn("/api/v1/payments/checkout/confirm", confirm_call.args[0])
        self.assertNotIn(
            "OAI-Web-Deployment-Attestation", confirm_call.kwargs["headers"]
        )

    def test_oaics_3ds_error_carries_intent_evidence(self) -> None:
        session = Mock()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
        )
        stripe_payload = {
            "id": "pi_evidence_fixture",
            "status": "requires_action",
            "amount": 2000,
        }
        with patch.object(
            card_payment,
            "_post_form",
            return_value=(Response(stripe_payload), stripe_payload),
        ):
            with self.assertRaises(card_payment.CardPaymentError) as raised:
                card_payment._confirm_oaics_intent(
                    session,
                    config,
                    "pk_test_fixture",
                    "oaics_fixture",
                    "ctoken_fixture",
                    {
                        "type": "payment_intent",
                        "client_secret": "pi_evidence_fixture_secret_fixture",
                    },
                )
        self.assertEqual(raised.exception.action_required, "stripe_3ds")
        self.assertEqual(raised.exception.details["intent_id"], "pi_evidence_fixture")
        self.assertEqual(raised.exception.details["intent_type"], "payment_intent")
        self.assertEqual(raised.exception.details["intent_status"], "requires_action")
        self.assertFalse(raised.exception.details["payment_terminal"])
        self.assertEqual(raised.exception.details["amount_minor"], 2000)

    def test_payment_page_3ds_preserves_confirm_action_payload(self) -> None:
        next_action = {
            "type": "use_stripe_sdk",
            "use_stripe_sdk": {
                "type": "stripe_3ds2_fingerprint",
                "three_d_secure_2_source": "src_3ds_fixture",
                "url": "https://stripe.example.test/3ds/fixture",
                "directory_server_name": "visa",
            },
        }
        payload = {
            "state": "open",
            "submission_attempt": {"state": "requires_approval"},
            "payment_intent": {
                "id": "pi_cs_3ds_fixture",
                "object": "payment_intent",
                "status": "requires_action",
                "client_secret": "pi_cs_3ds_fixture_secret_FULL_FIXTURE",
                "amount": 98214,
                "currency": "php",
                "next_action": next_action,
            },
        }
        with self.assertRaises(card_payment.CardPaymentError) as raised:
            card_payment._require_confirm_accepted(
                payload,
                checkout_id="cs_live_fixture",
                payment_page_id="cs_live_fixture",
                processor="vendor_entity",
                expected_amount=98214,
                currency="PHP",
            )

        error = raised.exception
        self.assertFalse(error.proxy_retry_safe)
        self.assertEqual(error.action_required, "stripe_3ds")
        self.assertTrue(error.checkout_link.endswith("cs_live_fixture"))
        self.assertEqual(error.details["intent_id"], "pi_cs_3ds_fixture")
        self.assertEqual(error.details["intent_type"], "payment_intent")
        self.assertEqual(error.details["intent_status"], "requires_action")
        self.assertEqual(
            error.details["client_secret"],
            "pi_cs_3ds_fixture_secret_FULL_FIXTURE",
        )
        self.assertEqual(error.details["amount_minor"], 98214)
        self.assertEqual(error.details["currency"], "php")
        self.assertEqual(error.details["next_action_type"], "use_stripe_sdk")
        self.assertEqual(error.details["next_action"], next_action)
        self.assertEqual(error.details["payment_intent"], payload["payment_intent"])
        self.assertEqual(error.details["stripe_confirm_response"], payload)
        self.assertEqual(
            error.details["next_action_url"],
            "https://stripe.example.test/3ds/fixture",
        )

    def test_payment_page_poll_3ds_preserves_redirect_action(self) -> None:
        payload = {
            "payment_intent": {
                "id": "pi_poll_3ds_fixture",
                "status": "requires_action",
                "client_secret": "pi_poll_3ds_fixture_secret_FULL_FIXTURE",
                "amount": 98214,
                "currency": "php",
                "next_action": {
                    "type": "redirect_to_url",
                    "redirect_to_url": {
                        "url": "https://stripe.example.test/redirect/fixture"
                    },
                },
            }
        }
        session = Mock()
        session.get.return_value = Response(payload)
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="cs_live_poll_fixture",
            processor_entity="vendor_entity",
            expected_amount=98214,
            currency="PHP",
            poll_attempts=1,
            poll_interval=0,
        )
        with self.assertRaises(card_payment.CardPaymentError) as raised:
            card_payment._poll_payment_page(
                session,
                config,
                "cs_live_poll_fixture",
                "pk_test_fixture",
            )
        self.assertEqual(raised.exception.action_required, "stripe_3ds")
        self.assertEqual(
            raised.exception.details["intent_id"], "pi_poll_3ds_fixture"
        )
        self.assertEqual(
            raised.exception.details["payment_stage"], "payment_page_poll"
        )
        self.assertEqual(
            raised.exception.details["next_action_url"],
            "https://stripe.example.test/redirect/fixture",
        )

    def test_payment_page_confirm_boundary_is_not_replayed(self) -> None:
        session = Mock()
        session.get.return_value = Response({"checkout_session_id": "cs_test_fixture"})
        session.close = Mock()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="cs_test_fixture",
            payment_page_id="cs_test_fixture",
            processor_entity="vendor_ie",
            publishable_key="pk_test_fixture",
            payment_method_publishable_key="pk_test_fixture",
            payment_method_id="pm_fixture",
            expected_amount=2000,
            billing=BILLING,
        )
        patches = (
            patch.object(card_payment, "_discover_publishable_key", return_value="pk_test_fixture"),
            patch.object(card_payment, "_stripe_client_bootstrap", return_value="pk_test_fixture"),
            patch.object(card_payment, "_update_checkout_taxes", return_value={}),
            patch.object(card_payment, "_init_payment_page", return_value=({}, "js_fixture")),
            patch.object(card_payment, "_create_elements_session", return_value={}),
            patch.object(card_payment, "_update_payment_page_address", return_value={
                "amount_minor": 2000, "currency": "USD",
            }),
            patch.object(card_payment, "_prepare_hcaptcha_token", return_value=""),
            patch.object(
                card_payment,
                "_payment_page_confirm",
                side_effect=card_payment.CardPaymentError("requires_action"),
            ),
        )
        for item in patches:
            item.start()
        try:
            with self.assertRaises(card_payment.CardPaymentError) as raised:
                card_payment.run_card_payment(
                    config, session_factory=lambda _config, _proxy: session
                )
        finally:
            for item in reversed(patches):
                item.stop()
        self.assertFalse(raised.exception.proxy_retry_safe)
        self.assertEqual(raised.exception.action_required, "stripe_3ds")
        self.assertTrue(raised.exception.checkout_link.endswith("cs_test_fixture"))

    def test_cs_prepare_tls_failure_rebuilds_transport_before_confirm(self) -> None:
        main_session = Mock()
        stripe_first = Mock()
        stripe_second = Mock()
        for item in (main_session, stripe_first, stripe_second):
            item.headers = {}
            item.close = Mock()
        main_session.get.return_value = Response(
            {"checkout_session_id": "cs_test_tls_fixture"}
        )
        sessions = iter((main_session, stripe_first, stripe_second))
        logs = []
        init_sessions = []

        def init_payment_page(active_session, *_args, **_kwargs):
            init_sessions.append(active_session)
            if active_session is stripe_first:
                raise RuntimeError(
                    "Failed to perform, curl: (35) TLS connect error"
                )
            return ({}, "js_fixture")

        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_id="cs_test_tls_fixture",
            payment_page_id="cs_test_tls_fixture",
            processor_entity="vendor_ie",
            publishable_key="pk_test_fixture",
            expected_amount=2000,
            billing=BILLING,
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
            stripe_prepare_attempts=2,
            stripe_prepare_retry_delay=0,
        )
        patches = (
            patch.object(card_payment, "_hydrate_payment_metadata", return_value={}),
            patch.object(card_payment, "_discover_publishable_key", return_value="pk_test_fixture"),
            patch.object(card_payment, "_stripe_client_bootstrap", return_value="pk_test_fixture"),
            patch.object(card_payment, "_update_checkout_taxes", return_value={}),
            patch.object(card_payment, "_init_payment_page", side_effect=init_payment_page),
            patch.object(
                card_payment,
                "_create_elements_session",
                side_effect=card_payment.CardPaymentError("stop after TLS retry"),
            ),
            patch.object(card_payment, "_payment_page_confirm", confirm := Mock()),
        )
        for item in patches:
            item.start()
        try:
            with self.assertRaisesRegex(
                card_payment.CardPaymentError, "stop after TLS retry"
            ):
                card_payment.run_card_payment(
                    config,
                    logger=logs.append,
                    session_factory=lambda *_args: next(sessions),
                )
        finally:
            for item in reversed(patches):
                item.stop()

        self.assertEqual(init_sessions, [stripe_first, stripe_second])
        self.assertTrue(
            any("prepare_checkout:stripe_init:retry" in line for line in logs)
        )
        self.assertTrue(
            any("prepare_checkout:stripe_init:done" in line for line in logs)
        )
        stripe_first.close.assert_called_once()
        stripe_second.close.assert_called_once()
        main_session.close.assert_called_once()
        confirm.assert_not_called()

    def test_cs_prepare_timeout_is_bounded(self) -> None:
        self.assertEqual(
            card_payment._stripe_prepare_timeout(
                card_payment.CardPaymentConfig(token="fixture")
            ),
            20,
        )
        self.assertEqual(
            card_payment._stripe_prepare_timeout(
                card_payment.CardPaymentConfig(
                    token="fixture", timeout=10, stripe_prepare_timeout=20
                )
            ),
            10,
        )
        self.assertEqual(
            card_payment._stripe_prepare_timeout(
                card_payment.CardPaymentConfig(
                    token="fixture", timeout=60, stripe_prepare_timeout=60
                )
            ),
            30,
        )


if __name__ == "__main__":
    unittest.main()
