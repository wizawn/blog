from __future__ import annotations

import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

from backend.platform_checkout import PlatformCheckoutAdapter
from backend.vendor import card_payment


class Response:
    def __init__(self, payload: dict, status_code: int = 200, headers=None):
        self.payload = payload
        self.status_code = status_code
        self.headers = dict(headers or {})
        self.text = ""

    def json(self):
        return self.payload


class CheckoutProtocolAbsorptionTests(unittest.TestCase):
    def test_checkout_mode_uses_custom_for_empty_or_matching_history(self) -> None:
        self.assertEqual(
            PlatformCheckoutAdapter._select_checkout_mode("PHP", ""),
            ("custom", "billing_currency_empty"),
        )
        self.assertEqual(
            PlatformCheckoutAdapter._select_checkout_mode("USD", "usd"),
            ("custom", "currency_matched"),
        )
        self.assertEqual(
            PlatformCheckoutAdapter._select_checkout_mode("PHP", "USD"),
            ("hosted", "currency_mismatched"),
        )

    def test_currency_incompatible_error_markers_are_normalized(self) -> None:
        for value in (
            "currency_incompatible",
            "Currency incompatible",
            "cannot combine currencies",
            "currency-mismatch",
        ):
            self.assertTrue(
                PlatformCheckoutAdapter._is_currency_incompatible_error(value)
            )
        self.assertFalse(
            PlatformCheckoutAdapter._is_currency_incompatible_error(
                "User is already paid"
            )
        )

    def test_custom_and_hosted_checkout_request_templates_are_distinct(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_plan_name="basic_plan",
            country="PH",
            currency="PHP",
        )
        with patch.object(card_payment, "_post_json", return_value={}) as post:
            card_payment._checkout_create_custom(object(), config)
            custom_body = post.call_args.args[2]
            card_payment._checkout_create_cs_live(object(), config)
            hosted_body = post.call_args.args[2]
        self.assertEqual(custom_body["checkout_ui_mode"], "custom")
        self.assertEqual(
            custom_body["entry_point"], "all_plans_pricing_modal"
        )
        self.assertNotIn("locale", custom_body)
        self.assertEqual(hosted_body["checkout_ui_mode"], "hosted")
        self.assertEqual(hosted_body["locale"], "zh-CN")
        self.assertNotIn("entry_point", hosted_body)
        self.assertNotIn("promo_campaign", hosted_body)

    def test_account_snapshot_reads_subscription_diagnostics(self) -> None:
        module = SimpleNamespace(
            APP_BASE="https://platform.example.com",
            _get_app=lambda *_args, **_kwargs: Response(
                {
                    "accounts": {
                        "default": {
                            "account_id": "acct_fixture",
                            "plan_type": "plus",
                            "subscription_plan": "basic_plan",
                            "has_active_subscription": True,
                            "billing_currency": "USD",
                            "will_renew": True,
                        }
                    }
                }
            ),
            _response_json=lambda response: response.json(),
            _find_key=card_payment._find_key,
        )
        snapshot = PlatformCheckoutAdapter._account_snapshot(
            SimpleNamespace(), module, 30
        )
        self.assertEqual(snapshot["account_id"], "acct_fixture")
        self.assertEqual(snapshot["subscription_plan"], "basic_plan")
        self.assertTrue(snapshot["has_active_subscription"])
        self.assertEqual(snapshot["billing_currency"], "USD")

    def test_account_snapshot_scopes_currency_to_current_account(self) -> None:
        module = SimpleNamespace(
            APP_BASE="https://platform.example.com",
            _get_app=lambda *_args, **_kwargs: Response(
                {
                    "accounts": {
                        "default": {
                            "account": {"account_id": "acct_default"},
                            "billing_currency": "USD",
                        },
                        "selected": {
                            "account": {"account_id": "acct_selected"},
                            "billing_currency": "PHP",
                        },
                    }
                }
            ),
            _response_json=lambda response: response.json(),
            _find_key=card_payment._find_key,
        )
        snapshot = PlatformCheckoutAdapter._account_snapshot(
            SimpleNamespace(headers={"platform-account-id": "acct_selected"}),
            module,
            30,
        )
        self.assertEqual(snapshot["account_id"], "acct_selected")
        self.assertEqual(snapshot["billing_currency"], "PHP")

    def test_remote_pricing_config_uses_server_currency(self) -> None:
        module = SimpleNamespace(
            APP_BASE="https://platform.example.com",
            _get_app=lambda *_args, **_kwargs: Response({"data": {"currency": "PHP"}}),
            _response_json=lambda response: response.json(),
            _find_key=card_payment._find_key,
        )
        result = PlatformCheckoutAdapter._remote_pricing_config(
            SimpleNamespace(), module, "PH", "USD", 30
        )
        self.assertEqual(result, ("PH", "PHP"))

    def test_checkout_amount_reads_taxes_snapshot_amount_total(self) -> None:
        self.assertEqual(
            card_payment._checkout_amount_minor(
                {"snapshot": {"amount_total": 98214, "currency": "php"}}
            ),
            98214,
        )

    def test_elements_session_uses_current_deferred_intent_get_contract(self) -> None:
        class Session:
            def __init__(self):
                self.get_calls = []
                self.post_calls = []

            def get(self, url, **kwargs):
                self.get_calls.append((url, kwargs))
                return Response({"id": "elements_oaics"})

            def post(self, url, **kwargs):
                self.post_calls.append((url, kwargs))
                return Response({"id": "elements_cs"})

        session = Session()
        config = card_payment.CardPaymentConfig(token="token_fixture", locale="en-US")
        init_payload = {"elements_options": {"amount": 2000, "currency": "usd"}}
        card_payment._create_elements_session(
            session, config, init_payload, "cs_live_fixture", "pk_test_fixture", "js_fixture"
        )
        self.assertEqual(len(session.post_calls), 0)
        self.assertEqual(len(session.get_calls), 1)
        cs_params = session.get_calls[0][1]["params"]
        self.assertEqual(cs_params["type"], "deferred_intent")
        self.assertEqual(cs_params["deferred_intent[mode]"], "subscription")
        self.assertEqual(cs_params["checkout_session_id"], "cs_live_fixture")

        card_payment._create_elements_session(
            session, config, init_payload, "oaics_fixture", "pk_test_fixture", "js_fixture"
        )
        self.assertEqual(len(session.get_calls), 2)
        oaics_params = session.get_calls[1][1]["params"]
        self.assertEqual(oaics_params["type"], "deferred_intent")
        self.assertEqual(oaics_params["deferred_intent[mode]"], "subscription")

    def test_inline_confirm_excludes_elements_initialization_options(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            card={
                "number": "4242424242424242",
                "cvc": "123",
                "exp_month": "12",
                "exp_year": "2032",
            },
            billing={
                "name": "Fixture User",
                "email": "fixture@example.com",
                "country": "US",
                "line1": "1 Fixture Street",
                "city": "Wilmington",
                "state": "Delaware",
                "postal_code": "19801",
            },
            stripe_runtime_version="runtime_fixture",
            stripe_js_checksum="checksum_fixture",
            stripe_rv_timestamp="1700000000",
        )
        fields = card_payment._inline_payment_method_fields(
            config,
            "cs_live_fixture",
            "checkout_config_fixture",
            "elements_session_fixture",
            "elements_config_fixture",
            "stripe_js_fixture",
        )
        self.assertTrue(fields["payment_method_data[card][number]"])
        self.assertFalse(
            any(key.startswith("elements_options_client[") for key in fields)
        )

    def test_checkout_context_joins_authjs_session_cookie_parts(self) -> None:
        adapter = PlatformCheckoutAdapter(Path(__file__).parents[1])
        context = adapter._session_runtime_context(
            {
                "cookies": [
                    {
                        "name": "__Secure-authjs.session-token.1",
                        "value": "part.three.four",
                    },
                    {
                        "name": "__Secure-authjs.session-token.0",
                        "value": "header.part.",
                    },
                ]
            },
            "token_fixture",
            "account_fixture",
        )
        self.assertEqual(
            context["session_token"], "header.part.part.three.four"
        )

    def test_stripe_runtime_is_captured_from_bootstrap_urls(self) -> None:
        captured = []
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            stripe_runtime_update=captured.append,
        )
        changed = card_payment._capture_stripe_runtime(
            {
                "assets": [
                    "https://js.stripe.com/v3/abcdef123456.js?rv=1700000000",
                    "https://checkout.stripe.com/c/pay/fedcba9876543210/session",
                ]
            },
            config,
        )
        self.assertEqual(changed["js_checksum"], "abcdef123456")
        self.assertEqual(changed["rv_timestamp"], "1700000000")
        self.assertEqual(changed["version"], "fedcba9876543210")
        self.assertEqual(captured[0], changed)

    def test_payment_method_sync_returns_safe_card_details(self) -> None:
        session = SimpleNamespace(
            get=lambda *args, **kwargs: Response(
                {
                    "items": [
                        {
                            "id": "pm_fixture",
                            "card": {
                                "brand": "visa",
                                "last4": "4242",
                                "exp_month": 12,
                                "exp_year": 2032,
                            },
                        }
                    ],
                    "default_payment_method_id": "pm_fixture",
                }
            )
        )
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            payment_method_poll_delays=(0.0,),
        )
        _status, payload = card_payment._verify_payment_method_sync(
            session, config, "pm_fixture", None
        )
        self.assertEqual(
            payload["_checkout_serverment_method"],
            {
                "brand": "visa",
                "last4": "4242",
                "exp_month": "12",
                "exp_year": "2032",
            },
        )
        self.assertTrue(payload["_xy_is_default_payment_method"])

    def test_payment_page_poll_retries_transient_states(self) -> None:
        class Session:
            def __init__(self):
                self.responses = [
                    Response({}, 404),
                    Response({"state": "processing"}),
                    Response({"state": "complete", "payment_intent": {"status": "succeeded"}}),
                ]

            def get(self, *args, **kwargs):
                return self.responses.pop(0)

        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="cs_fixture",
            processor_entity="vendor_ie",
            poll_attempts=3,
            poll_interval=0,
        )
        payload = card_payment._poll_payment_page(
            Session(), config, "cs_fixture", "pk_test_fixture"
        )
        self.assertEqual(card_payment._payment_page_state(payload), "succeeded")
        self.assertEqual(payload["_xy_poll_attempts"], 3)
        self.assertEqual(payload["_xy_poll_history"], ["processing", "succeeded"])

    def test_payment_state_does_not_hide_nested_failure(self) -> None:
        self.assertEqual(
            card_payment._payment_page_state(
                {"state": "succeeded", "payment_intent": {"status": "requires_payment_method"}}
            ),
            "requires_payment_method",
        )
        self.assertEqual(
            card_payment._vendor_checkout_state(
                {"state": "processing", "payment_intent": {"status": "failed"}}
            ),
            "failed",
        )

    def test_payment_page_poll_does_not_retry_non_transient_http_errors(self) -> None:
        class Session:
            def __init__(self):
                self.calls = 0

            def get(self, *args, **kwargs):
                self.calls += 1
                return Response({"detail": "forbidden"}, 403)

        session = Session()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="cs_fixture",
            poll_attempts=5,
            poll_interval=0,
        )
        with self.assertRaises(card_payment.CardPaymentError) as raised:
            card_payment._poll_payment_page(
                session, config, "cs_fixture", "pk_test_fixture"
            )
        self.assertEqual(session.calls, 1)
        self.assertEqual(raised.exception.details["http_status"], 403)

    def test_checkout_status_retries_initial_not_found(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer old"}
                self._vendor_pending_updates = []
                self.checkout_calls = 0

            def get(self, url, **kwargs):
                path = urlsplit(url).path
                if path == "/checkout/verify":
                    return Response({})
                if path.startswith("/api/v1/payments/checkout/"):
                    self.checkout_calls += 1
                    if self.checkout_calls == 1:
                        return Response({}, 404)
                    return Response({"state": "succeeded"})
                if path == "/api/auth/session":
                    return Response({"accessToken": "refreshed_fixture"})
                return Response({})

        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            checkout_status_attempts=2,
            checkout_status_interval=0,
        )
        result = card_payment._complete_vendor_checkout_return(
            Session(),
            config,
            "oaics_fixture",
            "vendor_ie",
            "https://platform.example.com/checkout/verify",
        )
        self.assertEqual(result["checkout_state"], "succeeded")
        self.assertEqual(result["checkout_poll_attempts"], 2)
        self.assertEqual(result["initial_checkout_status"], 404)

    def test_link_lookup_requires_explicit_support(self) -> None:
        self.assertFalse(card_payment._checkout_supports_link({"payment_method_types": ["card"]}))
        self.assertTrue(card_payment._checkout_supports_link({"payment_method_types": ["card", "link"]}))

    def test_checkout_create_never_injects_promo_or_coupon(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            promo_campaign="plus-1-month-free",
        )
        with patch.object(card_payment, "_post_json", return_value={}) as post:
            card_payment._checkout_create(SimpleNamespace(), config)
        body = post.call_args.args[2]
        self.assertNotIn("promo_campaign", body)
        self.assertNotIn("coupon", body)

    def test_platform_headers_carry_attestation_and_consistency_tokens(self) -> None:
        session = SimpleNamespace(
            _vendor_payment_attestation="attestation_fixture",
            _vendor_pending_updates=["update_fixture"],
        )
        headers = card_payment._app_headers(
            "https://platform.example.com/checkout/vendor_ie/oaics_fixture",
            "/api/v1/payments/checkout/confirm",
            payment_attestation=card_payment._payment_attestation(session),
            session=session,
        )
        self.assertEqual(
            headers["OAI-Web-Deployment-Attestation"], "attestation_fixture"
        )
        self.assertIn("update_fixture", headers["x-vendor-is-pending-updates"])

    def test_stripe_headers_remove_platform_session_headers(self) -> None:
        headers = card_payment._stripe_headers(
            "pk_test_fixture", "https://platform.example.com/checkout/vendor_ie/oaics_fixture"
        )
        for name in (
            "Authorization",
            "x-vendor-device-id",
            "vendor-language",
            "platform-account-id",
            "OAI-Client-Build-Number",
            "OAI-Client-Version",
            "OAI-Session-Id",
            "OAI-Web-Deployment-Attestation",
            "x-vendor-is-pending-updates",
        ):
            self.assertIsNone(headers[name])
        self.assertEqual(headers["Origin"], "https://js.stripe.com")

    def test_checkout_return_loads_success_data_and_adopts_auth_token(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer old"}
                self._vendor_pending_updates = []
                self.calls = []
                self.auth_referer = ""
                self.auth_query = {}
                self.auth_authorization = ""

            def get(self, url, **kwargs):
                path = urlsplit(url).path
                self.calls.append(path)
                if path.startswith("/api/v1/payments/checkout/"):
                    return Response({"state": "succeeded"})
                if path == "/api/auth/session":
                    self.auth_referer = kwargs.get("headers", {}).get("Referer", "")
                    self.auth_query = {
                        **parse_qs(urlsplit(url).query),
                        **{
                            str(key): [str(value)]
                            for key, value in dict(kwargs.get("params") or {}).items()
                        },
                    }
                    self.auth_authorization = self.headers.get("Authorization", "")
                    return Response({"accessToken": "refreshed_fixture"})
                return Response({"ok": True})

        session = Session()
        config = card_payment.CardPaymentConfig(
            token="token_fixture", account_id="account_fixture"
        )
        result = card_payment._complete_vendor_checkout_return(
            session,
            config,
            "oaics_fixture",
            "vendor_ie",
            "https://platform.example.com/checkout/verify",
        )
        self.assertLess(
            session.calls.index("/checkout/verify"),
            session.calls.index("/payments/success.data"),
        )
        self.assertLess(
            session.calls.index("/payments/success.data"),
            session.calls.index("/api/auth/session"),
        )
        self.assertLess(
            session.calls.index("/api/auth/session"),
            session.calls.index("/api/v1/payments/checkout/vendor_ie/oaics_fixture"),
        )
        self.assertTrue(result["auth_session_updated"])
        self.assertEqual(
            session.headers["Authorization"], "Bearer refreshed_fixture"
        )
        self.assertNotIn("_routes=", session.auth_referer)
        self.assertEqual(session.auth_query.get("refresh"), ["true"])
        self.assertEqual(session.auth_query.get("reason"), ["token_expired"])
        self.assertEqual(session.auth_authorization, "")

    def test_checkout_return_resolves_initial_action_after_success_loader(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer old"}
                self._vendor_pending_updates = []
                self.calls = []
                self.checkout_calls = 0

            def get(self, url, **_kwargs):
                path = urlsplit(url).path
                self.calls.append(path)
                if path.startswith("/api/v1/payments/checkout/"):
                    self.checkout_calls += 1
                    if self.checkout_calls == 1:
                        return Response({"state": "requires_action"})
                    return Response({"state": "succeeded"})
                if path == "/api/auth/session":
                    return Response({"accessToken": "refreshed_fixture"})
                return Response({"ok": True})

        session = Session()
        result = card_payment._complete_vendor_checkout_return(
            session,
            card_payment.CardPaymentConfig(
                token="token_fixture",
                checkout_status_attempts=1,
                checkout_status_interval=0,
            ),
            "oaics_fixture",
            "vendor_ie",
            "https://platform.example.com/checkout/verify",
        )
        self.assertEqual(result["initial_checkout_state"], "requires_action")
        self.assertEqual(result["checkout_state"], "succeeded")
        first_checkout = session.calls.index(
            "/api/v1/payments/checkout/vendor_ie/oaics_fixture"
        )
        self.assertLess(session.calls.index("/payments/success.data"), session.calls.index("/api/auth/session"))
        self.assertLess(session.calls.index("/api/auth/session"), first_checkout)

    def test_checkout_return_keeps_persistent_action_required(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer old"}
                self._vendor_pending_updates = []

            def get(self, url, **_kwargs):
                path = urlsplit(url).path
                if path.startswith("/api/v1/payments/checkout/"):
                    return Response({"state": "requires_action"})
                if path == "/api/auth/session":
                    return Response({"accessToken": "refreshed_fixture"})
                return Response({"ok": True})

        with self.assertRaises(card_payment.CardPaymentError) as raised:
            card_payment._complete_vendor_checkout_return(
                Session(),
                card_payment.CardPaymentConfig(
                    token="token_fixture",
                    checkout_status_attempts=1,
                    checkout_status_interval=0,
                ),
                "oaics_fixture",
                "vendor_ie",
                "https://platform.example.com/checkout/verify",
            )
        self.assertEqual(
            raised.exception.action_required,
            "checkout_session_confirmation",
        )
        self.assertEqual(
            raised.exception.details["initial_checkout_state"],
            "requires_action",
        )
        self.assertEqual(
            raised.exception.details["checkout_state"],
            "requires_action",
        )

    def test_checkout_return_refreshes_cookie_session_before_status_poll(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer stale"}
                self._vendor_pending_updates = []
                self.calls = []
                self.auth_headers = []

            def get(self, url, **_kwargs):
                path = urlsplit(url).path
                self.calls.append(path)
                if path == "/checkout/verify":
                    return Response({})
                if path == "/payments/success.data":
                    return Response({})
                if path == "/api/auth/session":
                    self.auth_headers.append(self.headers.get("Authorization"))
                    if self.headers.get("Authorization"):
                        return Response({"detail": "expired"}, 401)
                    return Response({"accessToken": "fresh_fixture"})
                if path.startswith("/api/v1/payments/checkout/"):
                    if self.headers.get("Authorization") == "Bearer fresh_fixture":
                        return Response({"state": "succeeded"})
                    return Response({"detail": "expired"}, 401)
                return Response({})

        session = Session()
        result = card_payment._complete_vendor_checkout_return(
            session,
            card_payment.CardPaymentConfig(
                token="stale", checkout_status_attempts=1, checkout_status_interval=0
            ),
            "oaics_fixture",
            "vendor_ie",
            "https://platform.example.com/checkout/verify",
        )
        self.assertEqual(result["checkout_state"], "succeeded")
        self.assertEqual(session.auth_headers, [None])
        checkout_indexes = [
            index
            for index, path in enumerate(session.calls)
            if path == "/api/v1/payments/checkout/vendor_ie/oaics_fixture"
        ]
        self.assertEqual(len(checkout_indexes), 1)
        self.assertLess(session.calls.index("/api/auth/session"), checkout_indexes[0])

    def test_subscription_401_refreshes_auth_and_retries_get_once(self) -> None:
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer old"}
                self._vendor_pending_updates = []
                self.subscription_calls = 0
                self.auth_calls = 0

            def get(self, url, **kwargs):
                path = urlsplit(url).path
                if path == "/api/v1/subscriptions":
                    self.subscription_calls += 1
                    if self.subscription_calls == 1:
                        return Response({"detail": "expired"}, 401)
                    return Response({"plan_type": "plus"})
                if path == "/api/auth/session":
                    self.auth_calls += 1
                    return Response({"accessToken": "refreshed_fixture"})
                return Response({})

        session = Session()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            account_id="account_fixture",
            subscription_attempts=1,
            subscription_interval=0,
        )
        response, plan = card_payment._verify_plus_subscription(
            session, config, "account_fixture", None
        )
        self.assertEqual(plan, "plus")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(session.subscription_calls, 2)
        self.assertEqual(session.auth_calls, 1)

    def test_conditional_offer_preflight_is_read_only(self) -> None:
        class Session:
            def __init__(self):
                self.calls = []

            def get(self, url, **kwargs):
                self.calls.append((urlsplit(url).path, kwargs.get("params", {})))
                return Response({"id": "seti_fixture", "status": "succeeded"})

        session = Session()
        config = card_payment.CardPaymentConfig(
            token="token_fixture", processor_entity="vendor_ie"
        )
        result = card_payment._verify_conditional_offer_preflight(
            session,
            config,
            "pk_test_fixture",
            "oaics_fixture",
            {
                "type": "setup_intent",
                "client_secret": "seti_fixture_secret_fixture",
            },
        )
        self.assertEqual(result["status"], "succeeded")
        self.assertEqual(session.calls[0][0], "/v1/setup_intents/seti_fixture")
        self.assertEqual(
            session.calls[0][1]["client_secret"],
            "seti_fixture_secret_fixture",
        )

    def test_local_stripe_runtime_reports_inline_api_readiness(self) -> None:
        root = Path(__file__).parents[1]
        status = PlatformCheckoutAdapter(root)._stripe_runtime_status()
        self.assertTrue(status["configured"])
        self.assertTrue(status["inlineApiReady"])
        self.assertTrue(all(status["fields"].values()))

    def test_versioned_fingerprint_profile_is_normalized(self) -> None:
        profile = {
            "profile": {
                "user_agent": "fixture-agent",
                "chrome_major": 146,
                "platform_os": "Windows",
                "tls_client_identifier": "chrome146",
                "mobile": False,
            },
            "version": 2,
        }
        context = PlatformCheckoutAdapter._session_runtime_context(
            {"fingerprint": profile}, "token_fixture", "account_fixture"
        )
        self.assertEqual(context["fingerprint_profile"]["ua"], "fixture-agent")
        self.assertEqual(context["fingerprint_profile"]["major"], "146")
        self.assertEqual(context["fingerprint_profile"]["platform"], "Windows")
        self.assertEqual(context["fingerprint_profile"]["tls_impersonate"], "chrome146")
        self.assertEqual(context["fingerprint_profile"]["mobile"], "?0")


if __name__ == "__main__":
    unittest.main()
