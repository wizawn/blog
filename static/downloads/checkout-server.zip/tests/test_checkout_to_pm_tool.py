from __future__ import annotations

import unittest
from pathlib import Path

from tools import test_checkout_to_pm


class CheckoutToPaymentMethodToolTests(unittest.TestCase):
    def test_fixture_checkout_is_local_and_contains_no_production_route(self) -> None:
        checkout = test_checkout_to_pm.fixture_checkout(
            "pk_test_fixture", 2000, "USD"
        )
        self.assertTrue(checkout["id"].startswith("oaics_test_"))
        self.assertTrue(checkout["url"].startswith("http://127.0.0.1:5602/"))

        source = (
            Path(__file__).parents[1] / "tools" / "test_checkout_to_pm.py"
        ).read_text(encoding="utf-8")
        self.assertNotIn("/api/v1/payments/checkout", source)
        self.assertNotIn("pk_live_", source)

    def test_fixture_uses_standard_stripe_test_card(self) -> None:
        self.assertEqual(
            test_checkout_to_pm.TEST_CARD["number"], "4242424242424242"
        )
        self.assertEqual(test_checkout_to_pm.TEST_CARD["cvc"], "123")


if __name__ == "__main__":
    unittest.main()
