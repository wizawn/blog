from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


ROOT = Path(__file__).parents[1]
SPEC = importlib.util.spec_from_file_location(
    "hosted_checkout_probe",
    ROOT / "tools" / "test_hosted_checkout.py",
)
probe = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(probe)


class HostedCheckoutProbeTests(unittest.TestCase):
    def test_oldest_fingerprint_matrix_covers_all_browser_families(self) -> None:
        self.assertEqual(
            probe.oldest_browser_targets(),
            [
                "chrome99",
                "edge99",
                "firefox133",
                "safari153",
                "chrome99_android",
                "safari172_ios",
                "tor145",
            ],
        )

    def test_non_chromium_profiles_disable_client_hints(self) -> None:
        firefox = probe.build_browser_target_fingerprint("firefox133")
        safari = probe.build_browser_target_fingerprint("safari153")
        self.assertEqual(firefox["client_hints"], "0")
        self.assertIn("Firefox/133.0", firefox["ua"])
        self.assertEqual(safari["client_hints"], "0")
        self.assertIn("Version/15.3", safari["ua"])

    def test_chromium_profiles_keep_matching_client_hints(self) -> None:
        edge = probe.build_browser_target_fingerprint("edge99")
        android = probe.build_browser_target_fingerprint("chrome99_android")
        self.assertEqual(edge["client_hints"], "1")
        self.assertIn("Edg/99.0.0.0", edge["ua"])
        self.assertEqual(android["mobile"], "?1")
        self.assertIn("Chrome/99.0.0.0", android["ua"])

    def test_default_probe_fingerprint_is_chrome_90(self) -> None:
        profile = probe.build_browser_fingerprint()
        self.assertEqual(profile["tls_impersonate"], "chrome99")
        self.assertEqual(profile["requested_browser_version"], "90.0.0.0")
        self.assertIn("Chrome/90.0.0.0", profile["ua"])
        self.assertIn('"Chromium";v="90"', profile["sec_ch_ua"])
        self.assertEqual(profile["full"], "90.0.0.0")

    def test_invalid_probe_fingerprint_version_is_rejected(self) -> None:
        with self.assertRaisesRegex(probe.ProbeError, "invalid Chrome major"):
            probe.build_browser_fingerprint("90.0")

    def test_hosted_body_uses_matching_us_country_and_currency(self) -> None:
        body = probe.build_hosted_checkout_body("us")
        self.assertEqual(body["checkout_ui_mode"], "hosted")
        self.assertEqual(
            body["billing_details"],
            {"country": "US", "currency": "USD"},
        )
        self.assertNotIn("entry_point", body)
        self.assertNotIn("promo_campaign", body)

    def test_hosted_template_has_target_route_headers(self) -> None:
        self.assertEqual(
            probe.HOSTED_CHECKOUT_HEADERS["x-vendor-target-path"],
            "/api/v1/payments/checkout",
        )
        self.assertEqual(
            probe.HOSTED_CHECKOUT_HEADERS["x-vendor-target-route"],
            "/api/v1/payments/checkout",
        )

    def test_custom_and_plan_names_are_explicit(self) -> None:
        body = probe.build_checkout_body("PH", mode="custom", plan="pro20")
        self.assertEqual(body["checkout_ui_mode"], "custom")
        self.assertEqual(body["plan_name"], "premium_plan")
        self.assertNotIn("entry_point", body)

    def test_country_currency_mismatch_is_rejected(self) -> None:
        with self.assertRaisesRegex(probe.ProbeError, "country/currency mismatch"):
            probe.build_checkout_body("US", "PHP")

    def test_proxy_country_is_changed_in_memory(self) -> None:
        original = (
            "socks5h://USER:PASSWORD_country-us@geo.iproyal.com:12321"
        )
        routed = probe.route_proxy_country(original, "PH")
        self.assertIn("country-ph", routed)
        self.assertIn("@geo.iproyal.com:12321", routed)
        self.assertNotIn("country-us", routed)

    def test_hosted_response_extracts_cs_from_provider_url(self) -> None:
        result = probe.summarize_checkout({
            "tag": "hosted_checkout_session",
            "url": "https://pay.vendor.com/c/pay/cs_live_fixture123#fragment",
        }, requested_mode="hosted")
        self.assertTrue(result["generatedCs"])
        self.assertTrue(result["modeMatch"])
        self.assertEqual(result["checkoutId"], "cs_live_fixture123")
        self.assertEqual(result["checkoutSessionId"], "cs_live_fixture123")
        self.assertEqual(result["responseTag"], "hosted_checkout_session")
        self.assertEqual(result["checkoutUrl"], result["providerUrl"])

    def test_custom_response_is_reported_without_claiming_cs(self) -> None:
        result = probe.summarize_checkout({
            "tag": "custom_checkout_session",
            "checkout_session_id": "oaics_fixture123",
            "processor_entity": "vendor_entity",
        }, requested_mode="custom")
        self.assertFalse(result["generatedCs"])
        self.assertTrue(result["modeMatch"])
        self.assertEqual(result["checkoutId"], "oaics_fixture123")
        self.assertEqual(
            result["checkoutUrl"],
            "https://platform.example.com/checkout/vendor_entity/oaics_fixture123",
        )

    def test_custom_response_with_cs_builds_platform_link(self) -> None:
        result = probe.summarize_checkout({
            "tag": "custom_checkout_session",
            "checkout_session_id": "cs_live_fixture456",
            "processor_entity": "vendor_entity",
        }, requested_mode="custom")
        self.assertTrue(result["generatedCs"])
        self.assertFalse(result["modeMatch"])
        self.assertEqual(
            result["checkoutUrl"],
            "https://platform.example.com/checkout/vendor_entity/cs_live_fixture456",
        )
        self.assertEqual(result["providerUrl"], "")

    def test_probe_source_has_no_payment_confirmation_endpoint(self) -> None:
        source = (ROOT / "tools" / "test_hosted_checkout.py").read_text(
            encoding="utf-8"
        )
        self.assertNotIn("/checkout/confirm", source)
        self.assertNotIn("/payment_intents/", source)
        self.assertNotIn("/setup_intents/", source)
        self.assertNotIn("payment_pages", source)


if __name__ == "__main__":
    unittest.main()
