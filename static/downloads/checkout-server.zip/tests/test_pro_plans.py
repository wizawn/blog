from __future__ import annotations

import unittest
from unittest.mock import patch

from backend.platform_checkout import (
    PLATFORM_CHECKOUT_PLAN_NAMES,
    subscription_matches_plan,
)
from backend.vendor import card_payment


class ProPlanCheckoutTests(unittest.TestCase):
    def test_checkout_plan_names_are_explicit(self) -> None:
        self.assertEqual(PLATFORM_CHECKOUT_PLAN_NAMES["pro5"], "standard_plan")
        self.assertEqual(PLATFORM_CHECKOUT_PLAN_NAMES["pro20"], "premium_plan")

    def test_checkout_create_uses_selected_plan_name(self) -> None:
        for plan_type, plan_name in (("pro5", "standard_plan"), ("pro20", "premium_plan")):
            config = card_payment.CardPaymentConfig(
                token="fixture-token",
                checkout_plan_type=plan_type,
                checkout_plan_name=plan_name,
                country="PH",
                currency="PHP",
            )
            with patch.object(
                card_payment,
                "_post_json",
                return_value={"checkout_session_id": "oaics_fixture"},
            ) as post_json:
                card_payment._checkout_create(object(), config)
            self.assertEqual(post_json.call_args.args[2]["plan_name"], plan_name)

    def test_subscription_matching_is_target_specific(self) -> None:
        self.assertTrue(subscription_matches_plan("pro5", "standard_plan"))
        self.assertFalse(subscription_matches_plan("pro5", "premium_plan"))
        self.assertTrue(subscription_matches_plan("pro20", "premium_plan"))
        self.assertFalse(subscription_matches_plan("plus", "standard_plan"))


if __name__ == "__main__":
    unittest.main()
