from __future__ import annotations

import unittest
from pathlib import Path

from backend.platform_checkout import PlatformCheckoutAdapter
from backend.platform_renewal import PlatformRenewalAdapter


class ProjectIndependenceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.root = Path(__file__).parents[1].resolve()

    def test_runtime_modules_are_bundled(self) -> None:
        checkout = PlatformCheckoutAdapter(self.root)
        module_path = Path(checkout._load().__file__).resolve()
        renewal_path = PlatformRenewalAdapter(self.root).script_path.resolve()
        session_util_path = PlatformRenewalAdapter(self.root).session_util_path.resolve()

        self.assertTrue(module_path.is_relative_to(self.root))
        self.assertTrue(renewal_path.is_relative_to(self.root))
        self.assertTrue(module_path.is_file())
        self.assertTrue(renewal_path.is_file())
        self.assertTrue(session_util_path.is_relative_to(self.root))
        self.assertTrue(session_util_path.is_file())

    def test_stripe_runtime_is_loaded_from_project_config(self) -> None:
        runtime = PlatformCheckoutAdapter(self.root)._stripe_runtime()
        self.assertTrue(runtime["version"])
        self.assertTrue(runtime["js_checksum"])
        self.assertTrue(runtime["rv_timestamp"])

    def test_production_sources_do_not_reference_sibling_projects(self) -> None:
        forbidden = (
            "zkky-main",
            "cat-cw-Gpt-Agreement-Payment",
            "crypto-9527-Gpt-Agreement-Payment",
            'parent / "cancel_renewal.py"',
        )
        sources = list((self.root / "backend").rglob("*.py"))
        sources.extend(
            (self.root / name)
            for name in ("server.py", "cancel_renewal.py", "session_util.py")
        )
        for path in sources:
            content = path.read_text(encoding="utf-8")
            for marker in forbidden:
                self.assertNotIn(marker, content, f"{path} contains external dependency {marker}")


if __name__ == "__main__":
    unittest.main()
