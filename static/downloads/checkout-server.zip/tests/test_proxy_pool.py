from __future__ import annotations

import unittest
import time
from unittest.mock import Mock, patch

from backend.proxy_pool import ProxyPool, normalize_proxy


class ProxyPoolTests(unittest.TestCase):
    def test_probe_accepts_any_exit_country(self) -> None:
        identity = Mock(status_code=200)
        identity.json.return_value = {
            "success": True,
            "ip": "203.0.113.8",
            "country_code": "US",
            "country": "United States",
            "city": "Fixture City",
        }
        platform = Mock(status_code=200)
        stripe = Mock(status_code=401)
        with patch("backend.proxy_pool.curl_requests.get", side_effect=[identity, platform, stripe]):
            result = ProxyPool("socks5h://USER:PASSWORD_country-us@proxy.example.test:8080").probe()
        self.assertTrue(result["ok"])
        self.assertEqual(result["country"], "US")
        self.assertTrue(result["targets"]["platform"]["ok"])
        self.assertTrue(result["targets"]["stripe"]["ok"])

    def test_normalize_supported_proxy_forms(self) -> None:
        self.assertEqual(normalize_proxy("ph-one:8080"), "")
        self.assertEqual(normalize_proxy("socks5://user:pass_country-ph@ph-two:1080"), "")
        self.assertEqual(
            normalize_proxy("socks5h://user:pass_country-ph@ph-two:1080"),
            "socks5h://user:pass_country-ph@ph-two:1080",
        )
        self.assertEqual(normalize_proxy("ftp://ph-three:21"), "")

    def test_round_robin_rotation(self) -> None:
        pool = ProxyPool([
            "socks5h://user:pass_country-us@one:8080",
            "socks5h://user:pass_country-us@two:8080",
        ])
        self.assertEqual(pool.next(), "socks5h://user:pass_country-us@one:8080")
        self.assertEqual(pool.next(), "socks5h://user:pass_country-us@two:8080")
        self.assertEqual(pool.next(), "socks5h://user:pass_country-us@one:8080")

    def test_failed_proxy_is_cooled_down_and_recovers(self) -> None:
        value = "socks5h://user:pass_country-us@one:8080"
        pool = ProxyPool(value)
        for _ in range(pool.FAILURE_LIMIT):
            pool.record_failure(value)
        self.assertEqual(pool.next(), "")
        self.assertFalse(pool.status()["proxies"][0]["healthy"])
        pool._cooldown_until[value] = time.time() - 1
        self.assertEqual(pool.next(), value)
        self.assertTrue(pool.status()["proxies"][0]["healthy"])
        self.assertEqual(pool.status()["proxies"][0]["failureCount"], 0)

    def test_runtime_replace_status_is_masked(self) -> None:
        pool = ProxyPool()
        status = pool.replace(
            "socks5h://USER:SECRET_session-fixture_lifetime-10m_country-ph@geo.example.test:12321"
        )
        self.assertTrue(status["configured"])
        self.assertEqual(status["count"], 1)
        self.assertEqual(status["countries"], ["PH"])
        self.assertEqual(status["lifetimes"], ["10m"])
        self.assertNotIn("SECRET", str(status))
        self.assertIn("***@", status["proxies"][0]["masked"])
        self.assertEqual(status["proxies"][0]["scheme"], "socks5h")

    def test_runtime_replace_rejects_empty_pool(self) -> None:
        with self.assertRaises(ValueError):
            ProxyPool().replace("")

if __name__ == "__main__":
    unittest.main()
