from __future__ import annotations

import json
import unittest
from urllib.parse import urlsplit

from backend.vendor import card_payment
from backend.vendor import challenge_solver


class _Response:
    text = ""

    def __init__(self, payload, status_code=200, headers=None):
        self.payload = payload
        self.status_code = status_code
        self.headers = dict(headers or {})

    def json(self):
        return self.payload


class _Session:
    def __init__(self, payload):
        self.headers = {
            "User-Agent": "fixture-agent",
            "sec-ch-ua": '"Chromium";v="146"',
        }
        self.payload = payload
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return _Response(self.payload)


class SentinelContextTests(unittest.TestCase):
    def test_refresh_builds_flow_bound_token(self):
        session = _Session({"token": "server-token", "proofofwork": {"required": False}})
        value = challenge_solver.refresh(
            session,
            device_id="device-fixture",
            flow="checkout_session_approval",
        )
        payload = json.loads(value)
        self.assertEqual(payload["c"], "server-token")
        self.assertEqual(payload["id"], "device-fixture")
        self.assertEqual(payload["flow"], "checkout_session_approval")
        self.assertTrue(session.calls)

    def test_ensure_context_attaches_token_and_telemetry(self):
        session = _Session({"token": "server-token"})
        config = card_payment.CardPaymentConfig(
            token="token-fixture",
            device_id="device-fixture",
        )
        token, telemetry = card_payment._ensure_sentinel_context(session, config)
        self.assertTrue(token.startswith("{"))
        self.assertEqual(telemetry, "[1,null]")
        self.assertEqual(session._oai_sentinel_token, token)
        headers = card_payment._app_headers(
            "https://platform.example.com/checkout/vendor_ie/oaics_fixture",
            "/api/v1/payments/checkout/confirm",
            session=session,
        )
        self.assertEqual(headers["Vendor-Sentinel-Token"], token)
        self.assertEqual(headers["OAI-Telemetry"], "[1,null]")

    def test_session_context_header_names_are_case_insensitive(self):
        from backend.platform_checkout import PlatformCheckoutAdapter

        context = PlatformCheckoutAdapter._sentinel_context({
            "headers": {
                "Vendor-Sentinel-Token": "sentinel-fixture",
                "OAI-Telemetry": "telemetry-fixture",
            }
        })
        self.assertEqual(context, ("sentinel-fixture", "telemetry-fixture"))

    def test_session_context_reads_nested_checkout_headers(self):
        from backend.platform_checkout import PlatformCheckoutAdapter

        context = PlatformCheckoutAdapter._sentinel_context({
            "checkoutContext": {
                "headers": {
                    "Vendor-Sentinel-Token": "nested-sentinel",
                    "OAI-Telemetry": "nested-telemetry",
                }
            }
        })
        self.assertEqual(context, ("nested-sentinel", "nested-telemetry"))

    def test_pow_solution_uses_enforcement_prefix(self):
        builder = challenge_solver._TokenBuilder("device-fixture", "fixture-agent")
        value = builder.solve("seed", "f")
        self.assertTrue(value.startswith("gAAAAAB"))

    def test_auth_refresh_retries_without_stale_bearer_header(self):
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer stale"}
                self._oai_pending_updates = []
                self.auth_header_values = []

            def get(self, url, **_kwargs):
                if urlsplit(url).path == "/api/auth/session":
                    self.auth_header_values.append(self.headers.get("Authorization"))
                    if self.headers.get("Authorization"):
                        return _Response({"detail": "expired"}, status_code=401)
                    return _Response({"accessToken": "fresh-token"})
                return _Response({})

        session = Session()
        config = card_payment.CardPaymentConfig(token="stale")
        response, updated = card_payment._refresh_auth_session(
            session,
            config,
            referer="https://platform.example.com/payments/success",
            params={"reason": "fixture"},
        )
        self.assertEqual(response.status_code, 200)
        self.assertTrue(updated)
        self.assertEqual(session.auth_header_values, ["Bearer stale", None])
        self.assertEqual(session.headers["Authorization"], "Bearer fresh-token")
        self.assertEqual(config.token, "fresh-token")

    def test_attestation_is_read_from_escaped_checkout_markup(self):
        response = _Response({})
        response.text = r'<script>{\"webDeploymentAttestation\":\"attestation-fixture\"}</script>'
        self.assertEqual(
            card_payment._payment_attestation_from_response(response),
            "attestation-fixture",
        )

    def test_client_bootstrap_parser_reads_authenticated_attestation(self):
        payload = card_payment._client_bootstrap_payload(
            '<script type="application/json" id="client-bootstrap">'
            '{"authStatus":"logged_in","sessionId":"session-fixture",'
            '"webDeploymentAttestation":"attestation-fixture"}'
            "</script>"
        )
        self.assertEqual(payload["authStatus"], "logged_in")
        self.assertEqual(
            payload["webDeploymentAttestation"], "attestation-fixture"
        )

    def test_logged_out_cookie_does_not_block_valid_access_token(self):
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer token-fixture"}

            def get(self, _url, **_kwargs):
                response = _Response({})
                response.text = (
                    '<script type="application/json" id="client-bootstrap">'
                    '{"authStatus":"logged_out","sessionId":"session-fixture"}'
                    "</script>"
                )
                return response

        messages = []
        config = card_payment.CardPaymentConfig(
            token="token-fixture",
            session_token="stale-cookie-fixture",
        )
        metadata = card_payment._hydrate_payment_metadata(
            Session(), config, messages.append
        )
        self.assertEqual(metadata["session_id"], "session-fixture")
        self.assertTrue(
            any("继续使用 accessToken" in message for message in messages)
        )

    def test_missing_cookie_attestation_defers_to_checkout_refresh(self):
        class Session:
            def __init__(self):
                self.headers = {"Authorization": "Bearer token-fixture"}

            def get(self, _url, **_kwargs):
                response = _Response({})
                response.text = (
                    '<script type="application/json" id="client-bootstrap">'
                    '{"authStatus":"logged_in","sessionId":"session-fixture"}'
                    "</script>"
                )
                return response

        messages = []
        config = card_payment.CardPaymentConfig(
            token="token-fixture",
            session_token="cookie-fixture",
        )
        metadata = card_payment._hydrate_payment_metadata(
            Session(), config, messages.append
        )
        self.assertFalse(metadata["attestation"])
        self.assertTrue(
            any("继续由 Checkout 上下文刷新" in message for message in messages)
        )

    def test_current_sentinel_loader_selects_versioned_platform_sdk(self):
        class Session:
            headers = {"Authorization": "Bearer fixture"}

            def get(self, url, **kwargs):
                self.url = url
                self.kwargs = kwargs
                response = _Response({})
                response.text = (
                    "(function(){var script=document.createElement('script');"
                    "script.src='https://platform.example.com/sentinel/current123/sdk.js';"
                    "document.head.appendChild(script);})();"
                )
                return response

        session = Session()
        url = challenge_solver._discover_sdk_url(session, 10)
        self.assertEqual(
            url, "https://platform.example.com/sentinel/current123/sdk.js"
        )
        self.assertEqual(
            session.kwargs["headers"]["Authorization"], None
        )
        headers = challenge_solver._request_headers(
            session,
            "fixture-agent",
            "device-fixture",
            endpoint="https://platform.example.com/api/v1/sentinel/req",
            sdk_url=url,
        )
        self.assertEqual(headers["Origin"], "https://platform.example.com")
        self.assertEqual(
            headers["Referer"],
            "https://platform.example.com/sentinel/frame.html?sv=current123",
        )


if __name__ == "__main__":
    unittest.main()
