from __future__ import annotations

import tempfile
import time
import unittest
from pathlib import Path

from backend.service import OrderService, ServiceError


API_KEY = "A" * 64
OTHER_API_KEY = "B" * 64
SESSION = {
    "user": {"email": "fixture@example.test"},
    "expires": "2099-01-01T00:00:00Z",
    "accessToken": "LOCAL_FIXTURE_TOKEN",
    "sessionToken": "LOCAL_FIXTURE_SESSION_COOKIE",
}


class OrderServiceTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.service = OrderService(root / "test.db", Path(__file__).parents[1], step_delay=0.001)

    def tearDown(self) -> None:
        self.service.close()
        self.temp_dir.cleanup()

    def wait_for_terminal(self, order_key: str, timeout: float = 2.0) -> dict:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            order = self.service.order_status({"apiKey": API_KEY, "orderKey": order_key})
            if order["status"] in {"succeeded", "failed"}:
                return order
            time.sleep(0.01)
        self.fail("order did not reach a terminal state")

    def test_create_complete_and_list_order(self) -> None:
        created = self.service.create_order(
            {
                "apiKey": API_KEY,
                "session": SESSION,
                "planType": "plus",
                "provider": "sandbox",
                "paymentFixture": "test_visa",
            }
        )
        self.assertTrue(created["orderKey"].startswith("XY-"))
        self.assertTrue(created["cardKey"].startswith("XYK-"))
        self.assertEqual(created["status"], "queued")

        completed = self.wait_for_terminal(created["orderKey"])
        self.assertEqual(completed["status"], "succeeded")
        self.assertEqual(completed["cardKey"], created["cardKey"])
        self.assertIsNotNone(completed["completedAt"])
        self.assertTrue(completed["confirmationRef"].startswith("sbx_"))
        self.assertEqual(completed["email"], "fixture@example.test")

        history = self.service.list_orders({"apiKey": API_KEY, "page": 1, "pageSize": 20})
        self.assertEqual(history["total"], 1)
        self.assertEqual(history["items"][0]["orderKey"], created["orderKey"])
        self.assertEqual(history["items"][0]["cardKey"], created["cardKey"])

    def test_api_key_isolates_order(self) -> None:
        created = self.service.create_order(
            {
                "apiKey": API_KEY,
                "session": SESSION,
                "planType": "pro5",
                "provider": "sandbox",
                "paymentFixture": "test_mastercard",
            }
        )
        with self.assertRaises(ServiceError) as raised:
            self.service.order_status({"apiKey": OTHER_API_KEY, "orderKey": created["orderKey"]})
        self.assertEqual(raised.exception.status, 404)

    def test_order_detail_includes_stage_timeline(self) -> None:
        created = self.service.create_order(
            {
                "apiKey": API_KEY,
                "session": SESSION,
                "planType": "plus",
                "provider": "sandbox",
                "paymentFixture": "test_visa",
            }
        )
        row = self.service.database.get_order_by_key(created["orderKey"])
        self.service.database.add_order_event(
            int(row["id"]), "fixture_stage", "fixture event", 1250
        )
        detailed = self.service.order_status(
            {"apiKey": API_KEY, "orderKey": created["orderKey"]}
        )
        self.assertEqual(detailed["timeline"][0]["stage"], "fixture_stage")
        self.assertEqual(detailed["timeline"][0]["elapsedMs"], 1250)

    def test_decline_can_be_retried(self) -> None:
        created = self.service.create_order(
            {
                "apiKey": API_KEY,
                "session": SESSION,
                "planType": "pro20",
                "provider": "sandbox",
                "paymentFixture": "test_declined",
            }
        )
        failed = self.wait_for_terminal(created["orderKey"])
        self.assertEqual(failed["status"], "failed")
        self.assertEqual(failed["errorCode"], "test_declined")

        retried = self.service.retry_order(created["orderKey"], {"apiKey": API_KEY})
        self.assertEqual(retried["status"], "queued")
        self.assertEqual(retried["retryCount"], 1)

    def test_session_summary_does_not_return_token(self) -> None:
        summary = self.service.validate_session(SESSION)
        self.assertEqual(summary["email"], "fixture@example.test")
        self.assertTrue(summary["has_session_cookie"])
        self.assertNotIn("accessToken", summary)
        self.assertNotIn("LOCAL_FIXTURE_TOKEN", str(summary))
        self.assertNotIn("LOCAL_FIXTURE_SESSION_COOKIE", str(summary))

    def test_session_summary_detects_missing_login_cookie(self) -> None:
        summary = self.service.validate_session(
            {
                "user": {"email": "fixture@example.test"},
                "expires": "2099-01-01T00:00:00Z",
                "accessToken": "LOCAL_FIXTURE_TOKEN",
            }
        )
        self.assertTrue(summary["has_access_token"])
        self.assertFalse(summary["has_session_cookie"])


if __name__ == "__main__":
    unittest.main()
