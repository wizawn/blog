from __future__ import annotations

import base64
import json
import time
import unittest
from pathlib import Path
from types import SimpleNamespace

import session_util
from backend.platform_renewal import PlatformRenewalAdapter, RenewalError
from backend.session_info import summarize_session


def jwt(expires_at: int) -> str:
    def encode(value):
        raw = json.dumps(value, separators=(",", ":")).encode("utf-8")
        return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")

    return f"{encode({'alg': 'none'})}.{encode({'exp': expires_at})}.fixture"


class Response:
    def __init__(self, payload, status_code=200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


class Session:
    def __init__(self, refreshed_token):
        self.refreshed_token = refreshed_token
        self.urls = []

    def get(self, url, **_kwargs):
        self.urls.append(url)
        return Response({"accessToken": self.refreshed_token})


class SessionRenewalTests(unittest.TestCase):
    def test_backend_session_summary_uses_jwt_expiry(self) -> None:
        summary = summarize_session({
            "user": {"email": "fixture@example.test"},
            "expires": "2099-01-01T00:00:00Z",
            "accessToken": jwt(int(time.time()) - 60),
        })
        self.assertTrue(summary["expired"])

    def test_cookie_parts_are_joined(self) -> None:
        cookie = "eyJheader.part.two.three.four"
        split = len(cookie) // 2
        source = json.dumps({
            "cookies": {
                "__Secure-platform.session-token.0": cookie[:split],
                "__Secure-platform.session-token.1": cookie[split:],
            }
        })
        credentials = session_util.parse_credentials(source)
        self.assertEqual(credentials["session_cookie"], cookie)

    def test_cancel_refreshes_token_before_first_subscription_call(self) -> None:
        old_token = jwt(int(time.time()) + 3600)
        new_token = jwt(int(time.time()) + 7200)
        session_cookie = "eyJheader.part.two.three.four"
        http_session = Session(new_token)
        used_tokens = []

        def cancel_renewal(_session, token, account_id):
            used_tokens.append(token)
            return {
                "account_id": account_id,
                "cancelled": True,
                "will_renew": False,
                "active_until": "2099-01-01",
            }

        module = SimpleNamespace(
            _session=lambda: http_session,
            resolve_account_id=lambda _session, _token: "account_fixture",
            cancel_renewal=cancel_renewal,
        )
        adapter = PlatformRenewalAdapter(Path(__file__).parents[1])
        adapter._module = module
        result = adapter.cancel(json.dumps({
            "accessToken": old_token,
            "sessionToken": session_cookie,
        }))

        self.assertTrue(result["cancelled"])
        self.assertEqual(used_tokens, [new_token])
        self.assertTrue(any("refresh=true&reason=token_expired" in url for url in http_session.urls))

    def test_credential_failure_without_cookie_is_not_retryable(self) -> None:
        token = jwt(int(time.time()) + 3600)
        calls = []

        def cancel_renewal(_session, used_token, _account_id):
            calls.append(used_token)
            raise RuntimeError("HTTP 401 token_expired")

        adapter = PlatformRenewalAdapter(Path(__file__).parents[1])
        adapter._module = SimpleNamespace(
            _session=lambda: Session(token),
            resolve_account_id=lambda _session, _token: "account_fixture",
            cancel_renewal=cancel_renewal,
        )
        with self.assertRaises(RenewalError) as raised:
            adapter.cancel(json.dumps({"accessToken": token}))
        self.assertTrue(raised.exception.credential_error)
        self.assertEqual(calls, [token])

    def test_cancel_reuses_token_already_refreshed_by_payment_flow(self) -> None:
        current_token = jwt(int(time.time()) + 7200)
        session_cookie = "eyJheader.part.two.three.four"
        http_session = Session(jwt(int(time.time()) + 10800))
        used_tokens = []

        adapter = PlatformRenewalAdapter(Path(__file__).parents[1])
        adapter._module = SimpleNamespace(
            _session=lambda: http_session,
            resolve_account_id=lambda _session, _token: "account_fixture",
            cancel_renewal=lambda _session, used_token, account_id: (
                used_tokens.append(used_token)
                or {
                    "account_id": account_id,
                    "cancelled": True,
                    "will_renew": False,
                }
            ),
        )
        result = adapter.cancel({
            "accessToken": current_token,
            "sessionToken": session_cookie,
            "_xyTokenRefreshedAfterPayment": True,
        })
        self.assertTrue(result["cancelled"])
        self.assertEqual(used_tokens, [current_token])
        self.assertEqual(http_session.urls, [])


if __name__ == "__main__":
    unittest.main()
