from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from backend import stripe_browser
from backend.vendor import card_payment


class StripeBrowserTests(unittest.TestCase):
    def test_card_fields_are_normalized_for_elements(self) -> None:
        result = stripe_browser._card_fields(
            {
                "number": "4242 4242 4242 4242",
                "expMonth": "12",
                "expYear": "2099",
                "cvc": "123",
            }
        )
        self.assertEqual(result["number"], "4242424242424242")
        self.assertEqual(result["expiry"], "1299")
        self.assertEqual(result["cvc"], "123")

    def test_authenticated_socks_proxy_uses_local_bridge(self) -> None:
        with stripe_browser._browser_proxy(
            "socks5h://USER:PASSWORD@proxy.example.test:1080"
        ) as proxy:
            self.assertTrue(proxy["server"].startswith("socks5://127.0.0.1:"))
            self.assertNotIn("USER", proxy["server"])
            self.assertNotIn("PASSWORD", proxy["server"])

    def test_runner_loads_real_stripe_js_and_elements(self) -> None:
        root = Path(__file__).parents[1]
        source = (root / "static" / "stripe-runner.html").read_text(
            encoding="utf-8"
        )
        self.assertIn("https://js.stripe.com/v3/", source)
        self.assertIn("elements.create('cardNumber'", source)
        self.assertIn("state.stripe.createPaymentMethod", source)

    def test_oaics_confirmation_token_uses_payment_method_only(self) -> None:
        root = Path(__file__).parents[1]
        source = (root / "backend" / "vendor" / "card_payment.py").read_text(
            encoding="utf-8"
        )
        function = source[
            source.index("def _create_confirmation_token(") : source.index(
                "def _publishable_tokenization_unsupported("
            )
        ]
        self.assertIn('"payment_method": external_payment_method', function)
        self.assertNotIn("payment_method_data[card]", function)
        self.assertIn("create_payment_method_with_stripe_js", source)

    def test_raw_confirmation_token_contains_card_and_billing_fields(self) -> None:
        root = Path(__file__).parents[1]
        source = (root / "backend" / "vendor" / "card_payment.py").read_text(
            encoding="utf-8"
        )
        function = source[
            source.index("def _create_confirmation_token_from_card(") : source.index(
                "def _confirm_oaics_checkout("
            )
        ]
        self.assertIn('"payment_method_data[type]": "card"', function)
        self.assertIn('"payment_method_data[card][number]"', function)
        self.assertIn('"payment_method_data[billing_details][address][country]"', function)

    def test_oaics_raw_mode_defers_elements_session_until_browser_fallback(self) -> None:
        root = Path(__file__).parents[1]
        source = (root / "backend" / "vendor" / "card_payment.py").read_text(
            encoding="utf-8"
        )
        function = source[
            source.index("def _run_oaics_card_payment(") : source.index(
                "def run_card_payment("
            )
        ]
        self.assertIn('checkout_id.startswith("oaics_")', function)
        self.assertIn("oaics raw-first strategy", function)
        self.assertLess(
            function.index("_create_confirmation_token_from_card("),
            function.index("create_payment_method_with_stripe_js"),
        )

    def test_raw_tokenization_fallback_requires_explicit_stripe_error(self) -> None:
        response = type("Response", (), {
            "status_code": 400,
            "json": lambda self: {
                "error": {
                    "code": "tokenization_unsupported",
                    "message": "This integration surface is unsupported for publishable key tokenization",
                }
            },
        })()
        self.assertTrue(card_payment._publishable_tokenization_unsupported(response))

        sdk_required = type("Response", (), {
            "status_code": 400,
            "json": lambda self: {
                "error": {
                    "message": "This publishable key tokenization request is required to use the Stripe SDK."
                }
            },
        })()
        self.assertTrue(
            card_payment._publishable_tokenization_unsupported(sdk_required)
        )

        card_declined = type("Response", (), {
            "status_code": 400,
            "json": lambda self: {
                "error": {"code": "card_declined", "message": "Your card was declined."}
            },
        })()
        self.assertFalse(
            card_payment._publishable_tokenization_unsupported(card_declined)
        )

    def test_raw_tls_transport_error_is_browser_fallback_eligible(self) -> None:
        message = (
            "Failed to perform, curl: (35) TLS connect error: "
            "OPENSSL_internal:invalid library (0)"
        )
        self.assertTrue(card_payment._is_transport_failure(message))
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
        )
        with patch.object(card_payment, "_post_form", side_effect=RuntimeError(message)):
            with self.assertRaises(card_payment.CardPaymentError) as raised:
                card_payment._create_confirmation_token_from_card(
                    object(), config, "pk_test_fixture", "oaics_fixture"
                )
        self.assertTrue(raised.exception.proxy_retry_safe)
        self.assertTrue(raised.exception.details["transport_error"])
        self.assertTrue(raised.exception.details["fallback_eligible"])

    def test_raw_confirmation_token_nests_stripe_device_ids(self) -> None:
        captured: dict[str, object] = {}
        response = type("Response", (), {"status_code": 200})()

        def post_form(_session, _url, body, **_kwargs):
            captured.update(body)
            payload = {"id": "ctoken_fixture", "payment_method": "pm_fixture"}
            return response, payload

        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
            billing={
                "name": "Fixture User",
                "country": "US",
                "postal_code": "19801",
            },
            stripe_runtime_version="runtime_fixture",
            stripe_client_session_id="stripe_js_fixture",
            stripe_elements_session_id="elements_session_fixture",
            stripe_elements_session_config_id="elements_config_fixture",
            stripe_customer_id="cus_fixture",
            hcaptcha_token="captcha_fixture",
        )
        with patch.object(card_payment, "_post_form", side_effect=post_form):
            token, payment_method, _payload = (
                card_payment._create_confirmation_token_from_card(
                    object(), config, "pk_test_fixture", "oaics_fixture"
                )
            )

        self.assertEqual(token, "ctoken_fixture")
        self.assertEqual(payment_method, "pm_fixture")
        self.assertNotIn("guid", captured)
        self.assertNotIn("muid", captured)
        self.assertNotIn("sid", captured)
        self.assertIn("payment_method_data[guid]", captured)
        self.assertIn("payment_method_data[muid]", captured)
        self.assertIn("payment_method_data[sid]", captured)
        self.assertIn("payment_method_data[time_on_page]", captured)
        self.assertEqual(
            captured["payment_method_data[referrer]"],
            "https://platform.example.com/checkout/vendor_ie/oaics_fixture",
        )
        self.assertEqual(captured["client_context[customer]"], "cus_fixture")
        self.assertEqual(
            captured["payment_method_data[payment_user_agent]"],
            "stripe.js/runtime_fixture; stripe-js-v3/runtime_fixture; "
            "payment-element; deferred-intent",
        )
        self.assertNotIn("client_attribution_metadata[client_session_id]", captured)
        self.assertEqual(
            captured[
                "payment_method_data[client_attribution_metadata][client_session_id]"
            ],
            "stripe_js_fixture",
        )
        self.assertEqual(
            captured[
                "payment_method_data[client_attribution_metadata][elements_session_id]"
            ],
            "elements_session_fixture",
        )
        self.assertEqual(
            captured[
                "payment_method_data[client_attribution_metadata]"
                "[elements_session_config_id]"
            ],
            "elements_config_fixture",
        )
        self.assertEqual(
            captured["payment_method_data[radar_options][hcaptcha_token]"],
            "captcha_fixture",
        )

    def test_raw_confirmation_token_reuses_supplied_stripe_session(self) -> None:
        shared = Mock()
        response = type("Response", (), {"status_code": 200})()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            stripe_proxy="socks5h://USER:PASSWORD_country-us@proxy.test:1080",
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
        )
        with (
            patch.object(card_payment, "_new_stripe_session") as new_session,
            patch.object(
                card_payment,
                "_post_form",
                return_value=(
                    response,
                    {"id": "ctoken_fixture", "payment_method": "pm_fixture"},
                ),
            ) as post_form,
        ):
            card_payment._create_confirmation_token_from_card(
                shared, config, "pk_test_fixture", "oaics_fixture"
            )

        new_session.assert_not_called()
        self.assertIs(post_form.call_args.args[0], shared)
        self.assertEqual(post_form.call_args.kwargs["timeout"], 15)
        shared.close.assert_not_called()

    def test_raw_transport_failure_cache_has_short_cooldown(self) -> None:
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            stripe_proxy="socks5h://USER:PASSWORD@proxy.test:1080",
            raw_transport_cooldown=120,
        )
        publishable_key = "pk_test_fixture"
        card_payment._clear_raw_transport_failure(config, publishable_key)
        remaining, error = card_payment._raw_transport_cooldown_remaining(
            config, publishable_key
        )
        self.assertEqual(remaining, 0)
        self.assertEqual(error, "")

        card_payment._remember_raw_transport_failure(
            config, publishable_key, "curl: (28) operation timed out"
        )
        remaining, error = card_payment._raw_transport_cooldown_remaining(
            config, publishable_key
        )
        self.assertGreater(remaining, 0)
        self.assertIn("curl: (28)", error)
        card_payment._clear_raw_transport_failure(config, publishable_key)

    def test_test_mode_device_registration_retains_cookie(self) -> None:
        class Cookies(dict):
            @property
            def jar(self):
                return ()

        class Session:
            def __init__(self):
                self.cookies = Cookies()
                self.calls = []

            def post(self, url, **kwargs):
                self.calls.append((url, kwargs))
                self.cookies["m"] = "cookie_fixture"
                return type(
                    "Response",
                    (),
                    {
                        "status_code": 200,
                        "json": lambda self: {
                            "guid": "guid_server",
                            "muid": "muid_server",
                            "sid": "sid_server",
                        },
                    },
                )()

        session = Session()
        config = card_payment.CardPaymentConfig(token="token_fixture")
        context = card_payment._register_stripe_device(session, config)

        self.assertEqual(session.calls[0][0], "https://m.stripe.com/6")
        self.assertEqual(context.guid, "guid_server")
        self.assertEqual(context.muid, "muid_server")
        self.assertEqual(context.sid, "sid_server")
        self.assertTrue(context.registered)
        self.assertTrue(context.cookie_present)

    def test_device_registration_failure_uses_local_fallback(self) -> None:
        logs = []
        config = card_payment.CardPaymentConfig(token="token_fixture")
        with patch.object(
            card_payment,
            "_register_stripe_device",
            side_effect=RuntimeError("fixture transport failed"),
        ):
            context = card_payment._ensure_stripe_device_context(
                object(), config, "pk_test_fixture", logs.append
            )

        self.assertFalse(context.registered)
        self.assertEqual(context.source, "local_fallback")
        self.assertTrue(context.guid)
        self.assertTrue(context.muid)
        self.assertTrue(context.sid)
        self.assertTrue(any("device_register:fallback" in item for item in logs))

    def test_live_key_keeps_device_registration_sdk_managed(self) -> None:
        logs = []
        config = card_payment.CardPaymentConfig(token="token_fixture")
        with patch.object(card_payment, "_register_stripe_device") as register:
            context = card_payment._ensure_stripe_device_context(
                object(), config, "pk_live_fixture", logs.append
            )

        register.assert_not_called()
        self.assertFalse(context.registered)
        self.assertEqual(context.source, "live_sdk_managed")
        self.assertTrue(any("live_sdk_managed" in item for item in logs))

    def test_elements_and_raw_share_registered_device_tuple(self) -> None:
        class Session:
            def __init__(self):
                self.get_calls = []

            def get(self, url, **kwargs):
                self.get_calls.append((url, kwargs))
                return type(
                    "Response",
                    (),
                    {
                        "status_code": 200,
                        "json": lambda self: {"id": "elements_fixture"},
                    },
                )()

        device = card_payment.StripeDeviceContext(
            guid="guid_server",
            muid="muid_server",
            sid="sid_server",
            source="m6",
            registered=True,
        )
        session = Session()
        config = card_payment.CardPaymentConfig(
            token="token_fixture",
            checkout_id="oaics_fixture",
            processor_entity="vendor_ie",
            stripe_device_context=device,
            card={
                "number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2099",
                "cvc": "123",
            },
        )
        card_payment._create_elements_session(
            session,
            config,
            {"elements_options": {"amount": 2000, "currency": "usd"}},
            "oaics_fixture",
            "pk_test_fixture",
            "stripe_js_fixture",
            device,
        )
        params = session.get_calls[0][1]["params"]
        captured = {}
        response = type("Response", (), {"status_code": 200})()

        def post_form(_session, _url, body, **_kwargs):
            captured.update(body)
            return response, {"id": "ctoken_fixture"}

        with patch.object(card_payment, "_post_form", side_effect=post_form):
            card_payment._create_confirmation_token_from_card(
                session,
                config,
                "pk_test_fixture",
                "oaics_fixture",
                device,
            )

        self.assertEqual(params["elements_session_client[guid]"], "guid_server")
        self.assertEqual(params["elements_session_client[muid]"], "muid_server")
        self.assertEqual(params["elements_session_client[sid]"], "sid_server")
        self.assertEqual(captured["payment_method_data[guid]"], "guid_server")
        self.assertEqual(captured["payment_method_data[muid]"], "muid_server")
        self.assertEqual(captured["payment_method_data[sid]"], "sid_server")
        self.assertEqual(
            captured["_stripe_version"],
            card_payment.STRIPE_CONFIRMATION_TOKEN_VERSION,
        )
        self.assertEqual(captured["payment_method_data[allow_redisplay]"], "limited")

    def test_telemetry_extension_is_non_blocking_noop_by_default(self) -> None:
        session = Mock()
        logs = []
        config = card_payment.CardPaymentConfig(token="token_fixture")
        card_payment._emit_stripe_telemetry(
            session, config, "checkout.confirm.start", logs.append
        )
        session.post.assert_not_called()
        self.assertTrue(any("reason=disabled" in item for item in logs))


if __name__ == "__main__":
    unittest.main()
