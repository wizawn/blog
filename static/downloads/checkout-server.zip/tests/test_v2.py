from __future__ import annotations

import hashlib
import hmac
import json
import tempfile
import threading
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from urllib.parse import urlsplit

from backend.platform_checkout import PlatformCheckoutAdapter, _DomainProxySession
from backend.database import Database
from backend.service import OrderService, ServiceError
from backend.stripe_gateway import StripeGateway, StripeSettings, WebhookSignatureError


API_KEY = "C" * 64
SESSION = {
    "user": {"email": "v2@example.test"},
    "expires": "2099-01-01T00:00:00Z",
    "accessToken": "LOCAL_TEST_TOKEN",
    "sessionToken": "LOCAL_TEST_SESSION_COOKIE",
}


class FakeStripeGateway:
    enabled = True
    settings = SimpleNamespace(publishable_key="")

    def create_payment_intent(self, **kwargs):
        return {"id": "pi_fixture_123", "status": "succeeded", "payment_method": {"card": {"last4": "4242"}}}

    def retrieve_payment_intent(self, intent_id):
        return {
            "id": intent_id,
            "status": "succeeded",
            "payment_method": {"card": {"last4": "4242"}},
        }


class FakeHTTPResponse:
    def __init__(self, payload, status_code=200):
        self._payload = payload
        self.status_code = status_code
        self.text = json.dumps(payload)

    def json(self):
        return self._payload


class OaicsPreflightSession:
    def __init__(self, bootstrap_key="pk_test_fixture"):
        self.calls = []
        self.closed = False
        self.bootstrap_key = bootstrap_key

    def get(self, url, **kwargs):
        path = urlsplit(url).path
        self.calls.append(("GET", path))
        if path == "/api/v1/accounts/check/v4-2023-04-27":
            return FakeHTTPResponse({
                "accounts": {
                    "default": {"account": {"account_id": "account_resolved_fixture"}}
                }
            })
        if path == "/api/v1/payments/stripe_client_bootstrap":
            return FakeHTTPResponse({"publishable_key": self.bootstrap_key})
        if path == "/api/v1/payments/checkout/vendor_ie/oaics_preflight_fixture":
            return FakeHTTPResponse({
                "checkout_session_id": "oaics_preflight_fixture",
                "processor_entity": "vendor_ie",
                "publishable_key": "pk_test_fixture",
                "currency": "PHP",
            })
        return FakeHTTPResponse({"ok": True})

    def post(self, url, **kwargs):
        path = urlsplit(url).path
        self.calls.append(("POST", path))
        if path == "/api/v1/payments/checkout":
            return FakeHTTPResponse({
                "checkout_session_id": "oaics_preflight_fixture",
                "processor_entity": "vendor_ie",
                "publishable_key": "pk_test_fixture",
                "currency": "PHP",
            })
        if path == "/api/v1/payments/checkout/taxes":
            return FakeHTTPResponse({"currency": "PHP"})
        return FakeHTTPResponse({"ok": True})

    def close(self):
        self.closed = True


class OaicsRecoverySession:
    def __init__(self):
        self.calls = []
        self.closed = False

    def get(self, url, **kwargs):
        path = urlsplit(url).path
        self.calls.append(("GET", path))
        if path == "/api/v1/payments/checkout/vendor_ie/oaics_recovery_fixture":
            return FakeHTTPResponse({"detail": "not found"}, 404)
        if path == "/api/v1/payments/checkout/vendor_entity/oaics_recovery_fixture":
            return FakeHTTPResponse({"checkout_session_id": "oaics_recovery_fixture"})
        if path == "/api/v1/subscriptions":
            return FakeHTTPResponse({"plan_type": "plus"})
        return FakeHTTPResponse({"ok": True})

    def close(self):
        self.closed = True


class CsRecoverySession:
    def __init__(self):
        self.calls = []
        self.subscription_calls = 0
        self.closed = False

    def get(self, url, **kwargs):
        path = urlsplit(url).path
        self.calls.append(("GET", path))
        if path == "/v1/payment_pages/cs_test_recovery/poll":
            return FakeHTTPResponse({
                "state": "succeeded",
                "return_url": (
                    "https://platform.example.com/checkout/verify?stripe_session_id=cs_test_recovery"
                    "&processor_entity=vendor_ie&plan_type=plus"
                ),
            })
        if path == "/api/v1/payments/checkout/vendor_ie/cs_test_recovery":
            return FakeHTTPResponse({"state": "succeeded"})
        if path == "/api/v1/subscriptions":
            self.subscription_calls += 1
            if self.subscription_calls < 3:
                return FakeHTTPResponse({"detail": "not found"}, 404)
            return FakeHTTPResponse({"plan_type": "plus"})
        return FakeHTTPResponse({"ok": True})

    def close(self):
        self.closed = True


class FakeRenewalAdapter:
    script_path = Path("cancel_renewal.py")

    def cancel(self, session, account_id=""):
        return {"cancelled": True, "will_renew": False, "active_until": "2099-02-01"}


class FakePlatformCheckoutAdapter:
    enabled = True
    country = "PH"
    currency = "PHP"
    billing_country = "US"

    def __init__(self):
        self.last_charge = None
        self.charge_calls = 0
        self.preflight_calls = 0
        self.bootstrap_calls = 0

    def normalize_billing(self, billing):
        source = dict(billing or {})
        source.setdefault("country", "US")
        return source

    def normalize_card(self, card):
        return PlatformCheckoutAdapter.normalize_card(card)

    def bootstrap_stripe_elements(self, session):
        self.bootstrap_calls += 1
        return {
            "publishable_key": "pk_test_fixture",
            "account_id": "account_fixture",
            "proxy": "socks5h://***@platform-proxy.test:1080",
            "stripe_proxy": "socks5h://***@stripe-proxy.test:1080",
        }

    def preflight(self, session, billing=None):
        self.preflight_calls += 1
        return {
            "checkout_id": "oaics_fixture123",
            "payment_page_id": "",
            "checkout_provider": "oaics",
            "payment_contract": "oaics_confirmation_token",
            "checkout_url": "https://platform.example.com/checkout/vendor_ie/oaics_fixture123",
            "processor_entity": "vendor_ie",
            "publishable_key": "pk_test_fixture",
            "country": "PH",
            "billing_country": "US",
            "currency": "PHP",
            "amount_minor": 2000,
            "card_input_modes": ["stripe_elements"],
            "proxy": "socks5://***@geo.example.test:12321",
            "diagnostics": [
                {"key": "checkout", "label": "创建 Platform Checkout", "status": "succeeded", "durationMs": 12, "detail": "PH/PHP"},
                {"key": "taxes", "label": "更新 Checkout Taxes", "status": "succeeded", "durationMs": 8, "detail": "US/PHP"},
            ],
        }

    def charge(self, session, payment_method_id, checkout, billing=None, card=None, card_last4="", logger=None):
        self.charge_calls += 1
        self.last_charge = {
            "payment_method_id": payment_method_id,
            "card": dict(card or {}),
        }
        return {
            "ok": True,
            "checkout_id": "oaics_fixture123",
            "processor_entity": "vendor_entity",
            "card_last4": card_last4 or "4242",
            "checkout_status": "succeeded",
            "payment_contract": "oaics_confirmation_token",
            "intent_status": "succeeded",
            "intent_type": "payment_intent",
            "intent_id": "pi_fixture_checkout",
            "return_url_status": 200,
            "checkout_verify_status": 200,
            "confirm_return_url": "https://platform.example.com/checkout/verify?stripe_session_id=oaics_fixture123",
            "subscription_plan": "plus",
        }

    def verify_subscription(self, session, checkout):
        return {"active": True, "plan": "plus", "pollState": "succeeded"}


class ActionRequiredCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        self.charge_calls += 1
        from backend.platform_checkout import CheckoutError
        raise CheckoutError(
            "checkout confirm precondition: missing flow-bound confirmation context",
            proxy_retry_safe=False,
            action_required="checkout_session_confirmation",
            checkout_id="oaics_action123",
            processor_entity="vendor_ie",
            checkout_link="https://platform.example.com/checkout/vendor_ie/oaics_action123",
            action_details={
                "payment_stage": "checkout_finalize",
                "intent_type": "payment_intent",
                "intent_id": "pi_action_fixture",
                "intent_status": "succeeded",
                "payment_terminal": True,
                "amount_minor": 2000,
                "checkout_state": "requires_action",
            },
        )


class Stripe3DSCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        self.charge_calls += 1
        from backend.platform_checkout import CheckoutError
        raise CheckoutError(
            "oaics intent confirm: requires_action (3DS verification required)",
            proxy_retry_safe=False,
            action_required="stripe_3ds",
            checkout_id="oaics_3ds_fixture",
            processor_entity="vendor_ie",
            checkout_link="https://platform.example.com/checkout/vendor_ie/oaics_3ds_fixture",
            action_details={
                "payment_stage": "intent_confirm",
                "intent_type": "payment_intent",
                "intent_id": "pi_3ds_fixture",
                "intent_status": "requires_action",
                "payment_terminal": False,
                "amount_minor": 2000,
                "next_action_type": "redirect_to_url",
                "next_action_url": "https://stripe.example.test/3ds/fixture",
                "next_action": {
                    "type": "redirect_to_url",
                    "redirect_to_url": {
                        "url": "https://stripe.example.test/3ds/fixture",
                        "client_secret": "pi_3ds_fixture_secret_LOCAL_TEST_TOKEN",
                    },
                },
            },
        )

    def verify_subscription(self, session, checkout):
        return {
            "active": False,
            "pending": True,
            "terminalFailure": False,
            "paymentTerminal": False,
            "checkoutState": "requires_action",
            "subscriptionStatus": 404,
        }


class SubscriptionPendingCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        self.charge_calls += 1
        from backend.platform_checkout import CheckoutError
        raise CheckoutError(
            "payment terminal succeeded; subscription pending; intent_type=payment_intent; "
            "intent_id=pi_pending_fixture; amount_minor=99000; "
            "subscription verify: HTTP 404 No subscription found for account"
        )


class TokenRotatedCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        self.charge_calls += 1
        from backend.platform_checkout import CheckoutError
        raise CheckoutError(
            "checkout finalize status: HTTP 401 token_expired "
            "Provided authentication token is expired.",
            proxy_retry_safe=False,
            action_details={
                "payment_stage": "checkout_finalize",
                "intent_type": "payment_intent",
                "intent_id": "pi_token_rotated_fixture",
                "intent_status": "succeeded",
                "payment_terminal": True,
                "amount_minor": 2000,
                "auth_session_status": 401,
            },
            renewal_session={"accessToken": "refreshed_fixture"},
        )


class UnverifiedSubscriptionPendingCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        self.charge_calls += 1
        from backend.platform_checkout import CheckoutError
        raise CheckoutError(
            "payment terminal succeeded; subscription pending; "
            "intent_type=unknown; intent_id=unknown; amount_minor=unknown; "
            "subscription verify: HTTP 404"
        )


class MissingTerminalCheckoutAdapter(FakePlatformCheckoutAdapter):
    def charge(self, *args, **kwargs):
        result = super().charge(*args, **kwargs)
        result.pop("intent_status", None)
        return result


class CsInlineCheckoutAdapter(FakePlatformCheckoutAdapter):
    def preflight(self, session, billing=None):
        self.preflight_calls += 1
        return {
            "checkout_id": "cs_test_inline_fixture",
            "payment_page_id": "cs_test_inline_fixture",
            "checkout_provider": "stripe",
            "payment_contract": "stripe_payment_page",
            "checkout_url": "https://platform.example.com/checkout/vendor_ie/cs_test_inline_fixture",
            "processor_entity": "vendor_ie",
            "publishable_key": "pk_test_fixture",
            "country": "PH",
            "billing_country": "US",
            "currency": "PHP",
            "amount_minor": 2000,
            "card_input_modes": ["api_card", "stripe_elements"],
        }

    def charge(self, *args, **kwargs):
        result = super().charge(*args, **kwargs)
        result.update({
            "checkout_id": "cs_test_inline_fixture",
            "payment_contract": "stripe_payment_page",
            "poll_state": "succeeded",
        })
        result.pop("intent_status", None)
        return result


class CsElementsOnlyCheckoutAdapter(CsInlineCheckoutAdapter):
    def preflight(self, session, billing=None):
        checkout = super().preflight(session, billing)
        checkout["card_input_modes"] = ["stripe_elements"]
        return checkout


class CsDynamicAmountCheckoutAdapter(CsInlineCheckoutAdapter):
    def preflight(self, session, billing=None):
        checkout = super().preflight(session, billing)
        checkout["amount_minor"] = None
        return checkout

    def charge(self, *args, **kwargs):
        result = super().charge(*args, **kwargs)
        result["amount_minor"] = 98214
        return result


class DynamicAmountCheckoutAdapter(FakePlatformCheckoutAdapter):
    def preflight(self, session, billing=None):
        checkout = super().preflight(session, billing)
        checkout["amount_minor"] = None
        return checkout


class FailedPollSyncAdapter(ActionRequiredCheckoutAdapter):
    def verify_subscription(self, session, checkout):
        return {
            "active": False,
            "pending": False,
            "terminalFailure": True,
            "pollState": "failed",
            "plan": "",
        }


class TransientVerifyCheckoutAdapter(ActionRequiredCheckoutAdapter):
    def verify_subscription(self, session, checkout):
        from backend.platform_checkout import CheckoutError
        raise CheckoutError("subscription verify: HTTP 503 upstream unavailable")


class ExistingPlusWithoutTerminalAdapter(Stripe3DSCheckoutAdapter):
    def verify_subscription(self, session, checkout):
        return {
            "active": True,
            "pending": False,
            "terminalFailure": False,
            "paymentTerminal": False,
            "pollState": "",
            "checkoutState": "unknown",
            "subscriptionStatus": 200,
        }


class SlowVerifyCheckoutAdapter(ActionRequiredCheckoutAdapter):
    def __init__(self):
        super().__init__()
        self.verify_calls = 0
        self.started = threading.Event()
        self.release = threading.Event()

    def verify_subscription(self, session, checkout):
        self.verify_calls += 1
        self.started.set()
        self.release.wait(3)
        return {
            "active": False,
            "pending": True,
            "terminalFailure": False,
            "paymentTerminal": True,
            "pollState": "succeeded",
            "checkoutState": "succeeded",
            "subscriptionStatus": 404,
        }


class FlakyRenewalAdapter(FakeRenewalAdapter):
    def __init__(self):
        self.calls = 0

    def cancel(self, session, account_id=""):
        from backend.platform_renewal import RenewalError
        self.calls += 1
        if self.calls < 3:
            raise RenewalError("续费接口暂时不可用")
        return super().cancel(session, account_id)


class FailingRenewalAdapter(FakeRenewalAdapter):
    def __init__(self):
        self.calls = 0

    def cancel(self, session, account_id=""):
        from backend.platform_renewal import RenewalError
        self.calls += 1
        raise RenewalError("续费接口测试失败")


class V2Tests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        root = Path(self.temp_dir.name)
        self.service = OrderService(
            root / "v2.db",
            Path(__file__).parents[1],
            step_delay=0.001,
            stripe_gateway=FakeStripeGateway(),
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )

    def tearDown(self) -> None:
        self.service.close()
        self.temp_dir.cleanup()

    def test_admin_managed_key_lifecycle(self) -> None:
        setup = self.service.setup_admin({"username": "admin", "password": "long-test-password"})
        key_result = self.service.create_managed_key(setup["token"], "test key")
        managed_key = key_result["key"]
        self.assertGreaterEqual(len(managed_key), 50)
        self.assertEqual(self.service.list_managed_keys(setup["token"])[0]["status"], "active")

        order = self.service.create_order(
            {
                "apiKey": managed_key,
                "session": SESSION,
                "planType": "plus",
                "provider": "sandbox",
                "paymentFixture": "test_visa",
            }
        )
        self.assertEqual(order["status"], "queued")
        self.service.revoke_managed_key(setup["token"], key_result["record"]["id"])
        with self.assertRaises(ServiceError) as raised:
            self.service.list_orders({"apiKey": managed_key, "page": 1, "pageSize": 20})
        self.assertEqual(raised.exception.code, "api_key_not_registered")

    def test_checkout_accepts_auth_session_json_without_login_cookie(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "missing-cookie.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
        )
        try:
            setup = service.setup_admin(
                {"username": "cookie-admin", "password": "long-test-password"}
            )
            key_result = service.create_managed_key(setup["token"], "cookie key")
            session_json = {
                "user": {"email": "v2@example.test"},
                "expires": "2099-01-01T00:00:00Z",
                "accessToken": "LOCAL_TEST_TOKEN",
            }
            bootstrap = service.bootstrap_platform_stripe_elements(
                {"apiKey": key_result["key"], "session": session_json}
            )
            prepared = service.preflight_platform_checkout(
                {
                    "apiKey": key_result["key"],
                    "session": session_json,
                    "planType": "plus",
                }
            )
            self.assertEqual(bootstrap["stripe"]["publishableKey"], "pk_test_fixture")
            self.assertEqual(prepared["checkout"]["checkoutId"], "oaics_fixture123")
            self.assertFalse(prepared["session"]["has_session_cookie"])
            self.assertEqual(adapter.bootstrap_calls, 1)
            self.assertEqual(adapter.preflight_calls, 1)
        finally:
            service.close()

    def test_admin_proxy_update_persists_and_admin_can_read_plaintext(self) -> None:
        database_path = Path(self.temp_dir.name) / "proxy-admin.db"
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            require_proxy=True,
            require_stripe_proxy=True,
        )
        service = OrderService(
            database_path,
            Path(__file__).parents[1],
            platform_checkout=adapter,
        )
        try:
            setup = service.setup_admin({"username": "proxy-admin", "password": "long-test-password"})
            status = service.configure_proxy(setup["token"], {
                "role": "platform",
                "proxies": "socks5h://USER:SECRET_country-ph_lifetime-10m@geo.example.test:12321",
            })
            self.assertFalse(status["configured"])
            status = service.configure_proxy(setup["token"], {
                "role": "stripe",
                "proxies": "socks5h://USER:STRIPE_SECRET_country-us_lifetime-5m@stripe.example.test:12321",
            })
            self.assertTrue(status["configured"])
            self.assertEqual(status["countries"], ["PH", "US"])
            self.assertEqual(status["platform"]["count"], 1)
            self.assertEqual(status["stripe"]["count"], 1)
            self.assertEqual(status["storage"], "database")
            self.assertIn("SECRET", json.dumps(status))
            self.assertTrue(status["persisted"]["platform"]["configured"])
            self.assertTrue(status["persisted"]["stripe"]["configured"])
            public_proxy = service.metadata()["platformCheckout"]["proxy"]
            self.assertNotIn("proxies", public_proxy)
            self.assertNotIn("SECRET", json.dumps(public_proxy))
            self.assertEqual(public_proxy["count"], 2)
            self.assertTrue(public_proxy["split"])
            self.assertTrue(public_proxy["platform"]["configured"])
            self.assertTrue(public_proxy["stripe"]["configured"])
            with self.assertRaises(ServiceError):
                service.configure_proxy("", {"proxies": "http://proxy.test:8080"})
        finally:
            service.close()

        reloaded_adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            require_proxy=True,
            require_stripe_proxy=True,
        )
        reloaded = OrderService(
            database_path,
            Path(__file__).parents[1],
            platform_checkout=reloaded_adapter,
        )
        try:
            restored = reloaded_adapter.proxy_status()
            self.assertTrue(restored["configured"])
            self.assertEqual(restored["platform"]["count"], 1)
            self.assertEqual(restored["stripe"]["count"], 1)
            self.assertEqual(
                set(reloaded.database.proxy_configurations()["platform"]),
                {"role", "proxies", "created_at", "updated_at"},
            )
        finally:
            reloaded.close()

    def test_domain_routed_session_uses_separate_platform_and_stripe_proxies(self) -> None:
        class RecordingSession:
            def __init__(self):
                self.calls = []

            def get(self, url, **kwargs):
                self.calls.append(("GET", url, kwargs))
                return FakeHTTPResponse({"ok": True})

            def post(self, url, **kwargs):
                self.calls.append(("POST", url, kwargs))
                return FakeHTTPResponse({"ok": True})

            def close(self):
                pass

        base = RecordingSession()
        routed = _DomainProxySession(
            base,
            "socks5h://platform-proxy.test:1080",
            "http://stripe-proxy.test:8080",
        )
        routed.get("https://platform.example.com/api/v1/subscriptions")
        routed.post("https://api.stripe.com/v1/confirmation_tokens")
        routed.get("https://m.stripe.network/inner.html")
        self.assertEqual(
            base.calls[0][2]["proxies"]["https"],
            "socks5h://platform-proxy.test:1080",
        )
        self.assertEqual(
            base.calls[1][2]["proxies"]["https"],
            "http://stripe-proxy.test:8080",
        )
        self.assertEqual(
            base.calls[2][2]["proxies"]["https"],
            "http://stripe-proxy.test:8080",
        )

    def test_oaics_preflight_never_calls_stripe_payment_pages(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], country="PH", currency="PHP", billing_country="US"
        )
        module = adapter._load()
        http = OaicsPreflightSession()
        session = {
            "accessToken": "fixture-token",
            "account_id": "account_fixture",
        }
        billing = {
            "name": "Fixture User", "email": "fixture@example.test",
            "line1": "100 Market Street", "city": "San Francisco",
            "state": "CA", "postal_code": "94105", "country": "US",
        }
        with patch.object(module, "_new_session", return_value=http):
            result = adapter._preflight_once(session, billing, "http://proxy.test:8080")
        self.assertEqual(result["checkout_provider"], "oaics")
        self.assertEqual(result["payment_contract"], "oaics_confirmation_token")
        self.assertEqual(result["payment_page_id"], "")
        self.assertIsNone(result["amount_minor"])
        self.assertFalse(result["amount_known"])
        self.assertFalse(any("/v1/payment_pages/" in path for _method, path in http.calls))
        self.assertFalse(http.closed)
        adapter.release_checkout_context(result["checkout_id"])
        self.assertTrue(http.closed)

    def test_hosted_preflight_defers_stripe_payment_page_initialization(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            country="PH",
            currency="PHP",
            billing_country="US",
        )
        module = adapter._load()
        http = OaicsPreflightSession()
        billing = {
            "name": "Fixture User",
            "email": "fixture@example.test",
            "line1": "100 Market Street",
            "city": "San Francisco",
            "state": "CA",
            "postal_code": "94105",
            "country": "US",
        }
        hosted_response = {
            "checkout_session_id": "cs_test_deferred_fixture",
            "processor_entity": "vendor_entity",
            "publishable_key": "pk_test_fixture",
            "currency": "PHP",
        }
        with (
            patch.object(module, "_new_session", return_value=http),
            patch.object(
                adapter,
                "_account_snapshot",
                return_value={
                    "account_id": "account_fixture",
                    "billing_currency": "USD",
                    "has_active_subscription": False,
                },
            ),
            patch.object(
                module,
                "_checkout_create_cs_live",
                return_value=hosted_response,
            ),
            patch.object(module, "_init_payment_page") as stripe_init,
            patch.object(module, "_create_elements_session") as elements,
            patch.object(module, "_update_payment_page_address") as address,
        ):
            result = adapter._preflight_once(
                {"accessToken": "fixture-token", "account_id": "account_fixture"},
                billing,
                "http://proxy.test:8080",
            )

        stripe_init.assert_not_called()
        elements.assert_not_called()
        address.assert_not_called()
        self.assertEqual(result["checkout_provider"], "stripe")
        self.assertEqual(result["payment_page_id"], "cs_test_deferred_fixture")
        self.assertIsNone(result["amount_minor"])
        self.assertFalse(result["amount_known"])
        self.assertEqual(
            result["card_input_modes"], ["api_card", "stripe_elements"]
        )
        self.assertTrue(
            any(item.get("key") == "stripe_deferred" for item in result["diagnostics"])
        )
        self.assertFalse(any("/v1/payment_pages/" in path for _method, path in http.calls))
        adapter.release_checkout_context(result["checkout_id"])

    def test_currency_incompatible_custom_create_upgrades_once_on_same_session(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            country="PH",
            currency="PHP",
            billing_country="US",
        )
        module = adapter._load()
        http = OaicsPreflightSession()
        session = {
            "accessToken": "fixture-token",
            "account_id": "account_fixture",
        }
        billing = {
            "name": "Fixture User",
            "email": "fixture@example.test",
            "line1": "100 Market Street",
            "city": "San Francisco",
            "state": "CA",
            "postal_code": "94105",
            "country": "US",
        }
        hosted_response = {
            "checkout_session_id": "oaics_preflight_fixture",
            "processor_entity": "vendor_ie",
            "publishable_key": "pk_test_fixture",
            "currency": "PHP",
        }
        with (
            patch.object(module, "_new_session", return_value=http),
            patch.object(
                module,
                "_checkout_create_custom",
                side_effect=RuntimeError("currency_incompatible"),
            ) as custom_create,
            patch.object(
                module,
                "_checkout_create_cs_live",
                return_value=hosted_response,
            ) as hosted_create,
        ):
            result = adapter._preflight_once(
                session,
                billing,
                "http://proxy.test:8080",
            )
        self.assertEqual(custom_create.call_count, 1)
        self.assertEqual(hosted_create.call_count, 1)
        self.assertIs(
            custom_create.call_args.args[0],
            hosted_create.call_args.args[0],
        )
        self.assertEqual(result["requested_checkout_mode"], "custom")
        self.assertEqual(result["selected_checkout_mode"], "hosted")
        self.assertEqual(result["actual_checkout_mode"], "custom")
        self.assertEqual(
            result["currency_route_reason"],
            "currency_incompatible_fallback",
        )
        self.assertTrue(result["upgraded_from_oaics"])
        adapter.release_checkout_context(result["checkout_id"])

    def test_known_currency_mismatch_selects_hosted_before_checkout(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            country="PH",
            currency="PHP",
            billing_country="US",
        )
        module = adapter._load()
        http = OaicsPreflightSession()
        billing = {
            "name": "Fixture User",
            "email": "fixture@example.test",
            "line1": "100 Market Street",
            "city": "San Francisco",
            "state": "CA",
            "postal_code": "94105",
            "country": "US",
        }
        hosted_response = {
            "checkout_session_id": "oaics_preflight_fixture",
            "processor_entity": "vendor_ie",
            "publishable_key": "pk_test_fixture",
            "currency": "PHP",
        }
        with (
            patch.object(module, "_new_session", return_value=http),
            patch.object(
                adapter,
                "_account_snapshot",
                return_value={
                    "account_id": "account_fixture",
                    "billing_currency": "USD",
                    "has_active_subscription": False,
                },
            ),
            patch.object(module, "_checkout_create_custom") as custom_create,
            patch.object(
                module,
                "_checkout_create_cs_live",
                return_value=hosted_response,
            ) as hosted_create,
        ):
            result = adapter._preflight_once(
                {"accessToken": "fixture-token", "account_id": "account_fixture"},
                billing,
                "http://proxy.test:8080",
            )
        custom_create.assert_not_called()
        self.assertEqual(hosted_create.call_count, 1)
        self.assertEqual(result["selected_checkout_mode"], "hosted")
        self.assertEqual(result["currency_route_reason"], "currency_mismatched")
        self.assertFalse(result["upgraded_from_oaics"])
        adapter.release_checkout_context(result["checkout_id"])

    def test_elements_bootstrap_is_read_only_and_does_not_create_checkout(self) -> None:
        adapter = PlatformCheckoutAdapter(Path(__file__).parents[1])
        module = adapter._load()
        http = OaicsPreflightSession()
        session = {
            "accessToken": "fixture-token",
            "account_id": "account_fixture",
        }
        with (
            patch.object(adapter, "_routed_session", return_value=http),
            patch.object(module, "_hydrate_payment_metadata", return_value={}),
            patch.object(
                module,
                "_ensure_sentinel_context",
                return_value=("sentinel_fixture", "[1,null]"),
            ),
        ):
            result = adapter._bootstrap_stripe_elements_once(session, "")
        self.assertEqual(result["publishable_key"], "pk_test_fixture")
        self.assertEqual(result["account_id"], "account_fixture")
        self.assertIn(
            ("GET", "/api/v1/payments/stripe_client_bootstrap"), http.calls
        )
        self.assertFalse(any(method == "POST" for method, _path in http.calls))
        self.assertFalse(any("/checkout" in path for _method, path in http.calls))
        self.assertTrue(http.closed)

    def test_elements_bootstrap_cache_is_account_scoped(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], stripe_bootstrap_cache_ttl=60
        )
        with patch.object(
            adapter,
            "_bootstrap_stripe_elements_once",
            side_effect=[
                {
                    "publishable_key": "pk_test_account_one",
                    "account_id": "account_one",
                    "proxy": "masked-one",
                    "stripe_proxy": "masked-stripe-one",
                },
                {
                    "publishable_key": "pk_test_account_two",
                    "account_id": "account_two",
                    "proxy": "masked-two",
                    "stripe_proxy": "masked-stripe-two",
                },
            ],
        ) as upstream:
            first = adapter.bootstrap_stripe_elements(
                {"accessToken": "token-one", "account_id": "account_one"}
            )
            second = adapter.bootstrap_stripe_elements(
                {"accessToken": "token-one", "account_id": "account_one"}
            )
            other = adapter.bootstrap_stripe_elements(
                {"accessToken": "token-two", "account_id": "account_two"}
            )
        self.assertFalse(first["cache_hit"])
        self.assertTrue(second["cache_hit"])
        self.assertEqual(second["publishable_key"], "pk_test_account_one")
        self.assertFalse(other["cache_hit"])
        self.assertEqual(other["publishable_key"], "pk_test_account_two")
        self.assertEqual(upstream.call_count, 2)
        self.assertNotIn("token-one", repr(adapter._stripe_bootstrap_cache))

    def test_elements_bootstrap_cache_expires(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], stripe_bootstrap_cache_ttl=0.01
        )
        with patch.object(
            adapter,
            "_bootstrap_stripe_elements_once",
            side_effect=[
                {"publishable_key": "pk_test_first", "account_id": "account_expire"},
                {"publishable_key": "pk_test_second", "account_id": "account_expire"},
            ],
        ) as upstream:
            first = adapter.bootstrap_stripe_elements(
                {"accessToken": "token-expire", "account_id": "account_expire"}
            )
            time.sleep(0.03)
            second = adapter.bootstrap_stripe_elements(
                {"accessToken": "token-expire", "account_id": "account_expire"}
            )
        self.assertFalse(first["cache_hit"])
        self.assertFalse(second["cache_hit"])
        self.assertEqual(upstream.call_count, 2)

    def test_elements_bootstrap_does_not_create_order_or_checkout(self) -> None:
        root = Path(self.temp_dir.name)
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            root / "elements-bootstrap.db",
            Path(__file__).parents[1],
            step_delay=0.001,
            stripe_gateway=FakeStripeGateway(),
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin(
                {"username": "bootstrap-admin", "password": "long-test-password"}
            )
            key_result = service.create_managed_key(
                setup["token"], "elements bootstrap key"
            )
            before = service.database.stats()["total"]
            result = service.bootstrap_platform_stripe_elements(
                {
                    "apiKey": key_result["key"],
                    "session": SESSION,
                }
            )
            after = service.database.stats()["total"]
        finally:
            service.close()
        self.assertEqual(result["stripe"]["publishableKey"], "pk_test_fixture")
        self.assertEqual(result["stripe"]["cardInputModes"], ["stripe_elements"])
        self.assertEqual(before, after)
        self.assertEqual(adapter.bootstrap_calls, 1)
        self.assertEqual(adapter.preflight_calls, 0)
        self.assertEqual(adapter.charge_calls, 0)

    def test_preflight_resolves_missing_account_id(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], country="PH", currency="PHP", billing_country="US"
        )
        module = adapter._load()
        http = OaicsPreflightSession()
        billing = {
            "name": "Fixture User", "email": "fixture@example.test",
            "line1": "100 Market Street", "city": "San Francisco",
            "state": "CA", "postal_code": "94105", "country": "US",
        }
        with patch.object(module, "_new_session", return_value=http):
            result = adapter._preflight_once(
                {"accessToken": "fixture-token"}, billing, "http://proxy.test:8080"
            )
        self.assertEqual(result["account_id"], "account_resolved_fixture")
        self.assertIn(
            ("GET", "/api/v1/accounts/check/v4-2023-04-27"), http.calls
        )

    def test_preflight_rejects_stripe_merchant_mismatch(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], country="PH", currency="PHP", billing_country="US"
        )
        module = adapter._load()
        http = OaicsPreflightSession("pk_test_other_merchant")
        billing = {
            "name": "Fixture User", "email": "fixture@example.test",
            "line1": "100 Market Street", "city": "San Francisco",
            "state": "CA", "postal_code": "94105", "country": "US",
        }
        with patch.object(module, "_new_session", return_value=http):
            with self.assertRaisesRegex(Exception, "商户公钥不一致"):
                adapter._preflight_once(
                    {"accessToken": "fixture-token", "account_id": "account_fixture"},
                    billing,
                    "http://proxy.test:8080",
                )

    def test_oaics_recovery_tries_alternate_processor_after_not_found(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], country="PH", currency="PHP", billing_country="US"
        )
        http = OaicsRecoverySession()
        session = {"accessToken": "fixture-token", "account_id": "account_fixture"}
        checkout = {
            "checkout_id": "oaics_recovery_fixture",
            "checkout_provider": "stripe",
            "payment_page_id": "cs_test_wrong_contract",
            "processor_entity": "vendor_ie",
        }
        with patch.object(adapter, "_routed_session", return_value=http):
            result = adapter.verify_subscription(session, checkout)
        self.assertTrue(result["active"])
        self.assertFalse(result["paymentTerminal"])
        self.assertEqual(result["processorEntity"], "vendor_entity")
        self.assertIn(
            ("GET", "/api/v1/payments/checkout/vendor_entity/oaics_recovery_fixture"),
            http.calls,
        )
        self.assertTrue(http.closed)

    def test_cs_recovery_visits_return_url_before_subscription_poll(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1], country="PH", currency="PHP", billing_country="US"
        )
        http = CsRecoverySession()
        session = {"accessToken": "fixture-token", "account_id": "account_fixture"}
        checkout = {
            "checkout_id": "cs_test_recovery",
            "payment_page_id": "cs_test_recovery",
            "checkout_provider": "oaics",
            "processor_entity": "vendor_ie",
            "publishable_key": "pk_test_fixture",
        }
        with patch.object(adapter, "_routed_session", return_value=http):
            result = adapter.verify_subscription(session, checkout)
        paths = [path for _method, path in http.calls]
        self.assertTrue(result["active"])
        self.assertTrue(result["paymentTerminal"])
        self.assertEqual(result["checkoutState"], "succeeded")
        self.assertEqual(result["returnUrlStatus"], 200)
        self.assertLess(paths.index("/checkout/verify"), paths.index("/api/v1/subscriptions"))
        self.assertEqual(http.subscription_calls, 3)
        self.assertTrue(http.closed)

    def test_oaics_charge_accepts_dynamic_amount_without_exposing_sentinel(self) -> None:
        adapter = DynamicAmountCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-dynamic-amount.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "dynamic-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "dynamic amount key")
            checkout = adapter.preflight(SESSION)
            result = service.charge_platform_checkout_order({
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "plus",
                "paymentMode": "stripe_elements",
                "paymentMethodId": "pm_fixture",
                "cardLast4": "4242",
                "checkout": checkout,
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(result["order"]["status"], "succeeded")
            self.assertIsNone(result["order"]["amountMinor"])
            self.assertFalse(result["order"]["amountKnown"])
            stored = service.database.get_order_by_key(result["order"]["orderKey"])
            self.assertEqual(stored["amount_minor"], -1)
        finally:
            service.close()

    def test_stripe_charge_and_sync(self) -> None:
        setup = self.service.setup_admin({"username": "stripe-admin", "password": "long-test-password"})
        key_result = self.service.create_managed_key(setup["token"], "stripe key")
        charged = self.service.charge_stripe_order(
            {
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "pro5",
                "paymentMethodId": "pm_card_visa",
            }
        )
        self.assertEqual(charged["order"]["status"], "succeeded")
        self.assertFalse(charged["actionRequired"])
        self.assertEqual(charged["order"]["renewal"]["status"], "succeeded")
        synced = self.service.sync_stripe_order(
            {"apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]}
        )
        self.assertEqual(synced["status"], "succeeded")
        self.assertEqual(synced["paymentLast4"], "4242")

    def test_webhook_signature(self) -> None:
        secret = "whsec_fixture"
        gateway = StripeGateway(StripeSettings(webhook_secret=secret))
        raw = json.dumps({"id": "evt_1", "type": "payment_intent.succeeded", "data": {"object": {}}}).encode()
        timestamp = str(int(time.time()))
        digest = hmac.new(secret.encode(), f"{timestamp}.".encode() + raw, hashlib.sha256).hexdigest()
        event = gateway.verify_webhook(raw, f"t={timestamp},v1={digest}")
        self.assertEqual(event["id"], "evt_1")
        with self.assertRaises(WebhookSignatureError):
            gateway.verify_webhook(raw, f"t={timestamp},v1=bad")

    def test_mandatory_renewal_failure_does_not_overwrite_payment_success(self) -> None:
        setup = self.service.setup_admin({"username": "failure-admin", "password": "long-test-password"})
        key_result = self.service.create_managed_key(setup["token"], "failure key")
        adapter = FailingRenewalAdapter()
        self.service.renewal_adapter = adapter
        result = self.service.charge_stripe_order(
            {
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "plus",
                "paymentMethodId": "pm_card_visa",
            }
        )
        self.assertEqual(result["order"]["status"], "succeeded")
        self.assertIsNone(result["order"]["errorCode"])
        self.assertEqual(result["order"]["renewal"]["status"], "failed")
        self.assertEqual(result["order"]["renewal"]["retryCount"], 3)
        self.assertEqual(adapter.calls, 3)

    def test_platform_checkout_success_triggers_mandatory_renewal_cancel(self) -> None:
        service = OrderService(
            Path(self.temp_dir.name) / "platform.db",
            Path(__file__).parents[1],
            step_delay=0.001,
            platform_checkout=FakePlatformCheckoutAdapter(),
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "checkout-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "checkout key")
            prepared = service.preflight_platform_checkout(
                {
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "billing": {
                        "name": "Fixture User",
                        "email": "fixture@example.test",
                        "line1": "100 Market Street",
                        "city": "San Francisco",
                        "state": "CA",
                        "postal_code": "94105",
                        "country": "US",
                    },
                }
            )
            self.assertEqual(prepared["checkout"]["checkoutId"], "oaics_fixture123")
            self.assertEqual(prepared["checkout"]["country"], "PH")
            self.assertEqual(prepared["checkout"]["billingCountry"], "US")
            self.assertEqual(len(prepared["checkout"]["diagnostics"]), 2)
            self.assertEqual(prepared["checkout"]["checkoutUrl"], "https://platform.example.com/checkout/vendor_ie/oaics_fixture123")
            self.assertEqual(prepared["checkout"]["cardInputModes"], ["api_card", "stripe_elements"])
            self.assertEqual(prepared["checkout"]["defaultCardInputMode"], "api_card")
            self.assertEqual(prepared["checkout"]["requestedCheckoutMode"], "custom")
            self.assertEqual(prepared["checkout"]["selectedCheckoutMode"], "custom")
            self.assertEqual(prepared["checkout"]["actualCheckoutMode"], "custom")
            self.assertFalse(prepared["checkout"]["upgradedFromOaics"])
            result = service.charge_platform_checkout_order(
                {
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "paymentMethodId": "pm_fixture",
                    "cardLast4": "4242",
                    "checkout": prepared["checkout"],
                    "billing": {
                        "name": "Fixture User",
                        "email": "fixture@example.test",
                        "line1": "100 Market Street",
                        "city": "San Francisco",
                        "state": "CA",
                        "postal_code": "94105",
                        "country": "US",
                    },
                }
            )
            self.assertEqual(result["order"]["provider"], "platform_checkout")
            self.assertEqual(result["order"]["status"], "succeeded")
            self.assertEqual(result["order"]["renewal"]["status"], "succeeded")
            stored = service.database.get_order_by_key(result["order"]["orderKey"])
            self.assertEqual(stored["checkout_provider"], "oaics")
            self.assertEqual(stored["processor_entity"], "vendor_entity")
            self.assertEqual(stored["payment_contract"], "oaics_confirmation_token")
            self.assertEqual(stored["intent_type"], "payment_intent")
            self.assertEqual(stored["confirmation_ref"], "pi_fixture_checkout")
            self.assertEqual(stored["payment_terminal_status"], "succeeded")
            self.assertEqual(stored["return_url_status"], 200)
            self.assertTrue(stored["confirm_return_url"].startswith("https://platform.example.com/checkout/verify"))
            self.assertNotIn("renewal_session_ciphertext", stored)
            self.assertNotIn("LOCAL_TEST_TOKEN", json.dumps(stored, ensure_ascii=False))
            self.assertEqual(service.metadata()["renewal"]["sessionStorage"], "memory_only")
            self.assertFalse(service.metadata()["renewal"]["encryptionRequired"])
        finally:
            service.close()

    def test_checkout_charge_runs_implicit_preflight_when_context_is_missing(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "implicit-preflight.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "implicit-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "implicit checkout key")
            result = service.charge_platform_checkout_order(
                {
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "paymentMode": "stripe_elements",
                    "paymentMethodId": "pm_fixture",
                    "cardLast4": "4242",
                    "billing": {
                        "name": "Fixture User",
                        "email": "fixture@example.test",
                        "line1": "100 Market Street",
                        "city": "San Francisco",
                        "state": "CA",
                        "postal_code": "94105",
                        "country": "US",
                    },
                }
            )
            self.assertEqual(adapter.preflight_calls, 1)
            self.assertEqual(result["order"]["status"], "succeeded")
            self.assertEqual(result["order"]["providerRef"], "oaics_fixture123")
        finally:
            service.close()

    def test_cached_preflight_contract_overrides_client_checkout_fields(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "server-contract.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "contract-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "contract key")
            prepared = service.preflight_platform_checkout(
                {"apiKey": key_result["key"], "session": SESSION, "planType": "plus"}
            )
            client_checkout = {
                **prepared["checkout"],
                "checkoutProvider": "stripe",
                "paymentContract": "stripe_payment_page",
                "paymentPageId": "cs_test_client_override",
                "processorEntity": "client_override",
                "amountMinor": 999999,
            }
            result = service.charge_platform_checkout_order(
                {
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "paymentMode": "stripe_elements",
                    "paymentMethodId": "pm_fixture",
                    "cardLast4": "4242",
                    "checkout": client_checkout,
                }
            )
            stored = service.database.get_order_by_key(result["order"]["orderKey"])
            self.assertEqual(adapter.preflight_calls, 1)
            self.assertEqual(stored["checkout_provider"], "oaics")
            self.assertEqual(stored["payment_contract"], "oaics_confirmation_token")
            self.assertIsNone(stored["payment_page_id"])
            self.assertEqual(stored["amount_minor"], 2000)
        finally:
            service.close()

    def test_checkout_charge_is_idempotent(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-idempotent.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "idempotent-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "idempotent key")
            payload = {
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "plus",
                "paymentMode": "stripe_elements",
                "paymentMethodId": "pm_fixture",
                "cardLast4": "4242",
                "checkout": {
                    "checkoutId": "oaics_idempotent123",
                    "checkoutUrl": "https://platform.example.com/checkout/vendor_ie/oaics_idempotent123",
                    "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture",
                    "currency": "PHP",
                    "amountMinor": 2000,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            }
            first = service.charge_platform_checkout_order(payload)
            second = service.charge_platform_checkout_order(payload)
            self.assertFalse(first["idempotent"])
            self.assertTrue(second["idempotent"])
            self.assertEqual(first["order"]["orderKey"], second["order"]["orderKey"])
            self.assertEqual(adapter.charge_calls, 1)
        finally:
            service.close()

    def test_action_required_syncs_to_success(self) -> None:
        adapter = ActionRequiredCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-action.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "action-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "action key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_action123", "checkoutUrl": "https://platform.example.com/checkout/vendor_ie/oaics_action123",
                    "processorEntity": "vendor_ie", "publishableKey": "pk_test_fixture", "currency": "PHP", "amountMinor": 2000,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test", "line1": "100 Market Street",
                    "city": "San Francisco", "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertTrue(charged["actionRequired"])
            self.assertEqual(charged["actionType"], "checkout_session_confirmation")
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            self.assertEqual(
                charged["order"]["errorCode"],
                "checkout_session_confirmation_required",
            )
            self.assertEqual(charged["order"]["paymentActionType"], "checkout_session_confirmation")
            self.assertEqual(charged["order"]["paymentTerminalStatus"], "succeeded")
            self.assertEqual(charged["order"]["intentType"], "payment_intent")
            self.assertEqual(charged["order"]["confirmationRef"], "pi_action_fixture")
            self.assertTrue(charged["order"]["paymentActionUrl"].endswith("oaics_action123"))
            synced = service.sync_stripe_order({"apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]})
            self.assertEqual(synced["status"], "succeeded")
            self.assertEqual(synced["renewal"]["status"], "succeeded")
        finally:
            service.close()

    def test_3ds_action_preserves_payment_stage_until_intent_succeeds(self) -> None:
        adapter = Stripe3DSCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-3ds.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "three-ds-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "3ds key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_3ds_fixture",
                    "checkoutUrl": "https://platform.example.com/checkout/vendor_ie/oaics_3ds_fixture",
                    "processorEntity": "vendor_ie", "publishableKey": "pk_test_fixture",
                    "currency": "PHP", "amountMinor": 2000,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(charged["order"]["step"], "confirm_payment")
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            self.assertIsNone(charged["order"]["completedAt"])
            self.assertEqual(charged["order"]["errorCode"], "stripe_action_required")
            self.assertEqual(charged["order"]["paymentActionType"], "stripe_3ds")
            self.assertEqual(charged["order"]["paymentTerminalStatus"], "requires_action")
            self.assertEqual(charged["order"]["intentType"], "payment_intent")
            self.assertEqual(charged["order"]["confirmationRef"], "pi_3ds_fixture")
            self.assertEqual(
                charged["order"]["paymentActionDetails"]["next_action"]
                ["redirect_to_url"]["client_secret"],
                "pi_3ds_fixture_secret_LOCAL_TEST_TOKEN",
            )
            self.assertEqual(
                charged["order"]["paymentActionUrl"],
                "https://stripe.example.test/3ds/fixture",
            )

            original_error = charged["order"]["errorMessage"]
            synced = service.sync_stripe_order({
                "apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]
            })
            self.assertEqual(synced["step"], "confirm_payment")
            self.assertEqual(synced["errorCode"], "stripe_action_required")
            self.assertEqual(synced["errorMessage"], original_error)
            self.assertEqual(synced["paymentTerminalStatus"], "requires_action")

            stored = service.database.get_order_by_key(charged["order"]["orderKey"])
            service.database.update_order(
                int(stored["id"]),
                recovery_attempts=11,
                recovery_next_at="2000-01-01T00:00:00+00:00",
            )
            service._run_checkout_recoveries()
            exhausted = service.public_order(
                service.database.get_order_by_id(int(stored["id"]))
            )
            self.assertEqual(exhausted["status"], "awaiting_payment")
            self.assertEqual(exhausted["step"], "confirm_payment")
            self.assertEqual(exhausted["errorCode"], "stripe_action_required")
            self.assertIsNone(exhausted["completedAt"])
            self.assertIsNone(exhausted["recoveryNextAt"])
        finally:
            service.close()

    def test_renewal_retries_until_success(self) -> None:
        adapter = FlakyRenewalAdapter()
        self.service.renewal_adapter = adapter
        setup = self.service.setup_admin({"username": "retry-admin", "password": "long-test-password"})
        key_result = self.service.create_managed_key(setup["token"], "retry key")
        result = self.service.charge_stripe_order({
            "apiKey": key_result["key"], "session": SESSION, "planType": "plus", "paymentMethodId": "pm_card_visa",
        })
        self.assertEqual(result["order"]["renewal"]["status"], "succeeded")
        self.assertEqual(result["order"]["renewal"]["retryCount"], 3)
        self.assertEqual(adapter.calls, 3)

    def test_oaics_accepts_backend_card_mode(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-api-card.db",
            Path(__file__).parents[1],
            step_delay=0.001,
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "api-card-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "api card key")
            result = service.charge_platform_checkout_order({
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "paymentMode": "api_card",
                    "card": {
                        "number": "4242 4242 4242 4242",
                        "expMonth": "12",
                        "expYear": str(time.gmtime().tm_year + 2),
                        "cvc": "123",
                    },
                    "checkout": {
                        "checkoutId": "oaics_fixture123",
                        "processorEntity": "vendor_ie",
                        "publishableKey": "pk_test_fixture",
                        "currency": "PHP",
                        "amountMinor": 0,
                    },
                    "billing": {
                        "name": "Fixture User",
                        "email": "fixture@example.test",
                        "line1": "100 Market Street",
                        "city": "San Francisco",
                        "state": "CA",
                        "postal_code": "94105",
                        "country": "US",
                    },
                })
            self.assertEqual(result["order"]["paymentLast4"], "4242")
            self.assertEqual(adapter.charge_calls, 1)
        finally:
            service.close()

    def test_recovery_contract_is_derived_from_checkout_id(self) -> None:
        context = OrderService._checkout_context_for_order({
            "provider_ref": "oaics_recovery_contract",
            "checkout_provider": "stripe",
            "payment_contract": "stripe_payment_page",
            "payment_page_id": "cs_test_wrong_contract",
            "processor_entity": "vendor_ie",
            "currency": "PHP",
        })
        self.assertEqual(context["checkoutProvider"], "oaics")
        self.assertEqual(context["paymentContract"], "oaics_confirmation_token")
        self.assertEqual(context["paymentPageId"], "")
        self.assertEqual(context["cardInputModes"], ["api_card", "stripe_elements"])

    def test_cs_checkout_allows_backend_inline_card_mode(self) -> None:
        adapter = CsInlineCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-cs-inline.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "cs-inline-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "cs inline key")
            result = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "api_card",
                "card": {
                    "number": "4242 4242 4242 4242", "expMonth": "12",
                    "expYear": str(time.gmtime().tm_year + 2), "cvc": "123",
                },
                "checkout": {
                    "checkoutId": "cs_test_inline_fixture",
                    "paymentPageId": "cs_test_inline_fixture",
                    "processorEntity": "vendor_ie", "publishableKey": "pk_test_fixture",
                    "currency": "PHP", "amountMinor": 2000,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(result["order"]["status"], "succeeded")
            self.assertEqual(result["paymentContract"], "stripe_payment_page")
            self.assertEqual(adapter.preflight_calls, 1)
            self.assertEqual(adapter.last_charge["payment_method_id"], "")
            self.assertEqual(adapter.last_charge["card"]["card_number"], "4242424242424242")
            stored = service.database.get_order_by_key(result["order"]["orderKey"])
            self.assertNotIn("4242424242424242", json.dumps(stored, ensure_ascii=False))
        finally:
            service.close()

    def test_cs_checkout_accepts_dynamic_amount_until_charge_preparation(self) -> None:
        adapter = CsDynamicAmountCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-cs-dynamic.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({
                "username": "cs-dynamic-admin",
                "password": "long-test-password",
            })
            key_result = service.create_managed_key(setup["token"], "cs dynamic key")
            result = service.charge_platform_checkout_order({
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "plus",
                "paymentMode": "api_card",
                "card": {
                    "number": "4242424242424242",
                    "expMonth": "12",
                    "expYear": str(time.gmtime().tm_year + 2),
                    "cvc": "123",
                },
                "checkout": {
                    "checkoutId": "cs_test_inline_fixture",
                    "paymentPageId": "cs_test_inline_fixture",
                    "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture",
                    "currency": "PHP",
                    "amountMinor": None,
                    "cardInputModes": ["api_card", "stripe_elements"],
                },
                "billing": {
                    "name": "Fixture User",
                    "email": "fixture@example.test",
                    "line1": "100 Market Street",
                    "city": "San Francisco",
                    "state": "CA",
                    "postal_code": "94105",
                    "country": "US",
                },
            })
            self.assertEqual(result["order"]["status"], "succeeded")
            self.assertTrue(result["order"]["amountKnown"])
            self.assertEqual(result["order"]["amountMinor"], 98214)
        finally:
            service.close()

    def test_cs_inline_card_requires_preflight_capability(self) -> None:
        adapter = CsElementsOnlyCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-cs-elements-only.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "cs-elements-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "cs elements key")
            prepared = service.preflight_platform_checkout({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
            })
            self.assertEqual(prepared["checkout"]["cardInputModes"], ["stripe_elements"])
            with self.assertRaises(ServiceError) as raised:
                service.charge_platform_checkout_order({
                    "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                    "paymentMode": "api_card",
                    "card": {
                        "number": "4242424242424242", "expMonth": "12",
                        "expYear": str(time.gmtime().tm_year + 2), "cvc": "123",
                    },
                    "checkout": prepared["checkout"],
                })
            self.assertEqual(raised.exception.code, "checkout_payment_mode_unavailable")
            self.assertEqual(adapter.charge_calls, 0)
        finally:
            service.close()

    def test_subscription_pending_keeps_context_and_failed_order_can_recover(self) -> None:
        adapter = SubscriptionPendingCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "subscription-recovery.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "recovery-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "recovery key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "4242",
                "checkout": {
                    "checkoutId": "oaics_recovery_fixture", "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture", "currency": "PHP", "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            self.assertEqual(charged["order"]["errorCode"], "subscription_pending")
            self.assertEqual(charged["order"]["confirmationRef"], "pi_pending_fixture")
            self.assertEqual(charged["order"]["amountMinor"], 99000)
            order_id = int(service.database.get_order_by_key(charged["order"]["orderKey"])["id"])

            # Simulate the historical state produced before recovery support and a process restart.
            service.database.update_order(
                order_id,
                status="failed",
                step="verify_result",
                progress=90,
                error_code="platform_checkout_failed",
                error_message="subscription verify: HTTP 404 No subscription found for account",
                completed_at="2026-08-04T16:11:29+00:00",
                renewal_cancel_status="not_required",
            )
            with service._renewal_lock:
                service._pending_renewals.clear()
                service._pending_checkout_context.clear()

            recovered = service.sync_stripe_order({
                "apiKey": key_result["key"],
                "orderKey": charged["order"]["orderKey"],
                "session": SESSION,
            })
            self.assertEqual(recovered["status"], "succeeded")
            self.assertEqual(recovered["renewal"]["status"], "succeeded")
        finally:
            service.close()

    def test_token_rotation_after_charge_is_recoverable_and_never_marked_failed(self) -> None:
        adapter = TokenRotatedCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "token-rotation-recovery.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({
                "username": "token-rotation-admin",
                "password": "long-test-password",
            })
            key_result = service.create_managed_key(
                setup["token"], "token rotation key"
            )
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"],
                "session": SESSION,
                "planType": "plus",
                "paymentMode": "stripe_elements",
                "paymentMethodId": "pm_fixture",
                "cardLast4": "4242",
                "checkout": {
                    "checkoutId": "oaics_token_rotation_fixture",
                    "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture",
                    "currency": "PHP",
                    "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User",
                    "email": "fixture@example.test",
                    "line1": "100 Market Street",
                    "city": "San Francisco",
                    "state": "CA",
                    "postal_code": "94105",
                    "country": "US",
                },
            })
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            self.assertEqual(
                charged["order"]["errorCode"], "auth_refresh_required"
            )
            self.assertEqual(
                charged["order"]["paymentTerminalStatus"], "succeeded"
            )
            self.assertEqual(
                charged["order"]["confirmationRef"],
                "pi_token_rotated_fixture",
            )
            stored = service.database.get_order_by_key(
                charged["order"]["orderKey"]
            )
            self.assertIsNone(stored["completed_at"])
            with service._renewal_lock:
                pending_session, _account_id = service._pending_renewals[
                    int(stored["id"])
                ]
            self.assertEqual(
                pending_session["accessToken"], "refreshed_fixture"
            )
        finally:
            service.close()

    def test_subscription_pending_without_intent_evidence_stays_in_payment_stage(self) -> None:
        adapter = UnverifiedSubscriptionPendingCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "unverified-payment-terminal.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "unverified-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "unverified key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "4242",
                "checkout": {
                    "checkoutId": "oaics_unverified_terminal",
                    "processorEntity": "vendor_ie", "publishableKey": "pk_test_fixture",
                    "currency": "PHP", "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            self.assertEqual(charged["order"]["step"], "confirm_payment")
            self.assertEqual(charged["order"]["errorCode"], "payment_terminal_unverified")
            self.assertIsNone(charged["order"]["paymentTerminalStatus"])
            self.assertIsNone(charged["order"]["confirmationRef"])
        finally:
            service.close()

    def test_transient_verify_error_keeps_order_pending(self) -> None:
        adapter = TransientVerifyCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "transient-verify.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "transient-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "transient key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_transient", "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture", "currency": "PHP", "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            synced = service.sync_stripe_order({
                "apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]
            })
            self.assertEqual(synced["status"], "awaiting_payment")
            self.assertEqual(synced["step"], "confirm_payment")
            self.assertEqual(synced["errorCode"], "checkout_session_confirmation_required")
            self.assertIn("missing flow-bound confirmation context", synced["errorMessage"])
        finally:
            service.close()

    def test_concurrent_sync_runs_one_upstream_verification(self) -> None:
        adapter = SlowVerifyCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "concurrent-sync.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "sync-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "sync key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_concurrent", "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture", "currency": "PHP", "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            sync_payload = {"apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]}
            first_result = {}

            def run_first_sync():
                first_result.update(service.sync_stripe_order(sync_payload))

            worker = threading.Thread(target=run_first_sync)
            worker.start()
            self.assertTrue(adapter.started.wait(1))
            duplicate = service.sync_stripe_order(sync_payload)
            adapter.release.set()
            worker.join(3)
            self.assertFalse(worker.is_alive())
            self.assertEqual(adapter.verify_calls, 1)
            self.assertEqual(duplicate["status"], "awaiting_payment")
            self.assertEqual(first_result["status"], "awaiting_payment")
        finally:
            adapter.release.set()
            service.close()

    def test_existing_plus_without_payment_terminal_stays_pending(self) -> None:
        adapter = ExistingPlusWithoutTerminalAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "existing-plus.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "existing-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "existing key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_existing_plus", "processorEntity": "vendor_ie",
                    "publishableKey": "pk_test_fixture", "currency": "PHP", "amountMinor": None,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            synced = service.sync_stripe_order({
                "apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]
            })
            self.assertEqual(synced["status"], "awaiting_payment")
            self.assertEqual(synced["errorCode"], "stripe_action_required")
            self.assertIsNone(synced["completedAt"])
        finally:
            service.close()

    def test_restart_freezes_platform_order_for_verification_without_recharge(self) -> None:
        database_path = Path(self.temp_dir.name) / "restart-recovery.db"
        service = OrderService(
            database_path,
            Path(__file__).parents[1],
            platform_checkout=FakePlatformCheckoutAdapter(),
            renewal_adapter=FakeRenewalAdapter(),
        )
        order = service.database.create_order({
            "order_key": "XY-RESTARTFIXTURE",
            "api_key_hash": "a" * 64,
            "api_key_prefix": "xy_tes...",
            "plan_type": "plus",
            "plan_name": "Plus",
            "amount_minor": -1,
            "currency": "PHP",
            "email": "fixture@example.test",
            "account_ref": "account-ref",
            "session_fingerprint": "session-fingerprint",
            "provider": "platform_checkout",
            "provider_ref": "oaics_restart_fixture",
            "checkout_provider": "oaics",
            "processor_entity": "vendor_ie",
            "payment_contract": "oaics_confirmation_token",
            "payment_fixture": "platform_checkout_stripe_elements",
            "payment_last4": "4242",
            "renewal_cancel_requested": 1,
            "renewal_cancel_status": "pending",
            "_status": "running",
            "_step": "confirm_payment",
            "_progress": 65,
        })
        service.close()
        restarted = OrderService(
            database_path,
            Path(__file__).parents[1],
            platform_checkout=FakePlatformCheckoutAdapter(),
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            recovered = restarted.database.get_order_by_id(int(order["id"]))
            self.assertEqual(recovered["status"], "awaiting_payment")
            self.assertEqual(recovered["error_code"], "payment_recovery_required")
            self.assertEqual(recovered["step"], "confirm_payment")
        finally:
            restarted.close()

    def test_database_does_not_infer_payment_success_from_subscription_pending(self) -> None:
        database_path = Path(self.temp_dir.name) / "payment-evidence-migration.db"
        database = Database(database_path)
        order = database.create_order({
            "order_key": "XY-FALSETERMINAL",
            "api_key_hash": "b" * 64,
            "api_key_prefix": "xy_tes...",
            "plan_type": "plus",
            "plan_name": "Plus",
            "amount_minor": -1,
            "currency": "PHP",
            "email": "fixture@example.test",
            "account_ref": "account-ref",
            "session_fingerprint": "session-fingerprint",
            "provider": "platform_checkout",
            "provider_ref": "oaics_false_terminal",
            "checkout_provider": "oaics",
            "processor_entity": "vendor_ie",
            "payment_contract": "oaics_confirmation_token",
            "payment_fixture": "platform_checkout_stripe_elements",
            "payment_last4": "4242",
            "payment_action_url": "https://platform.example.com/checkout/vendor_ie/oaics_false_terminal",
            "renewal_cancel_requested": 1,
            "renewal_cancel_status": "pending",
            "_status": "awaiting_payment",
            "_step": "verify_result",
            "_progress": 90,
        })
        database.update_order(
            int(order["id"]),
            error_code="subscription_pending",
            error_message="支付或绑卡终态已返回，正在核验 Plus",
            payment_terminal_status="succeeded",
        )

        migrated = Database(database_path).get_order_by_id(int(order["id"]))
        self.assertIsNone(migrated["payment_terminal_status"])
        self.assertEqual(migrated["error_code"], "payment_confirmation_required")
        self.assertEqual(migrated["step"], "confirm_payment")
        self.assertEqual(migrated["payment_action_type"], "payment_confirmation")

    def test_database_keeps_subscription_pending_with_real_intent_evidence(self) -> None:
        database_path = Path(self.temp_dir.name) / "real-payment-evidence.db"
        database = Database(database_path)
        order = database.create_order({
            "order_key": "XY-REALTERMINAL",
            "api_key_hash": "c" * 64,
            "api_key_prefix": "xy_tes...",
            "plan_type": "plus",
            "plan_name": "Plus",
            "amount_minor": 2000,
            "currency": "PHP",
            "email": "fixture@example.test",
            "account_ref": "account-ref",
            "session_fingerprint": "session-fingerprint",
            "provider": "platform_checkout",
            "provider_ref": "oaics_real_terminal",
            "checkout_provider": "oaics",
            "processor_entity": "vendor_ie",
            "payment_contract": "oaics_confirmation_token",
            "payment_fixture": "platform_checkout_stripe_elements",
            "payment_last4": "4242",
            "renewal_cancel_requested": 1,
            "renewal_cancel_status": "pending",
            "_status": "awaiting_payment",
            "_step": "verify_result",
            "_progress": 90,
        })
        database.update_order(
            int(order["id"]),
            error_code="subscription_pending",
            error_message="支付终态已确认，Plus 仍在同步",
            confirmation_ref="pi_real_terminal",
            intent_type="payment_intent",
            payment_terminal_status="succeeded",
        )

        migrated = Database(database_path).get_order_by_id(int(order["id"]))
        self.assertEqual(migrated["payment_terminal_status"], "succeeded")
        self.assertEqual(migrated["error_code"], "subscription_pending")
        self.assertEqual(migrated["step"], "verify_result")

    def test_database_repairs_unproven_subscription_recovery_exhaustion(self) -> None:
        database_path = Path(self.temp_dir.name) / "false-subscription-exhaustion.db"
        database = Database(database_path)
        order = database.create_order({
            "order_key": "XY-FALSEEXHAUSTED",
            "api_key_hash": "d" * 64,
            "api_key_prefix": "xy_tes...",
            "plan_type": "plus",
            "plan_name": "Plus",
            "amount_minor": -1,
            "currency": "PHP",
            "email": "fixture@example.test",
            "account_ref": "account-ref",
            "session_fingerprint": "session-fingerprint",
            "provider": "platform_checkout",
            "provider_ref": "oaics_false_exhausted",
            "checkout_provider": "oaics",
            "processor_entity": "vendor_ie",
            "payment_contract": "oaics_confirmation_token",
            "payment_fixture": "platform_checkout_stripe_elements",
            "payment_last4": "4242",
            "payment_action_url": "https://platform.example.com/checkout/vendor_ie/oaics_false_exhausted",
            "renewal_cancel_requested": 1,
            "renewal_cancel_status": "pending",
            "_status": "awaiting_payment",
            "_step": "verify_result",
            "_progress": 90,
        })
        database.update_order(
            int(order["id"]),
            error_code="subscription_recovery_exhausted",
            error_message="已自动完成多次 Checkout/Plus 核验，订阅仍未同步",
            payment_terminal_status="succeeded",
            recovery_attempts=12,
        )

        migrated = Database(database_path).get_order_by_id(int(order["id"]))
        self.assertIsNone(migrated["payment_terminal_status"])
        self.assertEqual(migrated["error_code"], "payment_recovery_exhausted")
        self.assertEqual(migrated["step"], "confirm_payment")
        self.assertEqual(migrated["progress"], 70)
        self.assertEqual(migrated["payment_action_type"], "payment_confirmation")

    def test_checkout_without_succeeded_payment_terminal_is_never_marked_success(self) -> None:
        service = OrderService(
            Path(self.temp_dir.name) / "platform-no-poll.db",
            Path(__file__).parents[1],
            platform_checkout=MissingTerminalCheckoutAdapter(),
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "no-poll-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "no poll key")
            with self.assertRaises(ServiceError) as raised:
                service.charge_platform_checkout_order({
                    "apiKey": key_result["key"],
                    "session": SESSION,
                    "planType": "plus",
                    "paymentMode": "stripe_elements",
                    "paymentMethodId": "pm_fixture",
                    "cardLast4": "4242",
                    "checkout": {
                        "checkoutId": "oaics_no_poll",
                        "paymentPageId": "cs_test_no_poll",
                        "processorEntity": "vendor_ie",
                        "publishableKey": "pk_test_fixture",
                        "currency": "PHP",
                        "amountMinor": 2000,
                    },
                    "billing": {
                        "name": "Fixture User", "email": "fixture@example.test",
                        "line1": "100 Market Street", "city": "San Francisco",
                        "state": "CA", "postal_code": "94105", "country": "US",
                    },
                })
            self.assertEqual(raised.exception.code, "checkout_verification_failed")
            self.assertEqual(raised.exception.details["order"]["status"], "failed")
        finally:
            service.close()

    def test_sync_terminal_failed_poll_marks_order_failed(self) -> None:
        service = OrderService(
            Path(self.temp_dir.name) / "platform-failed-poll.db",
            Path(__file__).parents[1],
            platform_checkout=FailedPollSyncAdapter(),
            require_managed_keys=True,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "failed-poll-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "failed poll key")
            charged = service.charge_platform_checkout_order({
                "apiKey": key_result["key"], "session": SESSION, "planType": "plus",
                "paymentMode": "stripe_elements", "paymentMethodId": "pm_fixture", "cardLast4": "3220",
                "checkout": {
                    "checkoutId": "oaics_failed_poll", "paymentPageId": "cs_test_failed_poll",
                    "checkoutUrl": "https://platform.example.com/checkout/vendor_ie/oaics_failed_poll",
                    "processorEntity": "vendor_ie", "publishableKey": "pk_test_fixture",
                    "currency": "PHP", "amountMinor": 2000,
                },
                "billing": {
                    "name": "Fixture User", "email": "fixture@example.test",
                    "line1": "100 Market Street", "city": "San Francisco",
                    "state": "CA", "postal_code": "94105", "country": "US",
                },
            })
            self.assertEqual(charged["order"]["status"], "awaiting_payment")
            synced = service.sync_stripe_order({
                "apiKey": key_result["key"], "orderKey": charged["order"]["orderKey"]
            })
            self.assertEqual(synced["status"], "failed")
            self.assertEqual(synced["errorCode"], "payment_page_failed")
            self.assertEqual(synced["renewal"]["status"], "not_required")
        finally:
            service.close()

    def test_us_billing_fields_and_tax_region_payload(self) -> None:
        adapter = PlatformCheckoutAdapter(
            Path(__file__).parents[1],
            country="PH",
            currency="PHP",
            billing_country="US",
        )
        billing = adapter.normalize_billing(
            {
                "name": "Fixture User",
                "email": "fixture@example.test",
                "line1": "100 Market Street",
                "city": "San Francisco",
                "state": "CA",
                "postal_code": "94105",
                "line2": "ignored",
                "phone": "ignored",
            }
        )
        self.assertEqual(
            set(billing),
            {"name", "email", "line1", "city", "state", "postal_code", "country"},
        )
        self.assertEqual(billing["country"], "US")
        with self.assertRaisesRegex(RuntimeError, "US"):
            adapter.normalize_billing({**billing, "country": "PH"})
        module = adapter._load()
        config = module.CardPaymentConfig(
            token="fixture",
            country="PH",
            currency="PHP",
            billing=billing,
        )
        payload = module._checkout_tax_payload(
            config,
            "oaics_fixture123",
            "vendor_ie",
        )
        self.assertEqual(payload["billing_country"], "US")
        self.assertEqual(payload["billing_currency"], "PHP")
        self.assertEqual(
            payload["tax_region"],
            {
                "line1": "100 Market Street",
                "city": "San Francisco",
                "state": "CA",
                "postal_code": "94105",
                "country": "US",
            },
        )
        self.assertEqual(payload["billing_details"]["email"], "fixture@example.test")

    def test_platform_checkout_rejects_mixed_card_inputs(self) -> None:
        adapter = FakePlatformCheckoutAdapter()
        service = OrderService(
            Path(self.temp_dir.name) / "platform-mixed-card.db",
            Path(__file__).parents[1],
            platform_checkout=adapter,
            require_managed_keys=False,
            renewal_adapter=FakeRenewalAdapter(),
        )
        try:
            setup = service.setup_admin({"username": "mixed-card-admin", "password": "long-test-password"})
            key_result = service.create_managed_key(setup["token"], "mixed card key")
            with self.assertRaises(ServiceError) as raised:
                service.charge_platform_checkout_order(
                    {
                        "apiKey": key_result["key"],
                        "session": SESSION,
                        "planType": "plus",
                        "paymentMode": "stripe_elements",
                        "paymentMethodId": "pm_fixture",
                        "card": {"number": "4242424242424242"},
                    }
                )
            self.assertEqual(raised.exception.code, "ambiguous_payment_input")
        finally:
            service.close()


if __name__ == "__main__":
    unittest.main()
