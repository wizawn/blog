import fs from 'node:fs';
import path from 'node:path';

const outputPath = process.argv[2] || 'fixtures/sandbox_us_tax_free_billing_profiles.json';
const states = ['AK', 'DE', 'MT', 'NH', 'OR'];
const profilesPerState = 40;

const pages = await fetch('http://127.0.0.1:9223/json/list').then((response) => response.json());
const page = pages.find((item) => item.type === 'page');
if (!page) throw new Error('Chrome DevTools page target not found');

const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => {
  socket.addEventListener('open', resolve, { once: true });
  socket.addEventListener('error', reject, { once: true });
});

let sequence = 0;
const pending = new Map();
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (!message.id || !pending.has(message.id)) return;
  const pair = pending.get(message.id);
  pending.delete(message.id);
  if (message.error) pair.reject(new Error(message.error.message));
  else pair.resolve(message.result || {});
});

function command(method, params = {}) {
  const id = ++sequence;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
}

async function evaluate(expression, awaitPromise = true) {
  const result = await command('Runtime.evaluate', {
    expression,
    awaitPromise,
    returnByValue: true,
  });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text || 'Evaluation failed');
  return result.result?.value;
}

await command('Page.enable');
await command('Runtime.enable');
const ready = await evaluate(`new Promise((resolve) => {
  const isReady = () => document.querySelector('#generate-address-btn') && document.readyState === 'complete';
  if (isReady()) return resolve(true);
  const timer = setInterval(() => { if (isReady()) { clearInterval(timer); resolve(true); } }, 100);
  setTimeout(() => { clearInterval(timer); resolve(false); }, 15000);
})`);
if (!ready) throw new Error('Address generator page did not become ready');

const profiles = [];
for (const stateCode of states) {
  const stateProfiles = await evaluate(`(async () => {
    const stateCode = ${JSON.stringify(stateCode)};
    const count = ${profilesPerState};
    const select = document.querySelector('#state-select');
    const button = document.querySelector('#generate-address-btn');
    const resultNode = document.querySelector('#address-result');
    select.value = stateCode;
    select.dispatchEvent(new Event('change', { bubbles: true }));

    const output = [];
    let attempts = 0;
    while (output.length < count && attempts < count * 4) {
      attempts += 1;
      const before = resultNode.innerHTML;
      button.click();
      const started = Date.now();
      let changed = false;
      while (Date.now() - started < 30000) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        if (!button.disabled && resultNode.innerHTML !== before && resultNode.querySelector('.address-card')) {
          changed = true;
          break;
        }
      }
      if (!changed) continue;

      const fields = {};
      resultNode.querySelectorAll('.address-card').forEach((card) => {
        const label = card.querySelector('label')?.textContent?.trim() || '';
        const key = label.includes('/') ? label.split('/').at(-1).trim() : label;
        const value = card.dataset.copy
          || card.querySelector('.address-card-value')?.textContent?.trim()
          || '';
        fields[key] = value;
      });
      const required = ['Last Name', 'First Name', 'Street Address', 'City', 'State', 'ZIP Code'];
      if (required.some((key) => !fields[key])) continue;

      output.push({
        name: fields['First Name'] + ' ' + fields['Last Name'],
        line1: fields['Street Address'],
        city: fields.City,
        state: fields.State,
        postal_code: fields['ZIP Code'],
        country: 'US',
      });
    }
    if (output.length !== count) throw new Error('Only generated ' + output.length + ' profiles for ' + stateCode);
    return output;
  })()`);

  stateProfiles.forEach((profile, index) => {
    profiles.push({
      id: `address_api-${stateCode.toLowerCase()}-${String(index + 1).padStart(3, '0')}`,
      ...profile,
    });
  });
  process.stderr.write(`${stateCode}: ${stateProfiles.length}\n`);
}

const generatedAt = new Date().toISOString();
const payload = {
  schema_version: 1,
  usage: 'sandbox_only',
  source_url: 'https://address-api.example.com/tax-free-address/',
  generated_at: generatedAt,
  count: profiles.length,
  states: Object.fromEntries(states.map((state) => [state, profiles.filter((item) => item.state === state).length])),
  profiles,
};

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
process.stdout.write(`${outputPath}\n`);
socket.close();
