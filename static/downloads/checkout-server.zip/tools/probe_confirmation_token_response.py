#!/usr/bin/env python3
"""Inspect Stripe ConfirmationToken response shape without persisting card data.

This is a temporary diagnostic for a Stripe test-mode integration.  It first
registers a Stripe browser-device tuple through m.stripe.com/6, then posts the
same tuple with card data to /v1/confirmation_tokens.  Output is deliberately
limited to response structure and masked Stripe identifiers.
"""

from __future__ import annotations

import argparse
import base64
import getpass
import json
import os
import re
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlsplit

from curl_cffi import requests


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT / "data" / "checkout-server.db"
STRIPE_VERSION = "2025-04-30.basil"
STRIPE_JS_RUNTIME = "stripe.js/572ee5cc22; stripe-js-v3/572ee5cc22"


def load_stripe_proxy(db_path: Path) -> str:
    if not db_path.exists():
        return ""
    with sqlite3.connect(db_path) as connection:
        row = connection.execute(
            "SELECT proxies FROM proxy_configurations WHERE role='stripe'"
        ).fetchone()
    if not row:
        return ""
    return next(
        (
            line.strip()
            for line in str(row[0] or "").replace("\r", "\n").split("\n")
            if line.strip()
        ),
        "",
    )


def mask_proxy(value: str) -> str:
    parsed = urlsplit(value)
    if not parsed.hostname:
        return "direct"
    return f"{parsed.scheme}://***@{parsed.hostname}:{parsed.port or ''}"


def mask_identifier(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if len(text) <= 13:
        return f"{text[:4]}…"
    return f"{text[:8]}…{text[-4:]}"


def safe_error(value: Exception, proxy: str) -> str:
    text = str(value)
    if proxy:
        text = text.replace(proxy, mask_proxy(proxy))
    return " ".join(text.split())[:500]


def m6_body() -> str:
    marker = uuid.uuid4().hex
    now_ms = int(time.time() * 1000)
    payload = {
        "v2": 1,
        "id": marker,
        "t": 1,
        "tag": "$npm_package_version",
        "src": "js",
        "a": {
            "c": {"v": "en-US", "t": 0},
            "d": {"v": "Win32", "t": 0},
            "f": {"v": "1920w_1030h_24d_1r", "t": 0},
            "g": {"v": "8", "t": 0},
            "l": {
                "v": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 Chrome/146.0.0.0 Safari/537.36"
                ),
                "t": 0,
            },
        },
        "b": {
            "d": "NA",
            "e": "NA",
            "f": False,
            "g": True,
            "h": True,
            "u": "platform.example.com",
            "w": f"{now_ms}:{os.urandom(16).hex()}",
        },
        "h": os.urandom(10).hex(),
    }
    compact = json.dumps(payload, separators=(",", ":"))
    return base64.b64encode(quote(compact, safe="").encode()).decode()


def register_device(
    session: requests.Session, proxy: str, timeout: int
) -> tuple[dict[str, str], dict[str, Any]]:
    response = session.post(
        "https://m.stripe.com/6",
        data=m6_body(),
        headers={
            "Accept": "*/*",
            "Content-Type": "text/plain;charset=UTF-8",
            "Origin": "https://m.stripe.network",
            "Referer": "https://m.stripe.network/",
        },
        proxies={"http": proxy, "https": proxy} if proxy else None,
        timeout=timeout,
    )
    try:
        payload = response.json()
    except Exception:
        payload = {}
    identifiers = {
        key: str(payload.get(key) or "").strip()
        for key in ("guid", "muid", "sid")
    }
    meta = {
        "httpStatus": int(response.status_code),
        "jsonKeys": sorted(payload.keys()) if isinstance(payload, dict) else [],
        "identifiers": {
            key: mask_identifier(value)
            for key, value in identifiers.items()
            if value
        },
    }
    if response.status_code >= 400 or not all(identifiers.values()):
        raise RuntimeError(
            "Stripe device registration did not return guid/muid/sid: "
            + json.dumps(meta, ensure_ascii=False)
        )
    return identifiers, meta


def find_identifiers(value: Any, prefix: str) -> list[str]:
    found: list[str] = []

    def walk(item: Any) -> None:
        if isinstance(item, dict):
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
        elif isinstance(item, str):
            for match in re.findall(rf"\b{re.escape(prefix)}[A-Za-z0-9_]+", item):
                if match not in found:
                    found.append(match)

    walk(value)
    return found


def response_report(response: Any) -> dict[str, Any]:
    try:
        payload = response.json()
    except Exception:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    error = payload.get("error") if isinstance(payload.get("error"), dict) else {}
    preview = payload.get("payment_method_preview")
    top_level_pm = payload.get("payment_method")
    recursive_pm = find_identifiers(payload, "pm_")
    recursive_ctoken = find_identifiers(payload, "ctoken_")
    return {
        "httpStatus": int(response.status_code),
        "jsonKeys": sorted(payload.keys()),
        "confirmationToken": mask_identifier(payload.get("id")),
        "confirmationTokenPresent": bool(
            str(payload.get("id") or "").startswith("ctoken_") or recursive_ctoken
        ),
        "topLevelPaymentMethod": mask_identifier(top_level_pm),
        "topLevelPaymentMethodPresent": bool(
            isinstance(top_level_pm, str) and top_level_pm.startswith("pm_")
        ),
        "recursivePaymentMethods": [mask_identifier(value) for value in recursive_pm],
        "paymentMethodPreviewKeys": (
            sorted(preview.keys()) if isinstance(preview, dict) else []
        ),
        "status": str(payload.get("status") or ""),
        "error": {
            "type": str(error.get("type") or ""),
            "code": str(error.get("code") or ""),
            "message": " ".join(str(error.get("message") or "").split())[:500],
            "param": str(error.get("param") or ""),
        }
        if error
        else {},
        "conclusion": (
            "ConfirmationToken response contains a durable pm_ identifier."
            if recursive_pm
            else "No pm_ identifier was returned; inspect payment_method_preview and "
            "consume ctoken_ during Intent confirmation to obtain the resulting PaymentMethod."
        ),
    }


def resolve_secret(cli_value: str, env_name: str, prompt: str) -> str:
    value = str(cli_value or os.getenv(env_name, "")).strip()
    if value:
        return value
    if not sys.stdin.isatty():
        return ""
    return getpass.getpass(prompt).strip()


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Probe Stripe test-mode ConfirmationToken response structure"
    )
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--proxy", default="")
    parser.add_argument("--direct", action="store_true")
    parser.add_argument("--timeout", type=int, default=20)
    parser.add_argument("--key", default="", help="or STRIPE_PUBLISHABLE_KEY")
    parser.add_argument("--card-number", default="", help="or CARD_NUMBER")
    parser.add_argument("--exp-month", default=os.getenv("EXP_MONTH", "12"))
    parser.add_argument("--exp-year", default=os.getenv("EXP_YEAR", "2030"))
    parser.add_argument("--cvc", default="", help="or CVC")
    parser.add_argument("--name", default=os.getenv("CARDHOLDER_NAME", "Card Holder"))
    parser.add_argument("--country", default=os.getenv("BILLING_COUNTRY", "US"))
    parser.add_argument("--city", default=os.getenv("BILLING_CITY", "Dover"))
    parser.add_argument(
        "--line1", default=os.getenv("BILLING_LINE1", "290 Washington Street")
    )
    parser.add_argument("--postal-code", default=os.getenv("BILLING_POSTAL_CODE", "19906"))
    parser.add_argument("--state", default=os.getenv("BILLING_STATE", "DE"))
    parser.add_argument(
        "--execute",
        action="store_true",
        help="send the test-mode request; without this flag only configuration is checked",
    )
    args = parser.parse_args()

    key = resolve_secret(args.key, "STRIPE_PUBLISHABLE_KEY", "Stripe pk_test_ key: ")
    card_number = resolve_secret(args.card_number, "CARD_NUMBER", "Test card number: ")
    cvc = resolve_secret(args.cvc, "CVC", "Test card CVC: ")
    proxy = "" if args.direct else str(args.proxy or load_stripe_proxy(args.db))
    timeout = max(3, min(60, int(args.timeout)))

    if not key.startswith("pk_test_"):
        print(
            json.dumps(
                {
                    "executed": False,
                    "error": "A Stripe pk_test_ publishable key is required.",
                    "proxy": mask_proxy(proxy),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2
    if not re.fullmatch(r"\d{12,19}", card_number):
        print(json.dumps({"executed": False, "error": "Invalid test card number."}, indent=2))
        return 2
    if not re.fullmatch(r"\d{3,4}", cvc):
        print(json.dumps({"executed": False, "error": "Invalid test card CVC."}, indent=2))
        return 2
    if not args.execute:
        print(
            json.dumps(
                {
                    "executed": False,
                    "ready": True,
                    "mode": "test",
                    "proxy": mask_proxy(proxy),
                    "stripeVersion": STRIPE_VERSION,
                    "note": "Add --execute to register the device and send the request.",
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    session = requests.Session(impersonate="chrome146")
    try:
        identifiers, registration = register_device(session, proxy, timeout)
        body = {
            "key": key,
            "_stripe_version": STRIPE_VERSION,
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": card_number,
            "payment_method_data[card][exp_month]": str(args.exp_month),
            "payment_method_data[card][exp_year]": str(args.exp_year),
            "payment_method_data[card][cvc]": cvc,
            "payment_method_data[billing_details][name]": str(args.name),
            "payment_method_data[billing_details][address][country]": str(args.country).upper(),
            "payment_method_data[billing_details][address][city]": str(args.city),
            "payment_method_data[billing_details][address][line1]": str(args.line1),
            "payment_method_data[billing_details][address][postal_code]": str(args.postal_code),
            "payment_method_data[billing_details][address][state]": str(args.state),
            "payment_method_data[allow_redisplay]": "limited",
            "payment_method_data[pasted_fields]": "number",
            "payment_method_data[payment_user_agent]": STRIPE_JS_RUNTIME,
            "payment_method_data[time_on_page]": "35000",
            "payment_method_data[guid]": identifiers["guid"],
            "payment_method_data[muid]": identifiers["muid"],
            "payment_method_data[sid]": identifiers["sid"],
        }
        response = session.post(
            "https://api.stripe.com/v1/confirmation_tokens",
            data=body,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "https://js.stripe.com",
                "Referer": "https://js.stripe.com/",
            },
            proxies={"http": proxy, "https": proxy} if proxy else None,
            timeout=timeout,
        )
        print(
            json.dumps(
                {
                    "executed": True,
                    "mode": "test",
                    "proxy": mask_proxy(proxy),
                    "deviceRegistration": registration,
                    "confirmationTokenResponse": response_report(response),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0 if int(response.status_code) < 400 else 1
    except Exception as exc:
        print(
            json.dumps(
                {
                    "executed": True,
                    "mode": "test",
                    "proxy": mask_proxy(proxy),
                    "transportError": safe_error(exc, proxy),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    raise SystemExit(main())
