#!/usr/bin/env python3
"""Compare Stripe's device-registration and telemetry collection endpoints.

The probe sends no card, Checkout, customer, account, or authentication data.
It reports only HTTP metadata and whether a response contains guid/muid/sid.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import re
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlsplit

from curl_cffi import requests


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = ROOT / "data" / "checkout-server.db"


def load_stripe_proxy(db_path: Path) -> str:
    if not db_path.exists():
        return ""
    with sqlite3.connect(db_path) as connection:
        row = connection.execute(
            "SELECT proxies FROM proxy_configurations WHERE role='stripe'"
        ).fetchone()
    if not row:
        return ""
    return next(
        (
            line.strip()
            for line in str(row[0] or "").replace("\r", "\n").split("\n")
            if line.strip()
        ),
        "",
    )


def mask_proxy(value: str) -> str:
    parsed = urlsplit(value)
    if not parsed.hostname:
        return "direct"
    return f"{parsed.scheme}://***@{parsed.hostname}:{parsed.port or ''}"


def mask_identifier(value: Any) -> str:
    text = str(value or "").strip()
    if len(text) <= 12:
        return "present" if text else ""
    return f"{text[:6]}…{text[-4:]}"


def safe_error(value: Exception, proxy: str) -> str:
    text = str(value)
    if proxy:
        text = text.replace(proxy, mask_proxy(proxy))
    return " ".join(text.split())[:300]


def m6_body() -> str:
    marker = uuid.uuid4().hex
    now_ms = int(time.time() * 1000)
    payload = {
        "v2": 1,
        "id": marker,
        "t": 1,
        "tag": "$npm_package_version",
        "src": "js",
        "a": {
            "c": {"v": "en-US", "t": 0},
            "d": {"v": "Win32", "t": 0},
            "f": {"v": "1920w_1030h_24d_1r", "t": 0},
            "g": {"v": "8", "t": 0},
            "l": {
                "v": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 Chrome/146.0.0.0 Safari/537.36"
                ),
                "t": 0,
            },
        },
        "b": {
            "d": "NA",
            "e": "NA",
            "f": False,
            "g": True,
            "h": True,
            "u": "platform.example.com",
            "w": f"{now_ms}:{os.urandom(16).hex()}",
        },
        "h": os.urandom(10).hex(),
    }
    compact = json.dumps(payload, separators=(",", ":"))
    return base64.b64encode(quote(compact, safe="").encode()).decode()


def r_b_body() -> str:
    payload = {
        "event": "xy.endpoint.probe",
        "created": int(time.time() * 1000),
        "session_id": str(uuid.uuid4()),
    }
    return base64.b64encode(
        json.dumps(payload, separators=(",", ":")).encode()
    ).decode()


def probe(
    session: requests.Session,
    *,
    name: str,
    url: str,
    body: str,
    headers: dict[str, str],
    proxy: str,
    timeout: int,
) -> dict[str, Any]:
    started = time.perf_counter()
    try:
        response = session.post(
            url,
            data=body,
            headers=headers,
            proxies={"http": proxy, "https": proxy} if proxy else None,
            timeout=timeout,
        )
        elapsed_ms = round((time.perf_counter() - started) * 1000)
        text = str(response.text or "")
        try:
            payload = response.json()
        except Exception:
            payload = None
        keys = sorted(str(key) for key in payload) if isinstance(payload, dict) else []
        identifiers = {
            key: mask_identifier(payload.get(key))
            for key in ("guid", "muid", "sid")
            if isinstance(payload, dict) and payload.get(key)
        }
        preview = " ".join(text.split())[:180]
        if isinstance(payload, dict):
            for key in ("guid", "muid", "sid"):
                raw_identifier = str(payload.get(key) or "")
                if raw_identifier:
                    preview = preview.replace(
                        raw_identifier, mask_identifier(raw_identifier)
                    )
        cookie_header = str(response.headers.get("set-cookie") or "")
        cookie_names = sorted(
            set(re.findall(r"(?:^|,\s*)([!#$%&'*+.^_`|~0-9A-Za-z-]+)=", cookie_header))
        )
        return {
            "name": name,
            "url": url,
            "status": int(response.status_code),
            "latencyMs": elapsed_ms,
            "contentType": str(response.headers.get("content-type") or ""),
            "responseBytes": len(response.content or b""),
            "json": isinstance(payload, dict),
            "jsonKeys": keys,
            "identifiers": identifiers,
            "setCookie": bool(cookie_header),
            "cookieNames": cookie_names,
            "bodyPreview": preview,
        }
    except Exception as exc:
        return {
            "name": name,
            "url": url,
            "status": 0,
            "latencyMs": round((time.perf_counter() - started) * 1000),
            "error": safe_error(exc, proxy),
        }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--proxy", default="")
    parser.add_argument("--direct", action="store_true")
    parser.add_argument("--timeout", type=int, default=15)
    args = parser.parse_args()

    proxy = "" if args.direct else str(args.proxy or load_stripe_proxy(args.db))
    timeout = max(3, min(30, int(args.timeout)))
    session = requests.Session(impersonate="chrome146")
    try:
        results = [
            probe(
                session,
                name="device_registration",
                url="https://m.stripe.com/6",
                body=m6_body(),
                headers={
                    "Accept": "*/*",
                    "Content-Type": "text/plain;charset=UTF-8",
                    "Origin": "https://m.stripe.network",
                    "Referer": "https://m.stripe.network/",
                },
                proxy=proxy,
                timeout=timeout,
            ),
            probe(
                session,
                name="telemetry_collection",
                url="https://r.stripe.com/b",
                body=r_b_body(),
                headers={
                    "Accept": "*/*",
                    "Content-Type": "text/plain;charset=UTF-8",
                    "Origin": "https://js.stripe.com",
                    "Referer": "https://js.stripe.com/",
                },
                proxy=proxy,
                timeout=timeout,
            ),
        ]
    finally:
        session.close()

    registration = results[0]
    telemetry = results[1]
    conclusion = {
        "fingerprintEndpoint": (
            "https://m.stripe.com/6"
            if registration.get("identifiers")
            else "not confirmed by this response"
        ),
        "telemetryEndpoint": "https://r.stripe.com/b",
        "note": (
            "r.stripe.com/b is an event collector; it is not expected to "
            "return guid/muid/sid"
        ),
    }
    print(
        json.dumps(
            {
                "proxy": mask_proxy(proxy),
                "timeoutSeconds": timeout,
                "results": results,
                "conclusion": conclusion,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
