#!/usr/bin/env python3
"""Standalone test-mode fixture: create a local Checkout link and obtain a PM.

The fixture never creates a Platform production Checkout.  It uses a caller's
Stripe test publishable key, Stripe's standard test card, and the same XY Raw
then Stripe.js decision logic so response shape and fallback behavior can be
observed without placing an order.
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urlsplit


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.stripe_browser import (  # noqa: E402
    StripeBrowserError,
    create_payment_method_with_stripe_js,
)
from backend.vendor import card_payment  # noqa: E402

try:  # noqa: E402
    from curl_cffi import requests as curl_requests
except Exception as exc:  # pragma: no cover
    raise SystemExit(f"curl_cffi is required: {exc}")


DEFAULT_DB = ROOT / "data" / "checkout-server.db"
TEST_CARD = {
    "number": "4242424242424242",
    "exp_month": "12",
    "exp_year": "2030",
    "cvc": "123",
}
TEST_BILLING = {
    "name": "Fixture User",
    "email": "fixture@example.test",
    "country": "US",
    "line1": "1 Fixture Street",
    "city": "Dover",
    "state": "DE",
    "postal_code": "19901",
}


def load_stripe_proxy(db_path: Path) -> str:
    if not db_path.exists():
        return ""
    with sqlite3.connect(db_path) as connection:
        row = connection.execute(
            "SELECT proxies FROM proxy_configurations WHERE role='stripe'"
        ).fetchone()
    if not row:
        return ""
    return next(
        (
            line.strip()
            for line in str(row[0] or "").replace("\r", "\n").split("\n")
            if line.strip()
        ),
        "",
    )


def mask_proxy(value: str) -> str:
    parsed = urlsplit(value)
    if not parsed.hostname:
        return "direct"
    return f"{parsed.scheme}://***@{parsed.hostname}:{parsed.port or ''}"


def mask_identifier(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if len(text) <= 13:
        return f"{text[:4]}…"
    return f"{text[:8]}…{text[-4:]}"


def fixture_checkout(key: str, amount: int, currency: str) -> dict[str, Any]:
    checkout_id = f"oaics_test_{uuid.uuid4().hex}"
    query = urlencode(
        {
            "checkout_id": checkout_id,
            "amount": int(amount),
            "currency": currency.upper(),
            "mode": "fixture",
        }
    )
    return {
        "id": checkout_id,
        "url": f"http://127.0.0.1:5602/checkout-fixture?{query}",
        "processor_entity": "fixture",
        "publishable_key": key,
        "amount_minor": int(amount),
        "currency": currency.upper(),
    }


def add_event(events: list[dict[str, Any]], started: float, stage: str, **data: Any) -> None:
    events.append(
        {
            "stage": stage,
            "elapsedMs": round((time.perf_counter() - started) * 1000),
            **data,
        }
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Create a local Checkout fixture and test ctoken_/pm_ creation"
    )
    parser.add_argument("--key", default="", help="Stripe pk_test_ publishable key")
    parser.add_argument("--mode", choices=("dual", "raw", "browser"), default="dual")
    parser.add_argument("--amount", type=int, default=2000)
    parser.add_argument("--currency", default="USD")
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--proxy", default="")
    parser.add_argument("--direct", action="store_true")
    parser.add_argument("--timeout", type=int, default=60)
    parser.add_argument(
        "--runner-url",
        default="http://127.0.0.1:5602/static/stripe-runner.html",
    )
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    key = str(args.key or "").strip()
    mode = str(args.mode)
    currency = str(args.currency or "USD").strip().upper()
    amount = max(50, min(100_000_000, int(args.amount)))
    timeout = max(30, min(180, int(args.timeout)))
    proxy = "" if args.direct else str(args.proxy or load_stripe_proxy(args.db))

    if not key.startswith("pk_test_"):
        print(
            json.dumps(
                {
                    "executed": False,
                    "error": "A Stripe pk_test_ publishable key is required.",
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 2

    checkout = fixture_checkout(key, amount, currency)
    if not args.execute:
        print(
            json.dumps(
                {
                    "executed": False,
                    "ready": True,
                    "mode": mode,
                    "checkout": {
                        "id": mask_identifier(checkout["id"]),
                        "url": checkout["url"],
                        "amountMinor": amount,
                        "currency": currency,
                    },
                    "proxy": mask_proxy(proxy),
                    "testCard": "4242********4242",
                    "note": "Add --execute to run the Stripe test-mode fixture.",
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    started = time.perf_counter()
    events: list[dict[str, Any]] = []
    add_event(
        events,
        started,
        "checkout_created",
        checkoutId=mask_identifier(checkout["id"]),
        checkoutUrl=checkout["url"],
        amountMinor=amount,
        currency=currency,
    )

    config = card_payment.CardPaymentConfig(
        token="fixture",
        checkout_id=checkout["id"],
        processor_entity=checkout["processor_entity"],
        publishable_key=key,
        currency=currency,
        expected_amount=amount,
        card=dict(TEST_CARD),
        billing=dict(TEST_BILLING),
        confirmation_token_mode=mode,
        stripe_proxy=proxy,
        timeout=timeout,
        stripe_device_registration_enabled=True,
    )
    session = curl_requests.Session(impersonate="chrome146")
    if proxy:
        session.proxies = {"http": proxy, "https": proxy}

    confirmation_token = ""
    payment_method = ""
    raw_error = ""
    try:
        if mode in {"dual", "raw"}:
            logs: list[str] = []
            device = card_payment._ensure_stripe_device_context(
                session, config, key, logs.append
            )
            add_event(
                events,
                started,
                "device_registered",
                source=device.source,
                registered=device.registered,
                cookiePresent=device.cookie_present,
            )

            config.stripe_client_session_id = str(uuid.uuid4())
            try:
                elements = card_payment._create_elements_session(
                    session,
                    config,
                    {
                        "elements_options": {
                            "amount": amount,
                            "currency": currency.lower(),
                            "payment_method_types": ["card"],
                        }
                    },
                    checkout["id"],
                    key,
                    config.stripe_client_session_id,
                    device,
                )
                config.stripe_elements_session_id = card_payment._find_key(
                    elements, ("session_id", "sessionId", "id")
                ) or card_payment._find_identifier(elements, ("elements_session_",))
                config.stripe_elements_session_config_id = card_payment._find_key(
                    elements, ("config_id", "configId")
                )
                add_event(
                    events,
                    started,
                    "elements_session",
                    ok=True,
                    sessionPresent=bool(config.stripe_elements_session_id),
                    tupleSource=device.source,
                )
            except Exception as exc:
                add_event(
                    events,
                    started,
                    "elements_session",
                    ok=False,
                    error=card_payment._safe_error(exc),
                )

            try:
                confirmation_token, payment_method, _payload = (
                    card_payment._create_confirmation_token_from_card(
                        session,
                        config,
                        key,
                        checkout["id"],
                        device,
                    )
                )
                add_event(
                    events,
                    started,
                    "raw_confirmation_token",
                    ok=True,
                    confirmationToken=mask_identifier(confirmation_token),
                    paymentMethod=mask_identifier(payment_method),
                    paymentMethodPresent=bool(payment_method),
                )
            except Exception as exc:
                raw_error = card_payment._safe_error(exc)
                add_event(
                    events,
                    started,
                    "raw_confirmation_token",
                    ok=False,
                    error=raw_error,
                )
                if mode == "raw":
                    print(
                        json.dumps(
                            {
                                "executed": True,
                                "ok": False,
                                "mode": mode,
                                "proxy": mask_proxy(proxy),
                                "events": events,
                            },
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                    return 1

        if mode == "browser" or (mode == "dual" and not payment_method):
            reason = "mode_browser" if mode == "browser" else (
                "raw_no_pm" if confirmation_token else "raw_failed"
            )
            add_event(events, started, "stripe_js_fallback", reason=reason)
            browser_result = create_payment_method_with_stripe_js(
                publishable_key=key,
                card=dict(TEST_CARD),
                billing=dict(TEST_BILLING),
                proxy=proxy,
                runner_url=str(args.runner_url),
                timeout=timeout,
            )
            payment_method = str(browser_result.get("id") or "").strip()
            add_event(
                events,
                started,
                "payment_method_created",
                strategy="stripe_js",
                paymentMethod=mask_identifier(payment_method),
                present=payment_method.startswith("pm_"),
            )
    except StripeBrowserError as exc:
        add_event(
            events,
            started,
            "payment_method_created",
            strategy="stripe_js",
            present=False,
            error=card_payment._safe_error(exc),
        )
    finally:
        session.close()

    ok = payment_method.startswith("pm_")
    print(
        json.dumps(
            {
                "executed": True,
                "ok": ok,
                "mode": mode,
                "proxy": mask_proxy(proxy),
                "checkout": {
                    "id": mask_identifier(checkout["id"]),
                    "url": checkout["url"],
                    "amountMinor": amount,
                    "currency": currency,
                },
                "result": {
                    "confirmationToken": mask_identifier(confirmation_token),
                    "paymentMethod": mask_identifier(payment_method),
                    "paymentMethodPresent": ok,
                    "rawError": raw_error,
                },
                "events": events,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
