#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import sqlite3
import sys
import uuid
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from backend.platform_checkout import PlatformCheckoutAdapter  # noqa: E402
from backend.proxy_pool import ProxyPool  # noqa: E402


REGION_CURRENCIES = {
    "US": "USD",
    "PH": "PHP",
    "CA": "CAD",
    "GB": "GBP",
    "AU": "AUD",
    "NZ": "NZD",
    "SG": "SGD",
    "HK": "HKD",
    "JP": "JPY",
    "DE": "EUR",
    "FR": "EUR",
    "IE": "EUR",
}
PLAN_NAMES = {
    "plus": "basic_plan",
    "pro5": "standard_plan",
    "pro20": "premium_plan",
}
MODE_VALUES = {"custom", "hosted", "both"}
HOSTED_CHECKOUT_HEADERS = {
    "Referer": "https://platform.example.com/",
    "x-vendor-target-path": "/api/v1/payments/checkout",
    "x-vendor-target-route": "/api/v1/payments/checkout",
}
DEFAULT_BROWSER_MAJOR = "90"
OLDEST_FINGERPRINT_SET = "oldest-all"
CS_PATTERN = re.compile(r"cs_(?:live|test)_[A-Za-z0-9]+|cs_[A-Za-z0-9_-]+")
CHECKOUT_PATTERN = re.compile(
    r"oaics_[A-Za-z0-9_-]+|cs_(?:live|test)_[A-Za-z0-9]+|cs_[A-Za-z0-9_-]+"
)


class ProbeError(RuntimeError):
    pass


def _curl_chrome_target(requested_major: str) -> str:
    """Select the nearest curl_cffi desktop-Chrome TLS target."""
    try:
        from curl_cffi.requests.impersonate import BrowserType

        supported = sorted(
            {
                int(match.group(1))
                for item in BrowserType
                if (match := re.fullmatch(r"chrome(\d+)", str(item.value)))
            }
        )
    except Exception:
        supported = [99, 100, 101, 104, 107, 110, 116, 119, 120, 123, 124, 131, 136, 142, 145, 146]
    if not supported:
        raise ProbeError("curl_cffi exposes no Chrome TLS impersonation targets")
    requested = int(requested_major)
    selected = min(supported, key=lambda value: (abs(value - requested), value))
    return f"chrome{selected}"


def available_browser_targets() -> list[str]:
    try:
        from curl_cffi.requests.impersonate import BrowserType

        return sorted({str(item.value) for item in BrowserType})
    except Exception as exc:
        raise ProbeError(f"failed to read curl_cffi browser targets: {exc}") from exc


def oldest_browser_targets() -> list[str]:
    """Return the oldest supported preset for each browser/platform family."""
    targets = available_browser_targets()
    patterns = (
        r"chrome\d+$",
        r"edge\d+$",
        r"firefox\d+$",
        r"safari\d+$",
        r"chrome\d+_android$",
        r"safari\d+_ios$",
        r"tor\d+$",
    )
    selected: list[str] = []
    for pattern in patterns:
        matches = [target for target in targets if re.fullmatch(pattern, target)]
        if not matches:
            continue
        matches.sort(
            key=lambda target: int(re.search(r"\d+", target).group(0))
        )
        selected.append(matches[0])
    if not selected:
        raise ProbeError("curl_cffi exposes no supported browser targets")
    return selected


def build_browser_target_fingerprint(target: str) -> dict[str, str]:
    """Create HTTP headers aligned with one curl_cffi impersonation target."""
    value = str(target or "").strip().lower()
    if value not in available_browser_targets():
        raise ProbeError(f"unsupported curl_cffi browser target: {value}")
    profile: dict[str, str] = {
        "tls_impersonate": value,
        "fingerprint_target": value,
        "accept_language": "en-US,en;q=0.9",
        "vendor_language": "en-US",
        "client_hints": "0",
        "mobile": "?0",
    }
    match = re.fullmatch(r"chrome(\d+)", value)
    if match:
        major = match.group(1)
        full = f"{major}.0.0.0"
        profile.update(
            build_browser_fingerprint(major),
            tls_impersonate=value,
            fingerprint_target=value,
            requested_browser_version=full,
            client_hints="1",
        )
        return profile
    match = re.fullmatch(r"edge(\d+)", value)
    if match:
        major = match.group(1)
        full = f"{major}.0.0.0"
        profile.update({
            "ua": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{full} "
                f"Safari/537.36 Edg/{full}"
            ),
            "major": major,
            "full": full,
            "platform": "Windows",
            "client_hints": "1",
            "sec_ch_ua": (
                f'" Not A;Brand";v="99", "Chromium";v="{major}", '
                f'"Microsoft Edge";v="{major}"'
            ),
        })
        return profile
    match = re.fullmatch(r"firefox(\d+)", value)
    if match:
        version = match.group(1)
        profile.update({
            "ua": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64; "
                f"rv:{version}.0) Gecko/20100101 Firefox/{version}.0"
            ),
            "major": version,
            "full": f"{version}.0",
            "platform": "Windows",
            "requested_browser_version": f"{version}.0",
        })
        return profile
    match = re.fullmatch(r"safari(\d+)", value)
    if match:
        digits = match.group(1)
        version = f"{digits[:2]}.{digits[2:]}" if len(digits) > 2 else digits
        profile.update({
            "ua": (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                f"AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} Safari/605.1.15"
            ),
            "major": digits[:2],
            "full": version,
            "platform": "macOS",
            "requested_browser_version": version,
        })
        return profile
    match = re.fullmatch(r"chrome(\d+)_android", value)
    if match:
        major = match.group(1)
        full = f"{major}.0.0.0"
        profile.update({
            "ua": (
                "Mozilla/5.0 (Linux; Android 12; Pixel 5) "
                f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{full} "
                "Mobile Safari/537.36"
            ),
            "major": major,
            "full": full,
            "platform": "Android",
            "mobile": "?1",
            "client_hints": "1",
            "requested_browser_version": full,
            "sec_ch_ua": (
                f'" Not A;Brand";v="99", "Chromium";v="{major}", '
                f'"Google Chrome";v="{major}"'
            ),
        })
        return profile
    match = re.fullmatch(r"safari(\d+)_ios", value)
    if match:
        digits = match.group(1)
        version = f"{digits[:2]}.{digits[2:]}" if len(digits) > 2 else digits
        os_version = version.replace(".", "_")
        profile.update({
            "ua": (
                f"Mozilla/5.0 (iPhone; CPU iPhone OS {os_version} like Mac OS X) "
                f"AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} "
                "Mobile/15E148 Safari/604.1"
            ),
            "major": digits[:2],
            "full": version,
            "platform": "iOS",
            "mobile": "?1",
            "requested_browser_version": version,
        })
        return profile
    match = re.fullmatch(r"tor(\d+)", value)
    if match:
        version = match.group(1)
        profile.update({
            "ua": (
                "Mozilla/5.0 (Windows NT 10.0; rv:128.0) "
                "Gecko/20100101 Firefox/128.0"
            ),
            "major": version,
            "full": version,
            "platform": "Windows",
            "requested_browser_version": version,
        })
        return profile
    raise ProbeError(f"browser target profile is not implemented: {value}")


def build_browser_fingerprint(major: str = DEFAULT_BROWSER_MAJOR) -> dict[str, str]:
    """Build a self-consistent curl_cffi Chrome fingerprint profile."""
    value = str(major or DEFAULT_BROWSER_MAJOR).strip()
    if not re.fullmatch(r"\d{2,3}", value):
        raise ProbeError(f"invalid Chrome major version: {value}")
    return {
        # curl_cffi 0.15 starts its desktop Chrome TLS presets at Chrome 99.
        # Keep the requested Chrome 90 HTTP fingerprint while using the
        # nearest available TLS preset instead of failing the probe.
        "tls_impersonate": _curl_chrome_target(value),
        "requested_browser_version": f"{value}.0.0.0",
        "ua": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            f"AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{value}.0.0.0 Safari/537.36"
        ),
        "major": value,
        "full": f"{value}.0.0.0",
        "platform": "Windows",
        "mobile": "?0",
        "accept_language": "en-US,en;q=0.9",
        "vendor_language": "en-US",
        "sec_ch_ua": (
            f'" Not A;Brand";v="99", "Chromium";v="{value}", '
            f'"Google Chrome";v="{value}"'
        ),
        "sec_ch_ua_full_version_list": (
            f'" Not A;Brand";v="99.0.0.0", "Chromium";v="{value}.0.0.0", '
            f'"Google Chrome";v="{value}.0.0.0"'
        ),
    }


def build_checkout_body(
    country: str,
    currency: str = "",
    *,
    mode: str = "hosted",
    plan: str = "plus",
) -> dict[str, Any]:
    normalized_country = str(country or "US").strip().upper()
    expected_currency = REGION_CURRENCIES.get(normalized_country)
    if expected_currency is None:
        raise ProbeError(f"unsupported checkout country: {normalized_country}")
    normalized_currency = str(currency or expected_currency).strip().upper()
    if normalized_currency != expected_currency:
        raise ProbeError(
            f"country/currency mismatch: {normalized_country} requires {expected_currency}"
        )
    normalized_mode = str(mode or "hosted").strip().lower()
    if normalized_mode == "redirect":
        normalized_mode = "hosted"
    if normalized_mode not in {"custom", "hosted"}:
        raise ProbeError(f"unsupported checkout mode: {normalized_mode}")
    normalized_plan = str(plan or "plus").strip().lower()
    if normalized_plan not in PLAN_NAMES:
        raise ProbeError(f"unsupported checkout plan: {normalized_plan}")
    return {
        "plan_name": PLAN_NAMES[normalized_plan],
        "billing_details": {
            "country": normalized_country,
            "currency": normalized_currency,
        },
        "checkout_ui_mode": normalized_mode,
    }


def build_hosted_checkout_body(
    country: str,
    currency: str = "",
    *,
    plan: str = "plus",
) -> dict[str, Any]:
    """Build the hosted template used by ideal_links_Service.

    The upstream service adds promo fields, but Checkout Server intentionally keeps
    promo/coupon qualification out of the probe. The hosted discriminator and
    billing structure are otherwise identical.
    """
    return build_checkout_body(country, currency, mode="hosted", plan=plan)


def selected_fingerprint_profile(args: argparse.Namespace) -> dict[str, str]:
    target = str(getattr(args, "fingerprint_target", "") or "").strip().lower()
    if target in {"", "chrome-custom"}:
        return build_browser_fingerprint(args.browser_major)
    return build_browser_target_fingerprint(target)


def load_session(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ProbeError(f"failed to read Session JSON: {exc}") from exc
    if isinstance(payload, dict) and isinstance(payload.get("session"), dict):
        payload = payload["session"]
    if not isinstance(payload, dict):
        raise ProbeError("Session JSON must be an object")
    if not str(payload.get("accessToken") or payload.get("access_token") or "").strip():
        raise ProbeError("Session JSON is missing accessToken")
    return payload


def stored_platform_proxy(data_dir: Path) -> str:
    database_path = data_dir / "checkout-server.db"
    source = ""
    if database_path.is_file():
        try:
            uri = database_path.resolve().as_uri() + "?mode=ro"
            with sqlite3.connect(uri, uri=True, timeout=5) as connection:
                row = connection.execute(
                    "SELECT proxies FROM proxy_configurations WHERE role = 'platform'"
                ).fetchone()
                source = str(row[0] or "") if row else ""
        except sqlite3.Error:
            source = ""
    source = source or os.environ.get("CS_PLATFORM_PROXY_POOL", "")
    pool = ProxyPool(source)
    return pool.next()


def route_proxy_country(proxy: str, country: str) -> str:
    normalized_country = str(country or "").strip().lower()
    if not re.fullmatch(r"[a-z]{2}", normalized_country):
        raise ProbeError("proxy country must be a two-letter country code")
    parsed = urlsplit(str(proxy or "").strip())
    auth, separator, host = parsed.netloc.rpartition("@")
    if parsed.scheme.lower() != "socks5h" or not separator or not host:
        raise ProbeError("stored proxy does not support country routing")
    routed_auth, replacements = re.subn(
        r"(?i)(country-)[a-z]{2}(?=_|:|$)",
        rf"\g<1>{normalized_country}",
        auth,
        count=1,
    )
    if replacements != 1:
        raise ProbeError("stored proxy has no country routing field")
    return urlunsplit(
        (parsed.scheme.lower(), f"{routed_auth}@{host}", parsed.path, "", "")
    )


def _walk_strings(value: Any):
    if isinstance(value, dict):
        for item in value.values():
            yield from _walk_strings(item)
    elif isinstance(value, list):
        for item in value:
            yield from _walk_strings(item)
    elif isinstance(value, str):
        yield value


def _first_value(payload: Any, names: tuple[str, ...]) -> str:
    wanted = {name.lower() for name in names}
    if isinstance(payload, dict):
        for key, value in payload.items():
            if str(key).lower() in wanted and isinstance(value, (str, int, float)):
                text = str(value).strip()
                if text:
                    return text
            nested = _first_value(value, names)
            if nested:
                return nested
    elif isinstance(payload, list):
        for value in payload:
            nested = _first_value(value, names)
            if nested:
                return nested
    return ""


def summarize_checkout(
    payload: dict[str, Any],
    *,
    requested_mode: str = "hosted",
    plan: str = "plus",
) -> dict[str, Any]:
    tag = str(payload.get("tag") or "").strip()
    provider_url = _first_value(
        payload,
        ("url", "checkout_url", "checkoutUrl", "redirect_url", "redirectUrl"),
    )
    checkout_id = _first_value(
        payload,
        ("checkout_session_id", "checkoutSessionId", "session_id", "id"),
    )
    if not CHECKOUT_PATTERN.fullmatch(checkout_id):
        checkout_id = ""
    candidates = [provider_url, *_walk_strings(payload)]
    if not checkout_id:
        for candidate in candidates:
            match = CHECKOUT_PATTERN.search(candidate)
            if match:
                checkout_id = match.group(0)
                break
    if not checkout_id:
        encoded = json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
        match = CHECKOUT_PATTERN.search(encoded)
        checkout_id = match.group(0) if match else ""
    if provider_url:
        parsed = urlsplit(provider_url)
        if parsed.scheme != "https" or not parsed.hostname:
            provider_url = ""
    processor_entity = _first_value(
        payload,
        ("processor_entity", "processorEntity"),
    )
    generated_cs = bool(CS_PATTERN.fullmatch(checkout_id))
    actual_mode = "hosted" if generated_cs else "custom" if checkout_id.startswith("oaics_") else "unknown"
    normalized_requested_mode = str(requested_mode or "hosted").strip().lower()
    if normalized_requested_mode == "redirect":
        normalized_requested_mode = "hosted"
    platform_url = (
        f"https://platform.example.com/checkout/{processor_entity}/{checkout_id}"
        if checkout_id and processor_entity
        else ""
    )
    return {
        "ok": True,
        "requestedMode": normalized_requested_mode,
        "requestedPlan": str(plan or "plus").strip().lower(),
        "actualMode": actual_mode,
        "modeMatch": actual_mode == normalized_requested_mode,
        "responseTag": tag or "unknown",
        "generatedCs": generated_cs,
        "checkoutSessionId": checkout_id,
        "checkoutId": checkout_id,
        "processorEntity": processor_entity,
        "checkoutUrl": provider_url or platform_url,
        "providerUrl": provider_url,
        "platformUrl": platform_url,
    }


def refresh_probe_session(
    module: Any,
    http_session: Any,
    config: Any,
    timeout: int,
) -> bool:
    """Mirror checkout-test-tool's cookie-backed POST session refresh."""
    session_token = str(getattr(config, "session_token", "") or "").strip()
    if not session_token:
        return False
    headers = {
        "Accept": "application/json",
        "Cookie": f"__Secure-platform.session-token={session_token}",
        "x-vendor-device-id": str(getattr(config, "device_id", "") or ""),
        "x-vendor-session-id": str(getattr(config, "vendor_session_id", "") or ""),
        "User-Agent": "Mozilla/5.0",
    }
    token = str(getattr(config, "token", "") or "").strip()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    session_headers = getattr(http_session, "headers", None)
    removed_defaults: dict[str, Any] = {}
    if session_headers is not None:
        for name in ("Content-Type", "Origin", "Referer"):
            if name in session_headers:
                removed_defaults[name] = session_headers.pop(name)
    try:
        response = http_session.post(
            f"{module.APP_BASE}/api/auth/session",
            headers=headers,
            timeout=timeout,
        )
    finally:
        if session_headers is not None:
            session_headers.update(removed_defaults)
    status = int(getattr(response, "status_code", 0) or 0)
    if status >= 400:
        detail = ""
        try:
            detail = str(module._response_error(response) or "").strip()
        except Exception:
            pass
        raise ProbeError(f"session refresh failed: HTTP {status} {detail}".strip())
    payload = module._response_json(response)
    refreshed = str(
        payload.get("accessToken")
        or payload.get("access_token")
        or payload.get("token")
        or ""
    ).strip()
    if not refreshed:
        raise ProbeError("session refresh returned no access token")
    config.token = refreshed
    session_headers = getattr(http_session, "headers", None)
    if session_headers is not None:
        session_headers["Authorization"] = f"Bearer {refreshed}"
    return True


def run_probe(args: argparse.Namespace) -> dict[str, Any]:
    session_value = load_session(args.session_file)
    requested_mode = str(args.mode or "hosted").strip().lower()
    modes = ["custom", "hosted"] if requested_mode == "both" else [requested_mode]
    if requested_mode not in MODE_VALUES:
        raise ProbeError(f"unsupported checkout mode: {requested_mode}")
    country = str(args.country or "US").strip().upper()
    currency = str(args.currency or REGION_CURRENCIES.get(country) or "").strip().upper()
    build_checkout_body(country, currency, mode=modes[0], plan=args.plan)
    proxy = "" if args.direct else stored_platform_proxy(args.data_dir)
    if not proxy and not args.direct:
        raise ProbeError(
            "Platform proxy is not configured in data/checkout-server.db or CS_PLATFORM_PROXY_POOL"
        )
    if args.proxy_country:
        if args.direct:
            raise ProbeError("--proxy-country cannot be used with --direct")
        proxy = route_proxy_country(proxy, args.proxy_country)

    adapter = PlatformCheckoutAdapter(
        ROOT,
        timeout=args.timeout,
        country=country,
        currency=currency,
        billing_country=country,
        proxy_pool=ProxyPool([proxy] if proxy else []),
        require_proxy=not args.direct,
    )
    module = adapter._load()
    token, account_id = adapter._token_and_account(
        session_value,
        require_account=False,
    )
    sentinel_token, telemetry = adapter._sentinel_context(session_value)
    fingerprint_profile = selected_fingerprint_profile(args)
    config = adapter._config(
        module,
        token,
        account_id,
        session_value=session_value,
        sentinel_token=sentinel_token,
        telemetry=telemetry,
        country=country,
        currency=currency,
        device_id=str(uuid.uuid4()),
        vendor_session_id=str(uuid.uuid4()),
        fingerprint_profile=fingerprint_profile,
    )
    http_session = adapter._routed_session(module, config, proxy, proxy)
    try:
        refresh_error = ""
        try:
            refreshed = refresh_probe_session(module, http_session, config, args.timeout)
        except ProbeError as exc:
            # Keep the probe useful for accessToken-only fixtures while exposing
            # the exact refresh failure in diagnostics.
            refresh_text = str(exc)
            refresh_status = any(
                marker in refresh_text for marker in ("HTTP 400", "HTTP 401", "HTTP 403")
            )
            if getattr(args, "strict_session_refresh", False) or not refresh_status:
                raise
            refreshed = False
            refresh_error = refresh_text[:240]
        account_snapshot = adapter._account_snapshot(
            http_session, module, args.timeout
        )
        account_id = str(account_snapshot.get("account_id") or account_id).strip()
        config.account_id = account_id
        adapter._apply_account_context(http_session, account_id)
        pricing_source = "remote"
        pricing_error = ""
        try:
            pricing_country, pricing_currency = adapter._remote_pricing_config(
                http_session,
                module,
                country,
                currency,
                args.timeout,
            )
            country, currency = pricing_country, pricing_currency
        except Exception as exc:
            pricing_source = "static_fallback"
            pricing_error = str(exc)[:240]
        config.country = country
        config.currency = currency
        module._hydrate_payment_metadata(http_session, config, lambda _message: None)
        module._ensure_sentinel_context(
            http_session,
            config,
            flow="platform_checkout",
        )
        attempts: list[dict[str, Any]] = []
        for mode in modes:
            body = (
                build_hosted_checkout_body(country, currency, plan=args.plan)
                if mode == "hosted"
                else build_checkout_body(country, currency, mode=mode, plan=args.plan)
            )
            payload = module._post_json(
                http_session,
                module.CHECKOUT_URL,
                body,
                timeout=args.timeout,
                stage=f"{mode} checkout create",
                route="/api/v1/payments/checkout",
                referer="https://platform.example.com/",
                additional_headers=HOSTED_CHECKOUT_HEADERS if mode == "hosted" else None,
            )
            attempt = summarize_checkout(
                payload,
                requested_mode=mode,
                plan=args.plan,
            )
            attempt["requestBody"] = body
            attempts.append(attempt)
        mode_control = "inconclusive"
        if len(attempts) == 1:
            mode_control = "matched" if attempts[0]["modeMatch"] else "mismatched"
        elif all(item["modeMatch"] for item in attempts):
            mode_control = "observed"
        else:
            mode_control = "mismatched"
        return {
            "ok": all(item["ok"] for item in attempts),
            "modeControl": mode_control,
            "requestedMode": requested_mode,
            "requestedPlan": str(args.plan or "plus").strip().lower(),
            "fingerprintTarget": str(
                config.fingerprint_profile.get("fingerprint_target")
                or config.fingerprint_profile.get("tls_impersonate")
                or ""
            ),
            "attempts": attempts,
            "country": country,
            "currency": currency,
            "preflight": {
                "sessionRefreshed": refreshed,
                "sessionRefreshError": refresh_error,
                "accountIdPresent": bool(account_id),
                "pricingSource": pricing_source,
                "pricingError": pricing_error,
                "deviceIdPresent": bool(config.device_id),
                "vendorSessionIdPresent": bool(config.vendor_session_id),
                "tlsImpersonate": str(config.fingerprint_profile.get("tls_impersonate") or ""),
                "requestedBrowserVersion": str(
                    config.fingerprint_profile.get("requested_browser_version")
                    or config.fingerprint_profile.get("full")
                    or ""
                ),
                "userAgent": str(config.fingerprint_profile.get("ua") or ""),
            },
            "proxyCountry": (
                str(args.proxy_country).upper() if args.proxy_country else "configured"
            ),
        }
    finally:
        http_session.close()


def run_oldest_fingerprint_matrix(args: argparse.Namespace) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    for target in oldest_browser_targets():
        child = argparse.Namespace(**vars(args))
        child.fingerprint_target = target
        try:
            result = run_probe(child)
        except Exception as exc:
            from backend.vendor.card_payment import _safe_error

            result = {
                "ok": False,
                "fingerprintTarget": target,
                "error": _safe_error(exc),
                "attempts": [],
            }
        results.append(result)

    cs_targets: list[str] = []
    oaics_targets: list[str] = []
    failed_targets: list[str] = []
    for result in results:
        target = str(result.get("fingerprintTarget") or "")
        attempts = result.get("attempts") if isinstance(result.get("attempts"), list) else []
        if not result.get("ok") or not attempts:
            failed_targets.append(target)
            continue
        if any(bool(item.get("generatedCs")) for item in attempts if isinstance(item, dict)):
            cs_targets.append(target)
        elif any(
            str(item.get("checkoutId") or "").startswith("oaics_")
            for item in attempts
            if isinstance(item, dict)
        ):
            oaics_targets.append(target)
    return {
        "ok": not failed_targets,
        "fingerprintSet": OLDEST_FINGERPRINT_SET,
        "targets": oldest_browser_targets(),
        "requestedMode": str(args.mode or "hosted"),
        "requestedPlan": str(args.plan or "plus"),
        "country": str(args.country or "US").upper(),
        "currency": str(
            args.currency
            or REGION_CURRENCIES.get(str(args.country or "US").upper())
            or ""
        ).upper(),
        "generatedCsAny": bool(cs_targets),
        "csTargets": cs_targets,
        "oaicsTargets": oaics_targets,
        "failedTargets": failed_targets,
        "fingerprintAttempts": results,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Create custom/hosted Platform Checkout probes and compare oaics_/cs_ prefixes. "
            "The script stops after Checkout creation and never submits card data or confirms payment."
        )
    )
    parser.add_argument(
        "--session-file",
        type=Path,
        required=True,
        help="Path to a local Platform Session JSON file",
    )
    parser.add_argument("--country", default="US", help="Checkout country (default: US)")
    parser.add_argument("--currency", default="", help="Currency; inferred from country by default")
    parser.add_argument(
        "--mode",
        choices=sorted(MODE_VALUES),
        default="hosted",
        help="Checkout UI mode to request (default: hosted)",
    )
    parser.add_argument(
        "--plan",
        choices=sorted(PLAN_NAMES),
        default="plus",
        help="Checkout plan to request (default: plus)",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=ROOT / "data",
        help="Checkout Server data directory used to read the Platform proxy",
    )
    parser.add_argument("--timeout", type=int, default=90, help="Request timeout in seconds")
    parser.add_argument(
        "--browser-major",
        default=DEFAULT_BROWSER_MAJOR,
        help=(
            "Chrome major version for the HTTP fingerprint; curl_cffi uses "
            "the nearest available TLS target (default: 90)"
        ),
    )
    parser.add_argument(
        "--fingerprint-target",
        choices=[OLDEST_FINGERPRINT_SET, "chrome-custom", *available_browser_targets()],
        default=OLDEST_FINGERPRINT_SET,
        help=(
            "curl_cffi browser fingerprint target; oldest-all tests the oldest "
            "desktop/mobile target in every supported browser family"
        ),
    )
    parser.add_argument(
        "--proxy-country",
        default="",
        help="Temporarily route a country-aware SOCKS proxy through this country",
    )
    parser.add_argument(
        "--direct",
        action="store_true",
        help="Use a direct connection instead of the stored Platform proxy",
    )
    parser.add_argument(
        "--strict-session-refresh",
        action="store_true",
        help="Stop when POST /api/auth/session cannot refresh the supplied Session Token",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        result = (
            run_oldest_fingerprint_matrix(args)
            if args.fingerprint_target == OLDEST_FINGERPRINT_SET
            else run_probe(args)
        )
    except Exception as exc:
        from backend.vendor.card_payment import _safe_error

        print(
            json.dumps(
                {"ok": False, "error": _safe_error(exc)},
                ensure_ascii=False,
                indent=2,
            )
        )
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result.get("fingerprintSet") == OLDEST_FINGERPRINT_SET:
        return 0 if result.get("ok") else 1
    return 0 if result.get("modeControl") in {"matched", "observed"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
