#!/usr/bin/env python3
"""Replay Checkout creation inside a real Chromium page.

The tool imports a local Session JSON, opens an isolated browser context, and
uses the page's fetch implementation to create Checkout sessions. It stops at
Checkout creation: no Taxes, PaymentMethod, card, or confirmation request is
made.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import uuid
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from tools.test_hosted_checkout import (  # noqa: E402
    MODE_VALUES,
    PLAN_NAMES,
    REGION_CURRENCIES,
    build_checkout_body,
)


CHECKOUT_ID = re.compile(r"(?:oaics_[A-Za-z0-9_-]+|cs_(?:live|test)_[A-Za-z0-9]+|cs_[A-Za-z0-9_-]+)")


class WebCheckoutError(RuntimeError):
    pass


def load_session(path: Path) -> dict[str, Any]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise WebCheckoutError(f"failed to read Session JSON: {exc}") from exc
    if isinstance(payload, dict) and isinstance(payload.get("session"), dict):
        payload = payload["session"]
    if not isinstance(payload, dict):
        raise WebCheckoutError("Session JSON must be an object")
    if not str(payload.get("accessToken") or payload.get("access_token") or "").strip():
        raise WebCheckoutError("Session JSON is missing accessToken")
    return payload


def _cookie_list(session: dict[str, Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    raw = session.get("cookies")
    if isinstance(raw, list):
        for cookie in raw:
            if not isinstance(cookie, dict):
                continue
            name = str(cookie.get("name") or "").strip()
            value = str(cookie.get("value") or "")
            if not name or not value:
                continue
            item = {
                "name": name,
                "value": value,
                "domain": str(cookie.get("domain") or ".platform.example.com"),
                "path": str(cookie.get("path") or "/"),
                "secure": bool(cookie.get("secure", True)),
                "httpOnly": bool(cookie.get("httpOnly", False)),
            }
            same_site = str(cookie.get("sameSite") or "Lax")
            if same_site in {"Strict", "Lax", "None"}:
                item["sameSite"] = same_site
            result.append(item)
    session_token = str(session.get("sessionToken") or session.get("session_token") or "").strip()
    if session_token and not any(
        item["name"] in {
            "__Secure-platform.session-token",
            "next-auth.session-token",
            "__Secure-authjs.session-token",
            "authjs.session-token",
        }
        for item in result
    ):
        result.append(
            {
                "name": "__Secure-platform.session-token",
                "value": session_token,
                "domain": ".platform.example.com",
                "path": "/",
                "secure": True,
                "httpOnly": True,
                "sameSite": "Lax",
            }
        )
    return result


def _summarize_response(status: int, text: str) -> dict[str, Any]:
    try:
        payload = json.loads(text or "{}")
    except json.JSONDecodeError:
        payload = {}
    if not isinstance(payload, dict):
        payload = {}
    encoded = json.dumps(payload, ensure_ascii=True, separators=(",", ":"))
    found = CHECKOUT_ID.search(encoded)
    checkout_id = found.group(0) if found else ""
    tag = str(payload.get("tag") or "").strip()
    if not tag:
        if checkout_id.startswith("oaics_"):
            tag = "custom_checkout_session"
        elif checkout_id.startswith("cs_"):
            tag = "hosted_checkout_session"
        else:
            tag = "unknown"
    processor = ""
    for key in ("processor_entity", "processorEntity"):
        value = payload.get(key)
        if isinstance(value, str) and value.strip():
            processor = value.strip()
            break
    return {
        "httpStatus": int(status),
        "responseTag": tag,
        "checkoutId": checkout_id,
        "prefix": "cs_" if checkout_id.startswith("cs_") else "oaics_" if checkout_id.startswith("oaics_") else "",
        "processorEntity": processor,
        "error": str(payload.get("error") or payload.get("message") or "").strip()[:500],
    }


def run(args: argparse.Namespace) -> dict[str, Any]:
    session = load_session(args.session_file)
    requested_mode = str(args.mode or "both").strip().lower()
    if requested_mode not in MODE_VALUES:
        raise WebCheckoutError(f"unsupported checkout mode: {requested_mode}")
    modes = ["custom", "hosted"] if requested_mode == "both" else [requested_mode]
    country = str(args.country or "US").strip().upper()
    currency = str(args.currency or REGION_CURRENCIES.get(country) or "").strip().upper()
    if not currency:
        raise WebCheckoutError(f"unsupported checkout country: {country}")
    bodies = [
        build_checkout_body(country, currency, mode=mode, plan=args.plan)
        for mode in modes
    ]
    access_token = str(session.get("accessToken") or session.get("access_token") or "").strip()
    device_id = str(session.get("deviceId") or session.get("device_id") or uuid.uuid4())
    vendor_session_id = str(session.get("vendorSessionId") or session.get("vendor_session_id") or uuid.uuid4())
    executable = args.executable or os.environ.get("BROWSER_EXECUTABLE", "") or shutil.which("chrome.exe") or ""

    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise WebCheckoutError("Playwright is not installed") from exc

    captured: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=executable,
            headless=not args.headed,
            chromium_sandbox=False,
            args=["--disable-background-networking", "--disable-component-update", "--no-first-run"],
        )
        context = browser.new_context(locale="en-US", timezone_id="America/New_York")
        cookies = _cookie_list(session)
        if cookies:
            context.add_cookies(cookies)
        page = context.new_page()
        page.set_default_timeout(max(10, args.timeout) * 1000)

        def on_request(request: Any) -> None:
            if "/api/v1/payments/checkout" not in request.url or request.method != "POST":
                return
            post_data = request.post_data or ""
            try:
                body = json.loads(post_data)
            except json.JSONDecodeError:
                body = {"raw": post_data[:1000]}
            captured.append({"url": request.url, "method": request.method, "body": body})

        page.on("request", on_request)
        page_error = ""
        try:
            page.goto("https://platform.example.com/", wait_until="domcontentloaded", timeout=args.timeout * 1000)
        except Exception as exc:
            page_error = str(exc)[:300]

        for mode, body in zip(modes, bodies):
            result = page.evaluate(
                """
                async ({body, token, deviceId, sessionId}) => {
                  const response = await fetch('/api/v1/payments/checkout', {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                      'Accept': 'application/json',
                      'Content-Type': 'application/json',
                      'Authorization': `Bearer ${token}`,
                      'x-vendor-device-id': deviceId,
                      'x-vendor-session-id': sessionId,
                      'vendor-language': 'en-US'
                    },
                    body: JSON.stringify(body)
                  });
                  return {status: response.status, text: await response.text()};
                }
                """,
                {"body": body, "token": access_token, "deviceId": device_id, "sessionId": vendor_session_id},
            )
            summary = _summarize_response(int(result.get("status") or 0), str(result.get("text") or ""))
            summary["requestedMode"] = mode
            summary["requestBody"] = body
            results.append(summary)

        final_url = page.url
        title = page.title()
        context.close()
        browser.close()

    return {
        "ok": all(item["httpStatus"] < 400 and bool(item["checkoutId"]) for item in results),
        "page": {"url": final_url, "title": title, "navigationError": page_error},
        "country": country,
        "currency": currency,
        "requestedMode": requested_mode,
        "requestedPlan": str(args.plan or "plus").strip().lower(),
        "results": results,
        "capturedCheckoutRequests": captured,
        "note": "Browser-only Checkout creation probe; no Taxes, card, PaymentMethod, or confirm request was sent.",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Verify Platform Checkout creation in Chromium")
    parser.add_argument("--session-file", type=Path, required=True)
    parser.add_argument("--country", default="US")
    parser.add_argument("--currency", default="")
    parser.add_argument("--mode", choices=sorted(MODE_VALUES), default="both")
    parser.add_argument("--plan", choices=sorted(PLAN_NAMES), default="plus")
    parser.add_argument("--timeout", type=int, default=45)
    parser.add_argument("--headed", action="store_true", help="Show Chrome instead of running headless")
    parser.add_argument("--executable", default="")
    return parser.parse_args()


def main() -> int:
    try:
        result = run(parse_args())
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)[:500]}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
