# Payment Gateway Panel

A web-based panel for managing subscription payments via Stripe. Handles card binding, protocol-based checkout flows, and account subscription management.

## Modules
- `app.py`: API server, background jobs, concurrency control, cancellation and retry logic.
- `card_bind_session.py`: SetupIntent and Stripe publishable-key resolution.
- `card_set_default.py`: Attach and set the default PaymentMethod.
- `card_checkout_context.py`: Checkout and CustomerSession context.
- `server_confirmation_token.py`: ConfirmationToken helper.
- `ph_checkout_protocol.py`: Short-checkout protocol flow.
- `static/`, `templates/`: Binding and protocol-payment frontend.
- `pay/`: Standalone payment and checkout service.
- `protocol/`: PayPal protocol checkout integration.

## Flow
1. Create SetupIntent with an account access token.
2. If Stripe context/key is missing, create one temporary Checkout.
3. Fetch a fresh SetupIntent and key.
4. Confirm binding through Stripe.js.
5. Set the PaymentMethod as default.
6. Run binding and extraction with concurrency 1-10.
7. Failed rows cancel their old child task and retry independently.

## Deployment
Install `requirements.txt`, copy `.env.example` to `.env`, configure the local account archive and internal service endpoints, then run behind Flask/Gunicorn.

```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your configuration
flask run --host=0.0.0.0 --port=5000
```

## License
Private / Internal use only.
