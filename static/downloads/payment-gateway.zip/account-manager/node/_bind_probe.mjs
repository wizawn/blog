// 临时诊断：对指定 phonePending 网页号直跑 bindPhone，打印全部 stderr（含 [CLOAK-DIAG]）看未知页 DOM。跑完删。
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const id = process.argv[2];
const probe = JSON.parse(readFileSync(path.join(__dirname, '..', '..', 'data', 'probe_accounts.json'), 'utf8'));
const list = Array.isArray(probe) ? probe : (probe.items || probe.accounts || []);
const acc = list.find((a) => String(a.id) === String(id));
if (!acc) { console.error('account not found', id); process.exit(1); }
const settings = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'settings.json'), 'utf8'));
const proxies = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'proxies.json'), 'utf8'));
const pool = proxies.filter((p) => p.status === 'ok');
const proxy = (pool.length ? pool : proxies)[Math.floor(Math.random() * (pool.length ? pool.length : proxies.length))];

const payload = {
  email: acc.email, password: acc.password || '', cookies: acc.cookies || [],
  bindPhone: true, settings, proxy, otpBase: 'http://127.0.0.1:5088',
  headless: false, licenseKey: settings.cloakLicenseKey || '',
};
const t0 = Date.now();
const stamp = () => `+${((Date.now() - t0) / 1000).toFixed(1)}s`;
console.error(`[T] ${stamp()} bind ${acc.email} ck=${(acc.cookies || []).length} proxy=${proxy.host}`);
const child = spawn(process.execPath, [path.join(__dirname, 'cloak_reg_runner.mjs')], { cwd: __dirname, stdio: ['pipe', 'pipe', 'pipe'] });
let out = '';
child.stdout.on('data', (d) => { out += d.toString(); });
let buf = '';
child.stderr.on('data', (d) => {
  buf += d.toString(); let i;
  while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i); buf = buf.slice(i + 1); if (line.trim()) console.error(`[T]${stamp()} ${line}`); }
});
child.on('close', (c) => {
  console.error(`[T] ${stamp()} exit=${c}`);
  let r = {}; try { r = JSON.parse(out.trim()); } catch { /* */ }
  console.error(`[T] result ok=${r.ok} rt=${r.refreshToken ? 'YES' : 'no'} err=${r.error || ''}`);
});
child.stdin.write(JSON.stringify(payload)); child.stdin.end();
