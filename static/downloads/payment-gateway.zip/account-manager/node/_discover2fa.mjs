// 临时探索：用已存账号的 CK 恢复会话，打开 platform.example.com 设置→安全，转储 2FA UI 的 DOM，供实现 TOTP 开启。跑完删。
import { launchContext } from 'autobrowser';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const id = process.argv[2];
const probe = JSON.parse(readFileSync(path.join(__dirname, '..', '..', 'data', 'probe_accounts.json'), 'utf8'));
const list = Array.isArray(probe) ? probe : (probe.items || []);
const acc = list.find((a) => String(a.id) === String(id));
if (!acc) { console.error('no account'); process.exit(1); }
const settings = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'settings.json'), 'utf8'));
const proxies = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'proxies.json'), 'utf8'));
const pool = proxies.filter((p) => p.status === 'ok');
const p = (pool.length ? pool : proxies)[0];
const proxyStr = `http://${encodeURIComponent(p.username)}:${encodeURIComponent(p.password || '')}@${p.host}:${p.port}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function sanitize(list) {
  const ok = new Set(['Strict', 'Lax', 'None']); const out = [];
  for (const c of list || []) {
    if (!c || !c.name || !c.domain) continue;
    const ck = { name: String(c.name), value: String(c.value || ''), domain: String(c.domain), path: c.path || '/', httpOnly: !!c.httpOnly, secure: !!c.secure };
    if (typeof c.expires === 'number' && c.expires > 0) ck.expires = c.expires;
    ck.sameSite = ok.has(c.sameSite) ? c.sameSite : 'Lax'; out.push(ck);
  }
  return out;
}
const dump = async (page, tag) => {
  const d = await page.evaluate(() => {
    const vis = (e) => e && (e.offsetParent !== null || e.getClientRects().length > 0);
    const btns = [...document.querySelectorAll('button, [role="button"], a, [role="tab"], [role="menuitem"]')].filter(vis)
      .map((b) => ((b.innerText || b.getAttribute('aria-label') || '').trim()).replace(/\s+/g, ' ').slice(0, 40)).filter(Boolean);
    const testids = [...document.querySelectorAll('[data-testid]')].filter(vis).map((e) => e.getAttribute('data-testid')).slice(0, 40);
    return { url: location.href, title: document.title, text: (document.body.innerText || '').replace(/\s+/g, ' ').slice(0, 300), btns: [...new Set(btns)].slice(0, 40), testids: [...new Set(testids)] };
  }).catch((e) => ({ err: String(e) }));
  console.error(`\n==== ${tag} ====\n` + JSON.stringify(d, null, 1));
};

(async () => {
  const ctx = await launchContext({ headless: false, proxy: proxyStr, licenseKey: settings.cloakLicenseKey || undefined, locale: 'en-US', humanize: true, args: ['--disable-quic'] });
  await ctx.clearCookies();
  await ctx.addCookies(sanitize(acc.cookies));
  const page = await ctx.newPage();
  await page.goto('https://platform.example.com/#settings/Security', { waitUntil: 'domcontentloaded' }).catch(() => {});
  await sleep(5000);
  await dump(page, 'security');
  // 等 TOTP 认证器开关出现再用 Playwright 真实点击
  const toggle = page.locator('[data-testid="mfa-authenticator-toggle"]').first();
  try { await toggle.waitFor({ state: 'visible', timeout: 15000 }); } catch { /* */ }
  let clicked = false;
  try { await toggle.click(); clicked = true; } catch (e) { console.error('toggle click err', String(e).slice(0, 120)); }
  console.error('click authenticator toggle=', clicked);
  await page.waitForLoadState('domcontentloaded').catch(() => {});
  await sleep(4000);
  // 连续几次转储，捕捉「re-auth 页 / setup 对话框（含 base32 密钥）」
  for (let k = 0; k < 3; k++) {
    const d = await page.evaluate(() => {
      const vis = (e) => e && (e.offsetParent !== null || e.getClientRects().length > 0);
      const text = (document.body.innerText || '').replace(/\s+/g, ' ');
      const inputs = [...document.querySelectorAll('input,textarea')].filter(vis).map((i) => ({ n: i.name, t: i.type, ml: i.getAttribute('maxlength'), im: i.getAttribute('inputmode'), ph: i.placeholder, testid: i.getAttribute('data-testid') || '' }));
      const codes = (text.match(/\b[A-Z2-7]{4}(?:\s?[A-Z2-7]{4}){3,}\b/g) || []);
      const codeEls = [...document.querySelectorAll('code, pre, [class*="secret" i], [class*="key" i]')].filter(vis).map((e) => (e.innerText || '').trim()).filter(Boolean).slice(0, 8);
      return { url: location.href, text: text.slice(0, 600), inputs, codes, codeEls };
    }).catch((e) => ({ err: String(e).slice(0, 100) }));
    console.error(`\n==== POST-CLICK #${k} ====\n` + JSON.stringify(d, null, 1));
    await sleep(3500);
  }
  // 若停在 email-verification：从 Flask 收件箱取新鲜码填入 Continue，再看 setup 页
  if (/email-verification/.test(page.url())) {
    const base = Date.now();
    let code = '';
    for (let i = 0; i < 40 && !code; i++) {
      await sleep(4000);
      try {
        const r = await fetch(`http://127.0.0.1:5088/api/reg/inbox?email=${encodeURIComponent(acc.email)}`);
        const j = await r.json();
        for (const m of (j.messages || [])) {
          const subj = (m.subject || '').toLowerCase(); const from = (m.from_addr || '').toLowerCase();
          if (!/vendor|platform/.test(subj + from)) continue;
          const c = m.extracted_code || ((m.body || m.subject || '').match(/\b(\d{6})\b/) || [])[1];
          if (c) { code = c; break; }
        }
      } catch { /* */ }
      console.error(`inbox poll #${i} code=${code || '-'}`);
    }
    if (code) {
      const box = page.locator('input[name="code"], input[autocomplete="one-time-code"]').first();
      await box.fill(code).catch(() => {});
      await page.locator('button:has-text("Continue")').first().click().catch(() => {});
      await sleep(6000);
      // 落到 ?action=enable&factor=totp#settings/Security 后，SPA 需要点时间渲染 setup 对话框；多轮转储。
      // 关键：re-auth 后回到设置弹窗，需要再点一次认证器开关才真正打开 TOTP setup（顶层新对话框）。
      await page.locator('[data-testid="mfa-authenticator-toggle"]').first().click({ timeout: 3000 }).catch((e) => console.error('toggle2 err', String(e).slice(0, 80)));
      await sleep(3500);
      for (let m = 0; m < 6; m++) {
        const s = await page.evaluate(() => {
          const vis = (e) => e && (e.offsetParent !== null || e.getClientRects().length > 0);
          // 取最顶层(最后一个)对话框 —— setup 多半是叠在设置弹窗之上的新 radix dialog。
          const dlgs = [...document.querySelectorAll('[role="dialog"]')];
          const top = dlgs[dlgs.length - 1] || null;
          const scope = top || document.body;
          const stext = (scope.innerText || '').replace(/\s+/g, ' ');
          const inputs = [...scope.querySelectorAll('input,textarea')].filter(vis).map((i) => ({ n: i.name, t: i.type, ml: i.getAttribute('maxlength'), im: i.getAttribute('inputmode'), ph: i.placeholder, testid: i.getAttribute('data-testid') || '' }));
          const codes = (stext.match(/\b[A-Z2-7]{4}(?:\s?[A-Z2-7]{4})+\b/g) || []);
          const mono = [...scope.querySelectorAll('code, pre, input[readonly], [class*="secret" i], [class*="key" i], [class*="mono" i]')].filter(vis).map((e) => (e.value || e.innerText || '').trim()).filter(Boolean).slice(0, 10);
          return { url: location.href, dlgCount: dlgs.length, topText: stext.slice(0, 600), inputs, codes, mono, topHtml: top ? top.outerHTML.replace(/\s+/g, ' ').slice(0, 3500) : '' };
        }).catch((e) => ({ err: String(e).slice(0, 120) }));
        console.error(`\n==== SETUP DUMP #${m} ====\n` + JSON.stringify(s, null, 1));
        if ((s.codes && s.codes.length) || (s.inputs && s.inputs.some((i) => i.ml === '6' || i.im === 'numeric'))) break;
        // 尝试露出手动密钥（只匹配 can't scan / enter key manually，避开 passkeys）
        await page.evaluate(() => {
          const r = /can'?t scan|enter (this |the )?key manually|manual entry|setup key/i;
          const dlgs = [...document.querySelectorAll('[role="dialog"]')];
          const scope = dlgs[dlgs.length - 1] || document.body;
          for (const n of scope.querySelectorAll('button,a,[role="button"]')) { if (r.test(n.innerText || '')) { n.click(); return; } }
        }).catch(() => {});
        await sleep(3500);
      }
      await page.screenshot({ path: path.join(__dirname, '_2fa_setup.png'), fullPage: true }).catch(() => {});
    }
  }
  // 转储 setup 对话框：全部可见文本 + 所有 input/其属性 + 疑似 base32 密钥 + testids
  const dlg = await page.evaluate(() => {
    const vis = (e) => e && (e.offsetParent !== null || e.getClientRects().length > 0);
    const text = (document.body.innerText || '').replace(/\s+/g, ' ');
    const inputs = [...document.querySelectorAll('input, textarea')].filter(vis).map((i) => ({
      name: i.name || '', type: i.type || '', ml: i.getAttribute('maxlength') || '', im: i.getAttribute('inputmode') || '',
      ph: i.getAttribute('placeholder') || '', ac: i.getAttribute('autocomplete') || '', testid: i.getAttribute('data-testid') || '',
    }));
    // 疑似 base32 密钥：≥16 位 A-Z2-7（可能含空格分组）
    const codes = (text.match(/\b[A-Z2-7]{4}(?:\s?[A-Z2-7]{4}){3,}\b/g) || []);
    const testids = [...document.querySelectorAll('[data-testid]')].filter(vis).map((e) => e.getAttribute('data-testid')).slice(0, 50);
    const btns = [...document.querySelectorAll('button,[role="button"]')].filter(vis).map((b) => (b.innerText || '').trim().slice(0, 30)).filter(Boolean);
    return { url: location.href, textSlice: text.slice(0, 700), inputs, codes, testids: [...new Set(testids)], btns: [...new Set(btns)].slice(0, 30) };
  }).catch((e) => ({ err: String(e) }));
  console.error('\n==== MFA SETUP DIALOG ====\n' + JSON.stringify(dlg, null, 1));
  await page.screenshot({ path: path.join(__dirname, '_2fa.png'), fullPage: true }).catch(() => {});
  await sleep(1500);
  await ctx.close().catch(() => {});
})();
