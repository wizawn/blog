// 临时计时脚本：有头真跑「网页客户端注册」，给每条日志打相对时间戳(ms)，用于提速前后耗时对比。
// 跑完即删。用法：node _web_probe.mjs <email> [bindPhone]
import { spawn } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const settings = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'settings.json'), 'utf8'));
const proxies = JSON.parse(readFileSync(path.join(__dirname, '..', 'config', 'proxies.json'), 'utf8'));
const pool = proxies.filter((p) => p.status === 'ok');
const proxy = (pool.length ? pool : proxies)[Math.floor(Math.random() * (pool.length ? pool.length : proxies.length))];

const email = process.argv[2] || 'cargoes.caducei.6f@icloud.com';
const payload = {
  email, settings, proxy, otpBase: 'http://127.0.0.1:5088',
  headless: false, skipPhone: true, webClient: true,
  licenseKey: settings.cloakLicenseKey || '',
};

const t0 = Date.now();
const stamp = () => `+${((Date.now() - t0) / 1000).toFixed(1)}s`;
console.error(`[T] ${stamp()} start email=${email} proxy=${proxy.host}:${proxy.port}`);
const child = spawn(process.execPath, [path.join(__dirname, 'cloak_reg_runner.mjs')], {
  cwd: __dirname, stdio: ['pipe', 'pipe', 'pipe'],
});
let out = '';
child.stdout.on('data', (d) => { out += d.toString(); });
let buf = '';
child.stderr.on('data', (d) => {
  buf += d.toString();
  let i;
  while ((i = buf.indexOf('\n')) >= 0) {
    const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
    if (!line || line.startsWith('[')) continue;
    let msg = line;
    try { const r = JSON.parse(line); msg = `${r.level}\t${r.msg}`; } catch { /* raw */ }
    console.error(`[T] ${stamp()}\t${msg}`);
  }
});
child.on('close', (code) => {
  console.error(`[T] ${stamp()} exit=${code} totalSec=${((Date.now() - t0) / 1000).toFixed(1)}`);
  let r = {}; try { r = JSON.parse(out.trim()); } catch { /* ignore */ }
  console.error(`[T] result ok=${r.ok} phonePending=${r.phonePending} at=${r.accessToken ? r.accessToken.length : 0} ck=${(r.cookies || []).length} rt=${r.refreshToken ? 'YES' : 'no'}`);
});
child.stdin.write(JSON.stringify(payload));
child.stdin.end();
