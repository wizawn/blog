// 查收 wrapper —— 由 Flask /api/plus/inbox 通过 `node inbox_runner.mjs` 调用。
// 输入：stdin 一段 JSON { email, clientId, refreshToken, limit? }
// 输出：stdout 一段 JSON
//   成功 { ok:true, address, via, messages:[...] }
//   失败 { ok:false, status, error }
// 复用 auto 项目原封不动的 plus-mailbox.js（fetchPlusInbox）。
import { fetchPlusInbox } from './plus-mailbox.js';

// 复用的脚本会用 console.log 打印诊断信息（如 plus-mailbox 的“令牌换取成功”），
// 这些默认写 stdout 会污染我们的 JSON 结果。统一改写到 stderr，保证 stdout 只有结果 JSON。
const _errWrite = (...a) => { try { process.stderr.write(a.map(String).join(' ') + '\n'); } catch { /* ignore */ } };
console.log = _errWrite;
console.info = _errWrite;
console.warn = _errWrite;

function readStdin() {
  return new Promise((resolve) => {
    let buf = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (c) => { buf += c; });
    process.stdin.on('end', () => resolve(buf));
  });
}

(async () => {
  try {
    const raw = await readStdin();
    const input = JSON.parse(raw || '{}');
    const { email, clientId, refreshToken } = input;
    const limit = Number(input.limit) || 15;
    const r = await fetchPlusInbox({ email, clientId, refreshToken }, limit);
    process.stdout.write(JSON.stringify({ ok: true, address: r.address, via: r.via, messages: r.messages || [] }));
  } catch (e) {
    process.stdout.write(JSON.stringify({ ok: false, status: e && e.status ? e.status : 502, error: (e && e.message) || String(e) }));
  }
})();
