// 「重拿RT」wrapper —— 对【已存在账号】用 codex 客户端跑一次全新登录（register:false），
// 换取新的 codex refreshToken / accessToken（全程用全新 device_id）。
// 输入（stdin JSON）：{ email, password, settings, proxy, otpBase }
// 输出：
//   - 过程日志：逐行写 stderr，每行 JSON { level, msg, account }
//   - 最终结果：stdout 一段 JSON（getRefreshToken 返回结构：{ ok, refreshToken, accessToken, clientId, deviceId, ... }）
import { getRefreshToken } from './get-rt.js';

const _errWrite = (...a) => { try { process.stderr.write(a.map(String).join(' ') + '\n'); } catch { /* ignore */ } };
console.log = _errWrite;
console.info = _errWrite;
console.warn = _errWrite;

function readStdin() {
  return new Promise((resolve) => {
    let buf = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (c) => { buf += c; });
    process.stdin.on('end', () => resolve(buf));
  });
}

function emitLog(level, msg, account) {
  try { process.stderr.write(JSON.stringify({ level, msg: String(msg), account: account || '' }) + '\n'); } catch { /* ignore */ }
}

(async () => {
  let email = '';
  try {
    const input = JSON.parse((await readStdin()) || '{}');
    email = input.email || '';
    const settings = input.settings || {};
    const proxy = input.proxy || null;
    const password = input.password || '';
    const otpBase = String(input.otpBase || 'http://127.0.0.1:5088').replace(/\/$/, '');
    if (!email) throw new Error('缺少邮箱');

    // 邮箱验证码来源：邮箱池（经 Flask /api/reg/inbox）。已注册账号的邮箱在池中，可读到新码。
    const fetchInbox = async (account /* , limit */) => {
      const addr = (account && account.email) || email;
      const url = `${otpBase}/api/reg/inbox?email=${encodeURIComponent(addr)}`;
      const res = await fetch(url, { method: 'GET' });
      if (!res.ok) throw new Error('读取邮箱失败 HTTP ' + res.status);
      const data = await res.json().catch(() => ({}));
      return { messages: (data && data.messages) || [] };
    };

    emitLog('info', '重拿RT中', email);
    const result = await getRefreshToken({ email, password }, {
      settings,
      proxy,
      register: false,
      password,
      log: (level, msg, acc) => emitLog(level, msg, acc || email),
      fetchInbox,
    });
    if (result && result.refreshToken) result.ok = true;
    process.stdout.write(JSON.stringify(result || { ok: false, error: '无结果' }));
  } catch (e) {
    emitLog('error', (e && e.message) || String(e), email);
    process.stdout.write(JSON.stringify({ ok: false, error: (e && e.message) || String(e) }));
  }
})();
