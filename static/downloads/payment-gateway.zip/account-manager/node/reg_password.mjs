// 注册密码统一来源 —— 协议模式(reg_runner.mjs) 与 浏览器模式(cloak_reg_runner.mjs) 共用。
//
// 为什么改成「固定/确定性密码」而不是每次随机：
//   随机密码会导致「同一邮箱之前已建号、这次又进来」时用新的随机密码去登录 → Vendor 报
//   "Incorrect email address or password"，账号再也拿不到登录态。固定密码让「建号」和
//   「已注册邮箱重进时的登录」始终用同一个口令，也方便导出账密后人工登录。
//
// 优先级：显式传入 input.password > settings.regPassword（用户可在设置里改）> 内置默认强密码。
// 默认口令为固定强口令：16 位、含大小写+数字+符号，满足 Vendor 复杂度且不含服务相关词，
// 所有账号共用同一个（Vendor 不做跨账号撞库校验，复用安全）。
export const DEFAULT_REG_PASSWORD = 'Tz7$Kq2wNp9mLx4B';

export function resolveRegPassword(input = {}, settings = {}) {
  const fromInput = input && typeof input.password === 'string' ? input.password.trim() : '';
  const fromSettings = settings && typeof settings.regPassword === 'string' ? settings.regPassword.trim() : '';
  return fromInput || fromSettings || DEFAULT_REG_PASSWORD;
}
