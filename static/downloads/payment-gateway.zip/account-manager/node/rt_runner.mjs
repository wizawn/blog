// 拿 RT wrapper —— 由 Flask /api/plus/get-rt 编排逐个账号通过 `node rt_runner.mjs` 调用。
// 输入：stdin 一段 JSON { account:{email,password,clientId,refreshToken}, settings, proxy }
// 输出：
//   - 过程日志：逐行写 stderr，每行是 JSON { level, msg, account }（供 Flask 汇集/落日志）
//   - 最终结果：stdout 一段 JSON（getRefreshToken 的返回结构）
//       成功  { ok:true, refreshToken, clientId, accessToken, idToken }
//       封号  { ok:false, banned:true, reason, error }
//       失败  { ok:false, banned:false, error }
// 复用 auto 项目原封不动的 get-rt.js（getRefreshToken）。
import { getRefreshToken } from './get-rt.js';

// 复用脚本内部的 console.log/info/warn（如 plus-mailbox 的诊断行）默认写 stdout，
// 会污染我们最终的结果 JSON。统一改写到 stderr，保证 stdout 只有结果 JSON。
const _errWrite = (...a) => { try { process.stderr.write(a.map(String).join(' ') + '\n'); } catch { /* ignore */ } };
console.log = _errWrite;
console.info = _errWrite;
console.warn = _errWrite;

function readStdin() {
  return new Promise((resolve) => {
    let buf = '';
    process.stdin.setEncoding('utf8');
    process.stdin.on('data', (c) => { buf += c; });
    process.stdin.on('end', () => resolve(buf));
  });
}

function emitLog(level, msg, account) {
  try { process.stderr.write(JSON.stringify({ level, msg: String(msg), account: account || '' }) + '\n'); } catch { /* ignore */ }
}

(async () => {
  let account = {};
  try {
    const raw = await readStdin();
    const input = JSON.parse(raw || '{}');
    account = input.account || {};
    const settings = input.settings || {};
    const proxy = input.proxy || null;
    const result = await getRefreshToken(account, {
      settings,
      proxy,
      log: (level, msg, acc) => emitLog(level, msg, acc || account.email),
    });
    process.stdout.write(JSON.stringify(result));
  } catch (e) {
    emitLog('error', (e && e.message) || String(e), account.email);
    process.stdout.write(JSON.stringify({ ok: false, banned: false, error: (e && e.message) || String(e) }));
  }
})();
