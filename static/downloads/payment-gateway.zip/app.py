from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import quote, unquote, urlencode, urlparse, urlsplit
from urllib.request import Request, urlopen

from flask import Flask, jsonify, redirect, render_template, request

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass


ROOT = Path(__file__).resolve().parent
app = Flask(__name__, template_folder="templates", static_folder="static")
app.json.ensure_ascii = False
# 模板改动即时生效，避免非 debug 模式下 Jinja 缓存旧模板导致前后端不一致
app.config["TEMPLATES_AUTO_RELOAD"] = True
app.jinja_env.auto_reload = True

REG_SESSION_SECRET = os.getenv("REG_SESSION_SECRET", "").strip()
REG_SESSION_COOKIE = os.getenv("REG_SESSION_COOKIE", "reg_access").strip() or "reg_access"
REG_INTERNAL_BASE = os.getenv("REG_INTERNAL_BASE", "http://127.0.0.1:18081").strip().rstrip("/")
PH_SHORT_BRIDGE_KEY = os.getenv("PH_SHORT_BRIDGE_KEY", "").strip()
JOB_TTL_SECONDS = max(1800, int(os.getenv("PH_PORTAL_JOB_TTL", "86400")))
MAX_JOBS = max(20, min(500, int(os.getenv("PH_PORTAL_MAX_JOBS", "120"))))
GATEWAY_PYTHON = os.getenv("GATEWAY_PYTHON", "").strip() or sys.executable
GATEWAY_INTERNAL_BASE = os.getenv("GATEWAY_INTERNAL_BASE", "http://127.0.0.1:18096").strip().rstrip("/")
GATEWAY_INTERNAL_KEY = os.getenv("GATEWAY_INTERNAL_KEY", "").strip()
PROTOCOL_HELPER = str(ROOT / "ph_checkout_protocol.py")
CARD_BIND_HELPER = str(ROOT / "card_bind_session.py")
CARD_DEFAULT_HELPER = str(ROOT / "card_set_default.py")
CARD_CHECKOUT_CONTEXT_HELPER = str(ROOT / "card_checkout_context.py")
CARD_SERVER_TOKEN_HELPER = str(ROOT / "server_confirmation_token.py")
STANDALONE_PAY_HELPER = str(ROOT / "standalone_protocol_pay.py")
ACCOUNT_FILE = Path(os.getenv("ACCOUNT_FILE", str(ROOT / "data" / "accounts.jsonl")))
REG_LEGACY_TASK_FILE = Path(os.getenv("REG_LEGACY_TASK_FILE", str(ROOT / "data" / "account_tasks.jsonl")))
CHECKOUT_CONTEXT_PATH = ROOT / "data" / "checkout_contexts.jsonl"
PROXY_PREFLIGHT_HELPER = str(ROOT / "proxy_preflight.py")
CARD_BIND_ACCOUNT_EMAIL = os.getenv("CARD_BIND_ACCOUNT_EMAIL", "user@example.com").strip().lower()
_jobs: dict[str, dict] = {}
_protocol_pay_jobs: dict[str, dict] = {}
_card_checkout_jobs: dict[str, dict] = {}
_key_probe_jobs: dict[str, dict] = {}
_lock = threading.RLock()
_external_at_lock = threading.Lock()


class PrefixMiddleware:
    def __init__(self, wrapped):
        self.wrapped = wrapped

    def __call__(self, environ, start_response):
        prefix = str(environ.get("HTTP_X_SCRIPT_NAME") or "").rstrip("/")
        if prefix:
            path = str(environ.get("PATH_INFO") or "/")
            if path == prefix:
                path = "/"
            elif path.startswith(prefix + "/"):
                path = path[len(prefix):]
            environ["SCRIPT_NAME"] = prefix
            environ["PATH_INFO"] = path
        return self.wrapped(environ, start_response)


app.wsgi_app = PrefixMiddleware(app.wsgi_app)


def shared_reg_session_valid() -> bool:
    if not REG_SESSION_SECRET:
        return True
    expected = hmac.new(
        REG_SESSION_SECRET.encode("utf-8"),
        b"register-console-access",
        hashlib.sha256,
    ).hexdigest()
    provided = str(request.cookies.get(REG_SESSION_COOKIE) or "")
    return bool(provided and hmac.compare_digest(provided, expected))


@app.before_request
def require_shared_reg_session():
    public_mount = request.script_root in {"/card-link", "/protocol-pay"}
    public_exact = {
        "/",
        "/api/card-bind/config",
        "/api/card-bind/session",
        "/api/card-bind/default",
        "/api/card-flow/quick-checkout",
        "/static/card-flow.css",
        "/static/card-flow.js",
        "/api/protocol-pay/jobs",
        "/api/protocol-pay/batch-confirm",
        "/static/protocol-pay.css",
        "/static/protocol-pay.js",
    }
    public_dynamic = request.path.startswith("/api/card-flow/task/") or request.path.startswith("/api/protocol-pay/jobs/") or request.path.startswith("/api/card-bind/key-probe/")
    if request.path == "/healthz":
        return None
    if public_mount and (request.path in public_exact or public_dynamic):
        return None
    if shared_reg_session_valid():
        return None
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "error": "LOGIN_REQUIRED"}), 401
    return redirect("/login")


def reg_console_request(path: str, method: str = "GET", payload: dict | None = None) -> tuple[int, dict]:
    if not REG_SESSION_SECRET:
        raise RuntimeError("REG_SESSION_SECRET_MISSING")
    session_value = hmac.new(
        REG_SESSION_SECRET.encode("utf-8"),
        b"register-console-access",
        hashlib.sha256,
    ).hexdigest()
    data = None
    headers = {
        "Cookie": f"{REG_SESSION_COOKIE}={session_value}",
        "Accept": "application/json",
    }
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = Request(
        f"{REG_INTERNAL_BASE}{path}",
        data=data,
        headers=headers,
        method=method.upper(),
    )
    try:
        with urlopen(req, timeout=30) as response:
            raw = response.read().decode("utf-8", errors="replace")
            return int(response.status), json.loads(raw or "{}")
    except Exception as exc:
        status = int(getattr(exc, "code", 502) or 502)
        raw = ""
        if hasattr(exc, "read"):
            try:
                raw = exc.read().decode("utf-8", errors="replace")
            except Exception:
                raw = ""
        try:
            body = json.loads(raw or "{}")
        except Exception:
            body = {"ok": False, "error": raw[:300] or str(exc)}
        return status, body


def reg_bridge_get(path: str, params: dict | None = None) -> dict:
    if not PH_SHORT_BRIDGE_KEY:
        raise RuntimeError("菲律宾短链账号桥接密钥尚未配置")
    query = f"?{urlencode(params or {})}" if params else ""
    req = Request(
        f"{REG_INTERNAL_BASE}{path}{query}",
        headers={"X-PH-Short-Bridge-Key": PH_SHORT_BRIDGE_KEY, "Accept": "application/json"},
    )
    try:
        with urlopen(req, timeout=15) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
    except Exception as exc:
        detail = ""
        if hasattr(exc, "read"):
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:300]
            except Exception:
                detail = ""
        raise RuntimeError(f"读取 APP.example 账号会话失败：{detail or exc}") from exc
    if not isinstance(payload, dict) or payload.get("ok") is False or payload.get("error"):
        raise RuntimeError(str((payload or {}).get("error") or "账号会话接口返回异常"))
    return payload


def validate_short_url(raw: str) -> tuple[str, str, str]:
    value = str(raw or "").strip()
    parsed = urlparse(value)
    if parsed.scheme != "https" or parsed.hostname != "platform.example.com":
        raise ValueError("短链必须使用 platform.example.com 官方 HTTPS 地址")
    parts = [part for part in parsed.path.split("/") if part]
    if len(parts) != 3 or parts[0] != "checkout":
        raise ValueError("短链路径格式不正确")
    processor, session_id = parts[1], parts[2]
    if processor not in {"vendor_eu", "vendor_entity"}:
        raise ValueError("短链处理实体不正确")
    if not re.fullmatch(r"(?:oaics_|cs_)[A-Za-z0-9_-]{12,}", session_id):
        raise ValueError("Checkout Session ID 格式不正确")
    return value, processor, session_id


def cleanup_jobs() -> None:
    cutoff = time.time() - JOB_TTL_SECONDS
    with _lock:
        expired = [
            key for key, value in _jobs.items()
            if value.get("created_at", 0) < cutoff
            and value.get("status") not in {"queued", "running", "verification_required"}
        ]
        for key in expired:
            _jobs.pop(key, None)
        if len(_jobs) > MAX_JOBS:
            finished = sorted(
                (item for item in _jobs.values() if item.get("status") not in {"queued", "running", "verification_required"}),
                key=lambda item: item.get("created_at", 0),
            )
            for item in finished[: max(0, len(_jobs) - MAX_JOBS)]:
                _jobs.pop(str(item.get("id") or ""), None)


def public_job(job: dict) -> dict:
    return {
        "id": job["id"],
        "task_id": job.get("task_id") or "",
        "account_email": job.get("account_email") or "",
        "status": job.get("status") or "queued",
        "progress": int(job.get("progress") or 0),
        "stage": job.get("stage") or "等待执行",
        "message": job.get("message") or "",
        "error": job.get("error") or "",
        "result": dict(job.get("result") or {}),
        "logs": list(job.get("logs") or []),
        "cancel_requested": bool(job.get("cancel_requested")),
        "created_at": job.get("created_at"),
        "updated_at": job.get("updated_at"),
        "finished_at": job.get("finished_at"),
    }


def add_log(job_id: str, level: str, message: str) -> None:
    text = str(message or "").strip()
    if not text:
        return
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return
        logs = job.setdefault("logs", [])
        if logs and logs[-1].get("message") == text:
            return
        logs.append({"time": time.strftime("%H:%M:%S"), "type": level, "message": text[:800]})
        if len(logs) > 100:
            del logs[:-100]
        job["updated_at"] = time.time()


def parse_cards(raw) -> list[dict[str, str]]:
    cards: list[dict[str, str]] = []
    seen: set[tuple[str, str, str, str]] = set()

    def luhn_ok(number: str) -> bool:
        total = 0
        parity = len(number) % 2
        for index, char in enumerate(number):
            digit = int(char)
            if index % 2 == parity:
                digit *= 2
                if digit > 9:
                    digit -= 9
            total += digit
        return total % 10 == 0

    def append_card(number: Any, month: Any, year: Any, cvc: Any) -> None:
        number_text = re.sub(r"\D", "", str(number or ""))
        month_text = re.sub(r"\D", "", str(month or ""))
        year_text = re.sub(r"\D", "", str(year or ""))
        cvc_text = re.sub(r"\D", "", str(cvc or ""))
        if len(year_text) == 2:
            year_text = "20" + year_text
        if not (12 <= len(number_text) <= 19 and luhn_ok(number_text)
                and 1 <= int(month_text or 0) <= 12 and len(year_text) == 4
                and 3 <= len(cvc_text) <= 4):
            return
        key = (number_text, str(int(month_text)), year_text, cvc_text)
        if key not in seen:
            seen.add(key)
            cards.append({"number": key[0], "exp_month": key[1], "exp_year": key[2], "cvc": key[3]})

    if isinstance(raw, list):
        for value in raw:
            if isinstance(value, dict):
                append_card(value.get("number"), value.get("exp_month") or value.get("month"),
                            value.get("exp_year") or value.get("year"),
                            value.get("cvc") or value.get("cvv") or value.get("csc"))
            else:
                parts = [item for item in re.split(r"[|,;\s]+", str(value or "").strip()) if item]
                if len(parts) >= 4:
                    append_card(*parts[:4])
    else:
        text = str(raw or "")
        for line in text.splitlines():
            parts = [item for item in re.split(r"[|,;\s]+", line.strip()) if item]
            if len(parts) >= 4:
                append_card(*parts[:4])
        number_pattern = re.compile(r"(?<!\d)(\d{12,19}|(?:\d{4}[ -]){3}\d{4}|(?:\d{4}[ -]){2}\d{3,4})(?!\d)")
        expiry_pattern = re.compile(r"(?<!\d)(0?[1-9]|1[0-2])\s*[/|,-]\s*(\d{2}|\d{4})(?!\d)")
        cvc_pattern = re.compile(r"(?:cvc|cvv|csc|verification|security(?:\s*code)?|\u5b89\u5168\u7801|\u9a8c\u8bc1\u7801)[^\d]{0,24}(\d{3,4})", re.I)
        for match in number_pattern.finditer(text):
            number = re.sub(r"\D", "", match.group(1))
            if not (12 <= len(number) <= 19 and luhn_ok(number)):
                continue
            tail = text[match.end():match.end() + 240]
            expiry = expiry_pattern.search(tail)
            if not expiry:
                continue
            cvc_match = cvc_pattern.search(tail)
            if cvc_match:
                cvc = cvc_match.group(1)
            else:
                plain = re.search(r"(?<!\d)(\d{3,4})(?!\d)", tail[expiry.end():])
                cvc = plain.group(1) if plain else ""
            append_card(number, expiry.group(1), expiry.group(2), cvc)
    if not cards:
        raise ValueError("未识别到完整支付卡，请检查卡号、有效期和 CVC")
    return cards[:20]


def parse_proxies(raw) -> list[str]:
    values = raw if isinstance(raw, list) else re.split(r"[\r\n,]+", str(raw or ""))
    result = []
    for value in values:
        item = str(value or "").strip()
        if item and item not in result:
            result.append(item)
    return result[:100]


def update_job(job_id: str, **updates) -> dict | None:
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return None
        job.update(updates)
        job["updated_at"] = time.time()
        return dict(job)


def job_cancelled(job_id: str) -> bool:
    with _lock:
        return bool((_jobs.get(job_id) or {}).get("cancel_requested"))


def stop_if_cancelled(job_id: str) -> None:
    if job_cancelled(job_id):
        raise InterruptedError("任务已停止")


def run_job(job_id: str) -> None:
    with _lock:
        job = _jobs.get(job_id)
    if not job:
        return
    try:
        update_job(job_id, status="running", progress=8, stage="读取账号任务", message="正在读取短链和原账号任务信息")
        add_log(job_id, "info", "读取菲律宾短链与原账号会话")
        stop_if_cancelled(job_id)
        snapshot = reg_bridge_get("/api/internal/ph-short/session", {"task_id": job["task_id"]})

        update_job(job_id, progress=20, stage="校验短链", message="正在核对 Checkout、币种和金额")
        stop_if_cancelled(job_id)
        short_url, processor, checkout_session_id = validate_short_url(snapshot.get("short_url"))
        currency = str(snapshot.get("currency") or "PHP").upper()
        if currency != "PHP":
            raise RuntimeError(f"短链币种不匹配：{currency or '未知'}")
        amount = int(snapshot.get("amount") or 0)
        if amount < 0:
            raise RuntimeError("短链金额不正确")

        update_job(job_id, progress=28, stage="检查账号环境", message="正在确认原任务仍有可用账号环境")
        stop_if_cancelled(job_id)
        has_account_context = bool(
            str(snapshot.get("access_token") or "").strip()
            or str(snapshot.get("session_token") or "").strip()
            or snapshot.get("session_cookies")
        )
        if not has_account_context:
            raise RuntimeError("原任务账号环境已失效，请先在账号页刷新后重新提取短链")

        user_proxy_pool = list(job.get("_proxies") or [])
        proxy_candidates: list[str] = []
        proxy_source = "user_pool" if user_proxy_pool else ""
        if user_proxy_pool:
            proxy_candidates.extend(user_proxy_pool)
        else:
            checkout_proxy = str(snapshot.get("checkout_proxy") or "").strip()
            if checkout_proxy:
                proxy_candidates.append(checkout_proxy)
                proxy_source = "checkout_sticky_us"
                add_log(job_id, "info", "Reusing the original US checkout session")
            if not str(job.get("_confirmation_token") or "").strip():
                for _ in range(2):
                    try:
                        generated = reg_bridge_get("/api/internal/ph-short/proxy", {"country": "US"})
                        candidate = str(generated.get("proxy") or "").strip()
                        if candidate and candidate not in proxy_candidates:
                            proxy_candidates.append(candidate)
                    except Exception as exc:
                        add_log(job_id, "warn", f"US fallback proxy fetch failed: {type(exc).__name__}")
            else:
                add_log(job_id, "info", "ConfirmationToken is locked to the original Checkout proxy")
        if not proxy_candidates:
            raise RuntimeError("No usable payment proxy is available")
        proxy = proxy_candidates[0]
        if not proxy_source:
            proxy_source = "auto_us"
        update_job(job_id, _selected_proxy=proxy, _proxy_source=proxy_source)
        payload = {
            "short_url": short_url,
            "processor_entity": processor,
            "checkout_session_id": checkout_session_id,
            "access_token": snapshot.get("access_token"),
            "platform_account_id": str(snapshot.get("platform_account_id") or ""),
            "session_cookies": snapshot.get("session_cookies") or {},
            "user_agent": str(snapshot.get("user_agent") or ""),
            "checkout_device_id": str(snapshot.get("checkout_device_id") or ""),
            "checkout_platform_session_id": str(snapshot.get("checkout_platform_session_id") or ""),
            "email": str(snapshot.get("email") or job.get("account_email") or ""),
            "proxy": proxy,
            "proxies": proxy_candidates,
            "cards": list(job.get("_cards") or []),
            "saved_payment_method_id": str(job.get("_saved_payment_method_id") or ""),
            "confirmation_token": str(job.get("_confirmation_token") or ""),
            "preconfirmed_checkout": dict(job.get("_preconfirmed_checkout") or {}),
            "card_retry_count": int(job.get("_card_retry_count", 2)),
            "card_retry_delay": 1,
        }
        update_job(job_id, progress=36, stage="初始化 Stripe", message="正在初始化现有 PH Checkout")
        process = subprocess.Popen(
            [GATEWAY_PYTHON, PROTOCOL_HELPER],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        with _lock:
            if job_id in _jobs:
                _jobs[job_id]["_process"] = process
        assert process.stdin is not None and process.stdout is not None
        process.stdin.write(json.dumps(payload, ensure_ascii=False))
        process.stdin.close()
        result = {}
        last_error = ""
        for line in process.stdout:
            stop_if_cancelled(job_id)
            text = line.strip()
            if not text:
                continue
            try:
                event = json.loads(text)
            except Exception:
                add_log(job_id, "info", text)
                continue
            if event.get("type") == "log":
                level = str(event.get("level") or "info")
                message = str(event.get("message") or "")
                add_log(job_id, level, message)
                lower = message.lower()
                if "oaics session resolved" in lower:
                    update_job(job_id, progress=48, stage="Resolve Checkout", message="Loading Stripe Elements context")
                elif "elements session initialized" in lower or "billing snapshot" in lower:
                    update_job(job_id, progress=62, stage="Initialize payment", message="Preparing the saved PaymentMethod")
                elif "paymentmethod created" in lower:
                    update_job(job_id, progress=74, stage="Prepare authorization", message="PaymentMethod is ready for Checkout")
                elif "confirmationtoken created" in lower:
                    update_job(job_id, progress=82, stage="Submit payment", message="Submitting the Checkout confirmation")
                elif "payment succeeded" in lower:
                    update_job(job_id, progress=96, stage="Payment complete", message="Payment succeeded; finalizing authorization")
                elif "post-payment card binding status" in lower:
                    update_job(job_id, progress=98, stage="Finalize", message="Checking the final account binding")
                elif "checkout confirm returned" in lower:
                    update_job(job_id, progress=90, stage="Checkout confirmed", message="Confirming the Stripe Intent")
                elif "submit platform checkout approval" in lower:
                    update_job(job_id, progress=94, stage="Checkout approval", message="Submitting final approval and confirming again")
            elif event.get("type") == "result":
                result = dict(event.get("result") or {})
            elif event.get("type") == "error":
                last_error = str(event.get("error") or "")
        code = process.wait(timeout=10)
        with _lock:
            if job_id in _jobs:
                _jobs[job_id]["_process"] = None
        if code != 0 or not result:
            clean_error = last_error or f"Protocol helper exited with code {code}"
            if clean_error.startswith("RuntimeError: "):
                clean_error = clean_error[len("RuntimeError: "):]
            raise RuntimeError(clean_error)
        result.update({
            "short_url": short_url,
            "processor_entity": processor,
            "checkout_session_id": checkout_session_id,
            "amount_minor": amount,
            "currency": "PHP",
            "billing_country": "PH",
            "account_email": str(snapshot.get("email") or job.get("account_email") or ""),
            "protocol_mode": "stripe_checkout_protocol",
        })
        if result.get("status") == "verification_required":
            update_job(
                job_id,
                status="verification_required",
                progress=92,
                stage="等待支付验证",
                message="支付方式需要额外验证，完成后点击继续确认",
                result=result,
                _resume_payload={
                    "mode": "resume",
                    "checkout_session_id": checkout_session_id,
                    "stripe_publishable_key": str(result.get("stripe_publishable_key") or ""),
                    "intent_type": str(result.get("intent_type") or ""),
                    "intent_client_secret": str(result.get("intent_client_secret") or ""),
                    "proxy": proxy,
                    "session_cookies": snapshot.get("session_cookies") or {},
                },
            )
        else:
            update_job(job_id, status="ready", progress=100, stage="支付完成", message="菲律宾 Checkout 协议支付完成", result=result, finished_at=time.time())
    except InterruptedError as exc:
        with _lock:
            process = (_jobs.get(job_id) or {}).get("_process")
        if process and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        update_job(
            job_id,
            status="cancelled",
            progress=100,
            stage="已停止",
            message=str(exc),
            finished_at=time.time(),
        )
    except Exception as exc:
        add_log(job_id, "error", f"{type(exc).__name__}: {exc}")
        update_job(
            job_id,
            status="error",
            progress=100,
            stage="执行失败",
            error=str(exc),
            message="任务执行失败",
            finished_at=time.time(),
        )


def run_resume_job(job_id: str) -> None:
    with _lock:
        job = _jobs.get(job_id)
        payload = dict((job or {}).get("_resume_payload") or {})
        previous_result = dict((job or {}).get("result") or {})
    if not job or not payload:
        return
    try:
        update_job(job_id, status="running", progress=94, stage="确认验证结果", message="正在轮询原 Checkout 的最终状态", error="")
        process = subprocess.Popen(
            [GATEWAY_PYTHON, PROTOCOL_HELPER],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            bufsize=1,
        )
        with _lock:
            if job_id in _jobs:
                _jobs[job_id]["_process"] = process
        assert process.stdin is not None and process.stdout is not None
        process.stdin.write(json.dumps(payload, ensure_ascii=False))
        process.stdin.close()
        result: dict = {}
        last_error = ""
        for line in process.stdout:
            stop_if_cancelled(job_id)
            text = line.strip()
            if not text:
                continue
            try:
                event = json.loads(text)
            except Exception:
                add_log(job_id, "info", text)
                continue
            if event.get("type") == "log":
                add_log(job_id, str(event.get("level") or "info"), str(event.get("message") or ""))
            elif event.get("type") == "result":
                result = dict(event.get("result") or {})
            elif event.get("type") == "error":
                last_error = str(event.get("error") or "")
        code = process.wait(timeout=10)
        with _lock:
            if job_id in _jobs:
                _jobs[job_id]["_process"] = None
        if code != 0 or not result:
            raise RuntimeError(last_error or f"协议支付续跑进程退出：{code}")
        merged = {**previous_result, **result}
        if result.get("status") == "verification_required":
            update_job(job_id, status="verification_required", progress=94, stage="等待支付验证", message="尚未检测到验证完成，可稍后再次继续确认", result=merged)
            return
        update_job(job_id, status="ready", progress=100, stage="支付完成", message="菲律宾 Checkout 已确认到账", result=merged, finished_at=time.time())
    except InterruptedError as exc:
        with _lock:
            process = (_jobs.get(job_id) or {}).get("_process")
        if process and process.poll() is None:
            try:
                process.terminate()
            except Exception:
                pass
        update_job(job_id, status="cancelled", progress=100, stage="已停止", message=str(exc), finished_at=time.time())
    except Exception as exc:
        add_log(job_id, "error", f"{type(exc).__name__}: {exc}")
        update_job(job_id, status="error", progress=100, stage="最终确认失败", error=str(exc), finished_at=time.time())
def request_script_root(value: str | None) -> str:
    root = str(value or "").rstrip("/")
    return root




def _decode_access_token_claims(access_token: str) -> dict:
    token = str(access_token or "").strip()
    parts = token.split(".")
    if len(parts) < 2:
        raise ValueError("AT_FORMAT_INVALID")
    segment = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        claims = json.loads(base64.urlsafe_b64decode(segment.encode("ascii")).decode("utf-8"))
    except Exception as exc:
        raise ValueError("AT_PAYLOAD_INVALID") from exc
    if not isinstance(claims, dict):
        raise ValueError("AT_PAYLOAD_INVALID")
    return claims


def _external_at_identity(access_token: str) -> tuple[str, str, str]:
    claims = _decode_access_token_claims(access_token)
    auth = claims.get("https://api.vendor.example.com/auth") or {}
    profile = claims.get("https://api.vendor.example.com/profile") or {}
    if not isinstance(auth, dict):
        auth = {}
    if not isinstance(profile, dict):
        profile = {}
    account_id = str(auth.get("platform_account_id") or claims.get("platform_account_id") or claims.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("AT_ACCOUNT_ID_MISSING")
    token_hash = hashlib.sha256(access_token.encode("utf-8")).hexdigest()
    email = str(profile.get("email") or claims.get("email") or "").strip().lower()
    if not email or "@" not in email:
        email = f"external-{token_hash[:16]}@example.com"
    record_id = hashlib.sha256(("external-at:" + account_id).encode("utf-8")).hexdigest()[:12]
    return record_id, email, account_id


def ensure_external_at_account(access_token: str) -> str:
    token = str(access_token or "").strip()
    if len(token) < 300 or len(token) > 30000:
        raise ValueError("AT_FORMAT_INVALID")
    _record_id, email, _account_id = _external_at_identity(token)
    # External ATs are decoded in memory only. They are never appended to the
    # APP.example account archive.
    return email


def resolve_card_bind_email(body: dict | None = None) -> str:
    body = body or {}
    requested_id = str(body.get("record_id") or request.args.get("record_id") or "").strip()
    requested_email = str(body.get("email") or request.args.get("email") or "").strip().lower()
    requested_at = str(body.get("access_token") or body.get("at") or request.args.get("access_token") or "").strip()
    if not requested_id and not requested_email and not requested_at:
        return CARD_BIND_ACCOUNT_EMAIL
    matched_email = ""
    if ACCOUNT_FILE.exists():
        with ACCOUNT_FILE.open(encoding="utf-8", errors="ignore") as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                item_id = str(item.get("id") or "").strip()
                item_email = str(item.get("email") or "").strip().lower()
                item_at = str(item.get("access_token") or "").strip()
                if ((requested_id and item_id == requested_id) or
                    (requested_email and item_email == requested_email) or
                    (requested_at and item_at and hmac.compare_digest(requested_at, item_at))):
                    matched_email = item_email
                    break
    if matched_email:
        return matched_email
    if requested_at:
        return ensure_external_at_account(requested_at)
    raise ValueError("ACCOUNT_NOT_FOUND")


@app.get("/card-long/")
def card_long_page():
    return render_template("card-long-flow.html")


def _find_protocol_publishable_key(value) -> str:
    pattern = re.compile(r"pk_(?:live|test)_[A-Za-z0-9]{24,}")
    if isinstance(value, dict):
        for name in ("stripe_publishable_key", "publishable_key", "public_key", "key"):
            candidate = str(value.get(name) or "").strip()
            if pattern.fullmatch(candidate):
                return candidate
        for item in value.values():
            found = _find_protocol_publishable_key(item)
            if found:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _find_protocol_publishable_key(item)
            if found:
                return found
    elif isinstance(value, str):
        match = pattern.search(value)
        if match:
            return match.group(0)
    return ""


def initialize_card_stripe_via_checkout(record_id: str, proxy_pool: list[str], access_token: str = "") -> dict:
    # Creating the temporary Checkout is the initialization side effect.  Its
    # response key is optional because a fresh payment_method call follows it.
    token = str(access_token or "").strip()
    if not token:
        raise RuntimeError("AT_REQUIRED_FOR_CHECKOUT_KEY")
    status, created = _gateway_request("/api/checkout", "POST", {
        "token": token, "plan": "plus", "link_type": "hosted", "country": "US",
        "purpose": "stripe_elements_bootstrap",
        "entry_proxies": list(proxy_pool), "exit_proxies": list(proxy_pool),
        "entry_proxy_country": "US", "exit_proxy_country": "US", "use_promo": False,
        "promo_country": "US", "retry_count": 3, "use_sen": True, "use_so": True,
        "allow_missing_customer_session": True,
    })
    pay_job_id = str((created or {}).get("job_id") or "")
    if status >= 400 or not pay_job_id:
        raise RuntimeError(str((created or {}).get("error") or "CHECKOUT_KEY_TASK_CREATE_FAILED"))
    observed_key = ""
    for _ in range(720):
        pstatus, progress = _gateway_request("/api/checkout-progress", params={"job_id": pay_job_id})
        if pstatus >= 400:
            raise RuntimeError(str((progress or {}).get("error") or "CHECKOUT_KEY_TASK_QUERY_FAILED"))
        progress = progress if isinstance(progress, dict) else {}
        state = str(progress.get("status") or "")
        observed_key = observed_key or _find_protocol_publishable_key(progress)
        if state == "done":
            return {
                "pay_job_id": pay_job_id,
                "publishable_key": observed_key or _find_protocol_publishable_key(progress.get("result") or {}),
                "result": progress.get("result") or {},
            }
        if state in {"error", "failed", "cancelled"}:
            raise RuntimeError(str(progress.get("error") or progress.get("message") or "CHECKOUT_KEY_TASK_FAILED"))
        time.sleep(1)
    raise RuntimeError("CHECKOUT_INITIALIZATION_TIMEOUT")


def _run_card_bind_session_helper(account_email: str, selected_proxy: str, access_token: str) -> tuple[int, dict]:
    try:
        completed = subprocess.run(
            [GATEWAY_PYTHON, CARD_BIND_HELPER, account_email, selected_proxy, access_token],
            capture_output=True, text=True, timeout=70, check=False,
        )
    except FileNotFoundError:
        return 127, {"ok": False, "error": "HELPER_PYTHON_NOT_FOUND",
                     "detail": f"Python interpreter not found: {GATEWAY_PYTHON}"}
    except subprocess.TimeoutExpired:
        return 124, {"ok": False, "error": "BIND_SESSION_TIMEOUT",
                     "detail": "card_bind_session helper timed out"}
    try:
        payload = json.loads((completed.stdout or "{}").strip().splitlines()[-1])
    except Exception:
        stderr = str(completed.stderr or "").strip().splitlines()
        payload = {
            "ok": False,
            "error": "BIND_SESSION_INVALID_RESPONSE",
            "detail": (stderr[-1] if stderr else "helper returned no JSON")[:300],
        }
    return completed.returncode, payload


def _key_probe_public(job: dict) -> dict:
    return {
        "id": job.get("id"), "status": job.get("status"), "progress": int(job.get("progress") or 0),
        "message": job.get("message") or "", "error": job.get("error") or "",
        "publishable_key": job.get("publishable_key") or "",
        "session": dict(job.get("session") or {}),
    }


def _run_key_probe(probe_id: str):
    with _lock: job = dict(_key_probe_jobs.get(probe_id) or {})
    if not job: return
    try:
        token = str(job.get("_access_token") or "")
        account_email = str(job.get("_account_email") or "")
        selected_proxy = str(job.get("_selected_proxy") or "")
        proxy_pool = [selected_proxy] + [
            str(item or "") for item in list(job.get("_proxies") or [])
            if str(item or "") and str(item or "") != selected_proxy
        ]
        with _lock:
            _key_probe_jobs[probe_id].update(status="running", progress=12, message="Creating temporary Checkout to initialize Stripe")
        initialized = initialize_card_stripe_via_checkout(
            job.get("record_id") or "", [selected_proxy] if selected_proxy else proxy_pool, token,
        )
        initialized_key = str(initialized.get("publishable_key") or "")
        last_detail = ""
        refreshed = {}
        resolved_key = ""
        for attempt in range(1, 9):
            probe_proxy = proxy_pool[(attempt - 1) % len(proxy_pool)] if proxy_pool else selected_proxy
            with _lock:
                _key_probe_jobs[probe_id].update(
                    progress=min(96, 76 + attempt * 2),
                    message=f"Checkout initialized; refreshing SetupIntent and Stripe key ({attempt}/8)",
                )
            returncode, candidate = _run_card_bind_session_helper(account_email, probe_proxy, token)
            candidate = candidate if isinstance(candidate, dict) else {}
            upstream = int(candidate.get("status") or 0)
            if returncode == 0 and candidate.get("ok") and str(candidate.get("client_secret") or "").startswith("seti_"):
                key = _find_protocol_publishable_key(candidate) or initialized_key
                if str(key).startswith("pk_"):
                    refreshed = candidate
                    resolved_key = key
                    break
                last_detail = "SetupIntent ready but publishable key is still propagating"
            else:
                last_detail = str(candidate.get("detail") or candidate.get("error") or f"HTTP {upstream or 'unknown'}")
                if upstream == 401:
                    raise RuntimeError("AT_INVALIDATED_OR_EXPIRED")
            app.logger.info(
                "key-probe %s: refetch %s/8 pending, upstream=%s detail=%s",
                probe_id, attempt, upstream, last_detail[:160],
            )
            time.sleep(min(2 + attempt, 8))
        if not refreshed:
            raise RuntimeError(f"BIND_SESSION_REFETCH_EXHAUSTED: {last_detail or 'Stripe context did not propagate'}")
        refreshed["publishable_key"] = resolved_key
        refreshed["publishable_key_source"] = "checkout_then_refetch"
        refreshed["pending"] = False
        with _lock:
            _key_probe_jobs[probe_id].update(
                status="done", progress=100, message="Fresh SetupIntent and Stripe key resolved",
                publishable_key=resolved_key, session=refreshed, _access_token="", finished_at=time.time(),
            )
    except Exception as exc:
        with _lock:
            if probe_id in _key_probe_jobs:
                _key_probe_jobs[probe_id].update(status="error", progress=100, message="Stripe initialization/refetch failed", error=f"{type(exc).__name__}: {exc}"[:500], _access_token="", finished_at=time.time())


def _start_key_probe(record_id: str, account_email: str, selected_proxy: str, access_token: str, proxies: list[str], initial_session: dict | None = None) -> dict:
    probe_id = secrets.token_hex(6); now = time.time()
    job = {"id": probe_id, "record_id": record_id, "status": "queued", "progress": 2, "message": "Stripe initialization queued", "error": "", "publishable_key": "", "session": dict(initial_session or {}), "created_at": now, "finished_at": None, "_account_email": account_email, "_selected_proxy": selected_proxy, "_access_token": access_token, "_proxies": list(proxies)}
    with _lock:
        _key_probe_jobs[probe_id] = job
        if len(_key_probe_jobs) > 100:
            finished = sorted((x for x in _key_probe_jobs.values() if x.get("status") in {"done", "error"}), key=lambda x: x.get("created_at", 0))
            for old in finished[:max(0, len(_key_probe_jobs)-100)]: _key_probe_jobs.pop(str(old.get("id") or ""), None)
    threading.Thread(target=_run_key_probe, args=(probe_id,), daemon=True, name=f"key-probe-{probe_id}").start()
    return job


@app.get("/api/card-bind/key-probe/<probe_id>")
def card_bind_key_probe(probe_id: str):
    value = str(probe_id or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", value):
        return jsonify({"ok": False, "error": "INVALID_KEY_PROBE_ID"}), 400
    with _lock:
        job = _key_probe_jobs.get(value)
        payload = _key_probe_public(job) if job else None
    if not payload:
        return jsonify({"ok": False, "error": "KEY_PROBE_NOT_FOUND"}), 404
    return jsonify({"ok": True, "probe": payload})


def normalize_user_proxy(raw: str) -> str:
    value = str(raw or "").strip()
    if not value:
        raise ValueError("PROXY_REQUIRED")
    if "://" in value:
        parsed = urlsplit(value)
        scheme = parsed.scheme.lower()
        if scheme not in {"http", "https", "socks5", "socks5h"}:
            raise ValueError("UNSUPPORTED_PROXY_SCHEME")
        # Resolve DNS at the proxy (socks5h) instead of locally (socks5) so the
        # exit node's region is used for platform.example.com; local resolution triggers
        # TLS resets (curl 35) with residential SOCKS proxies.
        if scheme == "socks5":
            scheme = "socks5h"
        if not parsed.hostname or parsed.port is None:
            raise ValueError("PROXY_HOST_OR_PORT_MISSING")
        auth = ""
        if parsed.username is not None:
            auth = f"{quote(unquote(parsed.username), safe='')}:{quote(unquote(parsed.password or ''), safe='')}@"
        host = f"[{parsed.hostname}]" if ":" in parsed.hostname else parsed.hostname
        return f"{scheme}://{auth}{host}:{parsed.port}"
    if value.count("@") == 1:
        left, right = value.split("@", 1)
        if left.count(":") == 1 and right.count(":") >= 1:
            username, password = left.split(":", 1)
            host, port = right.rsplit(":", 1)
        else:
            host, port = left.rsplit(":", 1)
            username, password = right.split(":", 1)
        if not port.isdigit():
            raise ValueError("PROXY_PORT_INVALID")
        return f"http://{quote(username, safe='')}:{quote(password, safe='')}@{host}:{port}"
    parts = value.split(":")
    if len(parts) >= 4 and parts[1].isdigit():
        host, port, username = parts[0], parts[1], parts[2]
        password = ":".join(parts[3:])
        return f"http://{quote(username, safe='')}:{quote(password, safe='')}@{host}:{port}"
    if len(parts) == 2 and parts[1].isdigit():
        return f"http://{value}"
    raise ValueError("PROXY_FORMAT_INVALID")


def normalize_user_proxy_pool(raw) -> list[str]:
    values = raw if isinstance(raw, list) else str(raw or "").replace("\r", "").split("\n")
    result = []
    seen = set()
    for index, item in enumerate(values, 1):
        text = str(item or "").strip()
        if not text:
            continue
        try:
            proxy = normalize_user_proxy(text)
        except Exception as exc:
            raise ValueError(f"PROXY_LINE_{index}: {exc}") from exc
        if proxy not in seen:
            seen.add(proxy); result.append(proxy)
    if not result:
        raise ValueError("PROXY_POOL_REQUIRED")
    if len(result) > 500:
        raise ValueError("PROXY_POOL_MAX_500")
    return result


def card_helper_error_response(payload: dict, fallback_status: int = 502):
    result = dict(payload or {})
    if not result.get("error"):
        result["error"] = "CARD_PROTOCOL_EMPTY_RESPONSE"
    app.logger.warning(
        "card helper error: error=%s status=%s detail=%s",
        result.get("error"), result.get("status"), str(result.get("detail") or "")[:400],
    )
    upstream = int(result.get("status") or 0)
    if upstream == 401:
        result["error"] = "AT_INVALIDATED_OR_EXPIRED"
        result["upstream_status"] = upstream
        return jsonify(result), 422
    if upstream == 403:
        result["error"] = "UPSTREAM_ROUTE_BLOCKED"
        result["upstream_status"] = upstream
        return jsonify(result), 503
    if upstream == 429:
        result["error"] = result.get("error") or "UPSTREAM_RATE_LIMITED"
        return jsonify(result), 429
    if upstream >= 500:
        return jsonify(result), 503
    return jsonify(result), fallback_status


@app.post("/api/card-bind/default")
def card_bind_default():
    body = request.get_json(silent=True) or {}
    payment_method_id = str(body.get("payment_method_id") or "").strip()
    if not re.fullmatch(r"pm_[A-Za-z0-9]+", payment_method_id):
        return jsonify({"ok": False, "error": "INVALID_PAYMENT_METHOD"}), 400
    try:
        account_email = resolve_card_bind_email(body)
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    try:
        selected_proxy = normalize_user_proxy(body.get("proxy"))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    submitted_at = str(body.get("access_token") or body.get("at") or "").strip()
    completed = subprocess.run(
        [GATEWAY_PYTHON, CARD_DEFAULT_HELPER, account_email, payment_method_id, selected_proxy, submitted_at],
        capture_output=True, text=True, timeout=90, check=False,
    )
    try:
        payload = json.loads((completed.stdout or "{}").strip().splitlines()[-1])
    except Exception:
        payload = {"ok": False, "error": "SET_DEFAULT_INVALID_RESPONSE"}
    if completed.returncode != 0 or not payload.get("ok"):
        return card_helper_error_response(payload)
    return jsonify(payload)

@app.post("/api/card-flow/context")
def card_flow_context():
    body = request.get_json(silent=True) or {}
    task_id = str(body.get("task_id") or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", task_id):
        return jsonify({"ok": False, "error": "Checkout task ID is invalid"}), 400
    try:
        snapshot = reg_bridge_get("/api/internal/ph-short/session", {"task_id": task_id})
        completed = subprocess.run(
            [GATEWAY_PYTHON, CARD_CHECKOUT_CONTEXT_HELPER],
            input=json.dumps(snapshot, ensure_ascii=False),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=90,
            check=False,
        )
        try:
            payload = json.loads((completed.stdout or "{}").strip().splitlines()[-1])
        except Exception:
            payload = {"ok": False, "error": "Checkout context response is invalid"}
        if completed.returncode != 0 or not payload.get("ok"):
            detail = (completed.stderr or "").strip().splitlines()
            return jsonify({"ok": False, "error": payload.get("error") or (detail[-1] if detail else "Checkout context failed")}), 502
        return jsonify(payload)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 502


@app.post("/api/card-flow/server-token")
def card_flow_server_token():
    body = request.get_json(silent=True) or {}
    task_id = str(body.get("task_id") or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", task_id):
        return jsonify({"ok": False, "error": "Checkout task ID is invalid"}), 400
    try:
        snapshot = reg_bridge_get("/api/internal/ph-short/session", {"task_id": task_id})
        completed = subprocess.run(
            [GATEWAY_PYTHON, CARD_SERVER_TOKEN_HELPER],
            input=json.dumps(snapshot, ensure_ascii=False),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            check=False,
        )
        lines = (completed.stdout or "").strip().splitlines()
        try:
            payload = json.loads(lines[-1] if lines else "{}")
        except Exception:
            payload = {"ok": False, "error": "Server ConfirmationToken response is invalid"}
        if completed.returncode != 0 or not payload.get("ok"):
            detail = (completed.stderr or "").strip().splitlines()
            error_code = str(payload.get("error_code") or "")
            status_code = 409 if error_code == "OFFER_NOT_ELIGIBLE" else 502
            return jsonify({
                "ok": False,
                "error_code": error_code,
                "error": payload.get("error") or (detail[-1] if detail else "Server ConfirmationToken failed"),
                "offer_check_ok": payload.get("offer_check_ok"),
                "offer_eligible": payload.get("offer_eligible"),
            }), status_code
        return jsonify(payload)
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)}), 502


@app.get("/card-flow/")
def card_flow_page():
    return render_template("card-flow.html")



def _checkout_result_context(result: dict, entry_proxies: list[str], source: str = "") -> dict:
    session_id = str(result.get("checkout_session_id") or "").strip()
    if not session_id:
        return {}
    try: attempt = max(1, int(result.get("attempt") or 1))
    except Exception: attempt = 1
    selected_proxy = str(result.get("checkout_proxy") or result.get("entry_proxy") or "").strip()
    if not selected_proxy and entry_proxies:
        selected_proxy = str(entry_proxies[(attempt - 1) % len(entry_proxies)] or "").strip()
    cookies = result.get("session_cookies") if isinstance(result.get("session_cookies"), dict) else {}
    return {
        "checkout_session_id": session_id,
        "checkout_url": str(result.get("checkout_url") or result.get("short_link") or result.get("short_url") or ""),
        "processor_entity": str(result.get("processor_entity") or "vendor_entity"),
        "checkout_proxy": selected_proxy,
        "checkout_device_id": str(result.get("checkout_device_id") or ""),
        "checkout_platform_session_id": str(result.get("checkout_platform_session_id") or ""),
        "checkout_user_agent": str(result.get("checkout_user_agent") or ""),
        "session_cookies": dict(cookies),
        "created_at": time.time(),
        "source": source,
    }


def _persist_checkout_context(context: dict) -> None:
    if not context or not context.get("checkout_session_id"):
        return
    CHECKOUT_CONTEXT_PATH.parent.mkdir(parents=True, exist_ok=True)
    with _lock:
        rows = []
        if CHECKOUT_CONTEXT_PATH.exists():
            for line in CHECKOUT_CONTEXT_PATH.read_text(encoding="utf-8", errors="ignore").splitlines():
                try: item = json.loads(line)
                except Exception: continue
                if not isinstance(item, dict): continue
                if str(item.get("checkout_session_id") or "") == str(context.get("checkout_session_id") or ""): continue
                if float(item.get("created_at") or 0) < time.time() - 7 * 86400: continue
                rows.append(item)
        rows.append(dict(context))
        CHECKOUT_CONTEXT_PATH.write_text("".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\\n" for item in rows[-1000:]), encoding="utf-8")


def _lookup_checkout_context(session_id: str) -> dict:
    target = str(session_id or "").strip()
    if not target: return {}
    candidates = []
    for path in (
        ROOT / "pay" / "data" / "ph_short_contexts.jsonl",
        Path("/opt/payment-gateway/data/ph_short_contexts.jsonl"),
    ):
        if not path.exists():
            continue
        for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            try: item = json.loads(line)
            except Exception: continue
            if isinstance(item, dict) and str(item.get("checkout_session_id") or "") == target:
                candidates.append(item)
    if CHECKOUT_CONTEXT_PATH.exists():
        for line in CHECKOUT_CONTEXT_PATH.read_text(encoding="utf-8", errors="ignore").splitlines():
            try: item = json.loads(line)
            except Exception: continue
            if isinstance(item, dict) and str(item.get("checkout_session_id") or "") == target:
                candidates.append(item)
    # Backfill links created by the older reg quick-checkout path.
    legacy_tasks = REG_LEGACY_TASK_FILE
    if legacy_tasks.exists():
        for line in legacy_tasks.read_text(encoding="utf-8", errors="ignore").splitlines():
            try: task = json.loads(line)
            except Exception: continue
            result = task.get("result") if isinstance(task.get("result"), dict) else {}
            if str(result.get("checkout_session_id") or "") != target: continue
            options = task.get("options") if isinstance(task.get("options"), dict) else {}
            entry = [str(item).strip() for item in (options.get("entry_proxies") or []) if str(item).strip()]
            context = _checkout_result_context(result, entry, "legacy_reg_task")
            context["created_at"] = float(task.get("finished_at") or task.get("created_at") or time.time())
            candidates.append(context)
    if not candidates: return {}
    return dict(max(candidates, key=lambda item: float(item.get("created_at") or 0)))


def _lookup_reg_account_session(email: str, account_id: str) -> dict:
    target_email = str(email or "").strip().lower()
    target_account = str(account_id or "").strip()
    source = ACCOUNT_FILE
    if not source.exists():
        return {}
    matches = []
    for line in source.read_text(encoding="utf-8", errors="ignore").splitlines():
        try:
            row = json.loads(line)
        except Exception:
            continue
        if not isinstance(row, dict):
            continue
        same_email = target_email and str(row.get("email") or "").strip().lower() == target_email
        same_account = target_account and str(row.get("account_id") or "").strip() == target_account
        if not (same_email or same_account):
            continue
        cookies = row.get("session_cookies") if isinstance(row.get("session_cookies"), dict) else {}
        if cookies:
            matches.append(row)
    if not matches:
        return {}
    latest = max(matches, key=lambda row: str(row.get("last_checked_at") or row.get("created_at") or ""))
    return {str(k): str(v) for k, v in dict(latest.get("session_cookies") or {}).items() if str(k) and str(v)}


def _gateway_request(path: str, method: str = "GET", payload: dict | None = None, params: dict | None = None) -> tuple[int, dict]:
    if not GATEWAY_INTERNAL_KEY:
        raise RuntimeError("GATEWAY_INTERNAL_KEY_MISSING")
    query = f"?{urlencode(params or {})}" if params else ""
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8") if payload is not None else None
    headers = {"X-Gateway-Internal-Key": GATEWAY_INTERNAL_KEY, "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json"
    req = Request(f"{GATEWAY_INTERNAL_BASE}{path}{query}", data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=35) as response:
            raw = response.read().decode("utf-8", errors="replace")
            return int(response.status), json.loads(raw or "{}")
    except Exception as exc:
        status = int(getattr(exc, "code", 502) or 502)
        raw = ""
        if hasattr(exc, "read"):
            try: raw = exc.read().decode("utf-8", errors="replace")
            except Exception: raw = ""
        try: body = json.loads(raw or "{}")
        except Exception: body = {"error": raw[:300] or str(exc)}
        return status, body


def _extend_sticky_proxy_ttl(value: str, minutes: int = 120) -> str:
    proxy = str(value or "").strip()
    if not proxy:
        return proxy
    if re.search(r"-t-\d+", proxy):
        return re.sub(r"-t-\d+", f"-t-{int(minutes)}", proxy, count=1)
    return proxy


def _card_checkout_public(job: dict) -> dict:
    return {
        "id": job.get("id"), "task_id": job.get("id"), "status": job.get("status"),
        "progress": int(job.get("progress") or 0), "message": job.get("message") or "",
        "error": job.get("error") or "", "result": dict(job.get("result") or {}),
        "created_at": job.get("created_at"), "finished_at": job.get("finished_at"),
    }


def _shorten_card_flow_checkout_result(result: dict) -> dict:
    """Normalize hosted pay.vendor.example.com URLs to platform.example.com/checkout short links.

    Card-flow '提链' should surface the same canonical short form the reference
    returns (via ph_short). Our merged /pay hosted path only emits the long
    Stripe URL; convert it here before persisting/storing the task result.
    """
    if not isinstance(result, dict):
        return {}
    out = dict(result)
    raw = (
        out.get("checkout_url")
        or out.get("short_link")
        or out.get("short_url")
        or out.get("url")
        or ""
    )
    short_url = ""
    processor = ""
    session_id = ""
    try:
        short_url, processor, session_id = _normalize_protocol_checkout_url(raw)
    except ValueError:
        session_id = str(out.get("checkout_session_id") or "").strip()
        if session_id and re.fullmatch(r"(?:oaics_|cs_)[A-Za-z0-9_-]{12,}", session_id):
            short_url = f"https://platform.example.com/checkout/vendor_entity/{session_id}"
            processor = "vendor_entity"
        else:
            return out
    out["checkout_url"] = short_url
    out["short_link"] = short_url
    out["short_url"] = short_url
    if processor:
        out["processor_entity"] = str(out.get("processor_entity") or processor)
    if session_id and not out.get("checkout_session_id"):
        out["checkout_session_id"] = session_id
    return out


def _run_card_flow_protocol_payment(task_id: str, access_token: str, checkout_result: dict, entry_proxies: list[str], mode: str = "run") -> dict:
    """Prepare and/or confirm subscription after PH short-link extraction.

    mode="run"     -> prepare + confirm in one shot (original single-account path).
    mode="prepare" -> stop at the 'prepared' barrier (bind/Checkout/CustomerSession/
                      ConfirmationToken all ready), return the private prepared context
                      WITHOUT confirming the subscription. The caller then confirms
                      later via _run_prepared_card_confirm when the release event fires.
    """
    short_url, processor, session_id = _normalize_protocol_checkout_url(
        checkout_result.get("checkout_url")
        or checkout_result.get("short_link")
        or checkout_result.get("short_url")
        or ""
    )
    origin = _lookup_checkout_context(session_id) or {}
    identity = _protocol_token_identity(access_token)
    origin_cookies = dict(origin.get("session_cookies") or {})
    result_cookies = dict(checkout_result.get("session_cookies") or {})
    merged_cookies = dict(origin_cookies)
    merged_cookies.update(result_cookies)
    account_cookies = _lookup_reg_account_session(identity.get("email") or "", identity.get("account_id") or "")
    if account_cookies:
        base = dict(account_cookies)
        base.update(merged_cookies)
        merged_cookies = base

    proxies: list[str] = []
    for candidate in (
        origin.get("checkout_proxy"),
        checkout_result.get("checkout_proxy"),
        *(entry_proxies or []),
    ):
        text = str(candidate or "").strip()
        if not text:
            continue
        try:
            normalized = normalize_user_proxy(text)
        except Exception:
            continue
        if normalized and normalized not in proxies:
            proxies.append(normalized)
    if not proxies:
        raise RuntimeError("NO_PAYMENT_PROXY_FOR_PROTOCOL_SUBMIT")

    snapshot = {
        "short_url": short_url,
        "processor_entity": processor,
        "checkout_session_id": session_id,
        "access_token": access_token,
        "platform_account_id": identity["account_id"],
        "session_cookies": merged_cookies,
        "user_agent": str(
            origin.get("checkout_user_agent")
            or checkout_result.get("checkout_user_agent")
            or "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
        ),
        "checkout_device_id": str(
            origin.get("checkout_device_id")
            or checkout_result.get("checkout_device_id")
            or uuid.uuid4()
        ),
        "checkout_platform_session_id": str(
            origin.get("checkout_platform_session_id")
            or checkout_result.get("checkout_platform_session_id")
            or ""
        ),
        "email": identity.get("email") or checkout_result.get("account_email") or "",
        "proxy": proxies[0],
        "checkout_proxy": proxies[0],
        "preserve_checkout_identity": True,
        "context_source": str(origin.get("source") or checkout_result.get("source") or "isolated_card_flow"),
    }
    with _lock:
        if task_id in _card_checkout_jobs:
            _card_checkout_jobs[task_id].update(
                progress=72,
                message="Preparing checkout barrier" if mode == "prepare" else "Submitting payment / confirming subscription",
            )
    proc = subprocess.Popen(
        [GATEWAY_PYTHON, STANDALONE_PAY_HELPER],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
        cwd=str(ROOT),
    )
    with _lock:
        if task_id in _card_checkout_jobs:
            _card_checkout_jobs[task_id]["_pay_process"] = proc
    assert proc.stdin is not None and proc.stdout is not None
    proc.stdin.write(json.dumps({"mode": mode, "snapshot": snapshot, "proxies": proxies}, ensure_ascii=False))
    proc.stdin.close()
    pay_result: dict = {}
    last_error = ""
    for line in proc.stdout:
        text = line.strip()
        if not text:
            continue
        try:
            event = json.loads(text)
        except Exception:
            continue
        if event.get("type") == "log":
            message = str(event.get("message") or "")
            phase = str(event.get("phase") or "")
            with _lock:
                current = _card_checkout_jobs.get(task_id)
                if not current:
                    continue
                if phase == "validate":
                    current.update(progress=76, message=message or "Validating saved card")
                elif phase in {"headless", "headless_done", "prepared"}:
                    current.update(progress=82, message=message or "Preparing checkout context")
                elif phase == "protocol":
                    current.update(progress=90, message=message or "Submitting subscription")
                else:
                    lower = message.lower()
                    if "checkout confirm" in lower:
                        current.update(progress=93, message=message)
                    elif "stripe" in lower and "status=" in lower:
                        current.update(progress=96, message=message)
                    elif message:
                        current.update(message=message)
        elif event.get("type") == "result":
            pay_result = dict(event.get("result") or {})
        elif event.get("type") == "error":
            last_error = str(event.get("error") or "")
    code = proc.wait(timeout=10)
    with _lock:
        if task_id in _card_checkout_jobs:
            _card_checkout_jobs[task_id]["_pay_process"] = None
    if code != 0 or not pay_result:
        raise RuntimeError(last_error or f"PROTOCOL_PAY_HELPER_EXIT_{code}")
    return pay_result


def _run_isolated_card_checkout(task_id: str):
    with _lock: job = dict(_card_checkout_jobs.get(task_id) or {})
    if not job: return
    access_token = str(job.get("_access_token") or "")
    try:
        with _lock: _card_checkout_jobs[task_id].update(status="running", progress=5, message="Validating US/TR proxy pools")
        preflight = subprocess.run(
            [GATEWAY_PYTHON, PROXY_PREFLIGHT_HELPER],
            input=json.dumps({
                "entry": [_extend_sticky_proxy_ttl(item, 120) for item in job["_entry_proxies"]],
                "exit": [_extend_sticky_proxy_ttl(item, 120) for item in job["_exit_proxies"]],
            }, ensure_ascii=False),
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=45, check=False,
        )
        try: checked = json.loads((preflight.stdout or "{}").strip().splitlines()[-1])
        except Exception: checked = {}
        entry_valid = list(checked.get("entry") or [])
        exit_valid = list(checked.get("exit") or [])
        if not entry_valid or not exit_valid:
            raise RuntimeError(
                f"PROXY_PREFLIGHT_FAILED: US {int(checked.get('entry_valid') or 0)}/{int(checked.get('entry_total') or 0)}, "
                f"TR {int(checked.get('exit_valid') or 0)}/{int(checked.get('exit_total') or 0)}"
            )
        with _lock: _card_checkout_jobs[task_id].update(status="running", progress=12, message=f"Proxy preflight passed: US {len(entry_valid)}, TR {len(exit_valid)}")
        # Mirror reference card-flow: ph_short + PH, US entry / TR promo exit.
        payload = {
            "token": access_token, "plan": "plus", "link_type": "ph_short", "country": "PH",
            "entry_proxies": entry_valid, "exit_proxies": exit_valid,
            "entry_proxy_country": "US", "exit_proxy_country": "TR", "use_promo": True,
            "promo_country": "TR", "retry_count": 10, "paired_proxy_rotation": True,
            "allow_missing_customer_session": True,
            "use_sen": True, "use_so": True,
        }
        status, created = _gateway_request("/api/checkout", "POST", payload)
        pay_job_id = str(created.get("job_id") or "")
        if status >= 400 or not pay_job_id:
            raise RuntimeError(str(created.get("error") or f"GATEWAY_HTTP_{status}"))
        with _lock: _card_checkout_jobs[task_id].update(progress=18, message="PH short-link extraction running", _pay_job_id=pay_job_id)
        deadline = time.monotonic() + 15 * 60
        result = {}
        while time.monotonic() < deadline:
            status, progress = _gateway_request("/api/checkout-progress", params={"job_id": pay_job_id})
            if status >= 400: raise RuntimeError(str(progress.get("error") or f"GATEWAY_PROGRESS_HTTP_{status}"))
            state = str(progress.get("status") or "")
            with _lock:
                current = _card_checkout_jobs.get(task_id)
                if not current: return
                current.update(
                    progress=min(68, max(18, int(progress.get("percent") or 0) * 68 // 100)),
                    message=str(progress.get("text") or "PH short-link extraction running"),
                )
            if state == "done":
                result = _shorten_card_flow_checkout_result(
                    progress.get("result") if isinstance(progress.get("result"), dict) else {}
                )
                _persist_checkout_context(_checkout_result_context(result, entry_valid, "isolated_card_flow"))
                break
            if state in {"error", "cancelled"}: raise RuntimeError(str(progress.get("error") or progress.get("text") or "Checkout failed"))
            time.sleep(2)
        else:
            raise TimeoutError("CHECKOUT_TIMEOUT")
        if not result:
            raise RuntimeError("CHECKOUT_RESULT_EMPTY")

        with _lock:
            if task_id not in _card_checkout_jobs:
                return
            _card_checkout_jobs[task_id].update(
                progress=70,
                message="Short link ready; submitting payment",
                result=dict(result),
            )

        defer_confirm = bool(job.get("_defer_confirm"))
        pay_result = _run_card_flow_protocol_payment(
            task_id, access_token, result, entry_valid,
            mode="prepare" if defer_confirm else "run",
        )
        if defer_confirm and str(pay_result.get("status") or "").lower() == "prepared":
            prepared_private = dict(pay_result.get("prepared") or {})
            if not prepared_private:
                raise RuntimeError("PREPARED_CONTEXT_MISSING")
            safe = dict(pay_result.get("safe") or {})
            prepared_at = time.time()
            with _lock:
                if task_id in _card_checkout_jobs:
                    _card_checkout_jobs[task_id].update(
                        status="prepared", progress=72,
                        message="已就绪(prepared)，等待统一放行",
                        result=dict(result), _prepared=prepared_private, _prepared_safe=safe,
                        prepared_at=prepared_at,
                    )
            app.logger.info("card-flow prepared task=%s", task_id)
            return
        payment_status = str(pay_result.get("status") or "").lower()
        final = dict(result)
        final.update({
            "payment_status": payment_status or "unknown",
            "payment_result": pay_result,
            "subscription_ok": payment_status == "success",
            "checkout_url": result.get("checkout_url") or result.get("short_link") or result.get("short_url") or "",
            "short_link": result.get("short_link") or result.get("checkout_url") or "",
            "short_url": result.get("short_url") or result.get("checkout_url") or "",
        })
        if payment_status == "success":
            with _lock:
                if task_id in _card_checkout_jobs:
                    _card_checkout_jobs[task_id].update(
                        status="done", progress=100, message="Payment completed",
                        result=final, finished_at=time.time(), _access_token="",
                    )
            return
        if payment_status == "verification_required":
            with _lock:
                if task_id in _card_checkout_jobs:
                    _card_checkout_jobs[task_id].update(
                        status="done", progress=100,
                        message="Payment requires additional verification",
                        result=final, finished_at=time.time(), _access_token="",
                    )
            return
        raise RuntimeError(
            f"PROTOCOL_PAYMENT_FAILED: status={payment_status or 'unknown'}; "
            f"{pay_result.get('error') or pay_result.get('message') or ''}".strip()
        )
    except Exception as exc:
        with _lock:
            child_job_id = str((_card_checkout_jobs.get(task_id) or {}).get("_pay_job_id") or "")
            child_proc = (_card_checkout_jobs.get(task_id) or {}).get("_pay_process")
        if child_job_id:
            try:
                _gateway_request("/api/checkout-cancel", "POST", {"job_id": child_job_id})
            except Exception:
                pass
        if child_proc is not None:
            try:
                child_proc.kill()
            except Exception:
                pass
        if "VENDOR_CONFIRM_BLOCKED" in str(exc):
            with _lock:
                current = _card_checkout_jobs.get(task_id) or {}
                rebuilds = int(current.get("_confirm_rebuilds") or 0)
                if rebuilds < 1 and current.get("status") != "cancelled":
                    current.update(
                        _confirm_rebuilds=rebuilds + 1,
                        _pay_job_id="",
                        _pay_process=None,
                        progress=12,
                        message="确认被拒；正在重建全新 Checkout/context/token",
                    )
                    should_rebuild = True
                else:
                    should_rebuild = False
            if should_rebuild:
                _run_isolated_card_checkout(task_id)
                return
        with _lock:
            if task_id in _card_checkout_jobs:
                current = _card_checkout_jobs[task_id]
                if current.get("status") != "cancelled":
                    current.update(
                        status="error", progress=100, message="Checkout/payment failed",
                        error=f"{type(exc).__name__}: {exc}"[:500], finished_at=time.time(), _access_token="",
                        _pay_process=None,
                    )


def _pool_account_opened(acc: dict) -> bool:
    """判定号池账号是否「已开通」。
    只有「已成功开通」才剔除：card-flow 成功后回写的 opened=true，或账号本身已是 PLUS/付费套餐。
    「尝试过但仍未开通」不算已开通（不看任何 attempted 标记），因此失败重试仍可再次加载。"""
    if not isinstance(acc, dict):
        return True
    if acc.get("opened") is True:
        return True
    plan = str(acc.get("livePlanType") or acc.get("planType") or "").strip().lower()
    if not plan:
        try:
            from account_manager import decode_jwt_payload
            payload = decode_jwt_payload(acc.get("accessToken")) or {}
            auth = payload.get("https://api.vendor.example.com/auth") or {}
            plan = str(auth.get("platform_plan_type") or "").strip().lower()
        except Exception:
            plan = ""
    # 空 / free / unknown 视为未开通（可加载）；其余非空套餐（plus/pro/team…）视为已开通。
    return plan not in ("", "free", "unknown", "none", "null")


@app.get("/api/card-flow/pool-ats")
def card_flow_pool_ats():
    """从账号号池随机取 N 个「未开通」账号的 AT，供批量直开页面自动填充。
    未开通 = 未标 opened 且非 PLUS；失败重试不排除，只有成功开通才剔除。
    该接口仅供已登录的内部用户使用（公开 /card-link 挂载访问会 401，前端会静默回退）。"""
    import random
    try:
        n = int(request.args.get("n", 30))
    except Exception:
        n = 30
    n = max(1, min(200, n))
    from account_manager import load_probe
    items = load_probe()
    candidates = []
    for a in items:
        if not isinstance(a, dict):
            continue
        at = str(a.get("accessToken") or "").strip()
        if not at:
            continue
        if _pool_account_opened(a):
            continue
        candidates.append({"email": a.get("email") or "", "accessToken": at})
    random.shuffle(candidates)
    picked = candidates[:n]
    return jsonify({"ok": True, "count": len(picked), "total_unopened": len(candidates), "ats": picked})


@app.post("/api/card-flow/pool-mark-opened")
def card_flow_pool_mark_opened():
    """批量直开成功开通后回写号池：把对应账号标记 opened=true + activatedAt（毫秒）。
    优先按 access_token 精确匹配，退而按 email 匹配；仅在成功开通时被前端调用。"""
    body = request.get_json(silent=True) or {}
    token = str(body.get("access_token") or "").strip()
    email = str(body.get("email") or "").strip().lower()
    if not token and not email:
        return jsonify({"ok": False, "error": "missing_key"}), 400
    from account_manager import load_probe, save_probe, _probe_lock
    with _probe_lock:
        items = load_probe()
        hit = None
        if token:
            for a in items:
                if isinstance(a, dict) and str(a.get("accessToken") or "").strip() == token:
                    hit = a
                    break
        if hit is None and email:
            for a in items:
                if isinstance(a, dict) and str(a.get("email") or "").strip().lower() == email:
                    hit = a
                    break
        if hit is None:
            return jsonify({"ok": False, "error": "account_not_found"}), 404
        hit["opened"] = True
        hit["activatedAt"] = int(time.time() * 1000)
        save_probe(items)
    return jsonify({"ok": True, "email": hit.get("email") or "", "id": hit.get("id") or ""})


@app.post("/api/card-flow/quick-checkout")
def public_card_flow_quick_checkout():
    body = request.get_json(silent=True) or {}
    try:
        access_token = _extract_protocol_access_token(body.get("access_token") or body.get("at"))
        entry_proxy_pool = normalize_user_proxy_pool(body.get("entry_proxy_pool") or body.get("bind_proxy_pool") or body.get("proxy_pool"))
        exit_proxy_pool = normalize_user_proxy_pool(body.get("exit_proxy_pool") or body.get("promo_proxy_pool"))
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    task_id = secrets.token_hex(6); now = time.time()
    job = {"id": task_id, "status": "queued", "progress": 0, "message": "Task created", "error": "", "result": {}, "created_at": now, "finished_at": None, "_access_token": access_token, "_entry_proxies": entry_proxy_pool, "_exit_proxies": exit_proxy_pool, "_pay_job_id": "", "_defer_confirm": bool(body.get("defer_confirm")), "_prepared": None, "_released": False}
    with _lock: _card_checkout_jobs[task_id] = job
    threading.Thread(target=_run_isolated_card_checkout, args=(task_id,), daemon=True, name=f"card-checkout-{task_id}").start()
    return jsonify({"ok": True, "task_id": task_id, "status": "queued"}), 201


@app.get("/api/card-flow/task/<task_id>")
def public_card_flow_task(task_id: str):
    value = str(task_id or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", value):
        return jsonify({"ok": False, "error": "INVALID_TASK_ID"}), 400
    with _lock:
        isolated = _card_checkout_jobs.get(value)
        if isolated:
            return jsonify(_card_checkout_public(isolated))
    if not REG_SESSION_SECRET:
        return jsonify({
            "ok": False,
            "status": "error",
            "error": "TASK_NOT_FOUND",
            "message": "提链任务不存在（服务可能已重启，请重新发起该 AT）",
        }), 404
    status, payload = reg_console_request(f"/api/tasks/{value}", "GET")
    if isinstance(payload, dict) and isinstance(payload.get("options"), dict):
        payload = dict(payload)
        payload["options"] = {
            key: val for key, val in payload["options"].items()
            if key not in {"entry_proxies", "exit_proxies", "proxies", "proxy_pool"}
        }
    return jsonify(payload), status


@app.post("/api/card-flow/task/<task_id>/cancel")
def public_card_flow_cancel(task_id: str):
    value = str(task_id or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", value):
        return jsonify({"ok": False, "error": "INVALID_TASK_ID"}), 400
    with _lock:
        job = _card_checkout_jobs.get(value)
        child_job_id = str((job or {}).get("_pay_job_id") or "")
        child_proc = (job or {}).get("_pay_process")
        if job:
            job.update(status="cancelled", progress=100, message="Task replaced by retry", error="", finished_at=time.time(), _access_token="", _pay_process=None)
    if child_job_id:
        try:
            _gateway_request("/api/checkout-cancel", "POST", {"job_id": child_job_id})
        except Exception:
            pass
    if child_proc is not None:
        try:
            child_proc.kill()
        except Exception:
            pass
    return jsonify({"ok": True, "task_id": value, "child_cancelled": bool(child_job_id)})


def _run_prepared_card_confirm(task_id: str, gate: threading.Event) -> None:
    """Pre-launched confirm worker for one prepared card-flow account.

    Already holds its own Checkout/ConfirmationToken context (job['_prepared']).
    Blocks on the shared release event so every account submits its subscription
    confirm at (almost) the same instant when the barrier is lifted.
    """
    with _lock:
        job = dict(_card_checkout_jobs.get(task_id) or {})
    prepared = job.get("_prepared")
    if not job or not prepared:
        return
    checkout_result = dict(job.get("result") or {})
    proc = None
    try:
        with _lock:
            if task_id in _card_checkout_jobs:
                _card_checkout_jobs[task_id].update(status="queued", progress=78, message="所有可用账号已就绪，等待同步屏障")
        gate.wait(timeout=30)
        with _lock:
            current = _card_checkout_jobs.get(task_id) or {}
            if current.get("status") == "cancelled":
                return
            if task_id in _card_checkout_jobs:
                _card_checkout_jobs[task_id].update(status="running", progress=82, message="屏障已释放，正在同时提交订阅")
        proc = subprocess.Popen(
            [GATEWAY_PYTHON, STANDALONE_PAY_HELPER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1, cwd=str(ROOT),
        )
        with _lock:
            if task_id in _card_checkout_jobs:
                _card_checkout_jobs[task_id]["_pay_process"] = proc
        assert proc.stdin is not None and proc.stdout is not None
        proc.stdin.write(json.dumps({"mode": "confirm", "prepared": prepared}, ensure_ascii=False))
        proc.stdin.close()
        pay_result: dict = {}
        last_error = ""
        for line in proc.stdout:
            text = line.strip()
            if not text:
                continue
            try:
                event = json.loads(text)
            except Exception:
                continue
            if event.get("type") == "log":
                message = str(event.get("message") or "")
                with _lock:
                    current = _card_checkout_jobs.get(task_id)
                    if not current:
                        continue
                    lower = message.lower()
                    if "checkout confirm" in lower:
                        current.update(progress=93, message=message)
                    elif "stripe" in lower and "status=" in lower:
                        current.update(progress=96, message=message)
                    elif message:
                        current.update(message=message)
            elif event.get("type") == "result":
                pay_result = dict(event.get("result") or {})
            elif event.get("type") == "error":
                last_error = str(event.get("error") or "")
        code = proc.wait(timeout=10)
        if code != 0 or not pay_result:
            raise RuntimeError(last_error or f"PROTOCOL_PAY_HELPER_EXIT_{code}")
        payment_status = str(pay_result.get("status") or "").lower()
        final = dict(checkout_result)
        final.update({
            "payment_status": payment_status or "unknown",
            "payment_result": pay_result,
            "subscription_ok": payment_status == "success",
            "checkout_url": checkout_result.get("checkout_url") or checkout_result.get("short_link") or checkout_result.get("short_url") or "",
            "short_link": checkout_result.get("short_link") or checkout_result.get("checkout_url") or "",
            "short_url": checkout_result.get("short_url") or checkout_result.get("checkout_url") or "",
        })
        if payment_status == "success":
            with _lock:
                if task_id in _card_checkout_jobs:
                    _card_checkout_jobs[task_id].update(status="done", progress=100, message="Payment completed", result=final, finished_at=time.time())
            return
        if payment_status == "verification_required":
            with _lock:
                if task_id in _card_checkout_jobs:
                    _card_checkout_jobs[task_id].update(status="done", progress=100, message="Payment requires additional verification", result=final, finished_at=time.time())
            return
        raise RuntimeError(
            f"PROTOCOL_PAYMENT_FAILED: status={payment_status or 'unknown'}; "
            f"{pay_result.get('error') or pay_result.get('message') or ''}".strip()
        )
    except Exception as exc:
        if proc is not None:
            try:
                proc.kill()
            except Exception:
                pass
        error_detail = re.sub(
            r"\b(?:ctoken|pi|seti|pm|cs)_[A-Za-z0-9_-]+\b",
            lambda match: match.group(0).split("_", 1)[0] + "_***",
            f"{type(exc).__name__}: {exc}"[:500],
        )
        app.logger.warning("card-flow confirm failed task=%s error=%s", task_id, error_detail)
        with _lock:
            current = _card_checkout_jobs.get(task_id)
            if current and current.get("status") != "cancelled":
                current.update(
                    status="error", progress=100, message="Checkout/payment failed",
                    error=error_detail, finished_at=time.time(),
                )
    finally:
        with _lock:
            if task_id in _card_checkout_jobs:
                _card_checkout_jobs[task_id]["_pay_process"] = None
                _card_checkout_jobs[task_id].pop("_prepared", None)
                _card_checkout_jobs[task_id]["_access_token"] = ""


@app.post("/api/card-flow/release")
def public_card_flow_release():
    """Two-phase barrier release: confirm every prepared card-flow account at once.

    Pre-launches one confirm thread per prepared task (each already holding its own
    Checkout/ConfirmationToken context), all blocked on a single shared event, then
    sets the event so their subscription confirms fire simultaneously. Idempotent:
    tasks already released/confirming are skipped, not double-submitted.
    """
    body = request.get_json(silent=True) or {}
    task_ids: list[str] = []
    for value in body.get("task_ids") or []:
        tid = str(value or "").strip().lower()
        if not re.fullmatch(r"[a-f0-9]{12}", tid):
            return jsonify({"ok": False, "error": "INVALID_TASK_ID", "task_id": tid}), 400
        if tid not in task_ids:
            task_ids.append(tid)
    if not task_ids or len(task_ids) > 50:
        return jsonify({"ok": False, "error": "TASK_IDS_INVALID"}), 400
    release_at = time.time()
    with _lock:
        missing = [tid for tid in task_ids if tid not in _card_checkout_jobs]
        if missing:
            return jsonify({"ok": False, "error": "TASK_NOT_FOUND", "task_ids": missing}), 404
        releasable: list[str] = []
        skipped: list[str] = []
        for tid in task_ids:
            job = _card_checkout_jobs.get(tid) or {}
            if job.get("status") == "prepared" and job.get("_prepared") and not job.get("_released"):
                job["_released"] = True
                job["released_at"] = release_at
                releasable.append(tid)
            else:
                skipped.append(tid)
    gate = threading.Event()
    for tid in releasable:
        threading.Thread(target=_run_prepared_card_confirm, args=(tid, gate), daemon=True, name=f"card-confirm-{tid}").start()
    time.sleep(0.08)
    gate.set()
    with _lock:
        waits = [
            round(max(0.0, release_at - float((_card_checkout_jobs.get(tid) or {}).get("prepared_at") or release_at)), 3)
            for tid in releasable
        ]
        jobs = [_card_checkout_public(_card_checkout_jobs[tid]) for tid in task_ids if tid in _card_checkout_jobs]
    app.logger.info("card-flow release tasks=%d prepared_wait_seconds=%s", len(releasable), waits)
    return jsonify({"ok": True, "released": len(releasable), "skipped": skipped, "jobs": jobs, "mode": "simultaneous"})


@app.get("/api/card-bind/config")
def card_bind_config():
    return jsonify({"ok": True, "requires_access_token": True})


@app.post("/api/card-bind/session")
def card_bind_session():
    body = request.get_json(silent=True) or {}
    try:
        account_email = resolve_card_bind_email(body)
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 404
    try:
        proxy_pool = normalize_user_proxy_pool(body.get("proxy_pool") or [body.get("proxy")])
        selected_proxy = normalize_user_proxy(body.get("proxy") or proxy_pool[0])
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    submitted_at = str(body.get("access_token") or "").strip()
    returncode, payload = _run_card_bind_session_helper(account_email, selected_proxy, submitted_at)
    if returncode != 0 or not payload.get("ok"):
        upstream = int(payload.get("status") or 0)
        detail_text = str(payload.get("detail") or "").lower()
        # New accounts can answer 403/5xx before any Checkout has initialized
        # their Stripe context. They can also return 400 "No payment account
        # exists for this account." until a Checkout bootstraps that account.
        # In all these cases: initialize once, then fetch a fresh session.
        needs_bootstrap = upstream in {403, 500, 502, 503, 504} or (
            upstream == 400 and "payment account" in detail_text
        )
        if submitted_at and needs_bootstrap:
            probe = _start_key_probe("", account_email, selected_proxy, submitted_at, proxy_pool)
            return jsonify({
                "ok": True, "pending": True, "key_probe_id": str(probe.get("id") or ""),
                "account_email": account_email, "publishable_key_source": "checkout_then_refetch",
            }), 202
        return card_helper_error_response(payload)
    if not str(payload.get("publishable_key") or "").startswith("pk_"):
        probe = _start_key_probe(
            str(payload.get("record_id") or ""), account_email, selected_proxy,
            submitted_at, proxy_pool, initial_session=payload,
        )
        payload.update({
            "pending": True,
            "key_probe_id": str(probe.get("id") or ""),
            "publishable_key_source": "checkout_then_refetch",
        })
        return jsonify(payload), 202
    payload["publishable_key_source"] = "access_token_protocol"
    return jsonify(payload)

@app.get("/")
def index():
    if request.script_root == "/card-link":
        return render_template("card-flow.html")
    if request.script_root == "/protocol-pay":
        return render_template("protocol-pay.html")
    return redirect("/card-flow/")


@app.get("/api/source/tasks")
def source_tasks():
    try:
        payload = reg_bridge_get("/api/internal/ph-short/tasks", {"limit": 100})
    except (RuntimeError, ValueError) as exc:
        return jsonify({"ok": False, "error": str(exc)}), 502
    return jsonify({"ok": True, "items": payload.get("items") or []})


@app.get("/api/jobs")
def list_jobs():
    cleanup_jobs()
    with _lock:
        items = sorted(_jobs.values(), key=lambda item: item.get("created_at", 0), reverse=True)
        result = [public_job(item) for item in items]
    return jsonify({"ok": True, "items": result})


@app.post("/api/jobs")
def create_job():
    cleanup_jobs()
    payload = request.get_json(silent=True) or {}
    task_id = str(payload.get("task_id") or "").strip().lower()
    if not re.fullmatch(r"[a-f0-9]{12}", task_id):
        return jsonify({"ok": False, "error": "请选择一个已完成的菲律宾短链任务"}), 400
    try:
        confirmation_token = str(payload.get("confirmation_token") or "").strip()
        if confirmation_token and not re.fullmatch(r"ctoken_[A-Za-z0-9]+", confirmation_token):
            raise ValueError("ConfirmationToken format is invalid")
        preconfirmed_checkout = payload.get("preconfirmed_checkout") or {}
        if not isinstance(preconfirmed_checkout, dict):
            raise ValueError("Preconfirmed Checkout response is invalid")
        saved_payment_method_id = str(payload.get("saved_payment_method_id") or "").strip()
        if saved_payment_method_id and not re.fullmatch(r"pm_[A-Za-z0-9]+", saved_payment_method_id):
            raise ValueError("Saved PaymentMethod format is invalid")
        cards = [] if (confirmation_token or saved_payment_method_id) else parse_cards(payload.get("cards") or payload.get("card_pool"))
        proxies = parse_proxies(payload.get("proxies") or payload.get("proxy_pool"))
        try:
            card_retry_count = int(payload.get("card_retry_count", 2))
        except (TypeError, ValueError) as exc:
            raise ValueError("\u91cd\u8bd5\u6b21\u6570\u5fc5\u987b\u662f\u6574\u6570") from exc
        card_retry_count = max(0, min(10, card_retry_count))
        source = reg_bridge_get("/api/internal/ph-short/tasks", {"limit": 100})
        source_item = next((item for item in source.get("items") or [] if item.get("task_id") == task_id), None)
        if not source_item:
            raise RuntimeError("短链任务不存在或尚未完成")
    except (RuntimeError, ValueError) as exc:
        return jsonify({"ok": False, "error": str(exc)}), 409

    with _lock:
        active = next(
            (
                item for item in _jobs.values()
                if item.get("task_id") == task_id and item.get("status") in {"queued", "running", "verification_required"}
            ),
            None,
        )
        if active:
            return jsonify({"ok": True, "job": public_job(active), "existing": True})
        job_id = secrets.token_hex(6)
        now = time.time()
        job = {
            "id": job_id,
            "task_id": task_id,
            "account_email": str(source_item.get("email") or ""),
            "status": "queued",
            "progress": 0,
            "stage": "等待执行",
            "message": "任务已创建",
            "error": "",
            "result": {},
            "logs": [],
            "cancel_requested": False,
            "created_at": now,
            "updated_at": now,
            "finished_at": None,
            "script_root": request.script_root,
            "_cards": cards,
            "_saved_payment_method_id": saved_payment_method_id,
            "_confirmation_token": confirmation_token,
            "_preconfirmed_checkout": preconfirmed_checkout,
            "_proxies": proxies,
            "_card_retry_count": card_retry_count,
            "_process": None,
        }
        _jobs[job_id] = job
    threading.Thread(target=run_job, args=(job_id,), name=f"ph-short-{job_id}", daemon=True).start()
    return jsonify({"ok": True, "job": public_job(job)}), 201


@app.get("/api/jobs/<job_id>")
def get_job(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        result = public_job(job) if job else None
    if not result:
        return jsonify({"ok": False, "error": "任务不存在或已过期"}), 404
    return jsonify({"ok": True, "job": result})


@app.post("/api/jobs/<job_id>/cancel")
def cancel_job(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return jsonify({"ok": False, "error": "任务不存在或已过期"}), 404
        if job.get("status") in {"ready", "error", "cancelled"}:
            return jsonify({"ok": True, "job": public_job(job)})
        if job.get("status") == "verification_required" and not job.get("_process"):
            job.update({
                "status": "cancelled",
                "progress": 100,
                "stage": "已停止",
                "message": "任务已停止",
                "finished_at": time.time(),
                "updated_at": time.time(),
            })
            return jsonify({"ok": True, "job": public_job(job)})
        job["cancel_requested"] = True
        job["message"] = "正在停止任务"
        job["updated_at"] = time.time()
        result = public_job(job)
    return jsonify({"ok": True, "job": result})


@app.post("/api/jobs/<job_id>/resume")
def resume_job(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return jsonify({"ok": False, "error": "任务不存在或已过期"}), 404
        if job.get("status") != "verification_required":
            return jsonify({"ok": False, "error": "当前任务不在等待验证状态"}), 409
        if not job.get("_resume_payload"):
            return jsonify({"ok": False, "error": "任务缺少验证续跑上下文"}), 409
        job["cancel_requested"] = False
        job["status"] = "queued"
        job["stage"] = "准备确认验证结果"
        job["message"] = "续跑任务已提交"
        job["updated_at"] = time.time()
        result = public_job(job)
    threading.Thread(target=run_resume_job, args=(job_id,), name=f"ph-resume-{job_id}", daemon=True).start()
    return jsonify({"ok": True, "job": result})


@app.delete("/api/jobs/<job_id>")
def delete_job(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        if not job:
            return jsonify({"ok": True})
        if job.get("status") in {"queued", "running", "verification_required"}:
            return jsonify({"ok": False, "error": "运行中的任务请先停止"}), 409
        _jobs.pop(job_id, None)
    return jsonify({"ok": True})


@app.get("/jobs/<job_id>/open")
def open_checkout(job_id: str):
    with _lock:
        job = _jobs.get(job_id)
        result = dict((job or {}).get("result") or {})
    short_url = str(result.get("short_url") or "")
    if not short_url:
        return redirect(f"{request.script_root}/?error=job_not_ready")
    return redirect(short_url, code=302)


@app.get("/healthz")
def healthz():
    cleanup_jobs()
    with _lock:
        active = sum(1 for item in _jobs.values() if item.get("status") in {"queued", "running", "verification_required"})
    return jsonify({
        "ok": True,
        "service": "reg_svc-ph-short-protocol",
        "mode": "stripe_checkout_protocol",
        "temporary_browser": False,
        "active_jobs": active,
        "jobs": len(_jobs),
    })



# --- Standalone saved-card payment: headless bootstrap, then protocol confirmation ---
def _extract_protocol_access_token(raw) -> str:
    value = str(raw or "").strip()
    if not value:
        raise ValueError("AT_REQUIRED")
    if value.startswith("{"):
        try:
            obj = json.loads(value)
        except Exception as exc:
            raise ValueError("AT_JSON_INVALID") from exc
        def find_token(item):
            if isinstance(item, dict):
                for key in ("accessToken", "access_token", "token", "at"):
                    candidate = str(item.get(key) or "").strip()
                    if candidate.count(".") == 2 and candidate.startswith("eyJ"):
                        return candidate
                for child in item.values():
                    found = find_token(child)
                    if found:
                        return found
            elif isinstance(item, list):
                for child in item:
                    found = find_token(child)
                    if found:
                        return found
            return ""
        value = find_token(obj)
    if value.lower().startswith("bearer "):
        value = value[7:].strip()
    if value.count(".") != 2 or not value.startswith("eyJ"):
        match = re.search(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", value)
        value = match.group(0) if match else ""
    if not value:
        raise ValueError("AT_FORMAT_INVALID")
    return value


def _protocol_token_identity(token: str) -> dict:
    try:
        segment = token.split(".")[1]
        segment += "=" * (-len(segment) % 4)
        claims = json.loads(base64.urlsafe_b64decode(segment.encode()).decode("utf-8"))
    except Exception as exc:
        raise ValueError("AT_PAYLOAD_INVALID") from exc
    auth = claims.get("https://api.vendor.example.com/auth") or {}
    profile = claims.get("https://api.vendor.example.com/profile") or {}
    account_id = str(auth.get("platform_account_id") or auth.get("account_id") or "").strip()
    email = str(profile.get("email") or claims.get("email") or "").strip().lower()
    if not account_id:
        raise ValueError("AT_ACCOUNT_ID_MISSING")
    exp = int(claims.get("exp") or 0)
    if exp and exp <= int(time.time()):
        raise ValueError("AT_EXPIRED")
    return {"account_id": account_id, "email": email}


def _normalize_protocol_checkout_url(raw: str) -> tuple[str, str, str]:
    value = str(raw or "").strip()
    parsed = urlparse(value)
    if parsed.scheme != "https":
        raise ValueError("CHECKOUT_HTTPS_REQUIRED")
    if parsed.hostname == "platform.example.com":
        return validate_short_url(value)
    if parsed.hostname == "pay.vendor.example.com":
        parts = [part for part in parsed.path.split("/") if part]
        if len(parts) >= 3 and parts[0] == "c" and parts[1] == "pay" and re.fullmatch(r"cs_[A-Za-z0-9_-]{12,}", parts[2]):
            session_id = parts[2]
            return f"https://platform.example.com/checkout/vendor_entity/{session_id}", "vendor_entity", session_id
    raise ValueError("CHECKOUT_URL_UNSUPPORTED")


def _protocol_public_job(job: dict) -> dict:
    return {
        "id": job.get("id"), "status": job.get("status"), "progress": int(job.get("progress") or 0),
        "stage": job.get("stage"), "message": job.get("message"), "error": job.get("error"),
        "result": dict(job.get("result") or {}), "logs": list(job.get("logs") or []),
        "account_email": job.get("account_email") or "", "checkout_url": job.get("checkout_url") or "",
        "created_at": job.get("created_at"), "updated_at": job.get("updated_at"), "finished_at": job.get("finished_at"),
    }


def _protocol_update(job_id: str, **updates):
    with _lock:
        job = _protocol_pay_jobs.get(job_id)
        if not job:
            return
        job.update(updates); job["updated_at"] = time.time()


def _protocol_log(job_id: str, level: str, message: str):
    text = str(message or "").strip()
    if not text:
        return
    with _lock:
        job = _protocol_pay_jobs.get(job_id)
        if not job:
            return
        logs = job.setdefault("logs", [])
        logs.append({"time": time.strftime("%H:%M:%S"), "type": level, "message": text[:600]})
        if len(logs) > 24:
            del logs[:-24]
        job["updated_at"] = time.time()


def _run_standalone_protocol_pay(job_id: str):
    with _lock:
        job = dict(_protocol_pay_jobs.get(job_id) or {})
    if not job:
        return
    try:
        _protocol_update(job_id, status="running", progress=8, stage="\u6821\u9a8c\u8d26\u53f7", message="\u6b63\u5728\u89e3\u6790 AT \u4e0e Checkout")
        origin = dict(job.get("_origin_context") or {})
        origin_cookies = dict(origin.get("session_cookies") or {})
        account_cookies = _lookup_reg_account_session(job.get("account_email") or "", job.get("account_id") or "")
        merged_cookies = dict(account_cookies)
        merged_cookies.update(origin_cookies)
        _protocol_log(job_id, "info", f"Session context merged: account={len(account_cookies)} checkout={len(origin_cookies)} total={len(merged_cookies)}")
        snapshot = {
            "short_url": job["checkout_url"], "processor_entity": job["processor_entity"],
            "checkout_session_id": job["checkout_session_id"], "access_token": job["_access_token"],
            "platform_account_id": job["account_id"], "session_cookies": merged_cookies,
            "user_agent": str(origin.get("checkout_user_agent") or "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"),
            "checkout_device_id": str(origin.get("checkout_device_id") or uuid.uuid4()),
            "checkout_platform_session_id": str(origin.get("checkout_platform_session_id") or ""),
            "email": job.get("account_email") or "", "proxy": job["_proxies"][0],
            "checkout_proxy": job["_proxies"][0],
            "preserve_checkout_identity": bool(origin),
            "context_source": str(origin.get("source") or "generated"),
        }
        proc = subprocess.Popen(
            [GATEWAY_PYTHON, STANDALONE_PAY_HELPER], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1,
        )
        with _lock:
            if job_id in _protocol_pay_jobs:
                _protocol_pay_jobs[job_id]["_process"] = proc
        assert proc.stdin is not None and proc.stdout is not None
        helper_mode = "prepare" if job.get("_defer_confirm") else "run"
        proc.stdin.write(json.dumps({"mode": helper_mode, "snapshot": snapshot, "proxies": job["_proxies"]}, ensure_ascii=False)); proc.stdin.close()
        result = {}; last_error = ""
        for line in proc.stdout:
            text = line.strip()
            if not text: continue
            try: event = json.loads(text)
            except Exception:
                _protocol_log(job_id, "info", text); continue
            if event.get("type") == "log":
                message = str(event.get("message") or ""); phase = str(event.get("phase") or "")
                _protocol_log(job_id, str(event.get("level") or "info"), message)
                if phase == "validate": _protocol_update(job_id, progress=18, stage="\u68c0\u67e5\u5df2\u7ed1\u5361", message=message)
                elif phase == "headless": _protocol_update(job_id, progress=38, stage="Checkout \u521d\u59cb\u5316", message=message)
                elif phase == "headless_done": _protocol_update(job_id, progress=66, stage="\u534f\u8bae\u4e0a\u4e0b\u6587\u5c31\u7eea", message=message)
                elif phase == "protocol": _protocol_update(job_id, progress=76, stage="\u534f\u8bae\u786e\u8ba4", message=message)
                else:
                    lower = message.lower()
                    if "checkout confirm" in lower: _protocol_update(job_id, progress=84, stage="Checkout \u786e\u8ba4", message=message)
                    elif "stripe" in lower and "status=" in lower: _protocol_update(job_id, progress=93, stage="Stripe \u6700\u7ec8\u72b6\u6001", message=message)
            elif event.get("type") == "result": result = dict(event.get("result") or {})
            elif event.get("type") == "error": last_error = str(event.get("error") or "")
        code = proc.wait(timeout=10)
        if code != 0 or not result:
            raise RuntimeError(last_error or f"PAY_HELPER_EXIT_{code}")
        status = str(result.get("status") or "").lower()
        if status == "prepared" and job.get("_defer_confirm"):
            private_prepared = dict(result.get("prepared") or {})
            safe_result = dict(result.get("safe") or {})
            if not private_prepared:
                raise RuntimeError("PREPARED_CONTEXT_MISSING")
            _protocol_update(job_id, status="prepared", progress=72, stage="\u51c6\u5907\u5b8c\u6210", message="\u5df2\u5c31\u7eea\uff0c\u7b49\u5f85\u6240\u6709\u4efb\u52a1\u540c\u65f6\u63d0\u4ea4", result=safe_result, _prepared=private_prepared)
            return
        if status == "verification_required":
            _protocol_update(job_id, status="verification_required", progress=94, stage="\u7b49\u5f85\u9a8c\u8bc1", message="\u652f\u4ed8\u9700\u8981\u989d\u5916\u9a8c\u8bc1", result=result)
        else:
            _protocol_update(job_id, status="ready", progress=100, stage="\u652f\u4ed8\u5b8c\u6210", message="\u7eaf\u534f\u8bae\u76f4\u5361\u652f\u4ed8\u5df2\u5b8c\u6210", result=result, finished_at=time.time())
    except Exception as exc:
        message = str(exc)
        if message.startswith("RuntimeError: "):
            message = message[14:]
        _protocol_log(job_id, "error", message)
        _protocol_update(job_id, status="error", progress=100, stage="\u6267\u884c\u5931\u8d25", message=message, error=message, finished_at=time.time())
    finally:
        with _lock:
            if job_id in _protocol_pay_jobs:
                _protocol_pay_jobs[job_id]["_process"] = None
                _protocol_pay_jobs[job_id].pop("_access_token", None)
                _protocol_pay_jobs[job_id].pop("_cards", None)


@app.get("/protocol-pay/")
def standalone_protocol_pay_page():
    return render_template("protocol-pay.html")


@app.post("/api/protocol-pay/jobs")
def create_standalone_protocol_pay_job():
    body = request.get_json(silent=True) or {}
    try:
        token = _extract_protocol_access_token(body.get("access_token") or body.get("at"))
        identity = _protocol_token_identity(token)
        raw_cards = body.get("cards") or body.get("card") or []
        cards = parse_cards(raw_cards) if raw_cards else []
        checkout_url, processor, session_id = _normalize_protocol_checkout_url(body.get("checkout_url") or body.get("url"))
        origin_context = _lookup_checkout_context(session_id)
        origin_proxy_raw = str(origin_context.get("checkout_proxy") or "")
        ttl_match = re.search(r"-t-(\d+)", origin_proxy_raw)
        origin_created = float(origin_context.get("created_at") or 0)
        if ttl_match and origin_created:
            ttl_seconds = max(60, int(ttl_match.group(1)) * 60)
            age_seconds = max(0, time.time() - origin_created)
            if age_seconds > max(60, ttl_seconds - 30):
                raise ValueError(
                    f"CHECKOUT_PROXY_SESSION_EXPIRED: link age {int(age_seconds // 60)}m exceeds sticky session {int(ttl_seconds // 60)}m; regenerate the Checkout link"
                )
        proxies = []
        origin_proxy = str(origin_context.get("checkout_proxy") or "").strip()
        if origin_proxy:
            proxies.append(normalize_user_proxy(origin_proxy))
        proxy_errors = []
        for _ in range(3):
            try:
                generated = reg_bridge_get("/api/internal/ph-short/proxy", {"country": "US"})
                candidate = normalize_user_proxy(str(generated.get("proxy") or ""))
                if candidate not in proxies:
                    proxies.append(candidate)
            except Exception as exc:
                proxy_errors.append(str(exc))
        if not proxies:
            raise RuntimeError("AUTO_PROXY_FAILED: " + (proxy_errors[-1] if proxy_errors else "NO_PROXY_RETURNED"))
        preflight = subprocess.run(
            [GATEWAY_PYTHON, PROXY_PREFLIGHT_HELPER],
            input=json.dumps({"proxies": proxies, "expected": "US", "limit": 3}, ensure_ascii=False),
            capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=45, check=False,
        )
        try:
            checked = json.loads((preflight.stdout or "{}").strip().splitlines()[-1])
        except Exception:
            checked = {}
        proxies = list(checked.get("proxies") or [])
        if not proxies:
            raise RuntimeError(
                f"US_PROXY_PREFLIGHT_FAILED: {int(checked.get('valid') or 0)}/{int(checked.get('total') or 0)}"
            )
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 502
    job_id = secrets.token_hex(6); now = time.time()
    job = {
        "id": job_id, "status": "queued", "progress": 0, "stage": "\u7b49\u5f85\u6267\u884c", "message": "\u4efb\u52a1\u5df2\u521b\u5efa",
        "error": "", "result": {}, "logs": [], "account_email": identity.get("email") or "",
        "account_id": identity["account_id"], "checkout_url": checkout_url, "processor_entity": processor,
        "checkout_session_id": session_id, "created_at": now, "updated_at": now, "finished_at": None,
        "_access_token": token, "_proxies": proxies, "_cards": cards, "_origin_context": origin_context, "_process": None,
        "_defer_confirm": bool(body.get("defer_confirm")), "_prepared": None,
    }
    with _lock:
        _protocol_pay_jobs[job_id] = job
        if len(_protocol_pay_jobs) > 100:
            finished = sorted((x for x in _protocol_pay_jobs.values() if x.get("status") in {"ready","error","cancelled"}), key=lambda x:x.get("created_at",0))
            for old in finished[:max(0,len(_protocol_pay_jobs)-100)]: _protocol_pay_jobs.pop(str(old.get("id")),None)
    threading.Thread(target=_run_standalone_protocol_pay, args=(job_id,), daemon=True, name=f"protocol-pay-{job_id}").start()
    return jsonify({"ok": True, "job": _protocol_public_job(job)}), 201


def _run_prepared_protocol_confirm(job_id: str, gate: threading.Event) -> None:
    with _lock:
        job = dict(_protocol_pay_jobs.get(job_id) or {})
    if not job or not job.get("_prepared"):
        return
    try:
        _protocol_update(job_id, status="queued", progress=78, stage="\u7b49\u5f85\u540c\u6b65\u5c4f\u969c", message="\u6240\u6709\u4efb\u52a1\u5df2\u5c31\u7eea")
        gate.wait(timeout=30)
        _protocol_update(job_id, status="running", progress=82, stage="\u540c\u65f6\u63d0\u4ea4\u8ba2\u9605", message="\u5c4f\u969c\u5df2\u91ca\u653e")
        proc = subprocess.Popen([GATEWAY_PYTHON, STANDALONE_PAY_HELPER], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
        with _lock:
            if job_id in _protocol_pay_jobs: _protocol_pay_jobs[job_id]["_process"] = proc
        assert proc.stdin is not None and proc.stdout is not None
        proc.stdin.write(json.dumps({"mode":"confirm","prepared":job["_prepared"]},ensure_ascii=False));proc.stdin.close()
        result={};last_error=""
        for line in proc.stdout:
            text=line.strip()
            if not text:continue
            try:event=json.loads(text)
            except Exception:_protocol_log(job_id,"info",text);continue
            if event.get("type")=="log":
                message=str(event.get("message") or "");_protocol_log(job_id,str(event.get("level") or "info"),message)
                if "checkout confirm" in message.lower():_protocol_update(job_id,progress=90,stage="Checkout \u786e\u8ba4",message=message)
            elif event.get("type")=="result":result=dict(event.get("result") or {})
            elif event.get("type")=="error":last_error=str(event.get("error") or "")
        code=proc.wait(timeout=10)
        if code!=0 or not result:raise RuntimeError(last_error or f"PAY_HELPER_EXIT_{code}")
        if str(result.get("status") or "").lower()=="verification_required":_protocol_update(job_id,status="verification_required",progress=94,stage="\u7b49\u5f85\u9a8c\u8bc1",message="\u652f\u4ed8\u9700\u8981\u989d\u5916\u9a8c\u8bc1",result=result)
        else:_protocol_update(job_id,status="ready",progress=100,stage="\u8ba2\u9605\u5b8c\u6210",message="\u540c\u6b65\u534f\u8bae\u8ba2\u9605\u5df2\u5b8c\u6210",result=result,finished_at=time.time())
    except Exception as exc:
        message=str(exc);_protocol_log(job_id,"error",message);_protocol_update(job_id,status="error",progress=100,stage="\u6267\u884c\u5931\u8d25",message=message,error=message,finished_at=time.time())
    finally:
        with _lock:
            if job_id in _protocol_pay_jobs:
                _protocol_pay_jobs[job_id]["_process"]=None;_protocol_pay_jobs[job_id].pop("_prepared",None)

@app.post("/api/protocol-pay/batch-confirm")
def confirm_protocol_pay_batch():
    body=request.get_json(silent=True) or {};job_ids=[]
    for value in body.get("job_ids") or []:
        jid=str(value or "").strip()
        if jid and jid not in job_ids:job_ids.append(jid)
    if not job_ids or len(job_ids)>50:return jsonify({"ok":False,"error":"JOB_IDS_INVALID"}),400
    with _lock:
        missing=[jid for jid in job_ids if jid not in _protocol_pay_jobs]
        unready=[jid for jid in job_ids if jid in _protocol_pay_jobs and _protocol_pay_jobs[jid].get("status")!="prepared"]
    if missing:return jsonify({"ok":False,"error":"TASK_NOT_FOUND","job_ids":missing}),404
    if unready:return jsonify({"ok":False,"error":"TASKS_NOT_PREPARED","job_ids":unready}),409
    gate=threading.Event()
    for jid in job_ids:
        threading.Thread(target=_run_prepared_protocol_confirm,args=(jid,gate),daemon=True,name=f"protocol-confirm-{jid}").start()
    time.sleep(0.08);gate.set()
    with _lock:jobs=[_protocol_public_job(_protocol_pay_jobs[jid]) for jid in job_ids]
    return jsonify({"ok":True,"jobs":jobs,"released":len(jobs),"mode":"simultaneous"})

@app.get("/api/protocol-pay/jobs/<job_id>")
def get_standalone_protocol_pay_job(job_id: str):
    with _lock:
        job = _protocol_pay_jobs.get(str(job_id or ""))
        payload = _protocol_public_job(job) if job else None
    if not payload:
        return jsonify({"ok": False, "error": "TASK_NOT_FOUND"}), 404
    return jsonify({"ok": True, "job": payload})

# --- Mount the pay checkout engine as an in-process sub-app under /pay ---
# The pay engine was merged into this project (payment-gateway/pay). Instead of
# running it as a separate service on its own port, we mount its WSGI app here so
# the whole system runs from a single command on port 5088. Internal calls target
# GATEWAY_INTERNAL_BASE=http://127.0.0.1:5088/pay (see .env).
def _mount_gateway():
    import importlib.util as _ilu
    from werkzeug.middleware.dispatcher import DispatcherMiddleware
    pay_dir = ROOT / "pay"
    app_file = pay_dir / "app.py"
    if not app_file.exists():
        app.logger.warning("pay sub-app not found at %s; /pay disabled", app_file)
        return
    if str(pay_dir) not in sys.path:
        sys.path.insert(0, str(pay_dir))
    spec = _ilu.spec_from_file_location("pay_app", str(app_file))
    module = _ilu.module_from_spec(spec)
    spec.loader.exec_module(module)
    app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {"/pay": module.app})
    app.logger.info("pay sub-app mounted at /pay")


try:
    _mount_gateway()
except Exception as exc:  # keep the main app usable even if the sub-app fails
    app.logger.warning("gateway mount failed: %s", exc)


# --- Mount the PayPal agreement protocol project under /protocol ---
# payment-gateway/protocol is a stdlib http.server (ThreadingHTTPServer), NOT a WSGI
# app, so it cannot be mounted directly via DispatcherMiddleware like /pay. Instead
# we start it as an internal child process on a loopback port and mount a tiny WSGI
# reverse-proxy under /protocol (still wired through DispatcherMiddleware) so the
# whole system stays a single public server on 5088. On restart we reuse an already
# healthy child (avoids port-in-use collisions from force-killed parents); the child
# serves its static files fresh from disk, so UI edits take effect without a respawn.
_PROTOCOL_PROC = None


def _mount_protocol():
    global _PROTOCOL_PROC
    import re as _re
    import json as _json
    import time as _t
    import subprocess as _sp
    import http.client as _hc
    from werkzeug.middleware.dispatcher import DispatcherMiddleware

    proto_dir = ROOT / "protocol"
    web_file = proto_dir / "web.py"
    if not web_file.exists():
        app.logger.warning("protocol sub-app not found at %s; /protocol disabled", web_file)
        return

    port = int(os.getenv("PROTOCOL_INTERNAL_PORT", "5099"))
    py = os.getenv("PROTOCOL_PYTHON") or sys.executable

    def _health_ok():
        try:
            c = _hc.HTTPConnection("127.0.0.1", port, timeout=2)
            c.request("GET", "/api/health")
            r = c.getresponse()
            r.read()
            c.close()
            return r.status == 200
        except Exception:
            return False

    ready = _health_ok()
    if ready:
        app.logger.info("protocol child already healthy on 127.0.0.1:%s; reusing", port)
    else:
        logf = open(proto_dir / "protocol.web.log", "ab", buffering=0)
        creationflags = getattr(_sp, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
        _PROTOCOL_PROC = _sp.Popen(
            [py, "web.py", "--host", "127.0.0.1", "--port", str(port)],
            cwd=str(proto_dir), stdout=logf, stderr=logf,
            env=os.environ.copy(), creationflags=creationflags,
        )
        for _ in range(50):
            if _health_ok():
                ready = True
                break
            _t.sleep(0.3)
        app.logger.info("protocol child started pid=%s ready=%s on 127.0.0.1:%s",
                        getattr(_PROTOCOL_PROC, "pid", None), ready, port)

    HOP = {"connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
           "te", "trailer", "transfer-encoding", "upgrade", "content-length", "content-encoding"}

    def _proxy(environ, start_response):
        script = environ.get("SCRIPT_NAME", "") or "/protocol"
        path = environ.get("PATH_INFO", "")
        if path == "":
            start_response("301 Moved Permanently", [("Location", script + "/"), ("Content-Length", "0")])
            return [b""]
        qs = environ.get("QUERY_STRING", "")
        target = path + ("?" + qs if qs else "")
        method = environ.get("REQUEST_METHOD", "GET")
        try:
            length = int(environ.get("CONTENT_LENGTH") or 0)
        except Exception:
            length = 0
        body = environ["wsgi.input"].read(length) if length > 0 else None
        headers = {}
        for k, v in environ.items():
            if k.startswith("HTTP_"):
                name = k[5:].replace("_", "-").title()
                if name.lower() in HOP:
                    continue
                headers[name] = v
        if environ.get("CONTENT_TYPE"):
            headers["Content-Type"] = environ["CONTENT_TYPE"]
        if length > 0:
            headers["Content-Length"] = str(length)
        try:
            conn = _hc.HTTPConnection("127.0.0.1", port, timeout=600)
            conn.request(method, target, body=body, headers=headers)
            resp = conn.getresponse()
            data = resp.read()
            conn.close()
        except Exception as exc:
            start_response("502 Bad Gateway", [("Content-Type", "application/json; charset=utf-8")])
            return [_json.dumps({"ok": False, "error": f"protocol upstream error: {exc}"}).encode("utf-8")]
        out_headers = []
        for k, v in resp.getheaders():
            lk = k.lower()
            if lk in HOP:
                continue
            if lk == "set-cookie":
                v = _re.sub(r";\s*Path=/(?!protocol)", "; Path=" + script + "/", v, flags=_re.I)
            out_headers.append((k, v))
        out_headers.append(("Content-Length", str(len(data))))
        start_response(f"{resp.status} {resp.reason}", out_headers)
        return [data]

    app.wsgi_app = DispatcherMiddleware(app.wsgi_app, {"/protocol": _proxy})
    app.logger.info("protocol reverse-proxy mounted at /protocol -> 127.0.0.1:%s", port)


try:
    _mount_protocol()
except Exception as exc:  # keep the main app usable even if the sub-app fails
    app.logger.warning("protocol mount failed: %s", exc)


# --- Register the 账号管理 (Account Management) blueprint (additive only) ---
# New feature ported from the auto(Node) `plus` tab. Adds the /account-manager/
# page and /api/plus* endpoints without touching any existing route/feature.
try:
    from account_manager import bp as account_manager_bp
    app.register_blueprint(account_manager_bp)
    app.logger.info("account_manager blueprint registered (/account-manager/, /api/plus*)")
except Exception as exc:  # keep the main app usable even if this fails to import
    app.logger.warning("account_manager blueprint registration failed: %s", exc)

if __name__ == "__main__":
    app.run(host=os.getenv("HOST", "0.0.0.0"), port=int(os.getenv("PORT", "5088")), debug=False, threaded=True)
