from __future__ import annotations
import json, sys, random, re, base64, hashlib, uuid, os, time
from curl_cffi.requests import Session
ACCOUNT_FILE=os.getenv("ACCOUNT_FILE", "./data/accounts.jsonl")
PK_RE=re.compile(r"pk_(?:live|test)_[A-Za-z0-9]{24,}")
def find_publishable_key(value):
 if isinstance(value,dict):
  for key in ("publishable_key","public_key","stripe_publishable_key","key"):
   candidate=str(value.get(key) or "").strip()
   if PK_RE.fullmatch(candidate): return candidate
  for item in value.values():
   found=find_publishable_key(item)
   if found:return found
 elif isinstance(value,list):
  for item in value:
   found=find_publishable_key(item)
   if found:return found
 elif isinstance(value,str):
  match=PK_RE.search(value)
  if match:return match.group(0)
 return ""
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"

def auto_us_billing(email):
 names=["James Wilson","Michael Brown","Daniel Miller","David Anderson","Robert Taylor","William Thomas"]
 address=None
 try:
  for candidate in ("/opt/paypal-pay", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),"paypal-agreement-protocol")):
   if os.path.isdir(os.path.join(candidate,"paypal")):
    sys.path.insert(0,candidate); break
  from paypal import models
  try:
   address=models._generate_address_from_online_map("US")
  except Exception:
   address=None
  if not address:
   address=models.generate_address("US")
 except (ImportError, ModuleNotFoundError):
  # payment-gateway is deployed independently from paypal-agreement-protocol on Linux.
  # Stripe Elements only requires a structurally valid US billing address here.
  return {
   "name":random.choice(names),
   "email":str(email or ""),
   "phone":"+12025550142",
   "address":{"country":"US","line1":"350 5th Ave","line2":"","city":"New York","state":"NY","postal_code":"10118"}
  }
 return {
  "name":random.choice(names),
  "email":str(email or ""),
  "phone":"+1202555%04d" % random.randint(100,9999),
  "address":{
   "country":"US",
   "line1":" ".join(x for x in [str(address.house_number or ""),str(address.street or "")] if x).strip(),
   "line2":str(address.district or ""),
   "city":str(address.city or ""),
   "state":str(address.state or ""),
   "postal_code":str(address.postal_code or ""),
  }
 }

def main():
 email=str(sys.argv[1] if len(sys.argv)>1 else "").strip().lower(); account=None
 access_token_override=str(sys.argv[3] if len(sys.argv)>3 else "").strip()
 email_candidate=None
 with open(ACCOUNT_FILE,encoding="utf-8",errors="ignore") as h:
  for line in h:
   try:item=json.loads(line)
   except:continue
   if access_token_override and str(item.get("access_token") or "").strip()==access_token_override:
    account=item
    break
   if str(item.get("email") or "").strip().lower()==email:
    email_candidate=item
 if not account and access_token_override:
  try:
   segment=access_token_override.split(".")[1];segment += "=" * (-len(segment) % 4);claims=json.loads(base64.urlsafe_b64decode(segment.encode()).decode());auth=claims.get("https://api.vendor.example.com/auth") or {};profile=claims.get("https://api.vendor.example.com/profile") or {};account_id=str(auth.get("platform_account_id") or claims.get("account_id") or "").strip();token_hash=hashlib.sha256(access_token_override.encode()).hexdigest();decoded_email=str(profile.get("email") or claims.get("email") or email or f"external-{token_hash[:16]}@example.com").strip().lower();record_id=hashlib.sha256(("external-at:"+account_id).encode()).hexdigest()[:12];device_id=str(uuid.uuid5(uuid.NAMESPACE_URL,"reg_svc-external-at:"+account_id));account={"id":record_id,"email":decoded_email,"account_id":account_id,"access_token":access_token_override,"session_cookies":{"x-vendor-did":device_id},"proxy":"DIRECT"}
  except Exception:
   account=None
 if not account: account=email_candidate
 if not account: print(json.dumps({"ok":False,"error":"ACCOUNT_NOT_FOUND"})); return 2
 if access_token_override:
  account=dict(account);account["access_token"]=access_token_override
 http=Session(impersonate="firefox144"); http.trust_env=False
 proxy=str(sys.argv[2] if len(sys.argv)>2 else account.get("proxy") or "").strip()
 if proxy and proxy.upper()!="DIRECT":http.proxies={"http":proxy,"https":proxy}
 cookies=account.get("session_cookies") or {}
 if isinstance(cookies,str):
  try:cookies=json.loads(cookies)
  except:cookies={}
 for name,value in dict(cookies).items():
  try:http.cookies.set(str(name),str(value),domain="platform.example.com")
  except:pass
 headers={"Authorization":"Bearer "+str(account.get("access_token") or ""),"Platform-Account-Id":str(account.get("account_id") or ""),"Vendor-Device-Id":str(cookies.get("x-vendor-did") or ""),"User-Agent":UA,"Accept":"*/*","Origin":"https://platform.example.com","Referer":"https://platform.example.com/","Content-Type":"application/json"}
 try:
  response=None;last_exc=None
  for _attempt in range(3):
   try:
    response=http.post("https://platform.example.com/api/v1/payments/payment_method",json={"account_id":account.get("account_id")},headers=headers,timeout=45)
    break
   except Exception as exc:
    last_exc=exc;msg=str(exc).lower()
    transient=any(k in msg for k in ("ssl","closed abruptly","timed out","timeout","connection","(35)","(28)","(52)","(56)","recv failure","reset"))
    if _attempt>=2 or not transient:raise
    time.sleep(1.2*(_attempt+1))
  try:data=response.json() or {}
  except:data={}
  secret=str(data.get("client_secret") or "")
  if response.status_code!=200 or not secret.startswith("seti_"):
   detail=data.get("detail") or data.get("error") or ""
   print(json.dumps({"ok":False,"error":"SETUP_INTENT_FAILED","status":response.status_code,"detail":str(detail)[:300]})); return 3
  billing=auto_us_billing(email)
  print(json.dumps({"ok":True,"client_secret":secret,"publishable_key":find_publishable_key(data),"record_id":str(account.get("id") or ""),"account_email":email,"billing_details":billing})); return 0
 finally:http.close()
if __name__=="__main__":
 try:
  raise SystemExit(main())
 except SystemExit:
  raise
 except Exception as exc:
  print(json.dumps({"ok":False,"error":"CARD_BIND_HELPER_ERROR","detail":f"{type(exc).__name__}: {exc}"[:300]}))
  raise SystemExit(10)
