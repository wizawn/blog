> **Sanitized distribution:** production credentials, runtime data, screenshots and private infrastructure values are not included. See `SANITIZED-NOTICE.md`.

# Payment Gateway - Checkout Link Router

Multi-channel checkout link console. Hosted, PayPal, iDEAL, UPI, PIX, Team and workspace plans unified task processing.

## Features

- Supports Plus, Pro, Team and workspace plans.
- Supports Hosted official links, PayPal, iDEAL, UPI and PIX payment paths.
- Supports Access Token and Session JSON auto-detection.
- Dual proxy pools, 1-500 proxies, local save, proxy detection and region adaptation.
- Auto currency selection by payment region with unsupported currency fallback.
- Failure retry with rebuilt Checkout, device identity and payment params each round.
- Global RPM, per-IP RPM, concurrency limits and task queuing.
- Dark/light theme with desktop and mobile responsive layout.

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Deployment

systemd example:

```ini
[Unit]
Description=Payment Gateway Checkout Link Service
After=network-online.target

[Service]
WorkingDirectory=/opt/payment-gateway
EnvironmentFile=-/opt/payment-gateway/.env
ExecStart=/opt/payment-gateway/.venv/bin/gunicorn --workers 1 --threads 12 --timeout 600 --bind 127.0.0.1:18096 app:app
Restart=always
RestartSec=2

[Install]
WantedBy=multi-user.target
```

## License
Private / Internal use only.
