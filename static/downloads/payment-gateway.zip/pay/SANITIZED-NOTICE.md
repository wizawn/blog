# Sanitized Source Package

This archive is a sanitized snapshot of the checkout-link extraction service.

## Removed or replaced

- Private domains, repository ownership and deployment branding.
- Production proxy usernames, passwords and provider hostnames.
- Runtime tokens, account data, cookies, logs, task databases and server backups.
- Production screenshots and private infrastructure configuration.

## Deployment checklist

1. Copy `.env.example` to a private environment file.
2. Set service URLs, proxy pools and credentials outside the repository.
3. Review rate limits and reverse-proxy headers before exposing the service.
4. Keep runtime state under a separate non-versioned data directory.

This package contains source code and synthetic fixtures only.
