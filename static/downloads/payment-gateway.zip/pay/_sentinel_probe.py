import asyncio, uuid, sys
import app

PROXY = "socks5h://p9mx1124350-region-US-sid-Y9qR1Wf8-t-3:iy2lm321zpy@us.arxlabs.io:3010"

async def main():
    did = str(uuid.uuid4())
    try:
        headers = await app.sentinel_headers(PROXY, "platform_checkout", did, did)
        print("OK headers keys:", list(headers.keys()))
        for k, v in headers.items():
            print(k, "=>", (v[:80] + "...") if len(v) > 80 else v)
    except Exception as e:
        print("FAIL:", type(e).__name__, e)

asyncio.run(main())
