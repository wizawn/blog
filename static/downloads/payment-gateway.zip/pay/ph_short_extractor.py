"""PH short-checkout helpers for link_type=ph_short.

Ported from the reference gateway `ph_short_extractor` surface used by
`ph_checkout_protocol.py` and the PH short extraction path. The original
gateway module lived outside this tree; this file restores the constants and
canonical short-link helpers our merged /pay engine needs.
"""
from __future__ import annotations

import json
import re
import threading
import time
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
)
# Platform web client fingerprint headers used by the PH short protocol path.
# Authoritative values recovered from the project's own upi_go tools
# (account-manager/linkgen/tools/upi_go/main.go and the gateway copy), which hit
# the same platform.example.com/api/v1/payments/checkout endpoints. The reference
# ph_short_extractor module was stripped from the sanitized package, but these
# constants are the real Vendor web-client version/build it supplied.
DEFAULT_CLIENT_VERSION = "prod-fb4a8a2a751dfec391053cfd7b01c52699ccf78c"
DEFAULT_CLIENT_BUILD = "8370486"

SHORT_RE = re.compile(
    r"^https://platform\.com/checkout/(?P<processor>vendor_eu|vendor_entity)/"
    r"(?P<session>(?:vendor_cs_|cs_)[A-Za-z0-9_-]{12,})"
)
SESSION_RE = re.compile(r"(?:vendor_cs_|cs_)[A-Za-z0-9_-]{12,}")

_CONTEXT_LOCK = threading.RLock()
_CONTEXT_PATH = Path(__file__).resolve().parent / "data" / "ph_short_contexts.jsonl"


def canonical_short_url(session_id: str, processor_entity: str = "vendor_entity") -> str:
    sid = str(session_id or "").strip()
    processor = str(processor_entity or "vendor_entity").strip() or "vendor_entity"
    if processor not in {"vendor_eu", "vendor_entity"}:
        processor = "vendor_entity"
    if not SESSION_RE.fullmatch(sid):
        raise ValueError("CHECKOUT_SESSION_ID_INVALID")
    return f"https://platform.example.com/checkout/{processor}/{sid}"


def normalize_short_checkout_url(raw: str, fallback_session_id: str = "") -> tuple[str, str, str]:
    """Return (short_url, processor, session_id) from a short or long checkout URL."""
    value = str(raw or "").strip()
    if value:
        match = SHORT_RE.match(value)
        if match:
            return value, match.group("processor"), match.group("session")
        parsed = urlparse(value)
        if parsed.scheme == "https" and parsed.hostname == "pay.vendor.example.com":
            parts = [part for part in parsed.path.split("/") if part]
            if len(parts) >= 3 and parts[0] == "c" and parts[1] == "pay" and SESSION_RE.fullmatch(parts[2]):
                return canonical_short_url(parts[2], "vendor_entity"), "vendor_entity", parts[2]
        sid_match = SESSION_RE.search(value)
        if sid_match:
            return canonical_short_url(sid_match.group(0), "vendor_entity"), "vendor_entity", sid_match.group(0)
    fallback = str(fallback_session_id or "").strip()
    if SESSION_RE.fullmatch(fallback):
        return canonical_short_url(fallback, "vendor_entity"), "vendor_entity", fallback
    raise ValueError("CHECKOUT_URL_UNSUPPORTED")


def cookie_dict(http: Any) -> dict[str, str]:
    try:
        raw = http.cookies.get_dict()
    except Exception:
        raw = {}
    out: dict[str, str] = {}
    for name, value in dict(raw or {}).items():
        key = str(name or "").strip()
        text = str(value or "").strip()
        if key and text:
            out[key] = text
    return out


def vendor_cs_total(state: dict[str, Any]) -> tuple[int, str]:
    """Extract due amount/currency from an VENDOR_CS checkout payload (same as protocol)."""
    checkout_state = state.get("checkout_state") if isinstance(state.get("checkout_state"), dict) else {}
    total = checkout_state.get("total") if isinstance(checkout_state.get("total"), dict) else {}
    final_total = total.get("total") if isinstance(total.get("total"), dict) else {}
    amount = final_total.get("minorUnitsAmount")
    if amount is None:
        amount = 0
    return int(amount), str(checkout_state.get("currency") or "php").lower()


def resolve_vendor_cs_checkout(
    http: Any,
    *,
    access_token: str,
    processor: str,
    session_id: str,
    device_id: str,
    user_agent: str = "",
    account_id: str = "",
    platform_session_id: str = "",
) -> dict[str, Any]:
    """Resolve PH/custom short checkout via Platform VENDOR_CS API — NOT Stripe payment_page.

    Custom `checkout_ui_mode` returns `vendor_cs_*` session ids. Stripe's
    payment_page init only understands `cs_*` and fails with resource_missing.
    """
    processor = str(processor or "vendor_entity").strip() or "vendor_entity"
    session_id = str(session_id or "").strip()
    if processor not in {"vendor_eu", "vendor_entity"}:
        raise ValueError("PROCESSOR_ENTITY_INVALID")
    if not SESSION_RE.fullmatch(session_id):
        raise ValueError("CHECKOUT_SESSION_ID_INVALID")
    path = f"/api/v1/payments/checkout/{processor}/{session_id}"
    headers = {
        "Authorization": f"Bearer {str(access_token or '').strip()}",
        "Accept": "*/*",
        "Origin": "https://platform.example.com",
        "Referer": f"https://platform.example.com/checkout/{processor}/{session_id}",
        "Vendor-Device-Id": str(device_id or ""),
        "Vendor-Language": "en-US",
        "User-Agent": str(user_agent or DEFAULT_USER_AGENT),
        "Accept-Language": "en-US,en;q=0.9",
        "Vendor-Client-Version": DEFAULT_CLIENT_VERSION,
        "Vendor-Client-Build-Number": DEFAULT_CLIENT_BUILD,
        "x-vendor-target-path": path,
        "x-vendor-target-route": path,
    }
    if platform_session_id:
        headers["Vendor-Session-Id"] = str(platform_session_id)
    if account_id:
        headers["Platform-Account-Id"] = str(account_id)
    response = http.get(f"https://platform.example.com{path}", headers=headers, timeout=45)
    text = str(getattr(response, "text", "") or "")
    try:
        data = response.json() or {}
    except Exception as exc:
        raise RuntimeError(
            f"VENDOR_CS Checkout returned non-JSON HTTP {getattr(response, 'status_code', '?')}: {text[:400]}"
        ) from exc
    if not isinstance(data, dict):
        raise RuntimeError("VENDOR_CS Checkout returned an invalid response")
    if getattr(response, "status_code", 0) != 200:
        err = data.get("error") if isinstance(data.get("error"), dict) else {}
        detail = str(err.get("message") or err.get("code") or data.get("detail") or data.get("message") or text[:300])
        raise RuntimeError(f"VENDOR_CS Checkout HTTP {getattr(response, 'status_code', '?')}: {detail}")
    resolved_id = str(data.get("checkout_session_id") or "")
    pk = str(data.get("publishable_key") or "")
    customer_secret = str(data.get("customer_session_client_secret") or "")
    if resolved_id != session_id or not pk.startswith("pk_") or not customer_secret.startswith("cuss_secret_"):
        raise RuntimeError("VENDOR_CS Checkout response is incomplete")
    methods = [str(item).lower() for item in (data.get("payment_method_types") or [])]
    if "card" not in methods:
        raise RuntimeError(f"Checkout does not expose card; methods={methods}")
    return data


def persist_ph_short_context(context: dict[str, Any]) -> None:
    if not isinstance(context, dict) or not context.get("checkout_session_id"):
        return
    _CONTEXT_PATH.parent.mkdir(parents=True, exist_ok=True)
    row = dict(context)
    row.setdefault("created_at", time.time())
    with _CONTEXT_LOCK:
        rows: list[dict[str, Any]] = []
        if _CONTEXT_PATH.exists():
            for line in _CONTEXT_PATH.read_text(encoding="utf-8", errors="ignore").splitlines():
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                if not isinstance(item, dict):
                    continue
                if str(item.get("checkout_session_id") or "") == str(row.get("checkout_session_id") or ""):
                    continue
                if float(item.get("created_at") or 0) < time.time() - 7 * 86400:
                    continue
                rows.append(item)
        rows.append(row)
        _CONTEXT_PATH.write_text(
            "".join(json.dumps(item, ensure_ascii=False, separators=(",", ":")) + "\n" for item in rows[-1000:]),
            encoding="utf-8",
        )
