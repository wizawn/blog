# Sanitized Source Package

This archive is a sanitized snapshot of the PayPal agreement protocol service.

## Replaced values

- Private domains were replaced with `example.com` placeholders.
- Repository ownership was replaced with `YOUR_GITHUB_ACCOUNT`.
- Billing Agreement examples use synthetic `BA-EXAMPLE...` values.
- The private route slug was replaced with `bt-vault-PRIVATE-SLUG`.
- Runtime logs, data files, cookies, tokens, proxy credentials, generated profiles, backups and server configuration are excluded.

## Before deployment

1. Review environment defaults in `config.py` and `web.py`.
2. Set a new private route slug and service-specific environment variables.
3. Use your own domain, reverse proxy and TLS configuration.
4. Keep runtime data and credentials outside the source directory.

This package contains source code only and does not contain production account data.
