"""Online country address resolution backed by OpenStreetMap Overpass."""
from __future__ import annotations
import json
from pathlib import Path
import random
import threading
import time
from typing import Any
import httpx
from paypal.models import BillingAddress
from paypal.runtime_country_resolver import validate_runtime_address

ROOT = Path(__file__).resolve().parents[1]
CACHE_PATH = ROOT / "data" / "runtime_address_cache.json"
CACHE_TTL_SECONDS = 24 * 60 * 60
_LOCK = threading.Lock()
_LAST_REQUEST_AT = 0.0
_ENDPOINTS = (
    "https://overpass-api.de/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.osm.ch/api/interpreter",
)
_NOMINATIM_ENDPOINTS = (
    "https://nominatim.openstreetmap.org/search",
    "https://nominatim.openstreetmap.fr/search",
)

_US_STATE_CODES = {
    "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR",
    "california": "CA", "colorado": "CO", "connecticut": "CT", "delaware": "DE",
    "district of columbia": "DC", "florida": "FL", "georgia": "GA", "hawaii": "HI",
    "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA", "kansas": "KS",
    "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
    "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS",
    "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV",
    "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york": "NY",
    "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK",
    "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI",
    "south carolina": "SC", "south dakota": "SD", "tennessee": "TN", "texas": "TX",
    "utah": "UT", "vermont": "VT", "virginia": "VA", "washington": "WA",
    "west virginia": "WV", "wisconsin": "WI", "wyoming": "WY",
}


def _normalize_state(country: str, value: str, iso_code: str = "") -> str:
    state = str(value or "").strip()
    if country != "US":
        return state
    iso = str(iso_code or "").strip().upper()
    if iso.startswith("US-") and len(iso) == 5:
        return iso[-2:]
    if len(state) == 2:
        return state.upper()
    return _US_STATE_CODES.get(state.lower(), state)


def _payload(address: BillingAddress) -> dict[str, str]:
    return {
        "line1": f"{address.house_number} {address.street}".strip(),
        "line2": address.district,
        "city": address.city,
        "state": address.state,
        "postalCode": address.postal_code,
    }


def _load_cache() -> dict[str, Any]:
    try:
        raw = json.loads(CACHE_PATH.read_text(encoding="utf-8"))
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_cache(cache: dict[str, Any]) -> None:
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CACHE_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(cache, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CACHE_PATH)


def _from_tags(country: str, tags: dict[str, Any]) -> BillingAddress | None:
    street = str(tags.get("addr:street") or tags.get("addr:place") or "").strip()
    house = str(tags.get("addr:housenumber") or "").strip()
    if not street or not house:
        return None
    city = str(
        tags.get("addr:city") or tags.get("addr:town") or tags.get("addr:village")
        or tags.get("addr:municipality") or tags.get("addr:county") or ""
    ).strip()
    state = _normalize_state(country, str(
        tags.get("addr:state") or tags.get("addr:province")
        or tags.get("addr:region") or ""
    ).strip(), tags.get("ISO3166-2") or tags.get("addr:state_code") or "")
    district = str(
        tags.get("addr:suburb") or tags.get("addr:district")
        or tags.get("addr:neighbourhood") or tags.get("addr:quarter") or ""
    ).strip()
    postcode = str(tags.get("addr:postcode") or "").strip().upper()
    return BillingAddress(street, house, district, city, state, postcode, country)


def _from_nominatim(country: str, item: dict[str, Any]) -> BillingAddress | None:
    """Normalize an OpenStreetMap Nominatim result into our address model."""
    tags = item.get("address") or {}
    if not isinstance(tags, dict):
        return None
    street = str(
        tags.get("road") or tags.get("pedestrian") or tags.get("residential")
        or tags.get("footway") or tags.get("path") or ""
    ).strip()
    house = str(tags.get("house_number") or "").strip()
    if not street or not house:
        return None
    city = str(
        tags.get("city") or tags.get("town") or tags.get("village")
        or tags.get("municipality") or tags.get("county") or ""
    ).strip()
    state = _normalize_state(country, str(
        tags.get("state") or tags.get("state_district")
        or tags.get("province") or tags.get("region") or ""
    ).strip(), tags.get("ISO3166-2-lvl4") or tags.get("ISO3166-2-lvl6") or "")
    district = str(
        tags.get("suburb") or tags.get("city_district") or tags.get("quarter")
        or tags.get("neighbourhood") or ""
    ).strip()
    postcode = str(tags.get("postcode") or "").strip().upper()
    return BillingAddress(street, house, district, city, state, postcode, country)


def _query_overpass(country: str) -> list[BillingAddress]:
    global _LAST_REQUEST_AT
    if country == "US":
        # US onboarding applies stricter residential checks.  Do not feed the
        # account-creation request with landmarks, offices or government POIs.
        query = (
            '[out:json][timeout:12];'
            f'area["ISO3166-1"="{country}"]->.searchArea;'
            'nwr(area.searchArea)'
            '["building"~"^(house|apartments|residential|detached|semidetached_house|terrace)$"]'
            '["addr:housenumber"]["addr:street"];'
            'out tags 120;'
        )
    else:
        query = (
            '[out:json][timeout:10];'
            f'area["ISO3166-1"="{country}"]->.searchArea;'
            'nwr(area.searchArea)["addr:housenumber"]["addr:street"];'
            'out tags 80;'
        )
    errors = []
    for endpoint in _ENDPOINTS:
        try:
            wait = 1.1 - (time.monotonic() - _LAST_REQUEST_AT)
            if wait > 0:
                time.sleep(wait)
            with httpx.Client(
                timeout=httpx.Timeout(12.0),
                trust_env=False,
                headers={"User-Agent": "gateway-address-resolver/3.0"},
            ) as client:
                response = client.post(endpoint, data={"data": query})
            _LAST_REQUEST_AT = time.monotonic()
            response.raise_for_status()
            body = response.json()
            rows = []
            for element in body.get("elements") or []:
                address = _from_tags(country, element.get("tags") or {})
                if address is not None:
                    rows.append(address)
            if rows:
                return rows
        except Exception as exc:
            errors.append(f"{endpoint}: {exc}")
    raise RuntimeError("online address lookup failed: " + " | ".join(errors))


def _query_nominatim(country: str) -> list[BillingAddress]:
    """Fallback for public Overpass outages.

    A narrow POI query returns address-bearing OSM objects without scanning an
    entire country's address dataset, which is substantially more reliable on
    shared Overpass instances.
    """
    global _LAST_REQUEST_AT
    errors: list[str] = []
    for endpoint in _NOMINATIM_ENDPOINTS:
        try:
            wait = 1.1 - (time.monotonic() - _LAST_REQUEST_AT)
            if wait > 0:
                time.sleep(wait)
            with httpx.Client(
                timeout=httpx.Timeout(18.0),
                trust_env=False,
                headers={
                    "User-Agent": "gateway-address-resolver/3.2",
                    "Accept-Language": "en",
                },
            ) as client:
                response = client.get(
                    endpoint,
                    params={
                        "format": "jsonv2",
                        "addressdetails": 1,
                        "limit": 50,
                        "countrycodes": country.lower(),
                        "q": "apartments" if country == "US" else "hotel",
                    },
                )
            _LAST_REQUEST_AT = time.monotonic()
            response.raise_for_status()
            rows = [
                address
                for item in (response.json() or [])
                if isinstance(item, dict)
                for address in [_from_nominatim(country, item)]
                if address is not None
            ]
            if rows:
                return rows
            errors.append(f"{endpoint}: no address-bearing results")
        except Exception as exc:
            errors.append(f"{endpoint}: {exc}")
    raise RuntimeError("nominatim address lookup failed: " + " | ".join(errors))


def resolve_online_address(
    country: str,
    schema: dict[str, Any],
    *,
    force_refresh: bool = False,
) -> BillingAddress:
    code = str(country or "").strip().upper()
    if len(code) != 2:
        raise ValueError("country must be a two-letter code")
    with _LOCK:
        cache = _load_cache()
        cached = cache.get(code) if isinstance(cache.get(code), dict) else None
        if cached and not force_refresh and time.time() - float(cached.get("saved_at") or 0) < CACHE_TTL_SECONDS:
            item = cached.get("address") or {}
            address = BillingAddress(**item)
            if not validate_runtime_address(schema, _payload(address)):
                return address
        lookup_errors: list[str] = []
        try:
            rows = _query_overpass(code)
        except Exception as exc:
            lookup_errors.append(str(exc))
            rows = []
        if not rows:
            try:
                rows = _query_nominatim(code)
            except Exception as exc:
                lookup_errors.append(str(exc))
                rows = []
        if not rows:
            raise RuntimeError("online address lookup failed: " + " | ".join(lookup_errors))
        random.shuffle(rows)
        best = None
        best_errors = None
        for address in rows:
            errors = validate_runtime_address(schema, _payload(address))
            if not errors:
                best = address
                break
            if best is None or len(errors) < len(best_errors or []):
                best, best_errors = address, errors
        if best is None:
            raise RuntimeError(f"online address lookup returned no usable address for {code}")
        final_errors = validate_runtime_address(schema, _payload(best))
        if final_errors:
            raise RuntimeError("online address did not satisfy runtime schema: " + ", ".join(final_errors))
        cache[code] = {"saved_at": time.time(), "address": best.__dict__}
        _save_cache(cache)
        return best
