(() => {
  "use strict";
  const storageKey = "app-shell:gpt-nav-open";

  function setOpen(group, open) {
    group.classList.toggle("open", open);
    const toggle = group.querySelector(".menu-group-toggle");
    if (toggle) toggle.setAttribute("aria-expanded", String(open));
  }

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".menu-group[data-nav-group]").forEach((group) => {
      const isCurrent = group.dataset.currentGroup === "true";
      let open = group.classList.contains("open");
      try {
        const saved = localStorage.getItem(storageKey);
        if (saved !== null) open = saved === "1";
      } catch (_) {}
      if (isCurrent) open = true;
      setOpen(group, open);

      const toggle = group.querySelector(".menu-group-toggle");
      if (!toggle) return;
      toggle.addEventListener("click", () => {
        const next = !group.classList.contains("open");
        setOpen(group, next);
        try { localStorage.setItem(storageKey, next ? "1" : "0"); } catch (_) {}
      });
    });
  });
})();
