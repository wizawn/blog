const apiBase=document.documentElement.dataset.apiBase||'';
const cardReady=document.getElementById('cardReady');
const flowToast=document.getElementById('flowToast');
const loadCardButton=document.getElementById('loadCardButton');
const atList=document.getElementById('atList');
const addAtButton=document.getElementById('addAtButton');
const clearAtButton=document.getElementById('clearAtButton');
const atCount=document.getElementById('atCount');
const atImportModal=document.getElementById('atImportModal');
const atImportInput=document.getElementById('atImportInput');
const confirmAtImport=document.getElementById('confirmAtImport');
const cancelAtImport=document.getElementById('cancelAtImport');
const cancelAtImportSecondary=document.getElementById('cancelAtImportSecondary');
const startButton=document.getElementById('startButton');
const stopButton=document.getElementById('stopButton');
const copyButton=document.getElementById('copyButton');
const clearButton=document.getElementById('clearButton');
const taskRows=document.getElementById('taskRows');
const statusBox=document.getElementById('status');
const progressText=document.getElementById('progressText');
const progressPercent=document.getElementById('progressPercent');
const progressBar=document.getElementById('progressBar');
const bindProxyPoolInput=document.getElementById('bindProxyPool');
const promoProxyPoolInput=document.getElementById('promoProxyPool');
const bindProxyCount=document.getElementById('bindProxyCount');
const promoProxyCount=document.getElementById('promoProxyCount');
const batchConcurrencyInput=document.getElementById('batchConcurrency');
const barrierMaxWaitInput=document.getElementById('barrierMaxWait');
const poolAtCountInput=document.getElementById('poolAtCount');
const refreshPoolAtsButton=document.getElementById('refreshPoolAtsButton');
const steps=[document.getElementById('stepAt'),document.getElementById('stepCard'),document.getElementById('stepBind'),document.getElementById('stepLink')];

const CONCURRENCY_MAX=50;
const CONCURRENCY_DEFAULT=2;
const BARRIER_WAIT_MIN_SECONDS=15;
const BARRIER_WAIT_MAX_SECONDS=300;
const BARRIER_WAIT_DEFAULT_SECONDS=90;
const MAX_AT_ENTRIES=200;
const POOL_AT_DEFAULT_N=30;
// AT(token) → 号池账号邮箱 的映射：自动填充时记录，成功开通后据此回写号池标记 opened。
const atPoolEmailByToken=new Map();

let stripe=null;
let stripeKey='';
let cardFieldsMounted=false;
const prefetchedSessions=new Map();
let cardNumberElement=null,cardExpiryElement=null,cardCvcElement=null;
const cardComplete={number:false,expiry:false,cvc:false};
let cardIsReady=false;
let stopped=false;
let running=false;
let proxyCursor=0;
let statusTimer=null,statusHideTimer=null;
let cardSetupChain=Promise.resolve();
let poolAtRequestedN=POOL_AT_DEFAULT_N;
let cardSetupPending=0;
const results=[];
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));

function clampConcurrency(value){return Math.max(1,Math.min(CONCURRENCY_MAX,Number(value||CONCURRENCY_DEFAULT)||CONCURRENCY_DEFAULT))}
function clampBarrierWait(value){return Math.max(BARRIER_WAIT_MIN_SECONDS,Math.min(BARRIER_WAIT_MAX_SECONDS,Number(value||BARRIER_WAIT_DEFAULT_SECONDS)||BARRIER_WAIT_DEFAULT_SECONDS))}
function clampPoolAtCount(value){return Math.max(1,Math.min(MAX_AT_ENTRIES,Number(value||POOL_AT_DEFAULT_N)||POOL_AT_DEFAULT_N))}
function status(text,kind=''){
  clearTimeout(statusTimer);
  clearTimeout(statusHideTimer);
  statusBox.textContent=text;
  statusBox.className=('status '+kind).trim();
  if(!text)return;
  requestAnimationFrame(()=>statusBox.classList.add('is-visible'));
  statusTimer=setTimeout(()=>{
    statusBox.classList.remove('is-visible');
    statusHideTimer=setTimeout(()=>{
      if(!statusBox.classList.contains('is-visible')){
        statusBox.textContent='';
        statusBox.className='status';
      }
    },200);
  },3000);
}
function showToast(text,duration=3000){
  if(!flowToast)return;
  flowToast.textContent=text;
  flowToast.classList.add('is-visible');
  setTimeout(()=>flowToast.classList.remove('is-visible'),duration);
}
function setStep(index){steps.forEach((el,i)=>{if(!el)return;el.classList.toggle('active',i===index);el.classList.toggle('done',i<index)})}
function setProgress(done,total,text){const percent=total?Math.round(done*100/total):0;progressText.textContent=text||'';progressPercent.textContent=percent+'%';progressBar.style.width=percent+'%'}
function tokenLabel(token,index){return 'AT '+(index+1)+' · '+token.slice(0,12)+'...'+token.slice(-8)}
function findJsonAccessToken(value){
  if(!value||typeof value!=='object')return'';
  if(Array.isArray(value)){
    for(const item of value){const found=findJsonAccessToken(item);if(found)return found}
    return'';
  }
  const preferred=['accessToken','access_token','access-token','at'];
  for(const key of preferred){
    const token=value[key];
    if(typeof token==='string'&&token.split('.').length===3&&token.length>300)return token.trim();
  }
  for(const [key,item] of Object.entries(value)){
    if(String(key).toLowerCase().includes('sessiontoken'))continue;
    const found=findJsonAccessToken(item);
    if(found)return found;
  }
  return'';
}
function extractToken(raw){
  const text=String(raw||'').trim();
  if(!text)return'';
  if(text.startsWith('{')||text.startsWith('[')){
    try{
      const token=findJsonAccessToken(JSON.parse(text));
      if(token)return token;
    }catch{}
  }
  const named=text.match(/["']access_?token["']\s*:\s*["']([^"']+)["']/i);
  if(named&&named[1])return named[1].trim();
  const jwtMatches=text.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g)||[];
  if(jwtMatches.length)return jwtMatches.sort((a,b)=>b.length-a.length)[0];
  const candidates=text.split(/[\s|,;]+/).filter(value=>value.length>300&&value.split('.').length===3);
  return(candidates.sort((a,b)=>b.length-a.length)[0]||text).trim();
}
function collectJsonAccessTokens(value,push){
  if(!value||typeof value!=='object')return;
  if(Array.isArray(value)){value.forEach(item=>collectJsonAccessTokens(item,push));return}
  const preferred=['accessToken','access_token','access-token','at'];
  for(const key of preferred){
    const token=value[key];
    if(typeof token==='string'&&token.split('.').length===3&&token.length>300)push(token);
  }
  for(const [key,item] of Object.entries(value)){
    if(String(key).toLowerCase().includes('sessiontoken'))continue;
    if(typeof item==='object'&&item)collectJsonAccessTokens(item,push);
  }
}
function extractAllTokens(raw){
  const text=String(raw||'').trim();
  if(!text)return[];
  const seen=new Set(),out=[];
  const push=t=>{const v=String(t||'').trim();if(v.length>=300&&v.includes('.')&&!seen.has(v)){seen.add(v);out.push(v)}};
  if(text.startsWith('{')||text.startsWith('[')){
    try{collectJsonAccessTokens(JSON.parse(text),push);if(out.length)return out}catch{}
  }
  for(const line of text.replace(/\r/g,'').split('\n')){
    const l=line.trim();if(!l)continue;
    const tok=extractToken(l);if(tok)push(tok);
  }
  if(!out.length){(text.match(/eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+/g)||[]).forEach(push)}
  return out;
}
function renumberAtCards(){
  const cards=[...atList.querySelectorAll('.at-entry')];
  cards.forEach((card,index)=>{
    card.querySelector('.at-entry-index').textContent='AT '+String(index+1).padStart(2,'0');
    card.querySelector('.remove-at-button').disabled=running;
  });
}
function handleAtInput(event){
  const input=event.target;
  const card=input.closest('.at-entry');
  if(!running){
    const tokens=extractAllTokens(input.value);
    if(tokens.length>1&&card){
      input.value=tokens[0];
      let ref=card;
      const available=Math.max(0,MAX_AT_ENTRIES-atList.children.length);
      const additions=tokens.slice(1,1+available);
      for(const token of additions){ref.after(buildAtEntry(token));ref=ref.nextElementSibling}
      if(tokens.length-1>additions.length)status('AT 最多只能添加 '+MAX_AT_ENTRIES+' 条。','warn');
      renumberAtCards();
    }
  }
  updateCount();
}
function buildAtEntry(value='',email=''){
  const card=document.createElement('article');
  card.className='at-entry';
  card.innerHTML='<div class="at-entry-head"><span class="at-entry-index"></span><span class="at-entry-state">单独输入</span><button class="remove-at-button" type="button">删除</button></div><textarea class="at-item-input" rows="1" wrap="off" spellcheck="false" autocomplete="off" placeholder="粘贴单个/多个 AT（每行一个）或含 accessToken 的 JSON"></textarea>';
  const input=card.querySelector('.at-item-input');
  input.value=value;
  if(email){card.dataset.email=email;card.querySelector('.at-entry-state').textContent=email;}
  input.addEventListener('input',handleAtInput);
  card.querySelector('.remove-at-button').addEventListener('click',()=>{if(running)return;card.remove();renumberAtCards();updateCount()});
  return card;
}
function addAtField(value=''){
  if(atList.children.length>=MAX_AT_ENTRIES){
    status('AT 最多只能添加 '+MAX_AT_ENTRIES+' 条。','warn');
    return false;
  }
  const card=buildAtEntry(value);
  atList.appendChild(card);renumberAtCards();updateCount();card.querySelector('.at-item-input').focus();
  return true;
}
function closeAtImportModal(){
  atImportModal.hidden=true;
  atImportModal.setAttribute('aria-hidden','true');
}
function openAtImportModal(){
  if(running)return;
  atImportModal.hidden=false;
  atImportModal.setAttribute('aria-hidden','false');
  atImportInput.focus();
}
function importAtTokens(){
  const tokens=extractAllTokens(atImportInput.value);
  const available=Math.max(0,MAX_AT_ENTRIES-atList.children.length);
  const additions=tokens.slice(0,available);
  additions.forEach(token=>atList.appendChild(buildAtEntry(token)));
  if(tokens.length>additions.length)status('AT 最多只能添加 '+MAX_AT_ENTRIES+' 条，已导入可用条目。','warn');
  else if(tokens.length)status('已导入 '+additions.length+' 条 AT。','ok');
  else status('未识别到有效 AT。','warn');
  renumberAtCards();
  updateCount();
  atImportInput.value='';
  closeAtImportModal();
}
function parseTokens(){
  const seen=new Set(),items=[];
  for(const input of atList.querySelectorAll('.at-item-input')){
    const token=extractToken(input.value);
    if(token.length<300||!token.includes('.')||seen.has(token))continue;
    seen.add(token);items.push(token);
  }
  return items;
}
function parseProxyInput(input){
  const seen=new Set(),items=[];
  for(const line of String(input?.value||'').replace(/\r/g,'').split('\n')){
    const value=line.trim();if(!value||seen.has(value))continue;
    seen.add(value);items.push(value);
    if(items.length>=500)break;
  }
  return items;
}
function parseBindProxyPool(){return parseProxyInput(bindProxyPoolInput)}
function parsePromoProxyPool(){return parseProxyInput(promoProxyPoolInput)}
function nextProxy(){
  const pool=parseBindProxyPool();
  if(!pool.length)throw new Error('请先在代理池 1 填写至少一个 US 绑卡节点');
  const value=pool[proxyCursor%pool.length];proxyCursor=(proxyCursor+1)%Math.max(1,pool.length);return value;
}
function saveAtList(){
  try{
    const values=[...atList.querySelectorAll('.at-item-input')].map(el=>el.value);
    if(values.length)localStorage.setItem('cardLinkAtList',JSON.stringify(values));
    else localStorage.removeItem('cardLinkAtList');
  }catch{}
}
function restoreAtList(){
  let saved=[];
  try{saved=JSON.parse(localStorage.getItem('cardLinkAtList')||'[]')}catch{}
  if(Array.isArray(saved)&&saved.length){
    saved.slice(0,MAX_AT_ENTRIES).forEach(v=>atList.appendChild(buildAtEntry(String(v||''))));
    renumberAtCards();updateCount();
  }
}
// 打开/刷新页面时，从账号号池随机拉取指定数量的「未开通」AT；失败时回退本地缓存。
async function autoLoadPoolAts(requestedN=poolAtRequestedN){
  const n=clampPoolAtCount(requestedN);
  poolAtRequestedN=n;
  if(poolAtCountInput)poolAtCountInput.value=String(n);
  localStorage.setItem('cardLinkPoolAtCount',String(n));
  if(refreshPoolAtsButton)refreshPoolAtsButton.disabled=true;
  try{
    const data=await api(apiBase+'/api/card-flow/pool-ats?n='+n);
    const items=Array.isArray(data?.ats)?data.ats:[];
    // 接口成功但号池已无「未开通」账号：清空列表（不回退旧缓存，避免已开通的 AT 复现），仅提示可手动导入。
    if(!items.length){
      atList.innerHTML='';atPoolEmailByToken.clear();renumberAtCards();updateCount();saveAtList();
      status('号池暂无未开通账号，可手动导入 AT。','warn');return;
    }
    atList.innerHTML='';
    atPoolEmailByToken.clear();
    items.slice(0,MAX_AT_ENTRIES).forEach(it=>{
      const token=String(it.accessToken||'').trim();
      if(!token)return;
      const email=String(it.email||'').trim();
      if(email)atPoolEmailByToken.set(token,email);
      atList.appendChild(buildAtEntry(token,email));
    });
    renumberAtCards();updateCount();
    // 自动填充后同步到本地缓存，避免下次因接口异常时列表为空。
    saveAtList();
    status('已从号池加载 '+atList.children.length+' / '+n+' 个未开通 AT（可用 '+(data.total_unopened||atList.children.length)+' 个）。','ok');
  }catch(error){
    // 未登录或接口异常时不打扰用户，回退本地缓存，保留手动导入能力。
    restoreAtList();
    status('号池读取失败，已保留本地 AT 列表。','warn');
  }finally{
    if(refreshPoolAtsButton)refreshPoolAtsButton.disabled=false;
  }
}
// 成功开通后回写号池：把该账号标记为已开通（opened=true），刷新页面即不再拉取。仅成功时调用。
function markPoolOpened(email,token){
  try{
    const body={};
    if(token)body.access_token=token;
    const mail=email||(token&&atPoolEmailByToken.get(token))||'';
    if(mail)body.email=mail;
    if(!body.access_token&&!body.email)return;
    fetch(apiBase+'/api/card-flow/pool-mark-opened',{
      method:'POST',headers:{'Content-Type':'application/json'},
      credentials:'same-origin',body:JSON.stringify(body)
    }).catch(()=>{});
  }catch{}
}
function updateCount(){
  const valid=parseTokens().length;
  const bindProxies=parseBindProxyPool().length;
  const promoProxies=parsePromoProxyPool().length;
  atCount.textContent=valid+' / '+poolAtRequestedN+' AT';
  bindProxyCount.textContent=bindProxies+' PROXY';
  promoProxyCount.textContent=promoProxies+' PROXY';
  if(!running){
    loadCardButton.disabled=cardFieldsMounted||!(valid&&bindProxies);
    loadCardButton.textContent=cardFieldsMounted?'卡片输入框已加载':'加载安全卡片输入框';
    startButton.disabled=!(cardFieldsMounted&&cardIsReady&&valid&&bindProxies&&promoProxies);
    startButton.textContent='开始批量绑卡并提链';
  }
  saveAtList();
}

async function api(url,options={}){
  let response;
  try{
    response=await fetch(url,{credentials:'include',...options});
  }catch(cause){
    const error=new Error(cause?.message||'网络请求失败');
    error.httpStatus=0;error.networkError=true;throw error;
  }
  const data=await response.json().catch(()=>({}));
  if(!response.ok||data.error||data.ok===false){
    const message=['AT_INVALID_OR_EXPIRED','AT_INVALIDATED_OR_EXPIRED'].includes(data.error)?'AT 已被服务端失效或轮换，请使用最新 AT 重试':(data.error||('HTTP '+response.status));
    const error=new Error(message);
    error.httpStatus=response.status;
    error.upstreamStatus=Number(data.status||0);
    throw error;
  }
  return data;
}
function retryableNetworkError(error){
  const http=Number(error?.httpStatus||0);
  const upstream=Number(error?.upstreamStatus||0);
  const message=String(error?.message||'').toLowerCase();
  if(error?.networkError)return true;
  if([502,503,504].includes(http)&&(!upstream||upstream>=500||upstream===403))return true;
  return /network|timeout|timed out|connection|transport|tls|ssl|empty reply|temporar|upstream/.test(message);
}
async function apiWithRetry(url,options={},attempts=3,onRetry=null){
  let lastError=null;
  for(let attempt=1;attempt<=attempts;attempt++){
    try{return await api(url,options)}
    catch(error){
      lastError=error;
      if(!retryableNetworkError(error)||attempt>=attempts)throw error;
      if(onRetry)onRetry(attempt,attempts,error);
      await sleep(1000*attempt);
    }
  }
  throw lastError||new Error('网络请求失败');
}
async function apiWithProxyRetry(url,baseBody,attempts=3,onRetry=null){
  let lastError=null;
  for(let attempt=1;attempt<=attempts;attempt++){
    const proxy=nextProxy();
    const body={...baseBody,proxy,proxy_pool:parseBindProxyPool()};
    try{return await api(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})}
    catch(error){
      lastError=error;
      if(!retryableNetworkError(error)||attempt>=attempts)throw error;
      if(onRetry)onRetry(attempt,attempts,error);
      await sleep(1000*attempt);
    }
  }
  throw lastError||new Error('代理请求失败');
}
function isCheckoutUrl(value){
  return typeof value==='string'&&/^https:\/\/(pay\.vendor-platform\.com\/|platform\.example\.com\/checkout\/|checkout\.stripe\.com\/)/.test(value);
}
function findLink(value){
  if(!value)return'';
  if(typeof value==='string')return isCheckoutUrl(value)?value:'';
  if(Array.isArray(value)){for(const item of value){const found=findLink(item);if(found)return found}return''}
  if(typeof value==='object'){
    for(const key of ['checkout_url','short_link','short_url','url','link']){if(isCheckoutUrl(value[key]))return value[key];}
    for(const item of Object.values(value)){const found=findLink(item);if(found)return found}
  }
  return'';
}
function normalizeActivationReason(value,kind=''){
  const text=String(value||'').trim();
  if(!text)return kind==='success'?'开通完成':'—';
  const lower=text.toLowerCase();
  if(/task[_\s-]?not[_\s-]?found/.test(lower))return'你的账号无资格！';
  if(lower.includes('billing country must match request country'))return'地区不支持！';
  if(lower.includes('vendor_confirm_blocked'))return'确认被拒（账号资格/风控）';
  if(lower.includes('no such payment_page'))return'结账会话失效，请重试';
  if(lower.includes('ph 短链优惠未生效'))return'优惠未生效（可能无资格）';
  if(/card_declined|card.*declined/.test(lower))return'银行卡被拒绝';
  if(/insufficient[_\s-]?funds|insufficient funds/.test(lower))return'余额不足';
  if(/token.*(invalid|invalidated|expired)|at.*(invalid|expired)|at_invalid/.test(lower))return'AT 已失效或过期';
  if(/not eligible|not_eligible/.test(lower))return'账号不符合开通条件';
  if(/setup[_\s-]?intent.*(failed|fail)|setup_intent_failed/.test(lower))return'绑卡失败';
  if(/no payment account|payment account.*(not|missing|exist)/.test(lower))return'支付账户未就绪';
  if(/proxy.*preflight.*failed|proxy_preflight_failed/.test(lower))return'代理不可用';
  if(/checkout.*timeout|checkout_timeout|开通超时/.test(lower))return'开通超时';
  return'未知原因：'+text;
}
function confirmCardSetupSerialized(clientSecret,paymentMethod){
  const stripeInstance=stripe;
  cardSetupPending++;
  loadCardButton.disabled=true;
  startButton.disabled=true;
  const confirmation=cardSetupChain.then(
    ()=>stripeInstance.confirmCardSetup(clientSecret,{payment_method:paymentMethod}),
    ()=>stripeInstance.confirmCardSetup(clientSecret,{payment_method:paymentMethod})
  );
  cardSetupChain=confirmation.catch(()=>{});
  return confirmation.finally(()=>{
    cardSetupPending=Math.max(0,cardSetupPending-1);
    if(!cardSetupPending&&!running)updateCount();
  });
}
function normalizeActivationStage(value){
  const text=String(value||'').trim();
  if(!text)return'等待中';
  const lower=text.toLowerCase();
  if(/validating us\/tr proxy pools|validating.*proxy pools/.test(lower))return'正在校验 US/TR 代理池';
  if(/checkout extraction running|checkout.*extract.*running/.test(lower))return'正在提链';
  if(/checkout completed/.test(lower))return'提链完成';
  if(/proxy preflight passed/.test(lower))return'代理预检通过';
  if(/checkout created/.test(lower))return'已创建开通任务';
  if(/task created/.test(lower))return'开通任务已创建';
  if(/submitting subscription|submitting/.test(lower))return'正在提交支付';
  return text;
}
function addRow(id,label){
  const row=document.createElement('div');row.className='task-row';row.id=id;
  row.innerHTML='<div class="row-account-wrap"><small>账号：</small><span class="row-account"></span></div><div class="row-line2"><div class="row-stage-wrap"><small>结果：</small><span class="row-stage">等待中</span></div><div class="row-message-wrap"><small>原因：</small><span class="row-message">—</span></div></div>';
  row.querySelector('.row-account').textContent=label;
  taskRows.appendChild(row);return row;
}
function updateRow(row,stage,kind='',result=''){
  row.className=('task-row '+kind).trim();
  row.querySelector('.row-stage').textContent=normalizeActivationStage(stage);
  const message=row.querySelector('.row-message');
  message.textContent=normalizeActivationReason(result,kind);
}
function refreshOutput(){}

async function pollCheckout(taskId,onProgress=null){
  for(let i=0;i<300;i++){
    if(stopped)throw new Error('任务已停止');
    const task=await apiWithRetry(apiBase+'/api/card-flow/task/'+taskId,{},3);
    if(onProgress)onProgress(task);
    if(task.status==='done'){
      const result=task.result||task;
      const link=findLink(result);
      if(!link)throw new Error('提链任务完成但未返回链接');
      const paymentStatus=String(result.payment_status||'').toLowerCase();
      if(paymentStatus==='verification_required'){
        const error=new Error('短链已生成，但支付需要额外验证');
        error.link=link;error.paymentStatus=paymentStatus;error.soft=true;
        throw error;
      }
      if(paymentStatus&&paymentStatus!=='success'&&result.subscription_ok!==true){
        const error=new Error(task.message||('支付未完成：'+paymentStatus));
        error.link=link;error.paymentStatus=paymentStatus;
        throw error;
      }
      return link;
    }
    if(['error','failed','cancelled'].includes(task.status))throw new Error(task.error||task.message||'开通失败');
    await sleep(2000);
  }
  throw new Error('提链/支付超时');
}
// 阶段一：轮询直到账号完成 绑卡→Checkout→CustomerSession→ConfirmationToken 的准备，停在 prepared 屏障。
async function pollUntilPrepared(taskId,onProgress=null){
  for(let i=0;i<300;i++){
    if(stopped)throw new Error('任务已停止');
    const task=await apiWithRetry(apiBase+'/api/card-flow/task/'+taskId,{},3);
    if(onProgress)onProgress(task);
    if(task.status==='prepared')return task;
    // defer 模式下正常不会直接 done；若后端未按屏障停住，回退当作已完成放行。
    if(task.status==='done')return task;
    if(['error','failed','cancelled'].includes(task.status))throw new Error(task.error||task.message||'准备失败');
    await sleep(2000);
  }
  throw new Error('准备超时');
}
async function mountCardFields(publishableKey){
  if(typeof window.Stripe!=='function')throw new Error('Stripe 安全组件加载失败，请刷新页面后重试');
  if(cardNumberElement){try{cardNumberElement.destroy()}catch{}}
  if(cardExpiryElement){try{cardExpiryElement.destroy()}catch{}}
  if(cardCvcElement){try{cardCvcElement.destroy()}catch{}}
  for(const key of Object.keys(cardComplete))cardComplete[key]=false;
  cardIsReady=false;updateCount();
  stripeKey=publishableKey;
  cardFieldsMounted=true;
  stripe=Stripe(publishableKey);
  const elements=stripe.elements();
  const style={
    base:{fontSize:'16px',fontFamily:'Inter,"Microsoft YaHei","PingFang SC","Segoe UI",system-ui,sans-serif',color:'#0f172a',iconColor:'#2563eb','::placeholder':{color:'#94a3b8'}},
    invalid:{color:'#dc2626',iconColor:'#dc2626'}
  };
  cardNumberElement=elements.create('cardNumber',{showIcon:true,placeholder:'卡号',style});
  cardExpiryElement=elements.create('cardExpiry',{placeholder:'有效期',style});
  cardCvcElement=elements.create('cardCvc',{placeholder:'安全码',style});
  const entries=[['number',cardNumberElement,'#cardNumberElement'],['expiry',cardExpiryElement,'#cardExpiryElement'],['cvc',cardCvcElement,'#cardCvcElement']];
  let readyCount=0;
  const refreshCardState=()=>{
    cardIsReady=cardComplete.number&&cardComplete.expiry&&cardComplete.cvc;
    cardReady.textContent=cardIsReady?'卡片信息已填写完整':'请填写完整卡号、有效期和 CVC';
    cardReady.className='inline-state '+(cardIsReady?'ok':'');updateCount();
  };
  for(const [name,element,selector] of entries){
    document.querySelector(selector).innerHTML='';
    element.on('ready',()=>{readyCount++;if(readyCount===3){cardReady.textContent='卡片输入框已就绪';cardReady.className='inline-state ok'}});
    element.on('change',event=>{cardComplete[name]=Boolean(event.complete);const host=document.querySelector(selector);host.classList.toggle('field-complete',Boolean(event.complete));host.classList.toggle('field-invalid',Boolean(event.error));if(event.error){cardReady.textContent=event.error.message;cardReady.className='inline-state error'}else refreshCardState()});
    element.mount(selector);
  }
}
async function init(){
  setStep(0);
  cardReady.textContent='请先填写 AT 和代理池，再点击“加载安全卡片输入框”';
  cardReady.className='inline-state';
  showToast('填写 AT 与代理池后，先加载卡片输入框，再输入卡号、有效期和 CVC。');
  updateCount();
}
async function resolvePendingKey(session){
  if(!session||!session.pending)return session;
  const probeId=String(session.key_probe_id||'');
  if(!probeId)throw new Error('缺少 Stripe 密钥探测 ID');
  for(let i=0;i<360;i++){
    const data=await apiWithRetry(apiBase+'/api/card-bind/key-probe/'+probeId,{},3);
    const probe=data.probe||{};
    status('正在通过临时 Checkout 解析 Stripe 密钥：'+Number(probe.progress||0)+'%');
    if(probe.status==='done'){
      const refreshed=(probe.session&&typeof probe.session==='object')?probe.session:{};
      const key=String(refreshed.publishable_key||probe.publishable_key||'');
      if(!key.startsWith('pk_'))throw new Error('Checkout 初始化完成但未返回 Stripe 密钥');
      if(!String(refreshed.client_secret||'').startsWith('seti_'))throw new Error('Checkout 已初始化，但缺少刷新后的 SetupIntent');
      return {...session,...refreshed,pending:false,publishable_key:key,publishable_key_source:'checkout_then_refetch'};
    }
    if(probe.status==='error')throw new Error(probe.error||probe.message||'Stripe 密钥解析失败');
    await sleep(2000);
  }
  throw new Error('Stripe 密钥解析超时');
}
async function loadCardFieldsFromAt(token){
  status('正在读取 AT 并解析 Stripe 账户…');
  let session=await apiWithProxyRetry(apiBase+'/api/card-bind/session',{access_token:token},3,(attempt,total)=>status('解析 Stripe 账户，代理重试 '+attempt+' / '+total));
  session=await resolvePendingKey(session);
  const key=String(session.publishable_key||'');
  if(!key.startsWith('pk_'))throw new Error('AT/Checkout 响应中未包含 Stripe 公钥');
  prefetchedSessions.set(token,session);
  await mountCardFields(key);
  status(session.publishable_key_source==='checkout_protocol_fallback'?'AT 响应无密钥，已创建一次 Checkout，卡片输入框现已就绪。':'已直接从 AT 响应解析出 Stripe 密钥。','ok');
}
async function prepareOne(token,index,total,existingRow=null,defer=false){
  const row=existingRow||addRow('task-'+Date.now()+'-'+index,tokenLabel(token,index));
  row._token=token;row.dataset.atIndex=String(index);
  row.querySelector('.row-account').textContent=tokenLabel(token,index);
  updateRow(row,'读取 AT 并创建 SetupIntent','running');
  let session=prefetchedSessions.get(token)||null;
  if(session)prefetchedSessions.delete(token);
  if(!session){
    session=await apiWithProxyRetry(apiBase+'/api/card-bind/session',{access_token:token},3,(attempt,total)=>updateRow(row,'代理重试 '+attempt+' / '+total,'running'));
    session=await resolvePendingKey(session);
  }
  const sessionKey=String(session.publishable_key||'');
  if(sessionKey&&sessionKey!==stripeKey){
    prefetchedSessions.set(token,session);
    await mountCardFields(sessionKey);
    stopped=true;
    const error=new Error('Stripe 账户已变更，卡片输入框已用新的 Checkout 密钥刷新；请重新输入卡片并重试该 AT。');
    error.cardReentryRequired=true;
    throw error;
  }
  const account=session.account_email||('account-'+(index+1));
  row.querySelector('.row-account').textContent=account;
  if(!session.billing_details)throw new Error('缺少自动生成的美国账单信息');

  updateRow(row,'正在绑定卡片','running');
  const confirmation=await confirmCardSetupSerialized(
    session.client_secret,
    {card:cardNumberElement,billing_details:session.billing_details}
  );
  if(confirmation.error)throw new Error(confirmation.error.message||'卡片绑定失败');
  if(!confirmation.setupIntent||confirmation.setupIntent.status!=='succeeded')throw new Error('卡片绑定状态：'+(confirmation.setupIntent?.status||'unknown'));
  const pm=typeof confirmation.setupIntent.payment_method==='string'?confirmation.setupIntent.payment_method:confirmation.setupIntent.payment_method?.id;
  if(!pm)throw new Error('Stripe 未返回 PaymentMethod');

  updateRow(row,'将卡片设为账号默认','running');
  await apiWithProxyRetry(apiBase+'/api/card-bind/default',{payment_method_id:pm,record_id:session.record_id,access_token:token},3,(attempt,total)=>updateRow(row,'绑定代理重试 '+attempt+' / '+total,'running'));

  updateRow(row,defer?'准备中(排队)':'开通已排队','running');
  const created=await apiWithRetry(apiBase+'/api/card-flow/quick-checkout',{
    method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({record_id:session.record_id,access_token:token,entry_proxy_pool:parseBindProxyPool(),exit_proxy_pool:parsePromoProxyPool(),defer_confirm:defer})
  },3,(attempt,total)=>updateRow(row,'提链重试 '+attempt+' / '+total,'running'));
  row._taskId=created.task_id;
  return{account,row,taskId:created.task_id,token};
}
async function retrySingleAt(row){
  if(!row?._token||row._retrying)return;
  if(!row.querySelector('.retry-one-button'))return;
  if(!cardIsReady){status('请先填写完整卡片信息，再重试该 AT。','error');return}
  const batchWasRunning=running;
  row._retrying=true;
  const retry=row.querySelector('.retry-one-button');
  retry.disabled=true;
  if(!batchWasRunning){startButton.disabled=true;addAtButton.disabled=true;clearAtButton.disabled=true}
  try{
    status('正在重试该 AT，重新绑卡并提链…');
    if(row._taskId){
      try{
        await api(apiBase+'/api/card-flow/task/'+row._taskId+'/cancel',{method:'POST'});
        await sleep(300);
      }catch{}
      row._taskId='';
    }
    const index=Number(row.dataset.atIndex||0);
    const prepared=await prepareOne(row._token,index,1,row);
    const link=await pollCheckout(prepared.taskId,task=>updateRow(prepared.row,task.message||'开通进行中','running'));
    const previous=results.findIndex(item=>item.account===prepared.account);
    if(previous>=0)results.splice(previous,1);
    results.push({account:prepared.account,link});
    refreshOutput();
    updateRow(row,'开通成功','success');
    markPoolOpened(prepared.account,row._token);
    status('该 AT 重试成功（已开通）。','ok');
  }catch(error){
    if(error.link){
      updateRow(row,error.soft?'待验证':'开通失败','failed',error.message);
    }else{
      updateRow(row,'重试失败','failed',error.message);
    }
    status('该 AT 重试失败：'+error.message,'error');
  }finally{
    row._retrying=false;retry.disabled=false;
    if(!batchWasRunning){
      startButton.disabled=!(cardFieldsMounted&&cardIsReady&&parseTokens().length&&parseBindProxyPool().length&&parsePromoProxyPool().length);
      addAtButton.disabled=false;clearAtButton.disabled=false;
    }
  }
}

loadCardButton.addEventListener('click',async()=>{
  if(running||cardFieldsMounted)return;
  const tokens=parseTokens();
  if(!tokens.length){status('请先填写至少一个有效 AT。','error');return}
  if(!parseBindProxyPool().length){status('请先在代理池 1 填写 US 绑卡节点。','error');return}
  running=true;setStep(1);loadCardButton.disabled=true;startButton.disabled=true;addAtButton.disabled=true;clearAtButton.disabled=true;
  cardReady.textContent='正在创建安全卡片输入会话…';cardReady.className='inline-state';
  try{
    await loadCardFieldsFromAt(tokens[0]);
    cardReady.textContent='卡片输入框已就绪，请输入卡号、有效期和 CVC';
    cardReady.className='inline-state ok';
  }catch(error){
    cardFieldsMounted=false;
    cardReady.textContent='卡片输入框加载失败：'+error.message;
    cardReady.className='inline-state error';
    status('卡片输入框加载失败：'+error.message,'error');
  }finally{
    running=false;addAtButton.disabled=false;clearAtButton.disabled=false;renumberAtCards();updateCount();
  }
});

startButton.addEventListener('click',async()=>{
  if(running)return;
  const tokens=parseTokens();
  if(!tokens.length){status('请填写至少一个有效 AT。','error');return}
  if(!parseBindProxyPool().length){status('请在代理池 1 填写 US 绑卡节点。','error');return}
  if(!parsePromoProxyPool().length){status('请在代理池 2 填写 TR 优惠节点。','error');return}
  if(!cardFieldsMounted){status('请先点击“加载安全卡片输入框”。','error');return}
  if(!cardIsReady){status('请填写完整卡号、有效期和 CVC。','error');return}
  const concurrency=clampConcurrency(Math.min(tokens.length,Number(batchConcurrencyInput?.value||CONCURRENCY_DEFAULT)||CONCURRENCY_DEFAULT));
  localStorage.setItem('cardLinkConcurrency',String(concurrency));
  running=true;stopped=false;results.length=0;refreshOutput();taskRows.innerHTML='';
  startButton.disabled=true;stopButton.disabled=false;addAtButton.disabled=true;clearAtButton.disabled=true;atList.querySelectorAll('textarea,button').forEach(el=>el.disabled=true);
  setStep(2);setProgress(0,tokens.length*2,'准备批量绑卡，并发 '+concurrency);
  let success=0,failed=0,finishedUnits=0,nextIndex=0;
  const totalUnits=tokens.length*2;
  const progressUpdate=text=>setProgress(Math.min(finishedUnits,totalUnits),totalUnits,text);
  const preparedTasks=[];
  const barrierWaitSeconds=clampBarrierWait(barrierMaxWaitInput?.value);
  localStorage.setItem('cardLinkBarrierWait',String(barrierWaitSeconds));
  let barrierReleased=false;
  let firstPreparedAt=0;
  let resolveFirstPrepared=null;
  const firstPrepared=new Promise(resolve=>{resolveFirstPrepared=resolve});
  const releasePrepared=async reason=>{
    if(barrierReleased||!preparedTasks.length||stopped)return;
    barrierReleased=true;
    const releaseBatch=preparedTasks.slice();
    setStep(3);
    const waited=Math.max(0,Math.round((Date.now()-firstPreparedAt)/1000));
    status(reason==='max_wait'
      ? '已达最大等待 '+barrierWaitSeconds+' 秒，放行 '+releaseBatch.length+' 个已就绪账号…'
      : '阶段二·统一放行 '+releaseBatch.length+' 个已就绪账号…');
    let released=false;
    try{
      await apiWithRetry(apiBase+'/api/card-flow/release',{
        method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({task_ids:releaseBatch.map(t=>t.taskId)})
      },3,(attempt,total)=>status('批量放行重试 '+attempt+' / '+total));
      released=true;
    }catch(error){
      status('批量放行失败：'+error.message,'error');
      releaseBatch.forEach(t=>{updateRow(t.row,'放行失败','failed',error.message);failed++;});
    }
    if(!released)return;
    await Promise.all(releaseBatch.map(async prepared=>{
      try{
        const link=await pollCheckout(prepared.taskId,task=>updateRow(prepared.row,task.message||'开通进行中','running'));
        results.push({account:prepared.account,link});refreshOutput();
        updateRow(prepared.row,'开通成功','success');success++;
        markPoolOpened(prepared.account,prepared.token);
      }catch(error){
        if(!prepared.row._retrying){
          failed++;
          updateRow(prepared.row,error.soft?'待验证':'开通失败','failed',error.message);
        }
      }finally{
        finishedUnits++;progressUpdate('已处理 '+(success+failed)+' / '+tokens.length);
      }
    }));
    if(reason==='max_wait')status('已在等待 '+waited+' 秒后放行 '+releaseBatch.length+' 个已就绪账号；其余未就绪账号不纳入本批。','warn');
  };
  // 阶段一（准备）：所有账号并发完成 绑卡→Checkout→CustomerSession→ConfirmationToken，停在 prepared 屏障，不立即确认订阅。
  const prepareWorker=async workerId=>{
    await sleep(workerId*120);
    while(!stopped&&!barrierReleased){
      const i=nextIndex++;
      if(i>=tokens.length)return;
      status('阶段一·准备中 '+Math.min(nextIndex,tokens.length)+' / '+tokens.length+'，并发 '+concurrency);
      let prepared=null;
      try{
        prepared=await prepareOne(tokens[i],i,tokens.length,null,true);
      }catch(error){
        failed++;finishedUnits+=2;
        const row=document.querySelector('[data-at-index="'+i+'"]')||taskRows.querySelectorAll('.task-row')[i];
        if(row)updateRow(row,'绑卡失败','failed',error.message);
        progressUpdate('准备失败 '+failed+' 个');
        continue;
      }
      if(stopped)return;
      try{
        await pollUntilPrepared(prepared.taskId,task=>updateRow(prepared.row,task.message||'准备中','running'));
        if(barrierReleased){
          updateRow(prepared.row,'未纳入本批','failed','已超过屏障等待上限');
          failed++;finishedUnits+=2;
          try{await apiWithRetry(apiBase+'/api/card-flow/task/'+prepared.taskId+'/cancel',{method:'POST'},1)}catch{}
          continue;
        }
        prepared.index=i;
        preparedTasks.push(prepared);
        if(!firstPreparedAt){
          firstPreparedAt=Date.now();
          resolveFirstPrepared();
          status('首个账号已就绪，最多等待 '+barrierWaitSeconds+' 秒后将放行当前已就绪账号。');
        }
        updateRow(prepared.row,'已就绪(prepared)，等待放行','prepared');
        finishedUnits++;progressUpdate('已就绪 '+preparedTasks.length+' 个，准备中/失败 '+(i+1-preparedTasks.length));
      }catch(error){
        failed++;finishedUnits+=2;
        updateRow(prepared.row,'准备失败','failed',error.message);
        progressUpdate('准备失败 '+failed+' 个');
      }
    }
  };
  const workersDone=Promise.all(Array.from({length:concurrency},(_,index)=>prepareWorker(index)));
  const releaseReason=await Promise.race([
    workersDone.then(()=> 'workers_done'),
    firstPrepared.then(()=>sleep(barrierWaitSeconds*1000).then(()=> 'max_wait')),
  ]);
  const releasePromise=releasePrepared(releaseReason);
  await Promise.all([workersDone,releasePromise]);
  setStep(3);setProgress(totalUnits,totalUnits,'全部完成');
  status('批量完成：成功 '+success+' 个，失败 '+failed+' 个'+(stopped?'（已停止）':''),failed?'error':'ok');
  running=false;stopButton.disabled=true;addAtButton.disabled=false;clearAtButton.disabled=false;atList.querySelectorAll('textarea,button').forEach(el=>el.disabled=false);taskRows.querySelectorAll('.retry-one-button:not([hidden])').forEach(button=>button.disabled=false);renumberAtCards();updateCount();
});
stopButton.addEventListener('click',()=>{stopped=true;stopButton.disabled=true;status('将在当前账号处理完成后停止…')});
copyButton.addEventListener('click',async()=>{
  const accounts=[...taskRows.querySelectorAll('.task-row.success .row-account')].map(el=>el.textContent.trim()).filter(Boolean);
  if(!accounts.length){status('暂无已开通账号。','warn');return}
  await navigator.clipboard.writeText(accounts.join('\n'));
  status('已复制 '+accounts.length+' 个已开通账号。','ok');
});
clearButton.addEventListener('click',()=>{results.length=0;refreshOutput();taskRows.innerHTML='';setProgress(0,0,'等待开始');status('结果已清空。')});
addAtButton.addEventListener('click',openAtImportModal);
clearAtButton.addEventListener('click',()=>{if(running)return;atList.innerHTML='';localStorage.removeItem('cardLinkAtList');renumberAtCards();updateCount();status('AT 列表已清空。','ok')});
confirmAtImport.addEventListener('click',importAtTokens);
cancelAtImport.addEventListener('click',closeAtImportModal);
cancelAtImportSecondary.addEventListener('click',closeAtImportModal);
atImportModal.addEventListener('click',event=>{if(event.target===atImportModal)closeAtImportModal()});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!atImportModal.hidden)closeAtImportModal()});
bindProxyPoolInput.value=localStorage.getItem('cardLinkBindProxyPool')||localStorage.getItem('cardLinkProxyPool')||'';
promoProxyPoolInput.value=localStorage.getItem('cardLinkPromoProxyPool')||'';
if(batchConcurrencyInput)batchConcurrencyInput.value=localStorage.getItem('cardLinkConcurrency')||String(CONCURRENCY_DEFAULT);
if(barrierMaxWaitInput)barrierMaxWaitInput.value=localStorage.getItem('cardLinkBarrierWait')||String(BARRIER_WAIT_DEFAULT_SECONDS);
poolAtRequestedN=clampPoolAtCount(localStorage.getItem('cardLinkPoolAtCount')||POOL_AT_DEFAULT_N);
if(poolAtCountInput)poolAtCountInput.value=String(poolAtRequestedN);
bindProxyPoolInput.addEventListener('input',()=>{localStorage.setItem('cardLinkBindProxyPool',bindProxyPoolInput.value);updateCount()});
promoProxyPoolInput.addEventListener('input',()=>{localStorage.setItem('cardLinkPromoProxyPool',promoProxyPoolInput.value);updateCount()});
batchConcurrencyInput?.addEventListener('change',()=>{const value=clampConcurrency(batchConcurrencyInput.value);batchConcurrencyInput.value=String(value);localStorage.setItem('cardLinkConcurrency',String(value))});
barrierMaxWaitInput?.addEventListener('change',()=>{const value=clampBarrierWait(barrierMaxWaitInput.value);barrierMaxWaitInput.value=String(value);localStorage.setItem('cardLinkBarrierWait',String(value))});
poolAtCountInput?.addEventListener('change',()=>{const value=clampPoolAtCount(poolAtCountInput.value);poolAtCountInput.value=String(value);poolAtRequestedN=value;localStorage.setItem('cardLinkPoolAtCount',String(value));updateCount()});
refreshPoolAtsButton?.addEventListener('click',()=>{if(!running)autoLoadPoolAts(poolAtCountInput?.value)});
autoLoadPoolAts(poolAtRequestedN);
init();
