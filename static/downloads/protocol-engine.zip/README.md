# Protocol Engine

A collection of modules for automating SaaS subscription checkout via the Stripe payment protocol.

## Overview

Protocol Engine implements the full lifecycle of Stripe-based subscription management:

- **Checkout** (`checkout.js`) - Subscription creation flow with guard logic and retry handling
- **Billing** (`billing.js`) - Account billing state queries and payment method management
- **Upgrade** (`upgrade.js`, `upgrade-invoice.js`) - Plan upgrade orchestration including invoice-based flows
- **Recharge** (`recharge.js`) - Core recharge pipeline: session setup, payment confirmation, and post-payment verification
- **Cards** (`cards.js`) - Payment method addition via SetupIntent / ConfirmationToken
- **Stripe Client** (`stripe-client.js`, `stripe-build.js`) - Low-level Stripe API interactions (Elements sessions, confirmation tokens, payment intent confirmation)
- **Virtual Card** (`virtual-card.js`) - Virtual card provider integration for automated card provisioning
- **Regions** (`regions.js`) - Multi-region checkout configuration (currency, pricing, tax)
- **Protocol Context** (`protocol-context.js`) - Shared execution context for a single checkout attempt
- **Fingerprint** (`fingerprint.js`, `device-fingerprint.js`) - Browser and device fingerprint generation
- **TLS Client** (`tls-client.js`) - TLS fingerprint-aware HTTP client wrapper

## Configuration

Key environment variables:

| Variable | Description |
|---|---|
| `VENDOR_PK` | Stripe publishable key |
| `VIRTUAL_CARD_API_KEY` | Virtual card provider API key |
| `VIRTUAL_CARD_BASE_URL` | Virtual card provider endpoint |

## Usage

```js
import { rechargePhp } from './src/recharge.js';
```

## License

Proprietary
