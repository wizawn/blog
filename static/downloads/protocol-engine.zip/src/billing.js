// Vendor billing: subscription, invoices, reconcile, cancel, payment-method list/delete.
// Extracted from platform.js (zero behavior change).
import { createHash } from 'node:crypto';
import { BASE, PLAN, accountFp } from './shared.js';
import { getAccessToken, refreshAccountSession } from './session.js';
import { ctlsFetch, applyFp, browserHeaders } from './ctls.js';
import {
  findNewPaidInvoice,
  hasConfirmedUnpaidReconciliation,
  isPaidInvoice,
  normalizePaymentPlan,
  planMatches,
} from './payment-state.js';
import { getOaiDeploy } from './x-vendor-deploy.js';

// client-version / build-number 从 platform.example.com HTML 的 <html data-build/data-seq> 收割，见 x-vendor-deploy.js
// HAR 取消页为 en-US；取消路径单独默认 en-US（VENDOR_LANGUAGE 仍可覆盖）
const VENDOR_CANCEL_LANGUAGE = process.env.VENDOR_CANCEL_LANGUAGE
  || process.env.VENDOR_LANGUAGE
  || 'en-US';

function stableCancelOaiId(label, seed) {
  const buf = createHash('sha1').update(String(label || '') + String(seed || 'default')).digest();
  buf[6] = (buf[6] & 0x0f) | 0x50;
  buf[8] = (buf[8] & 0x3f) | 0x80;
  const h = buf.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20, 32)}`;
}

/**
 * 取消自动续费 / 读订阅 用 platform.example.com backend-api 头（对齐 gpt8.1 HAR）。
 * 不发 x-x-vendor-is-pending-updates 加密 blob（浏览器专有，服务端不可还原）。
 */
export function cancelRenewalHeaders({
  accessToken,
  accountId = null,
  deviceId,
  sessionId,
  targetPath,
  fp = null,
  mutation = false,
} = {}) {
  const lang = VENDOR_CANCEL_LANGUAGE;
  const acceptLang = String(lang).startsWith('zh')
    ? 'zh-CN,zh;q=0.9,en;q=0.8'
    : 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7';
  const deploy = getOaiDeploy();
  const base = browserHeaders({
    Authorization: `Bearer ${accessToken}`,
    Accept: '*/*',
    'Accept-Language': acceptLang,
    'Cache-Control': 'no-cache',
    Pragma: 'no-cache',
    Priority: 'u=1, i',
    Origin: BASE,
    Referer: `${BASE}/`,
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'x-vendor-client-version': deploy.clientVersion,
    'x-vendor-client-build-number': deploy.buildNumber,
    'x-vendor-device-id': deviceId,
    'x-vendor-session-id': sessionId,
    'x-vendor-language': lang,
    'x-vendor-target-path': targetPath,
    'x-vendor-target-route': targetPath,
    ...(mutation ? { 'Content-Type': 'application/json' } : {}),
    // 参考项目 CancelStep 必带 platform-account-id；VENDOR_CANCEL_ACCOUNT_HEADER=0 可关
    ...(accountId && process.env.VENDOR_CANCEL_ACCOUNT_HEADER !== '0'
      ? { 'platform-account-id': accountId }
      : {}),
  });
  return applyFp(base, fp);
}

/** 对齐 Java OrderProcessingService.renewalCancellationDelayMinutes */
export function renewalCancellationDelayMinutes(attempt) {
  const n = Math.max(1, Number(attempt) || 1);
  if (n <= 1) return 2;
  if (n === 2) return 5;
  if (n === 3) return 10;
  if (n === 4) return 20;
  return 30;
}

/** 对齐 Java isCancellationCredentialFailure：401/403/session 失效不再补偿重试 */
export function isCancellationCredentialFailure(message, status = 0) {
  const code = Number(status) || 0;
  if (code === 401 || code === 403) return true;
  if (!message) return false;
  const n = String(message).toLowerCase();
  return n.includes('http 401')
    || n.includes('http 403')
    || n.includes('status 401')
    || n.includes('status 403')
    || n.includes('access_token_expired')
    || n.includes('token_expired')
    || n.includes('cancel_credential_dead')
    || n.includes('session 已过期')
    || n.includes('session token')
    || n.includes('unauthorized')
    || n.includes('forbidden')
    || n.includes('鉴权失败')
    || n.includes('查询账户失败: 401')
    || n.includes('查询账户失败: 403')
    || n.includes('取消续费失败: 401')
    || n.includes('取消续费失败: 403');
}

export function normalizePlan(p) {
  return normalizePaymentPlan(p) || 'free';
}

function nestedSubscriptionValue(root, keys) {
  if (!root || typeof root !== 'object') return null;
  for (const key of keys) {
    const direct = root[key];
    if (direct !== undefined && direct !== null && direct !== '' && typeof direct !== 'object') return direct;
    if (direct && typeof direct === 'object') {
      const found = nestedSubscriptionValue(direct, keys);
      if (found !== null) return found;
    }
  }
  for (const value of Object.values(root)) {
    if (value && typeof value === 'object') {
      const found = nestedSubscriptionValue(value, keys);
      if (found !== null) return found;
    }
  }
  return null;
}

/** 只读一层字段，避免 accounts/check 的 features 大树里误命中 plan_type 等。 */
function pickScalar(obj, keys = []) {
  if (!obj || typeof obj !== 'object') return null;
  for (const key of keys) {
    const direct = obj[key];
    if (direct === undefined || direct === null || direct === '') continue;
    if (typeof direct === 'object') continue;
    return direct;
  }
  return null;
}

function optionalBoolean(value) {
  if (typeof value === 'boolean') return value;
  if (value === 1 || String(value).toLowerCase() === 'true') return true;
  if (value === 0 || String(value).toLowerCase() === 'false') return false;
  return null;
}

function timestampMs(value) {
  if (typeof value === 'number' && Number.isFinite(value)) return value < 1e12 ? value * 1000 : value;
  if (typeof value === 'string' && /^\d+$/.test(value)) {
    const number = Number(value);
    return Number.isFinite(number) ? (number < 1e12 ? number * 1000 : number) : 0;
  }
  const parsed = Date.parse(value || '');
  return Number.isFinite(parsed) ? parsed : 0;
}

/**
 * 合并 GET /api/v1/subscriptions 与 accounts/check 片段。
 * 对齐 gpt8.1 HAR（2026-08-01「取消自动续费+查订阅类型」）:
 * - /subscriptions 有 plan_type/will_renew/active_until/cancellation_outcome/billing_*，
 *   **无** has_active_subscription
 * - check.entitlement 有 subscription_plan=basic_plan、has_active_subscription、expires_at/renews_at
 * - check.last_active_subscription 有 will_renew、cancellation_outcome、purchase_origin_platform
 * 取消续费后 plan 仍为 plus/pro 至 active_until，will_renew=false，cancellation_outcome=deactivate。
 */
export function subscriptionStateFromResponses(accountEntry = {}, subscription = {}, now = Date.now()) {
  const accountInfo = accountEntry?.account || {};
  const entitlement = accountEntry?.entitlement || {};
  const lastActive = accountEntry?.last_active_subscription || {};
  const sub = subscription && typeof subscription === 'object' ? subscription : {};

  // 优先读已知顶层字段；再兜底深搜（兼容未知包裹结构）
  const rawPlan = pickScalar(sub, ['plan_type', 'subscription_plan'])
    || pickScalar(accountInfo, ['plan_type'])
    || pickScalar(entitlement, ['subscription_plan', 'plan_type'])
    || nestedSubscriptionValue(sub, ['plan_type', 'subscription_plan'])
    || nestedSubscriptionValue(accountInfo, ['plan_type'])
    || nestedSubscriptionValue(entitlement, ['subscription_plan', 'plan_type'])
    || null;
  const normalizedPlan = normalizePlan(rawPlan) || null;
  const rawSubscriptionPlan = pickScalar(entitlement, ['subscription_plan'])
    || pickScalar(sub, ['subscription_plan'])
    || null;

  const willRenew = optionalBoolean(pickScalar(sub, ['will_renew']))
    ?? optionalBoolean(pickScalar(lastActive, ['will_renew']))
    ?? optionalBoolean(nestedSubscriptionValue(sub, ['will_renew']))
    ?? optionalBoolean(nestedSubscriptionValue(lastActive, ['will_renew']));

  // HAR: subscription.active_until 与 entitlement.expires_at 可能差几小时；优先 /subscriptions
  const activeUntil = pickScalar(sub, [
    'active_until', 'expires_at', 'current_period_end', 'renewal_date', 'cancels_at',
  ]) || pickScalar(entitlement, [
    'expires_at', 'active_until', 'current_period_end', 'renewal_date', 'cancels_at', 'renews_at',
  ]) || pickScalar(lastActive, [
    'active_until', 'expires_at', 'current_period_end', 'renewal_date', 'cancels_at',
  ]) || nestedSubscriptionValue(sub, [
    'active_until', 'expires_at', 'current_period_end', 'renewal_date', 'cancels_at',
  ]) || nestedSubscriptionValue(entitlement, [
    'expires_at', 'active_until', 'current_period_end', 'renewal_date', 'cancels_at', 'renews_at',
  ]) || null;

  const renewsAt = pickScalar(entitlement, ['renews_at'])
    || pickScalar(sub, ['renews_at', 'renewal_date'])
    || null;
  const activeStart = pickScalar(sub, ['active_start', 'current_period_start']) || null;
  const cancellationOutcome = pickScalar(sub, ['cancellation_outcome'])
    || pickScalar(lastActive, ['cancellation_outcome'])
    || null;
  const billingPeriod = pickScalar(sub, ['billing_period'])
    || pickScalar(entitlement, ['billing_period'])
    || null;
  const billingCurrency = pickScalar(sub, ['billing_currency'])
    || pickScalar(entitlement, ['billing_currency'])
    || null;
  const purchaseOrigin = pickScalar(lastActive, ['purchase_origin_platform', 'origin_platform'])
    || pickScalar(sub, ['purchase_origin_platform', 'origin_platform'])
    || null;
  const isDelinquent = optionalBoolean(pickScalar(sub, ['is_delinquent']))
    ?? optionalBoolean(pickScalar(entitlement, ['is_delinquent']));
  const isProcessorStripe = optionalBoolean(pickScalar(sub, ['is_processor_stripe']));
  const subscriptionId = pickScalar(sub, ['id', 'subscription_id'])
    || pickScalar(entitlement, ['subscription_id'])
    || pickScalar(lastActive, ['subscription_id'])
    || null;
  const seatsInUse = pickScalar(sub, ['seats_in_use']);
  const seatsEntitled = pickScalar(sub, ['seats_entitled']);

  const status = String(
    pickScalar(sub, ['status', 'subscription_status'])
    || nestedSubscriptionValue(sub, ['status', 'subscription_status'])
    || '',
  ).toLowerCase();

  // /subscriptions 通常不带 has_active_subscription；check.entitlement 带
  let hasActiveSubscription = optionalBoolean(pickScalar(sub, ['has_active_subscription', 'is_active']))
    ?? optionalBoolean(pickScalar(entitlement, ['has_active_subscription', 'is_active']));
  if (hasActiveSubscription === null && ['active', 'trialing'].includes(status)) hasActiveSubscription = true;
  if (hasActiveSubscription === null && ['inactive', 'expired', 'canceled', 'cancelled', 'ended'].includes(status)) {
    hasActiveSubscription = false;
  }
  // 付费 plan + 未到期 → 仍有效（含已关续费：will_renew=false 且 cancellation_outcome=deactivate）
  if (hasActiveSubscription === null && normalizedPlan && normalizedPlan !== 'free') {
    if (activeUntil) {
      hasActiveSubscription = timestampMs(activeUntil) > now;
    } else if (willRenew === true || cancellationOutcome) {
      hasActiveSubscription = true;
    } else {
      hasActiveSubscription = true;
    }
  }
  if (hasActiveSubscription === null && (normalizedPlan === 'free' || rawPlan === 'free')) {
    hasActiveSubscription = false;
  }
  if (hasActiveSubscription === null && activeUntil && willRenew === false && timestampMs(activeUntil) <= now) {
    hasActiveSubscription = false;
  }

  const effectivePlan = hasActiveSubscription === false
    ? 'free'
    : (normalizedPlan || rawPlan || null);

  return {
    accountId: accountInfo.account_id || accountInfo.id || null,
    plan_type: effectivePlan,
    subscription_plan: rawSubscriptionPlan || rawPlan || null,
    has_active_subscription: hasActiveSubscription,
    will_renew: willRenew,
    active_until: activeUntil,
    active_start: activeStart,
    renews_at: renewsAt,
    cancellation_outcome: cancellationOutcome,
    billing_period: billingPeriod,
    billing_currency: billingCurrency,
    purchase_origin_platform: purchaseOrigin,
    is_delinquent: isDelinquent,
    is_processor_stripe: isProcessorStripe,
    subscription_id: subscriptionId,
    seats_in_use: seatsInUse == null ? null : Number(seatsInUse) || seatsInUse,
    seats_entitled: seatsEntitled == null ? null : Number(seatsEntitled) || seatsEntitled,
  };
}

/**
 * backend-api 查询头。
 *
 * Origin 与 Referer 都不可省：声明 sec-fetch-site=same-origin 却不带来源，
 * Vendor 边缘会在鉴权之前直接回 403 HTML 挑战页，表现为「查询账户失败: 403」，
 * 与 token 是否有效、走哪条出口都无关（2026-08-09 实测三条网络路径一致）。
 *
 * 注意别按「浏览器同源 GET 不发 Origin」去省：reference-impl 每个请求都发
 * Origin，只发 Referer 会被挡。以对方线上实际行为为准。
 */
export function backendApiHeaders(accessToken, fp, extra = {}) {
  return applyFp(browserHeaders({
    Authorization: `Bearer ${accessToken}`,
    Origin: BASE,
    Referer: `${BASE}/`,
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    ...extra,
  }), fp);
}

/** GET /api/v1/subscriptions 请求头：对齐 gpt8.1 HAR（x-vendor-device/session/language/client-version/build） */
export function subscriptionQueryHeaders(account, ctx = {}) {
  const seed = account?.email || ctx.accountId || ctx.accessToken || 'sub';
  return cancelRenewalHeaders({
    accessToken: ctx.accessToken,
    accountId: ctx.accountId || null,
    deviceId: stableCancelOaiId('sub-device', seed),
    sessionId: stableCancelOaiId('sub-session', seed),
    targetPath: '/api/v1/subscriptions',
    fp: ctx.fp || accountFp(account),
    mutation: false,
  });
}

export function subscriptionPeriodEndFromInvoices(invoices = [], now = Date.now()) {
  const candidates = [];
  for (const invoice of invoices) {
    if (!isPaidInvoice(invoice)) continue;
    const periods = (invoice?.lines?.data || []).map((line) => line?.period?.end);
    periods.push(invoice?.period_end);
    for (const value of periods) {
      const parsed = timestampMs(value);
      if (Number.isFinite(parsed) && parsed > now) candidates.push(parsed);
    }
  }
  if (!candidates.length) return null;
  return new Date(Math.min(...candidates)).toISOString();
}

export function latestSubscriptionPeriodEndFromInvoices(invoices = []) {
  const candidates = [];
  for (const invoice of invoices) {
    if (!isPaidInvoice(invoice)) continue;
    const periods = (invoice?.lines?.data || []).map((line) => line?.period?.end);
    periods.push(invoice?.period_end);
    for (const value of periods) {
      const parsed = timestampMs(value);
      if (parsed > 0) candidates.push(parsed);
    }
  }
  if (!candidates.length) return null;
  return new Date(Math.max(...candidates)).toISOString();
}

export function invoicesFromResponse(inv = {}) {
  return (inv.invoices || inv.data || []).map((i) => ({
    id: i.id,
    number: i.number || null,
    amount: i.amount ?? i.total ?? i.amount_due ?? null,
    amount_paid: i.amount_paid ?? i.paid_amount ?? null,
    currency: i.currency || null,
    status: i.status || null,
    payment_status: i.payment_status || null,
    paid: i.paid === true,
    payment_intent: i.payment_intent || null,
    created: i.created ?? null,
    period_end: i.period_end ?? i.current_period_end ?? null,
    lines: {
      data: (i?.lines?.data || []).map((line) => ({
        description: line?.description || null,
        period: line?.period ? { start: line.period.start ?? null, end: line.period.end ?? null } : null,
      })),
    },
    hosted_invoice_url: i.hosted_invoice_url || null,
    invoice_pdf: i.invoice_pdf || null,
    // 升级补差价账单扫描（portal FetchInvoicesStep）需要 remaining 判断可付
    amount_remaining: i.amount_remaining ?? i.amountRemaining ?? null,
  }));
}

export function latestPaidInvoiceSummary(invoices = []) {
  const invoice = [...invoices].filter(isPaidInvoice).sort((a, b) => timestampMs(b?.created) - timestampMs(a?.created))[0];
  if (!invoice) return null;
  const paidAt = timestampMs(invoice.created);
  const amount = invoice.amount_paid ?? invoice.amount ?? null;
  return {
    paidAt: paidAt > 0 ? new Date(paidAt).toISOString() : null,
    amountMinor: amount !== null && amount !== '' && Number.isFinite(Number(amount)) ? Number(amount) : null,
    currency: invoice.currency || null,
    status: invoice.payment_status || invoice.status || (invoice.paid ? 'paid' : null),
  };
}

export function paymentMethodsFromResponse(data = {}) {
  return (data.data || data.payment_methods || []).map((m) => ({
    id: m.id || null,
    type: m.type || null,
    brand: m.card?.brand || m.brand || null,
    last4: m.card?.last4 || m.last4 || null,
    exp_month: m.card?.exp_month ?? m.exp_month ?? null,
    exp_year: m.card?.exp_year ?? m.exp_year ?? null,
    is_default: m.is_default ?? m.default ?? false,
  }));
}

export function preferredPaymentMethodSummary(methods = []) {
  const method = methods.find((item) => item.is_default) || methods[0];
  if (!method) return null;
  return {
    type: method.type || null,
    brand: method.brand || null,
    last4: method.last4 || null,
    expMonth: method.exp_month ?? null,
    expYear: method.exp_year ?? null,
    isDefault: method.is_default === true,
  };
}

/** 从 JWT AT 解 email（不验签，仅用于展示/指纹；失败返回空） */
export function emailFromAccessToken(accessToken) {
  try {
    const parts = String(accessToken || '').split('.');
    if (parts.length < 2) return '';
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = Buffer.from(b64, 'base64').toString('utf8');
    const payload = JSON.parse(json);
    const profile = payload?.['https://api.vendor.com/profile'];
    return String(
      payload?.email
      || profile?.email
      || payload?.preferred_username
      || payload?.['https://api.vendor.com/auth']?.user_id
      || '',
    ).trim();
  } catch {
    return '';
  }
}

/**
 * 从 Vendor AT JWT 抠 platform_account_id。
 * 对账 accounts/check 可能 403，但 JWT 里仍有 id，可直接 POST cancel（参考项目不依赖 check）。
 */
export function platformAccountIdFromAccessToken(accessToken) {
  try {
    const parts = String(accessToken || '').split('.');
    if (parts.length < 2) return '';
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const json = Buffer.from(b64, 'base64').toString('utf8');
    const payload = JSON.parse(json);
    const auth = payload?.['https://api.vendor.com/auth'] || payload?.auth || {};
    return String(auth.platform_account_id || auth.account_id || payload?.platform_account_id || '').trim();
  } catch {
    return '';
  }
}

// 一次取 accessToken + /accounts/check（accountId 稳定、accessToken 可复用数分钟），
// 把结果穿给 querySubscription/queryInvoices/reconcile 复用，避免每个查询各自重打一遍 token+check。
// 有 account.accessToken 时跳过 /api/auth/session 换票（直充 AT 模式）。
//
// 重要：NextAuth `/api/auth/session` 常返回仍带 JWT exp 的「缓存 AT」，但 backend-api 会以
// token_expired 拒掉。浏览器整页登录会走 refresh；协议路径必须在 401 时 forceRefresh 一次。
export async function resolveAccountContext(account, proxy = null, fp = accountFp(account)) {
  let accessToken = String(account?.accessToken || '').trim();
  let user = null;
  let sessionToken = String(account?.sessionToken || '').trim();

  async function loadAccessToken({ forceRefresh = false } = {}) {
    if (!sessionToken) {
      const err = new Error('invalid_access_token');
      err.code = 'invalid_access_token';
      throw err;
    }
    const got = await getAccessToken(sessionToken, proxy, fp, forceRefresh
      ? { forceRefresh: true, refreshReason: 'token_expired' }
      : {});
    accessToken = String(got.accessToken || '').trim();
    if (got.user) user = got.user;
    if (got.sessionToken && got.sessionToken !== sessionToken) {
      sessionToken = got.sessionToken;
      if (account && typeof account === 'object') account.sessionToken = sessionToken;
    }
    if (account && typeof account === 'object' && accessToken) account.accessToken = accessToken;
    return got;
  }

  if (!accessToken) {
    await loadAccessToken({ forceRefresh: false });
  } else if (!user) {
    const jwtEmail = emailFromAccessToken(accessToken);
    if (jwtEmail && jwtEmail.includes('@')) user = { email: jwtEmail };
  }

  const buildHeaders = () => backendApiHeaders(accessToken, fp);

  let requestHeaders = buildHeaders();
  let resp = await ctlsFetch(
    `${BASE}/api/v1/accounts/check/v4-2023-04-27`,
    { headers: requestHeaders, ja3: fp.ja3 },
    proxy,
  );

  // session 仍活但 AT 服务端已废：强制 /api/auth/session?refresh=true 后重试一次
  // 对齐 Java：带鉴权的 accounts/check 401/403 先刷票，再判凭证失效（不换付款 IP）
  if (!resp.ok && (Number(resp.status) === 401 || Number(resp.status) === 403) && sessionToken) {
    const firstStatus = Number(resp.status) || 401;
    const bodyText = await resp.text().catch(() => '');
    const looksExpired = firstStatus === 403
      || /token_expired|authentication token is expired|jwt expired|invalid_token|token.?invalid|unauthorized|forbidden/i.test(bodyText)
      || !bodyText;
    if (looksExpired) {
      try {
        await loadAccessToken({ forceRefresh: true });
        requestHeaders = buildHeaders();
        resp = await ctlsFetch(
          `${BASE}/api/v1/accounts/check/v4-2023-04-27`,
          { headers: requestHeaders, ja3: fp.ja3 },
          proxy,
        );
      } catch {
        // 保留下方统一错误分类（用第一次状态）
        resp = { ok: false, status: firstStatus, text: async () => bodyText, json: async () => ({}) };
      }
    } else {
      // 已消费 body，后续分支用合成 resp
      resp = { ok: false, status: firstStatus, text: async () => bodyText, json: async () => ({}) };
    }
  }

  if (!resp.ok) {
    const status = Number(resp.status) || 0;
    // 对齐 Java detectCurrentPlanOnce：带 Bearer 的 accounts/check 401/403 → token expired/forbidden，
    // 记凭证失败、禁止换付款出口；495/0/5xx 才按出口问题换线。
    if (status === 401 || status === 403) {
      const onlyAt = Boolean(accessToken && !sessionToken);
      const err = new Error(onlyAt && status === 401
        ? 'access_token_expired'
        : `查询账户失败: ${status}`);
      err.code = status === 401
        ? (onlyAt ? 'access_token_expired' : 'account_check_unauthorized')
        : 'account_check_forbidden';
      err.status = status;
      err.noProxyRetry = true;
      err.cfBlocked = false;
      throw err;
    }
    // 495：Vendor/边缘偶发拒绝（类似 CF），按可换 IP 处理
    if (status === 495) {
      const err = new Error(`查询账户失败: ${status}`);
      err.code = 'account_check_failed';
      err.status = status;
      err.cfBlocked = true;
      throw err;
    }
    throw Object.assign(new Error(`查询账户失败: ${status}`), { status, cfBlocked: status === 495 });
  }
  const chk = await resp.json().catch(() => ({}));
  const accounts = chk?.accounts || {};
  // 对齐 Java PollStep：优先本单 accountId，避免多账号 token 命中别的号
  const preferredId = account?.accountId || account?.platformAccountId || null;
  const accountEntry = pickAccountsCheckEntry(accounts, preferredId);
  const accountId = accountEntry?.account?.account_id
    || accountEntry?.account?.id
    || preferredId
    || null;
  return { accessToken, user, fp, requestHeaders, accountEntry, accountId, accountsCheck: chk };
}

/**
 * 从 accounts/check.accounts 取账号节点（Java：优先 ctx.accountId，再 default，再第一个）。
 */
export function pickAccountsCheckEntry(accounts, preferredAccountId = null) {
  const map = accounts && typeof accounts === 'object' ? accounts : {};
  const pref = String(preferredAccountId || '').trim();
  if (pref) {
    if (map[pref] && typeof map[pref] === 'object') return map[pref];
    for (const v of Object.values(map)) {
      if (!v || typeof v !== 'object') continue;
      const id = v?.account?.account_id || v?.account?.id;
      if (id && String(id) === pref) return v;
    }
  }
  if (map.default && typeof map.default === 'object') return map.default;
  for (const v of Object.values(map)) {
    if (v && typeof v === 'object') return v;
  }
  return {};
}

/** Java PollStep.retryWaitMillis */
export function pollRetryWaitMs(attempt, initialWaitMs, incrementMs, maxWaitMs) {
  const a = Math.max(1, Number(attempt) || 1);
  return Math.min(
    Number(initialWaitMs) + Math.max(0, a - 1) * Number(incrementMs),
    Number(maxWaitMs),
  );
}

/**
 * 支付后等订阅激活（对齐 Java PollStep + pollWithRecovery）。
 * - 主路径 accounts/check（按 accountId 取 plan），不每轮 forceRefresh
 * - full: 最多 10 轮，3s 起退避封顶 6s（~半分钟+）
 * - fast: 最多 6 轮，1s 起（延迟复核）
 * - 仅 401/403 时 forceRefresh 一次再继续
 */
export async function pollSubscriptionActivation(account, expectedPlan, {
  mode = 'full',
  proxy = null,
  log = () => {},
  allowAuthRefresh = true,
} = {}) {
  const target = normalizePaymentPlan(expectedPlan) || normalizePlan(expectedPlan) || 'plus';
  // cs_live：Stripe 已 paid、钱已扣，等 Vendor 挂订阅可以更宽松（对齐 Java PollStep.executeCsLive）
  const csLive = mode === 'cs_live';
  const full = mode !== 'fast';
  const maxAttempts = csLive ? 28 : (full ? 10 : 6);
  const initialWaitMs = csLive ? 5000 : (full ? 3000 : 1000);
  const incrementMs = csLive ? 500 : (full ? 700 : 400);
  const maxWaitMs = csLive ? 8000 : (full ? 6000 : 2500);

  let finalPlan = normalizePlan(account?.plan) || 'free';
  let lastError = null;
  let subscriptionChecked = false;
  // 扣款成功后 Vendor 常轮换凭证，旧 Bearer 会 401（Java PollStep 每轮重读 token）。
  // 只允许刷一次会让后续轮次全部 401 空转，放开到 3 次。
  let authRefreshCount = 0;
  const maxAuthRefresh = csLive ? 3 : 1;
  const preferredId = account?.accountId || account?.platformAccountId || null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      // resolveAccountContext：有 AT 时不 force 刷；仅 check 401 时内部 force 一次
      const ctx = await resolveAccountContext(account, proxy);
      subscriptionChecked = true;
      if (ctx.accountId && account && typeof account === 'object') {
        account.accountId = account.accountId || ctx.accountId;
        account.platformAccountId = account.platformAccountId || ctx.accountId;
      }
      // 再按 preferred 精修 entry（ctx 已带 preferred，双保险）
      const entry = preferredId
        ? pickAccountsCheckEntry(ctx.accountsCheck?.accounts || {}, preferredId)
        : ctx.accountEntry;
      const fromCheck = subscriptionStateFromResponses(
        entry && Object.keys(entry).length ? entry : ctx.accountEntry,
        {},
      );
      let plan = normalizePlan(fromCheck.plan_type) || 'free';

      // 可选补 /subscriptions（404 不致命）；失败仅记录
      try {
        const sub = await querySubscription(account, () => {}, proxy, ctx);
        const subPlan = normalizePlan(sub?.plan_type);
        if (subPlan && subPlan !== 'free') plan = subPlan;
        else if (subPlan) plan = subPlan;
      } catch (subErr) {
        const msg = String(subErr?.message || subErr || '');
        if (allowAuthRefresh && authRefreshCount < maxAuthRefresh && account?.sessionToken
          && /401|403|token|unauthorized|鉴权|access_token/i.test(msg)) {
          authRefreshCount += 1;
          log(`[poll] 订阅接口鉴权失败，forceRefresh ${authRefreshCount}/${maxAuthRefresh} 后继续: ${msg.slice(0, 120)}`);
          await refreshAccountSession(account, {
            proxy, log, reason: 'poll_401', attempts: 1,
          });
          await new Promise((r) => setTimeout(r, 400));
          attempt -= 1; // 本轮不计入等待配额
          continue;
        }
        lastError = msg;
      }

      finalPlan = plan;
      if (planMatches(plan, target)) {
        log(`[poll] 订阅已激活 attempt=${attempt}/${maxAttempts} plan=${plan} target=${target}`);
        return {
          activated: true,
          finalPlan: plan,
          subscriptionChecked: true,
          lastError: null,
          attempts: attempt,
        };
      }
      log(`[poll] attempt ${attempt}/${maxAttempts} plan=${plan} target=${target}`);
    } catch (e) {
      const msg = String(e?.message || e || '');
      lastError = msg;
      log(`[poll] attempt ${attempt}/${maxAttempts} 失败: ${msg.slice(0, 160)}`);
      if (allowAuthRefresh && authRefreshCount < maxAuthRefresh && account?.sessionToken
        && /401|403|token|unauthorized|鉴权|access_token|查询账户失败:\s*401/i.test(msg)) {
        authRefreshCount += 1;
        log(`[poll] accounts/check 鉴权失败，forceRefresh ${authRefreshCount}/${maxAuthRefresh} 后继续`);
        await refreshAccountSession(account, {
          proxy, log, reason: 'poll_401', attempts: 1,
        });
        await new Promise((r) => setTimeout(r, 400));
        attempt -= 1;
        continue;
      }
    }

    if (attempt < maxAttempts) {
      const wait = pollRetryWaitMs(attempt, initialWaitMs, incrementMs, maxWaitMs);
      await new Promise((r) => setTimeout(r, wait));
    }
  }

  return {
    activated: false,
    finalPlan: finalPlan || 'free',
    subscriptionChecked,
    lastError,
    attempts: maxAttempts,
  };
}

export async function querySubscription(account, log = () => {}, proxy = null, ctx = null) {
  // proxy：直充/支付路径应传入「付款代理」；与 accounts/check 同一出口，避免半直连半代理。
  const c = ctx || await resolveAccountContext(account, proxy);
  if (!c.accountId) throw new Error('无法获取 account_id');
  // gpt8.1 HAR：GET /subscriptions 带 x-vendor-device/session/language/client-version/build（非裸 Bearer）
  const headers = subscriptionQueryHeaders(account, c);
  const subResp = await ctlsFetch(
    `${BASE}/api/v1/subscriptions?account_id=${encodeURIComponent(c.accountId)}`,
    { headers, ja3: c.fp?.ja3 },
    proxy,
  );
  // 404/空：常见于从未订过或账号结构特殊；与 preflight(queryBillingProfile) 对齐：
  // 容忍后用 /accounts/check 拼套餐，通常判 free，禁止因 404 直接 failed_precharge。
  if (!subResp.ok) {
    const status = Number(subResp.status) || 0;
    if (status === 404 || status === 204 || status === 405) {
      log(`[subscription] /subscriptions HTTP ${status}（proxy=${proxy ? 'yes' : 'direct'}），回退 accounts/check 判套餐`);
      const state = subscriptionStateFromResponses(c.accountEntry || {}, {});
      return {
        ...state,
        plan_type: normalizePlan(state.plan_type) || 'free',
        accountId: c.accountId || state.accountId || null,
        subscriptionQueryStatus: status,
        subscriptionQuerySoft: true,
      };
    }
    // 对齐 Java：鉴权后的 401/403 → 凭证问题，不换 IP；495 仍按脏出口换线
    if (status === 401 || status === 403) {
      const err = new Error(`查询订阅失败: ${status}`);
      err.status = status;
      err.cfBlocked = false;
      err.noProxyRetry = true;
      err.code = status === 401 ? 'subscription_unauthorized' : 'subscription_forbidden';
      throw err;
    }
    if (status === 495) {
      const err = new Error(`查询订阅失败: ${status}`);
      err.status = status;
      err.cfBlocked = true;
      err.code = 'subscription_query_failed';
      throw err;
    }
    throw Object.assign(new Error(`查询订阅失败: ${status}`), { status, code: 'subscription_query_failed' });
  }
  const sub = await subResp.json().catch(() => ({}));
  const state = subscriptionStateFromResponses(c.accountEntry, sub);
  log(`[subscription] plan=${normalizePlan(state.plan_type)} active=${String(state.has_active_subscription)}`
    + ` renew=${String(state.will_renew)} outcome=${state.cancellation_outcome || '-'}`
    + ` period=${state.billing_period || '-'} origin=${state.purchase_origin_platform || '-'}`
    + ` proxy=${proxy ? 'yes' : 'direct'}`);
  return { ...state, accountId: c.accountId || state.accountId || null };
}

// ───── 商店订阅探测（对齐 reference-impl probeStoreSubscriptionBlock）─────
// 仅拦截 iOS/Google 等应用商店 processor；网页 Stripe 开通的 Plus 允许升级 Pro。

const STORE_SUB_BLOCK_MSG =
  '不支持网页升级（应用商店/iOS/谷歌订阅），请使用网页开通的账号；或换未开通会员的全新账号。';

/**
 * 在 API JSON 树中找商店计费信号（字段名/取值不固定）。
 * @returns {string|null} 命中说明
 */
export function findStoreProcessorSignal(node, depth = 0) {
  if (node == null || depth > 8) return null;
  if (Array.isArray(node)) {
    for (const item of node) {
      const hit = findStoreProcessorSignal(item, depth + 1);
      if (hit) return hit;
    }
    return null;
  }
  if (typeof node !== 'object') return null;
  for (const [key, val] of Object.entries(node)) {
    const keyL = String(key || '').toLowerCase();
    if ((keyL.includes('app_store') || keyL.includes('play_store') || keyL.includes('google_play')
      || keyL.includes('managed_by_app') || keyL.includes('is_apple') || keyL.includes('is_google'))
      && (val === true || String(val).toLowerCase() === 'true')) {
      return `${key}=${val}`;
    }
    if (typeof val === 'string' && val.trim()) {
      const sl = val.toLowerCase();
      const keyHint = keyL.includes('processor') || keyL.includes('billing_platform')
        || keyL.includes('purchase_origin') || keyL.includes('payment_provider')
        || keyL.includes('billing_source') || keyL.includes('store');
      const valHint = sl.includes('google') || sl.includes('play') || sl.includes('apple')
        || sl.includes('app_store') || sl.includes('appstore') || sl.includes('itunes')
        || sl.includes('iap') || sl === 'android' || sl === 'ios';
      const webOk = sl.includes('stripe') || sl.includes('vendor') || sl === 'web'
        || sl.includes('platform');
      if (keyHint && valHint && !webOk) return `${key}=${val}`;
      if ((keyL === 'processor' || keyL === 'subscription_processor' || keyL === 'billing_platform')
        && valHint && !webOk) {
        return `${key}=${val}`;
      }
    }
    const nested = findStoreProcessorSignal(val, depth + 1);
    if (nested) return nested;
  }
  return null;
}

export function isStoreProcessorErrorText(text) {
  if (!text) return false;
  const lower = String(text).toLowerCase();
  return lower.includes('unsupported subscription')
    || lower.includes('subscription processor')
    || String(text).includes('不支持网页升级')
    || String(text).includes('应用商店订阅');
}

/**
 * 开卡/升级前探测：是否应用商店订阅（无法网页升级）。
 * 探测失败不拦截（避免误杀）。返回错误文案或 null。
 * @param {{ trySubUpdate?: boolean, targetPlanName?: string }} [opts]
 */
export async function probeStoreSubscriptionBlock(account, proxy = null, log = () => {}, opts = {}) {
  const trySubUpdate = opts.trySubUpdate !== false;
  const targetPlanName = String(opts.targetPlanName || 'premium_planplan');
  let ctx;
  try {
    ctx = await resolveAccountContext(account, proxy);
  } catch (e) {
    log(`[store-probe] resolve context skip: ${e?.message || e}`);
    return null;
  }

  // 1) GET subscriptions
  try {
    if (ctx.accountId) {
      const subUrl = `${BASE}/api/v1/subscriptions?account_id=${ctx.accountId}`;
      const subResp = await ctlsFetch(subUrl, { headers: ctx.requestHeaders, ja3: ctx.fp.ja3 }, proxy);
      if (subResp.ok) {
        const body = await subResp.json().catch(() => ({}));
        const hit = findStoreProcessorSignal(body);
        if (hit) {
          log(`[store-probe] subscriptions 命中商店渠道: ${hit}`);
          return STORE_SUB_BLOCK_MSG;
        }
      }
    }
  } catch (e) {
    log(`[store-probe] subscriptions skip: ${e?.message || e}`);
  }

  // 2) accounts/check entitlement
  try {
    const hit = findStoreProcessorSignal(ctx.accountEntry);
    if (hit) {
      log(`[store-probe] accounts/check 命中商店渠道: ${hit}`);
      return STORE_SUB_BLOCK_MSG;
    }
  } catch {
    /* ignore */
  }

  // 3) 试 sub_update（商店号常回 Unsupported subscription processor）
  if (!trySubUpdate || !ctx.accountId) return null;
  try {
    const body = { updated_plan: targetPlanName, account_id: ctx.accountId };
    const upd = await ctlsFetch(`${BASE}/api/v1/subscriptions/update`, {
      method: 'POST',
      headers: {
        ...ctx.requestHeaders,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
      ja3: ctx.fp.ja3,
    }, proxy);
    const status = Number(upd.status) || 0;
    const text = await upd.text().catch(() => '');
    let detail = text;
    try {
      const j = JSON.parse(text);
      detail = [j.detail, j.message, j.status, j.error].filter(Boolean).join(' ');
    } catch {
      /* raw */
    }
    log(`[store-probe] sub_update 探测 HTTP ${status} detail=${String(detail).slice(0, 160)}`);
    if (status >= 400 && isStoreProcessorErrorText(detail)) {
      return STORE_SUB_BLOCK_MSG;
    }
  } catch (e) {
    log(`[store-probe] sub_update skip: ${e?.message || e}`);
  }
  return null;
}

// ───── 查询账单 ─────

export async function queryInvoices(account, log = () => {}, proxy = null, ctx = null) {
  const c = ctx || await resolveAccountContext(account, proxy);
  if (!c.accountId) throw new Error('无法获取 account_id');
  const invResp = await ctlsFetch(`${BASE}/api/v1/invoices?limit=10&account_id=${c.accountId}`, {
    headers: c.requestHeaders, ja3: c.fp.ja3,
  }, proxy);
  if (!invResp.ok) throw new Error(`查询账单失败: ${invResp.status}`);
  const inv = await invResp.json().catch(() => ({}));
  return {
    accountId: c.accountId,
    invoices: invoicesFromResponse(inv),
  };
}

export async function reconcilePaymentOutcome(account, expectedPlan, {
  knownInvoiceIds = [], submittedAt = 0, attempts = 1, delayMs = 0,
} = {}, log = () => {}, proxy = null) {
  let finalPlan = null;
  let paidInvoice = null;
  let lastError = null;
  let subscriptionChecked = false;
  let invoicesChecked = false;
  const rounds = Math.max(1, Number(attempts) || 1);

  for (let attempt = 1; attempt <= rounds; attempt++) {
    // 每轮取一次新鲜上下文(accessToken + /accounts/check),再并行查 /subscriptions 与 /invoices;
    // 相比原来「串行各自重取 token+check」,一轮从 6 个代理往返降到 ~2 个,且数据仍是本轮最新。
    const ctx = await resolveAccountContext(account, proxy).catch((e) => { lastError = e; return null; });
    const [subRes, invRes] = await Promise.allSettled([
      querySubscription(account, () => {}, proxy, ctx),
      queryInvoices(account, () => {}, proxy, ctx),
    ]);
    if (subRes.status === 'fulfilled') {
      subscriptionChecked = true;
      finalPlan = normalizePlan(subRes.value.plan_type);
      if (planMatches(finalPlan, expectedPlan)) {
        log(`[payment] 对账完成: 套餐已同步为 ${finalPlan}`);
        return {
          activated: true, finalPlan, paidInvoice, subscription: subRes.value,
          subscriptionChecked, invoicesChecked,
        };
      }
    } else {
      lastError = subRes.reason;
      log(`[payment] 套餐对账失败(${attempt}/${rounds}): ${subRes.reason?.message}`);
    }
    if (invRes.status === 'fulfilled') {
      invoicesChecked = true;
      paidInvoice = findNewPaidInvoice(invRes.value.invoices, knownInvoiceIds, submittedAt);
      if (paidInvoice) {
        log(`[payment] 已发现新支付账单 ${paidInvoice.id || '(无ID)'},套餐 ${finalPlan || 'unknown'} 尚未同步`);
        return {
          activated: false, finalPlan, paidInvoice, invoices: invRes.value.invoices,
          subscriptionChecked, invoicesChecked,
        };
      }
    } else {
      lastError = lastError || invRes.reason;
      log(`[payment] 账单对账失败(${attempt}/${rounds}): ${invRes.reason?.message}`);
    }
    // 响应驱动的自适应退避：首轮很快复查（套餐常在数秒内同步），之后逐步拉长，封顶 delayMs。
    if (attempt < rounds && delayMs > 0) {
      await new Promise((resolve) => setTimeout(resolve, Math.min(delayMs, 700 * attempt)));
    }
  }
  return {
    activated: false, finalPlan, paidInvoice, lastError: lastError?.message || null,
    subscriptionChecked, invoicesChecked,
  };
}

export function proUpgradeReconcileDelays(upgradeAccepted) {
  return upgradeAccepted ? [10_000, 20_000, 30_000] : [10_000];
}

export async function reconcileAfterProUpgradeResponse(account, knownInvoiceIds, submittedAt, upgradeAccepted, opts, log, proxy) {
  const configured = Array.isArray(opts.upgradeReconcileDelaysMs)
    ? opts.upgradeReconcileDelaysMs : proUpgradeReconcileDelays(upgradeAccepted);
  let result = { activated: false, finalPlan: normalizePlan(account.plan) };
  for (const delayMs of configured) {
    const waitMs = Math.max(0, Number(delayMs) || 0);
    if (waitMs > 0) await new Promise((resolve) => setTimeout(resolve, waitMs));
    const current = await reconcilePaymentOutcome(account, PLAN.PRO, {
      knownInvoiceIds, submittedAt, attempts: 1,
    }, log, proxy);
    result = {
      ...current,
      paidInvoice: current.paidInvoice || result.paidInvoice || null,
    };
    if (result.activated) return result;
  }
  return result;
}

export async function reconcilePendingPayment(account, log = () => {}, proxy = null) {
  const expectedPlan = account.pendingPlan || account.lastPaymentPlan;
  if (!expectedPlan) return { ok: false, stage: 'no_pending_payment', message: '没有待对账付款' };
  // 对齐 Java pollWithRecovery：先用 accounts/check 长轮询等激活；
  // 入口不再 forceRefresh（避免狂刷 cookie）；仅 401/403 时在 poll 内刷一次。
  const knownInvoiceIds = (account.knownInvoiceIds || [account.lastInvoiceId, account.invoiceId])
    .filter(Boolean);
  const polled = await pollSubscriptionActivation(account, expectedPlan, {
    mode: 'full', proxy, log, allowAuthRefresh: true,
  });
  if (polled.activated) {
    return {
      ok: true,
      completed: true,
      stage: 'done',
      finalPlan: polled.finalPlan,
      retryPayment: false,
      // 写回可能已轮换的 session，供交付/后续 cancel
      sessionToken: account.sessionToken || undefined,
      accessToken: account.accessToken || undefined,
    };
  }
  // 套餐仍未到：查是否有新账单（付费证据），不 force 刷
  let result = await reconcilePaymentOutcome(account, expectedPlan, {
    knownInvoiceIds, attempts: 1, delayMs: 0,
    submittedAt: Number(account.lastPaymentSubmittedAt) || 0,
  }, log, proxy);
  if (!result.activated && account?.sessionToken) {
    const errText = String(result.lastError || polled.lastError || '');
    if (!result.subscriptionChecked || /401|403|token|unauthorized|鉴权/i.test(errText)) {
      await refreshAccountSession(account, { proxy, log, reason: 'reconcile_retry', attempts: 1 });
      await new Promise((r) => setTimeout(r, 400));
      const polled2 = await pollSubscriptionActivation(account, expectedPlan, {
        mode: 'fast', proxy, log, allowAuthRefresh: false,
      });
      if (polled2.activated) {
        return {
          ok: true, completed: true, stage: 'done', finalPlan: polled2.finalPlan, retryPayment: false,
          sessionToken: account.sessionToken || undefined,
          accessToken: account.accessToken || undefined,
        };
      }
      result = await reconcilePaymentOutcome(account, expectedPlan, {
        knownInvoiceIds, attempts: 1, delayMs: 0,
        submittedAt: Number(account.lastPaymentSubmittedAt) || 0,
      }, log, proxy);
    }
  }
  if (result.activated) {
    return {
      ok: true, completed: true, stage: 'done', finalPlan: result.finalPlan, retryPayment: false,
      sessionToken: account.sessionToken || undefined,
      accessToken: account.accessToken || undefined,
    };
  }
  // 长 poll 结果写入 finalPlan（仍可能 free）
  if (!result.finalPlan || result.finalPlan === 'free') {
    result = { ...result, finalPlan: polled.finalPlan || result.finalPlan };
  }
  const confirmedUnpaid = hasConfirmedUnpaidReconciliation(result);
  const storedPaymentConfirmed = Boolean(account.lastPaymentConfirmedAt)
    && planMatches(account.lastPaymentPlan, expectedPlan);
  const paidLike = storedPaymentConfirmed
    || Boolean(account.lastPaymentIntent)
    || /paid_pending|settled/i.test(String(account.paymentState || ''));
  const errText = String(result.lastError || '');
  const credDead = isCancellationCredentialFailure(errText)
    || (!result.subscriptionChecked && /401|403|token|expired|鉴权/i.test(errText));
  // 已扣款 + Session/AT 失效：参考项目停止死磕对账；收口完成并提示手机关续费
  if (paidLike && credDead) {
    const plan = normalizePlan(expectedPlan);
    log(`[reconcile] 已扣款但凭据失效(${errText.slice(0, 80)}) → 收口完成，请手动关续费`);
    return {
      ok: true,
      completed: true,
      stage: 'done',
      code: 'subscription_credential_stale',
      paymentConfirmed: true,
      paymentRetryBlocked: true,
      subscriptionPending: false,
      retryPayment: false,
      finalPlan: plan,
      pendingPlan: null,
      renewalManualRequired: true,
      paymentEvidence: {
        confirmed: true,
        source: account.lastPaymentSource || 'stored_payment_evidence',
        confirmedAt: account.lastPaymentConfirmedAt || Date.now(),
        plan,
        paymentIntent: account.lastPaymentIntent || null,
        checkoutSessionId: account.lastCheckoutSessionId || null,
        invoiceId: account.lastInvoiceId || null,
        amount: account.lastPaymentAmount ?? null,
        currency: account.lastPaymentCurrency || null,
      },
      message: '付款已成功；登录态已失效无法再核验套餐，请登录 Platform 确认订阅并手动关闭自动续费',
    };
  }
  return {
    ok: true, completed: false, stage: account.paymentState || 'submitted_pending_reconciliation',
    code: confirmedUnpaid ? 'reconciliation_unpaid_confirmed' : undefined,
    subscriptionPending: true, retryPayment: false, pendingPlan: normalizePlan(expectedPlan),
    finalPlan: result.finalPlan || normalizePlan(account.plan),
    paymentEvidence: storedPaymentConfirmed ? {
      confirmed: true, source: account.lastPaymentSource || 'stored_payment_evidence',
      confirmedAt: account.lastPaymentConfirmedAt, plan: normalizePlan(expectedPlan),
      paymentIntent: account.lastPaymentIntent || null,
      checkoutSessionId: account.lastCheckoutSessionId || null,
      invoiceId: account.lastInvoiceId || null,
      amount: account.lastPaymentAmount ?? null, currency: account.lastPaymentCurrency || null,
    } : null,
    message: '付款仍处于待同步状态；保持禁止重试扣款。',
  };
}

// ───── 取消自动续费 ─────
// 协议（gpt8.1 HAR 2026-08-01）:
//   POST /api/v1/subscriptions/cancel  body={"account_id"}
//   → {"returned_amount": null}
//   GET  /api/v1/subscriptions?account_id=…
//   → will_renew=false, cancellation_outcome="deactivate", plan 仍 plus/pro 至 active_until
// 关键头: x-vendor-device-id / x-vendor-session-id / x-vendor-language / x-vendor-client-version / x-vendor-client-build-number
//         + x-vendor-target-path|route；无 vendor-sentinel-token

/**
 * 取消自动续费 — 对齐参考项目 runCancelStep + CancelStep：
 * 1) 用订单/上下文已有的 accountId（支付时已拿到），**不强制** accounts/check
 * 2) session 强制 refresh 拿新 AT
 * 3) POST cancel（Bearer + platform-account-id + body account_id）
 * 4) 401/403 → 再 refresh 再 cancel 一次
 * 5) cancel 200 后 sleep 1.2s verify；verify 失败 → 乐观成功
 */
export async function cancelRenewal(account, log = () => {}, proxy = null) {
  const fp = accountFp(account);
  const credentialDead = (status, message) => {
    const err = new Error(message || `取消续费凭据失效: ${status || ''}`);
    err.status = Number(status) || 0;
    err.code = 'cancel_credential_dead';
    err.authenticationFailed = true;
    return err;
  };

  // ① 强制 refresh（与 Java refreshOrderSession 一致；有 session 才刷）
  if (account?.sessionToken) {
    await refreshAccountSession(account, {
      proxy, fp, log, reason: 'pre_cancel', attempts: 1,
    });
  }

  // ② 解析 accessToken：优先 account 上已有（刷后的）
  let accessToken = String(account?.accessToken || '').trim();
  if (!accessToken && account?.sessionToken) {
    const got = await getAccessToken(account.sessionToken, proxy, fp, {
      forceRefresh: true, refreshReason: 'pre_cancel_token',
    });
    accessToken = got.accessToken;
    if (got.sessionToken) account.sessionToken = got.sessionToken;
    account.accessToken = accessToken;
  }
  if (!accessToken) {
    throw credentialDead(0, '订单无 Session/accessToken，无法取消续费');
  }

  // ③ accountId：订单缓存 → JWT 声明 → 最后才 accounts/check
  // 实测：check 可 403，但 AT JWT 里仍有 platform_account_id，直接 cancel 往往能成功
  let accountId = String(
    account?.platformAccountId
    || account?.accountId
    || account?.vendorAccountId
    || platformAccountIdFromAccessToken(accessToken)
    || '',
  ).trim();
  if (!accountId) {
    try {
      const ctx = await resolveAccountContext(account, proxy, fp);
      accessToken = ctx.accessToken || accessToken;
      accountId = String(
        ctx.accountId
        || ctx.accountEntry?.account?.account_id
        || ctx.accountEntry?.account?.id
        || platformAccountIdFromAccessToken(accessToken)
        || '',
      ).trim();
    } catch (e) {
      // check 失败仍可再从 AT JWT 取一次
      accountId = platformAccountIdFromAccessToken(accessToken);
      if (!accountId) {
        if (isCancellationCredentialFailure(e?.message, e?.status) || e?.code === 'access_token_expired') {
          throw credentialDead(e.status, e.message || 'Session 已过期且无 account_id，无法取消续费');
        }
        throw e;
      }
      log(`[cancel-renewal] accounts/check 失败但 JWT 有 account_id，继续 cancel`);
    }
  }
  if (accountId) {
    account.accountId = accountId;
    account.platformAccountId = accountId;
  }
  if (!accountId) throw credentialDead(0, 'Session 或账号 ID 缺失，无法取消续费');

  const seed = accountId || account?.email || account?.sessionToken || 'cancel';
  const deviceId = stableCancelOaiId('x-vendor-device-', seed);
  const sessionId = stableCancelOaiId('x-vendor-session-', seed);

  const cancelPath = '/api/v1/subscriptions/cancel';
  const postCancel = async (token) => {
    log(`[cancel-renewal] account_id=${String(accountId).slice(0, 8)}… POST ${cancelPath} (no-check path)`);
    const cancelResp = await ctlsFetch(`${BASE}${cancelPath}`, {
      method: 'POST',
      headers: cancelRenewalHeaders({
        accessToken: token,
        accountId,
        deviceId,
        sessionId,
        targetPath: cancelPath,
        fp,
        mutation: true,
      }),
      ja3: fp.ja3,
      body: JSON.stringify({ account_id: accountId }),
    }, proxy);
    const cancelText = await cancelResp.text().catch(() => '');
    let cancelBody = {};
    try { cancelBody = cancelText ? JSON.parse(cancelText) : {}; } catch { cancelBody = { raw: cancelText.slice(0, 200) }; }
    return { cancelResp, cancelText, cancelBody };
  };

  let { cancelResp, cancelText, cancelBody } = await postCancel(accessToken);
  // ④ 401/403：只 refresh AT 再 cancel，不再 accounts/check（Java runCancelStep）
  if (!cancelResp.ok && (cancelResp.status === 401 || cancelResp.status === 403) && account?.sessionToken) {
    log(`[cancel-renewal] cancel ${cancelResp.status} → session_refresh 后重试 cancel（跳过 check）`);
    const refreshed = await refreshAccountSession(account, {
      proxy, fp, log, reason: 'cancel_401', attempts: 1,
    });
    accessToken = refreshed.accessToken || account.accessToken || accessToken;
    if (!accessToken) {
      throw credentialDead(cancelResp.status, cancelText || '取消续费凭据失效');
    }
    ({ cancelResp, cancelText, cancelBody } = await postCancel(accessToken));
  }
  if (!cancelResp.ok) {
    if (cancelResp.status === 401 || cancelResp.status === 403) {
      throw credentialDead(cancelResp.status, `取消续费失败: ${cancelResp.status} ${cancelText.slice(0, 120)}`);
    }
    const err = new Error(`取消续费失败: ${cancelResp.status} ${cancelText.slice(0, 200)}`);
    err.status = cancelResp.status;
    err.code = 'cancel_renewal_failed';
    throw err;
  }
  log(`[cancel-renewal] cancel ok returned_amount=${cancelBody?.returned_amount ?? 'null'}`);

  // ⑤ cancel 成功后 sleep 1.2s 再 verify（Java CancelStep）
  await new Promise((r) => setTimeout(r, 1200));

  const subPath = `/api/v1/subscriptions?account_id=${encodeURIComponent(accountId)}`;
  let subResp = await ctlsFetch(`${BASE}${subPath}`, {
    headers: cancelRenewalHeaders({
      accessToken,
      accountId,
      deviceId,
      sessionId,
      targetPath: '/api/v1/subscriptions',
      fp,
      mutation: false,
    }),
    ja3: fp.ja3,
  }, proxy);
  if ((subResp.status === 401 || subResp.status === 403) && account?.sessionToken) {
    const refreshed = await refreshAccountSession(account, {
      proxy, fp, log, reason: 'cancel_verify_401', attempts: 1,
    });
    accessToken = refreshed.accessToken || account.accessToken || accessToken;
    if (accessToken) {
      subResp = await ctlsFetch(`${BASE}${subPath}`, {
        headers: cancelRenewalHeaders({
          accessToken,
          accountId,
          deviceId,
          sessionId,
          targetPath: '/api/v1/subscriptions',
          fp,
          mutation: false,
        }),
        ja3: fp.ja3,
      }, proxy);
    }
  }
  if (!subResp.ok) {
    // Java: verify 失败 → 乐观视为已取消
    log(`[cancel-renewal] verify HTTP ${subResp.status}，乐观视为已取消`);
    return {
      ok: true,
      will_renew: false,
      optimistic: true,
      message: '已发送取消请求(验证跳过)',
      returned_amount: cancelBody?.returned_amount ?? null,
      account_id: accountId,
    };
  }
  const sub = await subResp.json().catch(() => ({}));
  const willRenew = optionalBoolean(sub.will_renew);
  const cancellationOutcome = sub.cancellation_outcome ?? null;
  if (willRenew === true) {
    const err = new Error('取消续费后 will_renew 仍为 true，订阅可能未关闭自动续费');
    err.code = 'cancel_renewal_still_renewing';
    err.will_renew = true;
    err.cancellation_outcome = cancellationOutcome;
    throw err;
  }
  log(`[cancel-renewal] verify will_renew=${willRenew} outcome=${cancellationOutcome || '-'} until=${sub.active_until || '-'}`);
  return {
    ok: true,
    will_renew: willRenew,
    active_until: sub.active_until || null,
    cancellation_outcome: cancellationOutcome,
    plan_type: sub.plan_type || null,
    billing_period: sub.billing_period || null,
    returned_amount: cancelBody?.returned_amount ?? null,
    account_id: accountId,
  };
}

// ───── 信用卡管理 ─────

/**
 * @param {string|{ sessionToken?: string, accessToken?: string }} sessionTokenOrAccount
 *        兼容旧签名：传 sessionToken 字符串；或传 account 对象（可含 accessToken 跳过换票）
 */
export async function getAccountId(sessionTokenOrAccount, proxy = null, fp = null) {
  let accessToken = '';
  let sessionToken = '';
  if (sessionTokenOrAccount && typeof sessionTokenOrAccount === 'object') {
    accessToken = String(sessionTokenOrAccount.accessToken || '').trim();
    sessionToken = String(sessionTokenOrAccount.sessionToken || '').trim();
  } else {
    sessionToken = String(sessionTokenOrAccount || '').trim();
  }
  if (!accessToken) {
    if (!sessionToken) {
      const err = new Error('invalid_access_token');
      err.code = 'invalid_access_token';
      throw err;
    }
    ({ accessToken } = await getAccessToken(sessionToken, proxy, fp));
  }
  const resp = await ctlsFetch(`${BASE}/api/v1/accounts/check/v4-2023-04-27`, {
    headers: backendApiHeaders(accessToken, fp), ja3: fp?.ja3,
  }, proxy);
  if (!resp.ok) {
    const status = Number(resp.status) || 0;
    if ((status === 401 || status === 403) && accessToken && !sessionToken) {
      const err = new Error('access_token_expired');
      err.code = 'access_token_expired';
      err.status = status;
      err.noProxyRetry = true;
      throw err;
    }
    throw Object.assign(new Error(`查询账户失败: ${status}`), { status });
  }
  const chk = await resp.json();
  const accounts = chk?.accounts || {};
  const accountId = accounts.default?.account?.account_id || Object.values(accounts)[0]?.account?.account_id || null;
  if (!accountId) throw new Error('无法获取 account_id');
  return { accessToken, accountId };
}

export async function listPaymentMethods(account, log = () => {}, proxy = null) {
  const fp = accountFp(account);
  const { accessToken, accountId } = await getAccountId(account, proxy, fp);
  const resp = await ctlsFetch(`${BASE}/api/v1/payments/payment_methods?account_id=${accountId}`, {
    headers: backendApiHeaders(accessToken, fp), ja3: fp.ja3,
  }, proxy);
  if (!resp.ok) throw new Error(`获取支付方式失败: ${resp.status}`);
  const data = await resp.json();
  return {
    accountId,
    methods: paymentMethodsFromResponse(data),
  };
}

// Direct-payment preflight needs a coherent snapshot. Reuse one access-token/account lookup,
// then query subscription, invoices and payment methods together so historical plan names do
// not get mistaken for a currently active subscription.
export async function queryBillingProfile(account, log = () => {}, proxy = null) {
  const fp = accountFp(account);
  // 与直充主路径一致：有 AT 不换 session；401/403 → access_token_expired
  const ctx = await resolveAccountContext(account, proxy, fp);
  const { accessToken, user, requestHeaders, accountEntry, accountId } = ctx;
  if (!accountId) throw new Error('无法获取 account_id');

  const subHeaders = subscriptionQueryHeaders(account, { ...ctx, fp });
  const get = (path, headers = requestHeaders) => ctlsFetch(`${BASE}${path}`, { headers, ja3: fp.ja3 }, proxy);
  const [subscriptionResp, invoicesResp, methodsResp] = await Promise.all([
    get(`/api/v1/subscriptions?account_id=${encodeURIComponent(accountId)}`, subHeaders),
    get(`/api/v1/invoices?limit=10&account_id=${encodeURIComponent(accountId)}`).catch(() => null),
    get(`/api/v1/payments/payment_methods?account_id=${encodeURIComponent(accountId)}`).catch(() => null),
  ]);
  // 与 querySubscription 一致：subscriptions 404 不阻断，用 check 拼 free
  if (subscriptionResp && !subscriptionResp.ok) {
    const st = Number(subscriptionResp.status) || 0;
    if (st === 404 || st === 204) {
      log(`[subscription] preflight /subscriptions HTTP ${st}，回退 accounts/check`);
    } else {
      log(`[subscription] preflight /subscriptions HTTP ${st}，仍尝试用 check 拼套餐`);
    }
  }
  const subscriptionBody = (subscriptionResp?.ok
    ? await subscriptionResp.json().catch(() => ({}))
    : {});
  const invoiceBody = invoicesResp?.ok ? await invoicesResp.json().catch(() => ({})) : {};
  const methodBody = methodsResp?.ok ? await methodsResp.json().catch(() => ({})) : {};
  const invoices = invoicesFromResponse(invoiceBody);
  const methods = paymentMethodsFromResponse(methodBody);
  const subscription = subscriptionStateFromResponses(accountEntry, subscriptionBody);
  if (!subscription.active_until) {
    subscription.active_until = subscription.has_active_subscription === false
      ? latestSubscriptionPeriodEndFromInvoices(invoices)
      : subscriptionPeriodEndFromInvoices(invoices);
  }
  const lastPayment = latestPaidInvoiceSummary(invoices);
  const paymentMethod = preferredPaymentMethodSummary(methods);
  log(`[subscription] plan=${normalizePlan(subscription.plan_type)} active=${String(subscription.has_active_subscription)}`
    + ` expiry=${subscription.active_until ? 'available' : 'missing'} renewal=${String(subscription.will_renew)}`
    + ` outcome=${subscription.cancellation_outcome || '-'} period=${subscription.billing_period || '-'}`
    + ` invoice=${lastPayment ? 'available' : 'missing'} method=${paymentMethod ? 'available' : 'missing'}`);
  const email = user?.email
    || emailFromAccessToken(accessToken)
    || account?.email
    || null;
  return {
    accountId,
    email: email && String(email).includes('@') ? String(email) : (email || null),
    subscription,
    invoices,
    methods,
    lastPayment,
    paymentMethod,
  };
}

export async function deletePaymentMethod(account, paymentMethodId, log = () => {}, proxy = null) {
  const fp = accountFp(account);
  const { accessToken, accountId } = await getAccountId(account, proxy, fp);
  const resp = await ctlsFetch(`${BASE}/api/v1/payments/payment_methods/${paymentMethodId}?account_id=${accountId}`, {
    method: 'DELETE',
    headers: backendApiHeaders(accessToken, fp), ja3: fp.ja3,
  }, proxy);
  if (!resp.ok) {
    const err = await resp.text().catch(() => '');
    throw new Error(`删除支付方式失败: ${resp.status} ${err}`);
  }
  return { ok: true };
}
