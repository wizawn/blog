// Vendor payment method attach / set-default (SetupIntent).
// 对齐 Java GptBindCardProtocol：bootstrap(seti) → stripe mids → setup confirm → list/校验 → default。
import { BASE, uuid } from './shared.js';
import { getAccountId, listPaymentMethods } from './billing.js';
import {
  VENDOR_PK, SITEKEY_PAYMENT, deviceFingerprint, confirmSetupIntent, fetchStripeMids,
} from './stripe-client.js';
import { paymentAccountFp, paymentBillingName, stableOaiId, paymentPlatformHeaders } from './checkout.js';
import { generateTaxFreeAddress } from './address.js';
import { getHcaptchaToken, stripeConfirmCardPayment } from './hcaptcha.js';
import { ctlsFetch } from './ctls.js';
import { withPaymentProxyGate } from './payment-proxy-gate.js';
import { paymentEnvironmentIds } from './payment-protocol-context.js';

export async function setDefaultPaymentMethod(account, paymentMethodId, log = () => {}, proxy = null, ctx = null) {
  const fp = ctx?.fp || paymentAccountFp(account);
  const { accessToken, accountId } = ctx?.accessToken ? ctx : await getAccountId(account, proxy, fp);
  const seed = accountId || account?.email || 'default';
  const deviceId = ctx?.deviceId || stableOaiId('x-vendor-device-', seed);
  const sessionId = ctx?.sessionId || stableOaiId('x-vendor-session-', seed);
  const headers = paymentPlatformHeaders({
    accessToken,
    accountId,
    deviceId,
    sessionId,
    fp,
    extra: { targetPath: '/api/v1/payments/payment_method/default' },
  });
  const r = await ctlsFetch(`${BASE}/api/v1/payments/payment_method/default`, {
    method: 'POST',
    headers,
    ja3: fp.ja3,
    body: JSON.stringify({ account_id: accountId, payment_method_id: paymentMethodId }),
  }, proxy);
  const d = await r.json().catch(() => ({}));
  if (!d.success) throw new Error(`设默认卡失败(${r.status}): ${JSON.stringify(d).slice(0, 150)}`);
  log(`[DEBUG] 设默认卡 ${paymentMethodId} ✓`);
  return { ok: true };
}

// 绑卡 + 设为默认(换卡一步到位)。card:{number,cvv,expMonth,expYear}。返回 { ok, paymentMethodId, last4 }
export async function addPaymentMethod(account, card, opts = {}, log = () => {}, proxy = null) {
  const run = () => addPaymentMethodInner(account, card, opts, log, proxy);
  if (opts.skipProxyGate) return run();
  return withPaymentProxyGate(proxy, run, { log });
}

async function addPaymentMethodInner(account, card, opts = {}, log = () => {}, proxy = null) {
  if (!card?.number || card.expMonth == null || card.expYear == null || !card?.cvv) {
    const err = new Error('Card details incomplete: number/exp_month/exp_year/cvc missing');
    err.code = 'card_incomplete';
    throw err;
  }
  const envVariant = Math.max(0, Math.floor(Number(opts.browserEnvironmentVariant) || 0));
  const tlsFp = paymentAccountFp(account, {
    environmentVariant: envVariant,
    browserProfileId: opts.browserProfileId || account?.browserProfileId,
  });
  const { accessToken, accountId } = await getAccountId(account, proxy, tlsFp);
  const envIds = paymentEnvironmentIds({ accountId, email: account?.email }, envVariant);
  const deviceId = opts.oaiDeviceId || envIds.deviceId;
  const sessionId = opts.oaiSessionId || envIds.sessionId;
  const protocolSteps = [];
  const step = (id, detail) => {
    protocolSteps.push({ step_id: id, detail, at: new Date().toISOString() });
    log(`[bind] ${id}: ${detail}`);
  };

  // 1. SetupIntent（Java CreateSetupIntentStep）
  step('setup_intent', '创建 SetupIntent');
  const r0 = await ctlsFetch(`${BASE}/api/v1/payments/payment_method`, {
    method: 'POST',
    headers: paymentPlatformHeaders({
      accessToken, accountId, deviceId, sessionId, fp: tlsFp,
      extra: { targetPath: '/api/v1/payments/payment_method' },
    }),
    ja3: tlsFp?.ja3,
    body: JSON.stringify({ account_id: accountId }),
  }, proxy);
  const d0 = await r0.json().catch(() => ({}));
  const setupClientSecret = d0.client_secret;
  if (!setupClientSecret) throw new Error(`创建SetupIntent失败(${r0.status}): ${JSON.stringify(d0).slice(0, 150)}`);
  step('setup_intent', 'ok');

  // 2. Stripe mids（Java StripeEnvironment；失败可继续）
  step('stripe_env', 'fetch mids');
  let mids = null;
  try {
    mids = await fetchStripeMids({ pk: VENDOR_PK, proxy, tlsFp, log });
  } catch (e) {
    log(`[bind] mids 跳过: ${e.message}`);
  }

  // 3. 免税账单地址 + 一号确定性持卡人名 + email
  let billing = opts.billing;
  if (!billing) { try { billing = await generateTaxFreeAddress(opts.taxFreeState); } catch { billing = null; } }
  if (billing && !opts.billing?.name) billing = { ...billing, name: paymentBillingName(envIds.seed) };
  if (billing && !billing.email && account?.email) billing = { ...billing, email: String(account.email).trim() };

  // 4. SetupConfirm：默认 Playwright（真人）；opts.viaHttp=true 走 HTTP（Java SetupConfirmStep 形态）
  let pmId;
  if (opts.viaHttp === true) {
    step('setup_confirm', 'HTTP confirmSetupIntent');
    let hcaptchaToken = opts.hcaptchaToken || await getHcaptchaToken({ sitekey: SITEKEY_PAYMENT, log });
    const fp = {
      ...(mids?.muid ? mids : deviceFingerprint()),
      clientSessionId: uuid(),
    };
    const conf = await confirmSetupIntent({
      pk: VENDOR_PK, setupClientSecret, card, billing, fp, hcaptchaToken, proxy, tlsFp, log,
    });
    pmId = conf.paymentMethod;
    if (conf.status === 'requires_action') {
      const s = await stripeConfirmCardPayment({
        pk: VENDOR_PK, clientSecret: setupClientSecret, card, billing,
        returnUrl: `${BASE}/payment-methods`, proxy, mode: 'setup', fp: tlsFp, log,
      });
      if (!s.ok) throw new Error(`绑卡3DS失败: ${s.error || s.status || 'unknown'}`);
      pmId = s.pm || pmId;
    } else if (conf.status !== 'succeeded') {
      throw new Error(`绑卡未成功: status=${conf.status} ${JSON.stringify(conf.body).slice(0, 120)}`);
    }
  } else {
    step('setup_confirm', 'Playwright confirmCardSetup');
    log('绑卡走真实 Stripe.js(Playwright confirmCardSetup,与真人一致)…');
    const s = await stripeConfirmCardPayment({
      pk: VENDOR_PK, clientSecret: setupClientSecret, card, billing,
      returnUrl: `${BASE}/payment-methods`, proxy, mode: 'setup', fp: tlsFp, log,
    });
    if (!s.ok) throw new Error(`绑卡失败: ${s.error || s.status || 'unknown'}`);
    pmId = s.pm;
  }
  if (!pmId) throw new Error('绑卡成功但未拿到 payment_method id');
  step('setup_confirm', `pm=${String(pmId).slice(0, 16)}`);

  // 5. ListPaymentMethods 校验（Java ListPaymentMethodsStep）
  let listed = 0;
  try {
    const methods = await listPaymentMethods(account, log, proxy);
    const arr = methods?.methods || methods?.payment_methods || methods || [];
    listed = Array.isArray(arr) ? arr.length : 0;
    const found = Array.isArray(arr) && arr.some((m) => String(m.id || m.payment_method_id || '') === String(pmId));
    step('list_pms', found ? `found pm count=${listed}` : `pm 未在列表中 count=${listed}`);
  } catch (e) {
    step('list_pms', `skip: ${e.message}`);
  }

  // 6. 设为默认(subscriptions/update 只扣默认卡)
  if (opts.setDefault !== false) {
    step('set_default', pmId);
    await setDefaultPaymentMethod(account, pmId, log, proxy, {
      accessToken, accountId, fp: tlsFp, deviceId, sessionId,
    });
    log('已设为默认卡 ✓');
  }
  return {
    ok: true,
    paymentMethodId: pmId,
    last4: String(card.number).slice(-4),
    setDefault: opts.setDefault !== false,
    boundPaymentMethodCount: listed,
    protocolSteps,
    environmentVariant: envVariant,
  };
}
