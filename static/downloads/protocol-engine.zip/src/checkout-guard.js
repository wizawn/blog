// 结账账号级坏号池（对齐 reference-impl BadAccount 思路）
// - 命中 cs_live / 欠费 / $0 试用 / Vendor 风控等确定性失败后记入
// - 冷却期内直充/探针直接 swap_account，不换 IP、不换卡、不占额度
// - 默认内存 + 可选落盘（重启不丢近期坏号）
// - 同一账号同时按 accountId / email 双键入库，避免「记 id 拦 email 漏」

import { createHash } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_TTL_MS = Math.max(
  60 * 60 * 1000,
  Number(process.env.CHECKOUT_BAD_ACCOUNT_TTL_MS) || 48 * 60 * 60 * 1000,
);
// Vendor 结账风控（confirm blocked）单独短冷却：1 小时内重复提交直接拦截
const RISK_BLOCK_TTL_MS = Math.max(
  5 * 60 * 1000,
  Number(process.env.CHECKOUT_RISK_BLOCK_TTL_MS) || 60 * 60 * 1000,
);
// cs_live / 外部结账会话：默认 1 小时冷却（与风控同档；可用 env 调）
const CS_LIVE_BLOCK_TTL_MS = Math.max(
  5 * 60 * 1000,
  Number(process.env.CHECKOUT_CS_LIVE_BLOCK_TTL_MS) || 60 * 60 * 1000,
);
export const Vendor_RISK_BLOCK_USER_MESSAGE =
  '该账号本次支付被风控拦截，请更换账号重试，不要在1日内重复提交，请手动充值';
export const Vendor_CS_LIVE_BLOCK_USER_MESSAGE =
  '该账号结账会话异常(cs_live)，请更换账号重试';
const STORE_PATH = process.env.CHECKOUT_BAD_ACCOUNT_PATH
  || path.join(__dirname, '..', 'data', 'checkout-bad-accounts.json');

/** @type {Map<string, { reason: string, code: string, until: number, hits: number, at: number, emailHint?: string }>} */
const bad = new Map();
let loaded = false;
let saveTimer = null;

function ensureLoaded() {
  if (loaded) return;
  loaded = true;
  try {
    if (!fs.existsSync(STORE_PATH)) return;
    const raw = JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
    const now = Date.now();
    for (const [k, v] of Object.entries(raw?.accounts || {})) {
      if (!v || !v.until || v.until <= now) continue;
      bad.set(k, {
        reason: String(v.reason || ''),
        code: String(v.code || ''),
        until: Number(v.until) || 0,
        hits: Number(v.hits) || 1,
        at: Number(v.at) || now,
        emailHint: v.emailHint ? String(v.emailHint) : undefined,
      });
    }
  } catch {
    /* ignore corrupt store */
  }
}

function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      const dir = path.dirname(STORE_PATH);
      fs.mkdirSync(dir, { recursive: true });
      const accounts = {};
      const now = Date.now();
      for (const [k, v] of bad.entries()) {
        if (v.until <= now) {
          bad.delete(k);
          continue;
        }
        accounts[k] = v;
      }
      fs.writeFileSync(STORE_PATH, JSON.stringify({ updatedAt: now, accounts }, null, 0));
    } catch {
      /* best-effort */
    }
  }, 500);
  if (typeof saveTimer.unref === 'function') saveTimer.unref();
}

function hashIdentity(raw) {
  const s = String(raw || '').trim();
  if (!s) return '';
  return createHash('sha256').update(s).digest('hex').slice(0, 32);
}

/** 账号键：优先 accountId，其次 email（脱敏哈希，不落明文） */
export function checkoutAccountKey(account = {}) {
  const id = String(account.accountId || account.account_id || '').trim();
  const email = String(account.email || account.accountEmail || '').trim().toLowerCase();
  return hashIdentity(id || email);
}

/** 同时返回 accountId / email 两条键，记入时双写、查询时任一命中即拦 */
export function checkoutAccountKeys(account = {}) {
  if (typeof account === 'string') {
    const k = hashIdentity(account);
    return k ? [k] : [];
  }
  const id = String(account?.accountId || account?.account_id || '').trim();
  const email = String(account?.email || account?.accountEmail || '').trim().toLowerCase();
  const keys = [];
  const idKey = hashIdentity(id);
  const emailKey = hashIdentity(email);
  if (idKey) keys.push(idKey);
  if (emailKey && emailKey !== idKey) keys.push(emailKey);
  return keys;
}

function emailHintOf(account = {}) {
  const email = String(account.email || account.accountEmail || '').trim().toLowerCase();
  if (!email || !email.includes('@')) return undefined;
  const [local, domain] = email.split('@');
  if (!local) return undefined;
  const masked = local.length <= 2 ? `${local[0] || '*'}*` : `${local.slice(0, 2)}***`;
  return `${masked}@${domain}`;
}

/** Vendor 结账风控（confirm status=blocked / 文案「本次支付被风控拦截」） */
export function isGptRiskControlFailure(error) {
  const code = String(error?.code || '').toLowerCase();
  const msg = String(error?.message || error || '');
  if (code === 'vendor_blocked' || code === 'vendor_declined' || code === 'vendor_risk_blocked') return true;
  // 对齐 Java：approve result=blocked 首次是 soft 换卡，不是账号坏号。
  // 仅「账号风控」固定文案 / 换卡后仍失败 才记账号级。
  if (code === 'checkout_blocked') {
    if (/可换卡|未扣款|swap_card|approveBlocked/i.test(msg)) return false;
    if (/换卡后仍|疑似账号|该账号本次支付被风控拦截/i.test(msg)) return true;
    return false;
  }
  return /该账号本次支付被风控拦截|vendor confirm blocked|账号.*风控拦截|registration_disallowed/i.test(msg);
}

/** cs_live / 外部 hosted 会话（内部 confirm 不支持） */
export function isCsLiveCheckoutFailure(error) {
  const code = String(error?.code || '').toLowerCase();
  const msg = String(error?.message || error || '');
  // 对齐 Java f9ad71c：换卡后仍 unpaid → 账号异常（进坏号池）
  if (code === 'cs_unpaid_account') return true;
  if (code === 'external_checkout_session') return true;
  // 首次 cs_unpaid / cs_live_confirm_incomplete 是 soft 换卡，不算账号级
  if (code === 'cs_live_confirm_incomplete' || /^cs_unpaid\b/i.test(msg)) return false;
  if (/账号封控|疑似账号.*cs_unpaid|cs_unpaid.*换卡后仍|换卡后仍未扣款/i.test(msg)) return true;
  return /cs_live_|cs_test_|结账会话异常|internal checkout sessions|only for internal|external_checkout/i.test(msg);
}

/** 是否为账号级结账失败（禁止换 IP / 换卡重试） */
export function isAccountLevelCheckoutFailure(error) {
  if (isGptRiskControlFailure(error)) return true;
  if (isCsLiveCheckoutFailure(error)) return true;
  const code = String(error?.code || '').toLowerCase();
  const msg = String(error?.message || error || '');
  if (
    code === 'account_delinquent'
    || code === 'zero_amount_trial'
    || code === 'checkout_account_blocked'
    || code === 'cs_unpaid_account'
  ) return true;
  return /需更换账号|账号封控|请更换账号|isDelinquent|账号已欠费|免费试用|计费\$0|zero_amount_trial|疑似账号问题:\s*cs_unpaid/i.test(msg);
}

export function getCheckoutAccountBlock(accountOrKey, now = Date.now()) {
  ensureLoaded();
  const keys = typeof accountOrKey === 'string'
    ? (accountOrKey ? [accountOrKey] : [])
    : checkoutAccountKeys(accountOrKey);
  if (!keys.length) return null;
  let hit = null;
  let hitKey = '';
  for (const key of keys) {
    const row = bad.get(key);
    if (!row) continue;
    if (row.until <= now) {
      bad.delete(key);
      continue;
    }
    // 多键时取 until 最晚的一条
    if (!hit || row.until > hit.until) {
      hit = row;
      hitKey = key;
    }
  }
  if (!hit) {
    scheduleSave();
    return null;
  }
  return { key: hitKey, ...hit, remainingMs: hit.until - now };
}

/**
 * 记入坏号池。
 * @param {object|string} accountOrKey
 * @param {string} reason
 * @param {{ code?: string, ttlMs?: number }} [opts]
 */
export function markCheckoutAccountBad(accountOrKey, reason, opts = {}) {
  ensureLoaded();
  const keys = typeof accountOrKey === 'string'
    ? (accountOrKey ? [accountOrKey] : [])
    : checkoutAccountKeys(accountOrKey);
  if (!keys.length) return null;
  const now = Date.now();
  const ttl = Math.max(60_000, Number(opts.ttlMs) || DEFAULT_TTL_MS);
  const emailHint = typeof accountOrKey === 'object' ? emailHintOf(accountOrKey) : undefined;
  let primary = null;
  for (const key of keys) {
    const prev = bad.get(key);
    const row = {
      reason: String(reason || opts.code || 'checkout_account_bad').slice(0, 300),
      code: String(opts.code || 'checkout_account_bad').slice(0, 80),
      until: now + ttl,
      hits: (prev?.hits || 0) + 1,
      at: now,
      emailHint: emailHint || prev?.emailHint,
    };
    bad.set(key, row);
    if (!primary) primary = { key, ...row };
  }
  scheduleSave();
  return primary;
}

/** 冷却期内直接抛错（swap_account），不进支付链路 */
export function assertCheckoutAccountAllowed(account, log = () => {}) {
  const block = getCheckoutAccountBlock(account);
  if (!block) return;
  const hours = Math.max(1, Math.ceil(block.remainingMs / 3600000));
  const mins = Math.max(1, Math.ceil(block.remainingMs / 60000));
  const isRisk = block.code === 'vendor_risk_blocked'
    || isGptRiskControlFailure({ code: block.code, message: block.reason });
  const isCsLive = block.code === 'external_checkout_session'
    || isCsLiveCheckoutFailure({ code: block.code, message: block.reason });
  const shortTtl = isRisk || isCsLive;
  log(`[checkout-guard] 坏号拦截 key=${block.key.slice(0, 8)}… code=${block.code} hits=${block.hits} ~${shortTtl ? mins + 'm' : hours + 'h'}`);
  let message;
  if (isRisk) {
    message = Vendor_RISK_BLOCK_USER_MESSAGE;
  } else if (isCsLive) {
    message = Vendor_CS_LIVE_BLOCK_USER_MESSAGE;
  } else {
    message = `该账号近期结账异常已拦截(${block.code || 'blocked'}，约${hours}h 内请换号)：${block.reason || ''}`.trim();
  }
  const err = new Error(message);
  err.code = 'checkout_account_blocked';
  err.action = 'swap_account';
  err.noProxyRetry = true;
  err.block = block;
  throw err;
}

/** 风控 / cs_live 冷却阶梯:重复被拦的账号隔离时间递增(1x→6x→24x→48x，上限 48h)，
 * 避免短冷却到期后立刻又撞同一风控、反复烧号。 */
function escalatedBlockTtl(baseMs, priorHits = 0) {
  const factors = [1, 6, 24, 48];
  const f = factors[Math.min(Math.max(0, priorHits), factors.length - 1)];
  return Math.min(baseMs * f, 48 * 60 * 60 * 1000);
}

/** 从错误自动记坏号（仅账号级） */
export function markBadFromCheckoutError(account, error, log = () => {}) {
  if (!isAccountLevelCheckoutFailure(error)) return null;
  const isRisk = isGptRiskControlFailure(error);
  const isCsLive = !isRisk && isCsLiveCheckoutFailure(error);
  const code = isRisk
    ? 'vendor_risk_blocked'
    : (isCsLive ? 'external_checkout_session' : String(error?.code || 'checkout_account_bad'));
  const reason = isRisk
    ? Vendor_RISK_BLOCK_USER_MESSAGE
    : (isCsLive
      ? Vendor_CS_LIVE_BLOCK_USER_MESSAGE
      : String(error?.message || code).slice(0, 300));
  // 阶梯冷却：读取该号已有的命中次数，风控/cs_live 类随重复次数拉长隔离窗口。
  const priorHits = getCheckoutAccountBlock(account)?.hits || 0;
  const baseTtl = isRisk
    ? RISK_BLOCK_TTL_MS
    : (isCsLive ? CS_LIVE_BLOCK_TTL_MS : DEFAULT_TTL_MS);
  const ttlMs = (isRisk || isCsLive) ? escalatedBlockTtl(baseTtl, priorHits) : baseTtl;
  const row = markCheckoutAccountBad(account, reason, { code, ttlMs });
  if (row) {
    const mins = Math.round(ttlMs / 60000);
    const tag = isRisk ? ` (风控 hits=${row.hits} ~${mins}m)` : (isCsLive ? ` (cs_live hits=${row.hits} ~${mins}m)` : '');
    log(`[checkout-guard] 记入坏号 key=${row.key.slice(0, 8)}… code=${code} ttl=${ttlMs}ms${tag}`);
  }
  return row;
}

export function checkoutRiskBlockTtlMs() {
  return RISK_BLOCK_TTL_MS;
}

export function checkoutCsLiveBlockTtlMs() {
  return CS_LIVE_BLOCK_TTL_MS;
}

export function listCheckoutBadAccounts(now = Date.now()) {
  ensureLoaded();
  const out = [];
  for (const [key, v] of bad.entries()) {
    if (v.until <= now) {
      bad.delete(key);
      continue;
    }
    out.push({ key, ...v, remainingMs: v.until - now });
  }
  return out.sort((a, b) => b.at - a.at);
}

export function checkoutBadAccountTtlMs() {
  return DEFAULT_TTL_MS;
}
