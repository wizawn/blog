// Vendor Vendor checkout session + pricing + gateway headers.
// 2026-07-27: 对齐 reference-impl（hosted 内部会话 + 支付头/指纹）。
import { createHash } from 'node:crypto';
import {
  BASE,
  DEFAULT_REGION,
  PLAN,
  accountFp,
  apiPlanName,
  traceHeaders,
  uuid,
} from './shared.js';
import { getAccessToken } from './session.js';
import { getAccountId } from './billing.js';
import { ctlsFetch, applyFp, browserHeaders } from './ctls.js';
import {
  buildPaymentBrowserProfile,
  assertProfileCoherent,
  profileDiagFields,
  secChUaFullVersionList,
} from './browser-profile.js';
import {
  selectPaymentFpProfile,
  listPaymentFpProfiles,
  fingerprintRunSnapshot,
  appendPaymentFpRun,
} from './payment-fp-experiment.js';
import { normalizePaymentRegion } from './payment-regions.js';
import { parseGlobalCheckoutPricingConfig } from './pricing-config.js';
import { STRIPE, STRIPE_VERSION, stripeHeaders } from './stripe-client.js';
import { getOaiDeploy } from './x-vendor-deploy.js';
import {
  appendStripeTaxRegion,
  applyTaxPreviewToGlobalPricingCountry,
  enrichGlobalCheckoutTaxPrices,
  parseStripeCheckoutTaxPreview,
} from './tax-preview.js';
import {
  getGlobalVendorTaxLocation,
} from './tax-locations.generated.js';
import {
  markBadFromCheckoutError,
  assertCheckoutAccountAllowed,
} from './checkout-guard.js';

export {
  appendStripeTaxRegion,
  applyTaxPreviewToGlobalPricingCountry,
  enrichGlobalCheckoutTaxPrices,
  parseStripeCheckoutTaxPreview,
};
export {
  assertCheckoutAccountAllowed,
  markCheckoutAccountBad,
  markBadFromCheckoutError,
  getCheckoutAccountBlock,
  isAccountLevelCheckoutFailure,
  isGptRiskControlFailure,
  isCsLiveCheckoutFailure,
  listCheckoutBadAccounts,
  checkoutAccountKey,
  checkoutAccountKeys,
  Vendor_RISK_BLOCK_USER_MESSAGE,
  Vendor_CS_LIVE_BLOCK_USER_MESSAGE,
  checkoutRiskBlockTtlMs,
  checkoutCsLiveBlockTtlMs,
} from './checkout-guard.js';

// platform 支付网关头(taxes/confirm 真实携带;client-version/build 半静态,失效时按新抓包更新)
// client-version / build-number 从 platform.example.com HTML 的 <html data-build/data-seq> 收割，
// 见 x-vendor-deploy.js；env VENDOR_CLIENT_VERSION / VENDOR_CLIENT_BUILD 仍可钉死。
// 2026-08-07 oaics_ 成功单 HAR：x-vendor-language=en-US（accept-language 随浏览器地区）。
// 旧默认 zh-CN 与出口地区/币种不一致，改默认 en-US；VENDOR_LANGUAGE 仍可覆盖。
const VENDOR_LANGUAGE = process.env.VENDOR_LANGUAGE || 'en-US';

/** 一号确定性 UUID（对齐 Java UUID.nameUUIDFromBytes） */
export function stableOaiId(label, seed) {
  const buf = createHash('sha1').update(String(label || '') + String(seed || 'default')).digest();
  buf[6] = (buf[6] & 0x0f) | 0x50;
  buf[8] = (buf[8] & 0x3f) | 0x80;
  const h = buf.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20, 32)}`;
}

/** 支付路径强制 Windows 画像（单源 browser-profile，禁止 Mac + 禁止旧 JA3） */
export function paymentAccountFp(account, opts = {}) {
  const base = accountFp(account) || {};
  // AT 模式无稳定 session：用 AT 短哈希做号间分散（不落明文）
  let atSeed = '';
  if (account?.accessToken && !account?.accountId && !account?.email) {
    atSeed = `at:${createHash('sha256').update(String(account.accessToken)).digest('hex').slice(0, 16)}`;
  }
  const seedBase = account?.accountId || account?.email || atSeed || account?.sessionToken || 'default';
  // 对齐 Java BrowserFingerprint.forAccount(id, variant)：同 checkout 换环境时偏移画像
  const environmentVariant = Math.max(0, Math.floor(Number(
    opts.environmentVariant ?? opts.browserEnvironmentVariant ?? 0,
  ) || 0));
  const seed = environmentVariant > 0 ? `${seedBase}|env-${environmentVariant}` : seedBase;
  // 多画像：opts.browserProfileId / account.browserProfileId / sticky|random|fixed
  const profile = opts.profile || selectPaymentFpProfile({
    seed: seedBase,
    forceId: opts.browserProfileId || account?.browserProfileId || '',
    mode: opts.fpSelectMode,
    variant: environmentVariant,
  });
  const fp = buildPaymentBrowserProfile(seed, base, profile);
  fp.environmentVariant = environmentVariant;
  return fp;
}

export { assertProfileCoherent, profileDiagFields };
export {
  listPaymentFpProfiles,
  selectPaymentFpProfile,
  fingerprintRunSnapshot,
  appendPaymentFpRun,
};

// 一号确定性英文名（对齐 BrowserFingerprint.nameFor，避免万卡同名）
const PAY_FIRST = ['James','John','Robert','Michael','William','David','Richard','Joseph','Thomas','Charles','Christopher','Daniel','Matthew','Anthony','Mark','Steven','Paul','Andrew','Joshua','Kevin','Mary','Patricia','Jennifer','Linda','Elizabeth','Barbara','Susan','Jessica','Sarah','Karen','Emily','Emma','Olivia','Sophia','Isabella','Mia','Charlotte','Amelia','Grace','Chloe'];
const PAY_LAST = ['Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Rodriguez','Martinez','Hernandez','Lopez','Gonzalez','Wilson','Anderson','Thomas','Taylor','Moore','Jackson','Martin','Lee','Perez','Thompson','White','Harris','Sanchez','Clark','Lewis','Robinson','Walker','Young','Allen','King','Wright','Scott','Hill','Green','Adams','Baker','Nelson'];

/**
 * 一号确定性英文名。variant&gt;0 时换变体（对齐 Java BrowserFingerprint.nameFor(id, variant)，
 * 供 DECLINE_RETRY_RENAME_FIRST 实验：拒付后先改名再试）。
 */
export function paymentBillingName(seed, variant = 0) {
  const s = String(seed || 'default');
  const v = Math.max(0, Math.floor(Number(variant) || 0));
  const salt = v <= 0 ? s : `${s}-v${v}`;
  let h1 = 0; let h2 = 1;
  for (let i = 0; i < salt.length; i++) {
    h1 = (Math.imul(h1, 31) + salt.charCodeAt(i)) >>> 0;
    h2 = (Math.imul(h2, 33) + salt.charCodeAt(i) + i) >>> 0;
  }
  let first = PAY_FIRST[h1 % PAY_FIRST.length];
  let last = PAY_LAST[h2 % PAY_LAST.length];
  if (v > 0) {
    const base = paymentBillingName(seed, 0);
    if (`${first} ${last}` === base) {
      first = PAY_FIRST[(h1 + 1) % PAY_FIRST.length];
      last = PAY_LAST[(h2 + 1) % PAY_LAST.length];
    }
  }
  return `${first} ${last}`;
}

/** 支付关键节点诊断日志（对照文档 §6.3） */
export function logPaymentDiag(log, tag, fields = {}) {
  if (typeof log !== 'function') return;
  const parts = Object.entries(fields)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${k}=${typeof v === 'string' ? v.slice(0, 80) : v}`);
  log(`[pay-diag] ${tag} ${parts.join(' ')}`);
}

/** 明确银行侧 decline_code（发卡行/网络常见） */
const BANK_DECLINE_CODES = new Set([
  'insufficient_funds', 'do_not_honor', 'lost_card', 'stolen_card', 'expired_card',
  'incorrect_cvc', 'incorrect_number', 'invalid_cvc', 'invalid_expiry_year', 'invalid_expiry_month',
  'invalid_number', 'card_not_supported', 'currency_not_supported', 'duplicate_transaction',
  'card_velocity_exceeded', 'withdrawal_count_limit_exceeded', 'pickup_card', 'restricted_card',
  'revocation_of_authorization', 'revocation_of_all_authorizations', 'security_violation',
  'service_not_allowed', 'stop_payment_order', 'transaction_not_allowed', 'try_again_later',
  'authentication_required', 'approve_with_id', 'call_issuer', 'card_not_supported',
  'new_account_information_available', 'no_action_taken', 'not_permitted', 'reenter_transaction',
]);

/**
 * 区分拒付来源：bank=银行/发卡行；vendor=Vendor 账号/结账风控；merchant=Stripe Radar/商户规则。
 * @returns {'bank'|'vendor'|'merchant'|'unknown'}
 */
export function classifyDeclineSource(input = {}) {
  const code = String(input.code || input.failure?.code || '').trim().toLowerCase();
  const decline = String(input.failure?.declineCode || input.declineCode || input.failure?.decline_code || '').trim().toLowerCase();
  const stage = String(input.stage || '').trim().toLowerCase();
  const msg = String(input.message || input.failure?.message || input.err || '').trim();
  const outcomeType = String(input.failure?.outcomeType || input.outcomeType || '').trim().toLowerCase();
  const networkStatus = String(input.failure?.networkStatus || input.networkStatus || '').trim().toLowerCase();
  const risk = String(input.failure?.riskLevel || input.riskLevel || '').trim().toLowerCase();
  const blob = `${code} ${decline} ${stage} ${msg} ${outcomeType} ${networkStatus}`;

  // Vendor / Vendor 结账风控（未到银行或明确账号拦截）
  if (
    code === 'checkout_blocked' || code === 'vendor_blocked' || code === 'vendor_declined'
    || stage === 'checkout_blocked'
    || /vendor confirm blocked|账号.*风控|该账号本次支付被风控|checkout_blocked|registration_disallowed/i.test(blob)
  ) {
    return 'vendor';
  }

  // Stripe Radar / 商户规则拦（非发卡行）
  if (
    outcomeType === 'blocked'
    || code === 'merchant_blocked' || code === 'stripe_blocked'
    || /radar|blocklist|highest_risk|rule|merchant.?block/i.test(blob)
    || (risk === 'highest' && /block|declin/i.test(blob))
  ) {
    return 'merchant';
  }

  // 发卡行 / 卡组织网络
  if (
    outcomeType === 'issuer_declined'
    || networkStatus === 'declined_by_network'
    || BANK_DECLINE_CODES.has(decline)
    || code === 'bank_declined'
  ) {
    return 'bank';
  }

  // generic_decline / Your card was declined：
  // - outcome.blocked → 明确商户/Radar
  // - issuer_declined / network → 银行
  // - 无 outcome/网络证据 → 按商户/协议拦截（常未真正打到发卡行；对齐运维对 Vendor 路径的判断）
  if (code === 'card_declined' || decline === 'generic_decline' || /card_declined|your card was declined/i.test(blob)) {
    if (outcomeType === 'blocked') return 'merchant';
    if (outcomeType === 'issuer_declined' || networkStatus === 'declined_by_network') return 'bank';
    const hasIssuerEvidence = outcomeType === 'issuer_declined'
      || networkStatus === 'declined_by_network'
      || BANK_DECLINE_CODES.has(decline);
    if (!hasIssuerEvidence && (decline === 'generic_decline' || !decline || /your card was declined/i.test(msg))) {
      return 'merchant';
    }
    return 'bank';
  }

  return 'unknown';
}

/**
 * 统一失败分类（文档 §6.2），便于看板聚合与换号/换卡动作。
 * 拒付额外字段：declineSource / userLabel（卡台展示用，区分银行 vs Vendor）
 * @returns {{ code: string, action: string, declineCode?: string|null, declineSource?: string, userLabel?: string }}
 */
export function classifyPaymentFailure(input = {}) {
  const code = String(input.code || input.failure?.code || '').trim();
  const decline = String(input.failure?.declineCode || input.declineCode || input.failure?.decline_code || '').trim();
  const stage = String(input.stage || '').trim();
  const msg = String(input.message || input.failure?.message || input.err || '').trim();
  const blob = `${code} ${decline} ${stage} ${msg}`;
  const withDecline = (base) => {
    const declineSource = base.declineSource || classifyDeclineSource({ ...input, code: base.code });
    const userLabel = base.userLabel || declineUserLabel(declineSource, decline || base.declineCode);
    return { ...base, declineSource, userLabel, declineCode: base.declineCode ?? (decline || null) };
  };

  // 仅「账号被强制外部会话、需换号」才标 external_checkout。
  // cs_live 支付路径自身的 confirm/challenge/poll 失败码以 cs_live_ 开头，禁止再改写成换号。
  if (code === 'external_checkout_session') {
    return withDecline({ code: 'external_checkout_session', action: 'swap_account', declineSource: 'vendor', userLabel: 'Vendor结账会话异常(需换号)' });
  }
  if (
    !/^cs_live_/i.test(code)
    && /internal checkout sessions|only for internal|结账会话异常\(需换号\)/i.test(blob)
  ) {
    return withDecline({ code: 'external_checkout_session', action: 'swap_account', declineSource: 'vendor', userLabel: 'Vendor结账会话异常(需换号)' });
  }
  if (
    !/^cs_live_/i.test(code)
    && /cs_live_|cs_test_/i.test(blob)
    && /需换号|external_checkout|not supported for this api/i.test(blob)
  ) {
    return withDecline({ code: 'external_checkout_session', action: 'swap_account', declineSource: 'vendor', userLabel: 'Vendor结账会话异常(需换号)' });
  }
  if (code === 'account_delinquent' || /isDelinquent|欠费/i.test(blob)) {
    return withDecline({ code: 'account_delinquent', action: 'swap_account', declineSource: 'vendor', userLabel: 'Vendor账号欠费(需换号)' });
  }
  if (code === 'zero_amount_trial' || /zero_amount|计费\$0|免费试用/i.test(blob)) {
    return withDecline({ code: 'zero_amount_trial', action: 'swap_account', declineSource: 'vendor', userLabel: 'Vendor试用$0账号(需换号)' });
  }
  // 对齐 Java：approve result=blocked 先换卡。码保持 checkout_blocked（卡台 soft 认这个），勿改写成 vendor_blocked。
  if (
    code === 'checkout_blocked'
    || /vendor confirm blocked|checkout_blocked|approve.*风控拦截|result["']?\s*[:=]\s*["']?blocked/i.test(blob)
  ) {
    return withDecline({
      code: 'checkout_blocked',
      action: 'swap_card',
      declineSource: 'vendor',
      userLabel: 'approve风控拦截(未扣款，可换卡)',
    });
  }
  if (code === 'vendor_blocked' || code === 'vendor_declined' || /账号.*风控|该账号本次支付被风控|registration_disallowed/i.test(blob)) {
    return withDecline({ code: 'vendor_blocked', action: 'swap_account_or_proxy', declineSource: 'vendor', userLabel: 'Vendor风控拒绝(非银行)' });
  }
  // 泛 blocked 且无卡字段：按可换卡 soft 处理（与 Java approve blocked 一致）
  if (/\bblocked\b/i.test(blob) && !/card_declined|your card was declined/i.test(blob)) {
    return withDecline({
      code: 'checkout_blocked',
      action: 'swap_card',
      declineSource: 'vendor',
      userLabel: 'approve风控拦截(未扣款，可换卡)',
    });
  }
  if (code === 'checkout_quote_out_of_range' || /out_of_range|超出管理员允许范围/i.test(blob)) {
    return { code: 'checkout_quote_out_of_range', action: 'stop_check_config', userLabel: '报价超出配置(未扣款)' };
  }
  // 对齐 Java PaymentResult.CURRENCY_MISMATCH=9：Vendor confirm Phase A 币种与既有账单账户不一致。
  // 未进 Stripe 扣款；不换卡、不补款、不记代理连败；应重建结账/锁账单国后重试。
  if (
    code === 'currency_mismatch'
    || /currency is incompatible|incompatible currency|currency_incompatible|币种不兼容|existing billing account/i.test(blob)
  ) {
    return {
      code: 'currency_mismatch',
      action: 'rebuild_checkout',
      declineSource: 'vendor',
      userLabel: '结账币种与账号账单账户不兼容(未扣款，勿换卡)',
    };
  }
  if (stage === 'paid_pending_subscription' || code === 'paid_pending_subscription') {
    return { code: 'paid_pending_subscription', action: 'no_retry', userLabel: '已付款待同步套餐' };
  }
  if (stage === 'requires_action' || code === 'three_ds' || /requires_action|3DS|three[_-]?ds/i.test(blob)) {
    return { code: 'three_ds', action: 'browser_or_swap_card', userLabel: '需3DS验证' };
  }
  if (
    code === 'card_declined' || code === 'bank_declined' || code === 'merchant_blocked'
    || decline
    || /card_declined|do_not_honor|insufficient|generic_decline|stolen_card|lost_card|fraudulent|pickup_card|your card was declined/i.test(blob)
  ) {
    const declineSource = classifyDeclineSource(input);
    if (declineSource === 'vendor') {
      return withDecline({
        code: 'vendor_blocked', action: 'swap_account_or_proxy', declineSource: 'vendor',
        declineCode: decline || null,
        userLabel: 'Vendor风控拒绝(非银行)',
      });
    }
    if (declineSource === 'merchant') {
      return withDecline({
        code: 'merchant_blocked', action: 'swap_card_or_account', declineSource: 'merchant',
        declineCode: decline || null,
        userLabel: declineUserLabel('merchant', decline),
      });
    }
    return withDecline({
      code: 'bank_declined', action: 'swap_card', declineSource: 'bank',
      declineCode: decline || null,
      userLabel: declineUserLabel('bank', decline),
    });
  }
  if (code === 'need_hcaptcha' || stage === 'need_hcaptcha') {
    return { code: 'need_hcaptcha', action: 'retry', userLabel: '验证码获取失败' };
  }
  if (code === 'plan_transition_unsupported') {
    return { code: 'plan_transition_unsupported', action: 'skip', userLabel: '套餐路径不支持' };
  }
  // 对齐 Java：User is already paid / 已有同档 → 本单失败换号，未扣款，不换代理
  if (code === 'already_subscribed' || /user is already paid|already paid|已有同档/i.test(blob)) {
    return {
      code: 'already_subscribed',
      action: 'swap_account',
      declineSource: 'vendor',
      userLabel: '账号已有同档订阅(未扣款，需换号)',
    };
  }
  if (/查询订阅失败|token_expired|token_invalid|session.*(invalid|expired)|unauthorized/i.test(blob)) {
    return { code: 'session_invalid', action: 'relogin_or_swap_account', userLabel: '会话失效' };
  }
  if (/404|not\s*found/i.test(blob) && /订阅|subscription|account/i.test(blob)) {
    return { code: 'subscription_lookup_failed', action: 'relogin_or_swap_account', userLabel: '订阅查询失败' };
  }
  // 避免把整句中文错误当 code 键
  const cleanCode = code && !/[\u4e00-\u9fff]/.test(code) && code.length <= 64
    ? code
    : '';
  if (cleanCode) {
    return withDecline({ code: cleanCode, action: 'retry_or_inspect', declineCode: decline || null, userLabel: msg.slice(0, 80) || cleanCode });
  }
  if (stage) return { code: stage, action: 'retry_or_inspect', userLabel: msg.slice(0, 80) || stage };
  return { code: 'payment_error', action: 'retry_or_inspect', userLabel: msg.slice(0, 80) || '支付失败' };
}

/** 卡台可读短标签 */
export function declineUserLabel(source, declineCode = '') {
  const d = declineCode ? `(${declineCode})` : '';
  if (source === 'bank') {
    if (declineCode === 'generic_decline' || !declineCode) return `银行拒付${d || '(原因未披露)'}`;
    if (declineCode === 'insufficient_funds') return '银行拒付(余额不足)';
    if (declineCode === 'do_not_honor') return '银行拒付(发卡行拒绝)';
    if (declineCode === 'lost_card' || declineCode === 'stolen_card') return '银行拒付(挂失/盗卡)';
    if (declineCode === 'expired_card') return '银行拒付(卡过期)';
    if (declineCode === 'incorrect_cvc' || declineCode === 'invalid_cvc') return '银行拒付(CVV错误)';
    return `银行拒付${d}`;
  }
  if (source === 'vendor') return 'Vendor风控拒绝(非银行)';
  if (source === 'merchant') {
    if (declineCode === 'generic_decline' || !declineCode) {
      return '协议/Stripe侧拦截(未到发卡行或未返回发卡证据)';
    }
    return `商户/Stripe风控拦截(非银行)${d}`;
  }
  return `拒付来源未知${d}`;
}

/** 给失败结果补齐 code + failureClass（成功路径原样返回） */
export function withPaymentFailureClass(result) {
  if (!result || typeof result !== 'object') return result;
  if (result.ok && !result.failure) return result;
  if (result.skipped && result.stage === 'paid_pending_subscription') {
    const fc = classifyPaymentFailure({ ...result, code: result.code || 'paid_pending_subscription' });
    return {
      ...result,
      code: result.code || fc.code,
      failureClass: fc,
      message: result.message || fc.userLabel || result.message,
    };
  }
  if (result.ok && !result.failure && result.stage !== 'requires_action') return result;
  const fc = classifyPaymentFailure(result);
  // 对用户/卡台文案：优先 failureClass.userLabel，保留原始 Stripe 句在 failure.message
  const message = fc.userLabel
    ? (result.message && /pi_status=/.test(result.message)
      ? `${fc.userLabel} · ${result.message}`
      : (result.failure?.message && result.failure.message !== fc.userLabel
        ? `${fc.userLabel}：${result.failure.message}${result.piStatus ? ` pi_status=${result.piStatus}` : ''}`
        : fc.userLabel))
    : result.message;
  return {
    ...result,
    code: result.code && ['bank_declined', 'vendor_blocked', 'merchant_blocked', 'checkout_blocked'].includes(result.code)
      ? result.code
      : (fc.code || result.code),
    message: message || result.message,
    failureClass: result.failureClass || fc,
    declineSource: fc.declineSource || result.declineSource,
  };
}

export function oaiGatewayHeaders(deviceId, sessionId, targetPath, language = VENDOR_LANGUAGE) {
  const deploy = getOaiDeploy();
  return {
    'x-vendor-client-version': deploy.clientVersion,
    'x-vendor-client-build-number': deploy.buildNumber,
    'x-vendor-device-id': deviceId,
    'x-vendor-session-id': sessionId,
    'x-vendor-language': language,
    'x-vendor-telemetry': '[1,null]',
    'x-vendor-target-path': targetPath,
    'x-vendor-target-route': targetPath,
  };
}

/** platform.example.com 支付请求头：一号 device + account-id + 完整 Client Hints */
export function paymentPlatformHeaders({
  accessToken, accountId, deviceId, sessionId, fp, referer = `${BASE}/`, extra = {},
}) {
  // 多画像：优先 fp 上的语言（实验画像），否则 env VENDOR_LANGUAGE
  const oaiLang = String(fp?.oaiLanguage || VENDOR_LANGUAGE || 'en-US');
  const acceptLang = String(
    fp?.acceptLanguage
    || (oaiLang.startsWith('zh') ? 'zh-CN,zh;q=0.9,en;q=0.8' : 'en-US,en;q=0.9'),
  );
  const base = browserHeaders({
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
    Accept: '*/*',
    'Accept-Language': acceptLang,
    Origin: BASE,
    Referer: referer,
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    ...oaiGatewayHeaders(deviceId, sessionId, extra.targetPath || '/api/v1/payments/checkout', oaiLang),
    ...(accountId ? { 'platform-account-id': accountId } : {}),
    ...extra,
  });
  delete base.targetPath;
  const out = applyFp(base, fp);
  // 兜底：与 applyFp 同源 full-version-list
  if (fp?.chromeFull) {
    const full = String(fp.chromeFull).replace(/^"|"$/g, '');
    out['sec-ch-ua-full-version-list'] = secChUaFullVersionList(full);
    out['sec-ch-ua-full-version'] = `"${full}"`;
  }
  if (out['sec-ch-ua-model'] == null) out['sec-ch-ua-model'] = fp?.model || '""';
  return out;
}

// 2026-07-13 的 Plus→Pro 真 Chrome 抓包只发送低熵 Client Hints。applyFp 默认还会补高熵
// arch/full-version 等字段，这些字段在该请求上反而偏离浏览器，故升级链显式移除。
export function upgradeRequestHeaders(ctx, targetPath, mutation = false) {
  const deploy = getOaiDeploy();
  // 与直充对齐：同一 VENDOR_LANGUAGE + account-id + 稳定 device；低熵 Client Hints 仍删除高熵项（抓包升级链）
  const base = browserHeaders({
    'Authorization': `Bearer ${ctx.accessToken}`,
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
    'Priority': 'u=1, i',
    'Referer': `${BASE}/`,
    'Accept-Language': VENDOR_LANGUAGE.startsWith('zh') ? 'zh-CN,zh;q=0.9,en;q=0.8' : 'en-US,en;q=0.9',
    ...traceHeaders(),
    'x-vendor-client-version': deploy.clientVersion,
    'x-vendor-client-build-number': deploy.buildNumber,
    'x-vendor-device-id': ctx.deviceId,
    'x-vendor-session-id': ctx.sessionId,
    'x-vendor-language': VENDOR_LANGUAGE,
    'x-x-vendor-is-client-observation': 'v1.r.m',
    'x-x-vendor-is-pending-updates': '{"v":3,"updates":[]}',
    'x-vendor-target-path': targetPath,
    'x-vendor-target-route': targetPath,
    // Origin 每次都发：只在 mutation 上带会让 GET 变成「声明同源却无来源」，
    // 被 Vendor 边缘在鉴权前回 403 挑战页（同 backendApiHeaders 的教训）。
    'Origin': BASE,
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    ...(ctx.accountId ? { 'platform-account-id': ctx.accountId } : {}),
    ...(mutation ? { 'Content-Type': 'application/json' } : {}),
  });
  const result = applyFp(base, ctx.fp);
  delete result['sec-ch-ua-arch'];
  delete result['sec-ch-ua-bitness'];
  delete result['sec-ch-ua-full-version'];
  delete result['sec-ch-ua-platform-version'];
  return result;
}

/**
 * 创建结账会话。
 * 2026-07-27 对齐友方：请求 checkout_ui_mode=hosted 才倾向返回 oaics_ 内部会话；
 * 响应里的 checkout_ui_mode 可能是 custom，不能当请求值。
 */
export function buildCheckoutRequestPayload({
  plan,
  region,
  entryPoint = 'all_plans_pricing_modal',
  interval = 'month',
  teamPlanData = null,
  checkoutUiMode = 'hosted',
} = {}) {
  // checkoutUiMode 仅显式 custom 时覆盖（cs_live）；默认 hosted 不变
  const uiMode = String(checkoutUiMode || 'hosted').trim() === 'custom' ? 'custom' : 'hosted';
  return {
    entry_point: entryPoint,
    plan_name: plan,
    billing_details: { country: region.country, currency: region.currency },
    checkout_ui_mode: uiMode,
    ...(!teamPlanData ? {
      price_interval: interval,
      selected_cadence: interval,
    } : {}),
    ...(teamPlanData ? { team_plan_data: { ...teamPlanData } } : {}),
    ...plusPromoCampaign(plan),
  };
}

/**
 * 对齐 Java PaymentPagesCheckoutStep 请求体：
 * settings_upsell + custom + 写死 PH/PHP，不带 price_interval/selected_cadence。
 */
export function buildPaymentPagesCheckoutPayload(plan) {
  return {
    entry_point: 'settings_upsell',
    plan_name: plan,
    billing_details: { country: 'PH', currency: 'PHP' },
    checkout_ui_mode: 'custom',
    ...plusPromoCampaign(plan),
  };
}

/**
 * 对齐 Java PaymentPagesCheckoutStep 请求头（刻意精简）：
 * Authorization / platform-account-id / Content-Type / Origin / Referer
 * + ProtocolHttpClient 默认 User-Agent。
 * 不带 x-vendor-*、Client Hints、telemetry、x-vendor-target-*（与 CheckoutStep 指纹头不同）。
 */
export function paymentPagesCheckoutHeaders({ accessToken, accountId, fp = null } = {}) {
  return vendorCheckoutLeanHeaders({
    accessToken,
    accountId,
    fp,
    referer: `${BASE}/`,
  });
}

/**
 * 对齐 Java TaxesStep / PaymentPagesStep.doApprove 的精简 Vendor 支付头。
 * 不带 x-vendor-device/session/telemetry、Client Hints、x-vendor-target-*。
 *
 * - taxes：Referer=深链 checkout，另带 `x-vendor-language: zh-CN`
 * - approve：Referer=`https://platform.example.com/`，带 `Accept: application/json`
 */
export function vendorCheckoutLeanHeaders({
  accessToken,
  accountId = null,
  referer = `${BASE}/`,
  oaiLanguage = null,
  accept = null,
  fp = null,
  extra = {},
} = {}) {
  const ua = String(fp?.ua || '').trim()
    || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36';
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    ...(accountId ? { 'platform-account-id': String(accountId) } : {}),
    'Content-Type': 'application/json',
    Origin: BASE,
    Referer: referer || `${BASE}/`,
    'User-Agent': ua,
  };
  if (accept) headers.Accept = accept;
  if (oaiLanguage) headers['x-vendor-language'] = String(oaiLanguage);
  for (const [k, v] of Object.entries(extra || {})) {
    if (v === undefined || v === null || v === '') continue;
    headers[k] = v;
  }
  return headers;
}

/**
 * Plus 档带 promo_campaign（对齐 reference-impl CheckoutStep.putPlusPromoIfNeeded）。
 * 必须用付费档 plus-1-month；plus-1-month-free 会开出 $0 免费试用，虚拟卡走协议付不过去。
 * 仅 Plus 带，Pro 不带。PAYMENT_PLUS_PROMO=0 可关，PAYMENT_PLUS_PROMO_ID 可换档。
 */
export function plusPromoCampaign(plan) {
  if (/^(0|false|no|off)$/i.test(String(process.env.PAYMENT_PLUS_PROMO || ''))) return {};
  const p = String(plan || '').trim().toLowerCase();
  if (!p.includes('plus') || p.includes('pro')) return {};
  const id = String(process.env.PAYMENT_PLUS_PROMO_ID || 'plus-1-month').trim() || 'plus-1-month';
  if (/-free$/.test(id)) return {}; // 防呆：绝不发免费试用档
  return { promo_campaign: { promo_campaign_id: id, is_coupon_from_query_param: false } };
}

export async function createCheckout(account, plan = PLAN.PLUS, region = DEFAULT_REGION, log = () => {}, proxy = null, fp = null, ctx = null) {
  plan = String(ctx?.checkoutPlanName || '').trim() || apiPlanName(plan);
  const entryPoint = String(ctx?.checkoutEntryPoint || '').trim()
    || 'all_plans_pricing_modal';
  const teamPlanData = ctx?.checkoutTeamPlanData && typeof ctx.checkoutTeamPlanData === 'object'
    ? { ...ctx.checkoutTeamPlanData }
    : null;
  region = normalizePaymentRegion(region?.country, region?.currency);
  fp = fp || ctx?.fp || paymentAccountFp(account);
  const accessToken = ctx?.accessToken || (await getAccountId(account, proxy, fp)).accessToken;
  const accountId = ctx?.accountId || account?.accountId || null;
  const seed = accountId || account?.email || 'default';
  const deviceId = ctx?.deviceId || stableOaiId('x-vendor-device-', seed);
  const sessionId = ctx?.sessionId || stableOaiId('x-vendor-session-', seed);
  const interval = ctx?.priceInterval || 'month';
  // payment_pages 直付 / 账单锁绕过：对齐 Java PaymentPagesCheckoutStep（精简头 + PH/PHP body）
  const paymentPagesCheckout = ctx?.paymentPagesCheckout === true;
  let headers;
  let payload;
  let checkoutUiMode;
  if (paymentPagesCheckout) {
    headers = paymentPagesCheckoutHeaders({ accessToken, accountId, fp });
    payload = buildPaymentPagesCheckoutPayload(plan);
    checkoutUiMode = 'custom';
    region = normalizePaymentRegion('PH', 'PHP');
  } else {
    headers = paymentPlatformHeaders({
      accessToken,
      accountId,
      deviceId,
      sessionId,
      fp,
      referer: `${BASE}/`,
      extra: { targetPath: '/api/v1/payments/checkout' },
    });
    // 对齐 Java CheckoutStep：无 x-vendor-telemetry / x-vendor-target-*（BrowserFingerprint 也不带）
    delete headers['x-vendor-telemetry'];
    delete headers['x-vendor-target-path'];
    delete headers['x-vendor-target-route'];
    // hosted → oaics_ 内部会话；custom 易得到 cs_live_（仅 csLive 开关路径传入）。
    checkoutUiMode = String(ctx?.checkoutUiMode || 'hosted').trim() === 'custom' ? 'custom' : 'hosted';
    payload = buildCheckoutRequestPayload({
      plan, region, entryPoint, interval, teamPlanData, checkoutUiMode,
    });
  }
  const resp = await ctlsFetch(`${BASE}/api/v1/payments/checkout`, {
    method: 'POST',
    headers,
    ja3: fp.ja3,
    body: JSON.stringify(payload),
  }, proxy);
  const body = await resp.json().catch(() => resp.text());
  log(`[DEBUG] checkout(${region.country}/${region.currency}) status=${resp.status} mode=${checkoutUiMode}`
    + `${paymentPagesCheckout ? ' payment_pages=1' : ''}`);
  return {
    status: resp.status,
    ok: resp.ok,
    region,
    body,
    meta: { deviceId, sessionId, accountId, accessToken, paymentPagesCheckout },
  };
}

/** checkout 成功后的账号/会话门禁（对齐 CheckoutStep.java） */
export function assertCheckoutSessionUsable(body, log = () => {}, account = null) {
  const sessionId = body?.checkout_session_id || body?.checkout_session?.id || '';
  if (!sessionId) {
    const err = new Error('结账会话缺少 checkout_session_id');
    err.code = 'checkout_missing_session';
    throw err;
  }
  if (String(sessionId).startsWith('cs_live_') || String(sessionId).startsWith('cs_test_')) {
    // 真抓包 req-522：浏览器可走 custom + payment_pages + approve 付完 cs_live；
    // ACC 主路径仍用 oaic 内部 confirm，故 cs_live 记坏号换号（可选后续 PAYMENT_CS_LIVE_RESCUE）。
    const tag = body?.tag || body?.checkout_ui_mode || '';
    const manual = body?.requires_manual_approval === true;
    log(
      `[checkout] 外部会话 ${String(sessionId).slice(0, 24)}… tag=${tag}`
      + ` requires_manual_approval=${manual} → 内部 confirm 不支持（请求已是 hosted，属账号降级）`,
    );
    const err = new Error('该账号结账会话异常(cs_live)，请更换账号重试');
    err.code = 'external_checkout_session';
    err.action = 'swap_account';
    err.noProxyRetry = true;
    err.checkoutSessionId = String(sessionId);
    err.requiresManualApproval = manual;
    err.checkoutTag = String(tag || '');
    // 始终记入 1h 冷却；无 account 时由上层 markBad 再补
    if (account) markBadFromCheckoutError(account, err, log);
    throw err;
  }
  if (isDelinquentTrue(body)) {
    const err = new Error('账号已欠费(isDelinquent)，无法出账单，请更换账号');
    err.code = 'account_delinquent';
    err.action = 'swap_account';
    err.noProxyRetry = true;
    if (account) markBadFromCheckoutError(account, err, log);
    throw err;
  }
  const amountTotal = extractAmountTotal(body);
  if (amountTotal === 0) {
    const err = new Error('该账号有免费试用资格(计费$0)，无法使用虚拟卡支付');
    err.code = 'zero_amount_trial';
    err.action = 'swap_account';
    err.noProxyRetry = true;
    if (account) markBadFromCheckoutError(account, err, log);
    throw err;
  }
  // 请求必须是 hosted；响应 mode 仅诊断
  const respMode = body?.checkout_ui_mode || body?.checkout_session?.ui_mode || '';
  if (respMode && String(respMode) !== 'hosted' && String(respMode) !== 'custom') {
    log(`[checkout] 响应 ui_mode=${respMode}（请求仍为 hosted；custom 响应在 oaics_ 下可接受）`);
  }
  return { sessionId, amountTotal };
}

/**
 * 轻量结账探针：只 POST checkout + 门禁，不 taxes/confirm/开卡。
 * 用于直充前筛 cs_live 坏号（对齐 Java Debug checkout）。
 */
export async function probeCheckoutSession(account, opts = {}, log = () => {}, proxy = null) {
  assertCheckoutAccountAllowed(account, log);
  const plan = apiPlanName(opts.plan || PLAN.PLUS);
  const region = normalizePaymentRegion(opts.region?.country || opts.country, opts.region?.currency || opts.currency);
  const fp = opts.fp || paymentAccountFp(account);
  const seed = account?.accountId || account?.email || 'default';
  const deviceId = opts.deviceId || stableOaiId('x-vendor-device-', seed);
  const sessionId = opts.sessionId || stableOaiId('x-vendor-session-', seed);
  const ctx = {
    fp, deviceId, sessionId,
    accountId: account?.accountId || null,
    accessToken: opts.accessToken,
    priceInterval: opts.priceInterval || 'month',
  };
  logPaymentDiag(log, 'checkout_probe_req', {
    ui_mode_req: 'hosted',
    plan,
    country: region.country,
    currency: region.currency,
    ...profileDiagFields(fp),
  });
  const co = await createCheckout(account, plan, region, log, proxy, fp, ctx);
  if (!co.ok) {
    const err = new Error(`创建结账会话失败(${co.status})`);
    err.status = co.status;
    err.checkoutBody = co.body;
    err.preCharge = true;
    throw err;
  }
  try {
    const gate = assertCheckoutSessionUsable(co.body, log, account);
    logPaymentDiag(log, 'checkout_probe_ok', {
      session_prefix: String(gate.sessionId).slice(0, 12),
      internal: String(gate.sessionId).startsWith('oaics_'),
      amount_total: gate.amountTotal,
    });
    return {
      ok: true,
      sessionType: String(gate.sessionId).startsWith('oaics_') ? 'oaics' : 'other',
      checkoutSessionId: gate.sessionId,
      amountTotal: gate.amountTotal,
      publishableKey: co.body?.publishable_key || null,
    };
  } catch (e) {
    markBadFromCheckoutError(account, e, log);
    throw e;
  }
}

function isDelinquentTrue(node) {
  if (!node || typeof node !== 'object') return false;
  if (Array.isArray(node)) return node.some(isDelinquentTrue);
  for (const [k, v] of Object.entries(node)) {
    if (/^is_?delinquent$/i.test(k) && (v === true || v === 'true' || v === 1)) return true;
    if (v && typeof v === 'object' && isDelinquentTrue(v)) return true;
  }
  return false;
}

function extractAmountTotal(body) {
  if (!body || typeof body !== 'object') return -1;
  if (typeof body.amount_total === 'number') return body.amount_total;
  const cs = body.checkout_session;
  if (cs && typeof cs.amount_total === 'number') return cs.amount_total;
  const state = body.checkout_state || cs?.checkout_state;
  const sub = state?.total?.subtotal?.minorUnitsAmount;
  if (typeof sub === 'number') return sub;
  return -1;
}

// 从 checkout 响应体里取错误文案(兼容 Vendor 多种错误形状)。
export function checkoutErrorText(body) {
  if (typeof body === 'string') return body;
  if (body && typeof body === 'object') {
    const m = body.detail || body.error?.message || body.message;
    if (m) return String(m);
    try { return JSON.stringify(body); } catch { return ''; }
  }
  return '';
}

// 判定 checkout 400 是否为「账单国家必须匹配请求出口国」——反应式切 PH 计费代理拉账单的触发条件。
export function isBillingCountryMismatch(body) {
  return /billing country must match request country|billing[_\s-]*country.*match.*request.*country/i.test(checkoutErrorText(body));
}

async function fetchCheckoutPricingConfigByKey(account, pricingKey, proxy, fp, ctx = null) {
  fp = fp || ctx?.fp || accountFp(account);
  const accessToken = ctx?.accessToken || (await getAccountId(account, proxy, fp)).accessToken;
  const url = `${BASE}/api/v1/checkout_pricing_config/configs/${encodeURIComponent(pricingKey)}`;
  const resp = await ctlsFetch(url, {
    method: 'GET',
    headers: applyFp(browserHeaders({
      Authorization: `Bearer ${accessToken}`, Accept: 'application/json',
      Origin: BASE, Referer: `${BASE}/`,
      'sec-fetch-site': 'same-origin', 'sec-fetch-mode': 'cors', 'sec-fetch-dest': 'empty',
    }), fp),
    ja3: fp.ja3,
  }, proxy);
  const body = await resp.json().catch(() => null);
  if (!resp.ok || !body?.currency_config) {
    const status = Number(resp.status) || 0;
    const error = new Error(`checkout_pricing_unavailable:${status}`);
    error.code = 'checkout_pricing_unavailable';
    error.status = status;
    // 对齐 Java：带 Bearer 的定价接口 401/403 → 凭证问题，不换付款 IP
    if (status === 401 || status === 403) {
      error.noProxyRetry = true;
      error.cfBlocked = false;
    } else if (status === 495) {
      error.cfBlocked = true;
    }
    throw error;
  }
  return body;
}

async function fetchCheckoutPricingConfig(account, region, proxy, fp, ctx = null) {
  region = normalizePaymentRegion(region?.country, region?.currency);
  const body = await fetchCheckoutPricingConfigByKey(account, region.pricingKey, proxy, fp, ctx);
  return { body, region };
}

function checkoutQuote(body, region, plan, log = () => {}) {
  plan = apiPlanName(plan);
  const priceKey = plan === PLAN.PRO ? 'pro' : plan === PLAN.PRO_LITE ? 'prolite' : 'plus';
  const monthly = body.currency_config?.[priceKey]?.month;
  const majorAmount = Number(monthly?.psp_override?.amount ?? monthly?.amount);
  const exponent = Number(body.currency_config?.minor_unit_exponent ?? 2);
  const responseCurrency = String(body.currency_config?.symbol_code || '').toUpperCase();
  const responseCountry = String(body.country_code || '').toUpperCase();
  if (!Number.isFinite(majorAmount) || majorAmount <= 0 || !Number.isInteger(exponent) || exponent < 0 || exponent > 4 || responseCurrency !== region.currency || responseCountry !== region.country) {
    const error = new Error('checkout_pricing_invalid');
    error.code = 'checkout_pricing_invalid';
    throw error;
  }
  const amountMinor = Math.round(majorAmount * (10 ** exponent));
  log(`[pricing] ${priceKey} ${region.country}/${region.currency}: ${amountMinor} (exp=${exponent})`);
  return {
    country: region.country, currency: region.currency, pricingKey: region.pricingKey,
    plan: priceKey, amountMinor, amountMajor: majorAmount, minorUnitExponent: exponent,
    tax: String(monthly?.psp_override?.tax || monthly?.tax || ''), fetchedAt: Date.now(),
  };
}

export async function getCheckoutPricing(account, plan = PLAN.PLUS, region = DEFAULT_REGION, log = () => {}, proxy = null, fp = null, ctx = null) {
  const config = await fetchCheckoutPricingConfig(account, region, proxy, fp, ctx);
  return checkoutQuote(config.body, config.region, plan, log);
}

export async function getCheckoutPrices(account, region = DEFAULT_REGION, log = () => {}, proxy = null, fp = null) {
  const config = await fetchCheckoutPricingConfig(account, region, proxy, fp);
  return {
    plus: checkoutQuote(config.body, config.region, PLAN.PLUS, log),
    pro_5x: checkoutQuote(config.body, config.region, PLAN.PRO_LITE, log),
    pro_20x: checkoutQuote(config.body, config.region, PLAN.PRO, log),
  };
}

function pricingFailureCode(error) {
  const code = String(error?.code || error?.message || 'checkout_pricing_failed')
    .trim()
    .toLowerCase();
  return /^[a-z0-9_-]{1,80}$/.test(code) ? code : 'checkout_pricing_failed';
}

function taxPreviewError(code) {
  const error = new Error(code);
  error.code = code;
  return error;
}

function globalTaxPreviewPlan(country) {
  if (country?.plans?.plus) return { key: 'plus', apiName: PLAN.PLUS };
  if (country?.plans?.pro_5x) return { key: 'pro_5x', apiName: PLAN.PRO_LITE };
  if (country?.plans?.pro_20x) return { key: 'pro_20x', apiName: PLAN.PRO };
  return null;
}

/**
 * Create an unpaid custom checkout and read its Stripe payment-page totals.
 * This path never confirms the checkout and is gated by the global-pricing opt-in.
 */
export async function fetchGlobalCheckoutTaxPreview(
  account,
  country,
  log = () => {},
  proxy = null,
  fp = null,
  ctx = null,
) {
  const countryCode = String(country?.countryCode || '').trim().toUpperCase();
  const currency = String(country?.currency || '').trim().toUpperCase();
  const representativePlan = globalTaxPreviewPlan(country);
  if (!/^[A-Z]{2}$/.test(countryCode)
      || !/^[A-Z]{3}$/.test(currency)
      || !representativePlan) {
    throw taxPreviewError('tax_preview_country_invalid');
  }

  const fingerprint = fp || ctx?.fp || paymentAccountFp(account);
  const identity = ctx?.accessToken && ctx?.accountId
    ? ctx
    : await getAccountId(account, proxy, fingerprint);
  const accountId = identity.accountId;
  const accessToken = identity.accessToken;
  const seed = accountId || account?.email || 'default';
  const deviceId = ctx?.deviceId || stableOaiId('x-vendor-device-', seed);
  const sessionId = ctx?.sessionId || stableOaiId('x-vendor-session-', seed);
  const checkoutResponse = await ctlsFetch(`${BASE}/api/v1/payments/checkout`, {
    method: 'POST',
    headers: paymentPlatformHeaders({
      accessToken,
      accountId,
      deviceId,
      sessionId,
      fp: fingerprint,
      referer: `${BASE}/`,
      extra: { targetPath: '/api/v1/payments/checkout' },
    }),
    ja3: fingerprint.ja3,
    body: JSON.stringify({
      entry_point: 'all_plans_pricing_modal',
      plan_name: representativePlan.apiName,
      billing_details: { country: countryCode, currency },
      checkout_ui_mode: 'custom',
    }),
    timeoutMs: 20000,
  }, proxy);
  const checkoutBody = await checkoutResponse.json().catch(() => null);
  const checkoutSessionId = String(checkoutBody?.checkout_session_id || '');
  const publishableKey = String(checkoutBody?.publishable_key || '');
  if (!checkoutResponse.ok
      || !/^cs_(?:live|test)_/.test(checkoutSessionId)
      || !/^pk_(?:live|test)_/.test(publishableKey)) {
    throw taxPreviewError('tax_preview_checkout_failed');
  }

  const stripeJSID = uuid();
  const form = new URLSearchParams();
  form.set('browser_locale', 'en-US');
  form.set('browser_timezone', 'UTC');
  form.set('elements_session_client[client_betas][0]', 'custom_checkout_server_updates_1');
  form.set('elements_session_client[client_betas][1]', 'custom_checkout_manual_approval_1');
  form.set('elements_session_client[elements_init_source]', 'custom_checkout');
  form.set('elements_session_client[referrer_host]', 'platform.example.com');
  form.set('elements_session_client[stripe_js_id]', stripeJSID);
  form.set('elements_session_client[locale]', 'en-US');
  form.set('elements_session_client[is_aggregation_expected]', 'false');
  form.set('elements_options_client[saved_payment_method][enable_save]', 'auto');
  form.set('elements_options_client[saved_payment_method][enable_redisplay]', 'auto');
  form.set('key', publishableKey);
  form.set('_stripe_version', STRIPE_VERSION);

  const paymentPageResponse = await ctlsFetch(
    `${STRIPE}/v1/payment_pages/${encodeURIComponent(checkoutSessionId)}/init`,
    {
      method: 'POST',
      headers: applyFp(stripeHeaders(), fingerprint),
      ja3: fingerprint.ja3,
      body: form.toString(),
      timeoutMs: 20000,
    },
    proxy,
  );
  const paymentPageBody = await paymentPageResponse.json().catch(() => null);
  if (!paymentPageResponse.ok || !paymentPageBody) {
    throw taxPreviewError('tax_preview_payment_page_failed');
  }
  let preview;
  try {
    preview = parseStripeCheckoutTaxPreview(paymentPageBody);
  } catch (error) {
    if (error?.code !== 'tax_preview_incomplete') throw error;
    const location = getGlobalVendorTaxLocation(countryCode);
    if (!location) throw taxPreviewError('tax_preview_location_unavailable');
    const updateForm = appendStripeTaxRegion(form, location);
    const elementsSessionId = String(paymentPageBody?.session_id || '').trim();
    if (elementsSessionId) {
      updateForm.set('elements_session_client[session_id]', elementsSessionId);
    }
    const updateResponse = await ctlsFetch(
      `${STRIPE}/v1/payment_pages/${encodeURIComponent(checkoutSessionId)}`,
      {
        method: 'POST',
        headers: applyFp(stripeHeaders(), fingerprint),
        ja3: fingerprint.ja3,
        body: updateForm.toString(),
        timeoutMs: 20000,
      },
      proxy,
    );
    const updateBody = await updateResponse.json().catch(() => null);
    if (!updateResponse.ok || !updateBody) {
      throw taxPreviewError('tax_preview_location_update_failed');
    }
    preview = parseStripeCheckoutTaxPreview(updateBody);
  }
  log(
    `[global-pricing-tax] country=${countryCode}`
    + ` plan=${representativePlan.key}`
    + ` exclusive=${preview.taxExclusiveAmountMinor}`
    + ` inclusive=${preview.taxInclusiveAmountMinor}`,
  );
  return { ...preview, representativePlan: representativePlan.key };
}

export async function getGlobalCheckoutPrices(
  account,
  countries,
  log = () => {},
  proxy = null,
  fp = null,
  {
    concurrency = 5,
    includeTaxPreview = false,
    taxConcurrency = 5,
    fetchTaxPreview = fetchGlobalCheckoutTaxPreview,
  } = {},
) {
  const requested = [...new Set((countries || [])
    .map((country) => String(country || '').trim().toUpperCase())
    .filter((country) => /^[A-Z]{2}$/.test(country)))];
  if (!requested.length || requested.length > 250) {
    const error = new Error('invalid_pricing_countries');
    error.code = 'invalid_pricing_countries';
    throw error;
  }

  const safeConcurrency = Math.max(1, Math.min(5, Number(concurrency) || 5));
  const fingerprint = fp || accountFp(account);
  const accessToken = (await getAccountId(account, proxy, fingerprint)).accessToken;
  const fetchedAt = Date.now();
  const results = new Array(requested.length);
  let cursor = 0;

  async function worker() {
    for (;;) {
      const index = cursor++;
      if (index >= requested.length) return;
      const countryCode = requested[index];
      try {
        const body = await fetchCheckoutPricingConfigByKey(
          account,
          countryCode,
          proxy,
          fingerprint,
          { accessToken, fp: fingerprint },
        );
        results[index] = {
          ok: true,
          country: parseGlobalCheckoutPricingConfig(body, countryCode, fetchedAt),
        };
      } catch (error) {
        results[index] = {
          ok: false,
          countryCode,
          code: pricingFailureCode(error),
        };
      }
    }
  }

  await Promise.all(Array.from(
    { length: Math.min(safeConcurrency, requested.length) },
    () => worker(),
  ));

  let successful = results.filter((result) => result?.ok).map((result) => result.country);
  const failed = results.filter((result) => result && !result.ok).map(({ countryCode, code }) => ({
    countryCode,
    code,
  }));
  let taxPreviewFailures = [];
  let taxPreviewSuccessfulCountries = 0;
  if (includeTaxPreview && successful.length) {
    try {
      const identity = await getAccountId(account, proxy, fingerprint);
      const taxResult = await enrichGlobalCheckoutTaxPrices(
        account,
        successful,
        log,
        proxy,
        fingerprint,
        { ...identity, fp: fingerprint },
        {
          concurrency: taxConcurrency,
          fetchPreview: fetchTaxPreview,
        },
      );
      successful = taxResult.countries;
      taxPreviewFailures = taxResult.failures;
      taxPreviewSuccessfulCountries = taxResult.successfulCountries;
    } catch (error) {
      taxPreviewFailures = successful.map((country) => ({
        countryCode: country.countryCode,
        code: pricingFailureCode(error),
      }));
    }
  }
  log(`[global-pricing] requested=${requested.length} successful=${successful.length} failed=${failed.length}`);
  return {
    fetchedAt,
    requestedCountries: requested.length,
    successfulCountries: successful.length,
    countries: successful,
    failures: failed,
    taxPreviewEnabled: includeTaxPreview,
    taxPreviewRequestedCountries: includeTaxPreview ? successful.length : 0,
    taxPreviewSuccessfulCountries,
    taxPreviewFailures,
  };
}
