// 支付多画像选择 + 运行记录（便于连跑几天做成功率归因）。
// 画像定义在 browser-profile.js；本模块负责选择策略与 JSONL 落盘。

import { appendFile, mkdir } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import {
  PAYMENT_FP_PROFILES,
  getPaymentFpProfile,
  listPaymentFpProfiles,
  seedHash,
  assertProfileCoherent,
  profileDiagFields,
} from './browser-profile.js';

/**
 * 选择模式（env PAYMENT_FP_SELECT）：
 * - sticky（默认）：同 seed 固定同一画像，便于「同号多日」对比
 * - random：每笔随机（池内）
 * - fixed:<id>：强制某套
 * - round：按时间片轮转（每小时换一套）
 */
export function paymentFpSelectMode() {
  return String(process.env.PAYMENT_FP_SELECT || 'sticky').trim().toLowerCase() || 'sticky';
}

export function paymentFpEnabledProfiles() {
  const raw = String(process.env.PAYMENT_FP_PROFILE_IDS || '').trim();
  const includeExp = process.env.PAYMENT_FP_INCLUDE_EXPERIMENTAL === '1'
    || process.env.PAYMENT_FP_INCLUDE_EXPERIMENTAL === 'true';
  // 默认优先 Java 对齐画像（Chrome148 + stripe.js/3704557c13 同代）
  const preferJava = !/^(0|false|no|off)$/i.test(String(process.env.PAYMENT_FP_PREFER_JAVA || '1').trim());
  let pool = listPaymentFpProfiles({ includeExperimental: includeExp });
  if (raw) {
    const want = new Set(raw.split(/[,\s]+/).map((s) => s.trim()).filter(Boolean));
    pool = PAYMENT_FP_PROFILES.filter((p) => want.has(p.id));
  } else if (preferJava) {
    const javaPool = pool.filter((p) => String(p.id || '').startsWith('java148-'));
    if (javaPool.length) pool = javaPool;
  }
  return pool.length ? pool : [PAYMENT_FP_PROFILES[0]];
}

export function selectPaymentFpProfile({
  seed = 'default',
  forceId = '',
  mode = paymentFpSelectMode(),
  variant = 0,
} = {}) {
  if (forceId) {
    const forced = getPaymentFpProfile(forceId);
    if (forced) return forced;
  }
  const pool = paymentFpEnabledProfiles();
  const m = String(mode || 'sticky').trim().toLowerCase();
  const envOffset = Math.max(0, Math.floor(Number(variant) || 0));
  if (m.startsWith('fixed:')) {
    const id = m.slice(6).trim();
    return getPaymentFpProfile(id) || pool[0];
  }
  if (m === 'random') {
    // 换环境时仍偏移，避免同 variant 随机撞同一画像
    return pool[(Math.floor(Math.random() * pool.length) + envOffset) % pool.length];
  }
  if (m === 'round' || m === 'hourly') {
    const slot = Math.floor(Date.now() / (60 * 60 * 1000));
    return pool[(slot + envOffset) % pool.length];
  }
  // sticky + variant 偏移（Java forAccount(id, variant)）
  return pool[(seedHash(seed) + envOffset) % pool.length];
}

/** 脱敏诊断字段（写入 job / JSONL，禁止凭据） */
export function fingerprintRunSnapshot(fp = {}, extra = {}) {
  const coherent = assertProfileCoherent(fp);
  return {
    profileId: String(fp.profileId || extra.profileId || ''),
    profileLabel: String(fp.profileLabel || ''),
    experimental: fp.profileExperimental === true,
    chromeFull: String(fp.chromeFull || '').slice(0, 24),
    platformVersion: String(fp.platformVersion || ''),
    acceptLanguage: String(fp.acceptLanguage || '').slice(0, 40),
    oaiLanguage: String(fp.oaiLanguage || '').slice(0, 16),
    uaMajor: coherent.major,
    ja3Head: String(fp.ja3 || '').slice(0, 32),
    coherent: coherent.ok,
    coherentIssues: coherent.ok ? [] : coherent.issues.slice(0, 8),
    selectMode: paymentFpSelectMode(),
    ...profileDiagFields(fp),
  };
}

function defaultRunLogPath() {
  if (process.env.PAYMENT_FP_RUN_LOG) return process.env.PAYMENT_FP_RUN_LOG;
  // 相对 server 工作目录：生产 WorkingDirectory=/srv/acc/app/current/server
  return join(process.cwd(), 'data', 'payment-fp-runs.jsonl');
}

/**
 * 追加一条运行记录（成功/失败都写）。
 * 失败仅 console.warn，不阻断支付主路径。
 */
export async function appendPaymentFpRun(record = {}) {
  if (process.env.PAYMENT_FP_RUN_LOG === '0' || process.env.PAYMENT_FP_RUN_LOG === 'off') {
    return { ok: false, skipped: true };
  }
  const path = defaultRunLogPath();
  const line = JSON.stringify({
    at: new Date().toISOString(),
    ts: Date.now(),
    ...record,
  });
  try {
    await mkdir(dirname(path), { recursive: true });
    await appendFile(path, `${line}\n`, 'utf8');
    return { ok: true, path };
  } catch (e) {
    console.warn(`[payment-fp] run log append failed: ${e.message}`);
    return { ok: false, error: e.message, path };
  }
}

/** 从引擎 result 抽可分析字段 */
export function outcomeFromPaymentResult(result = {}, error = null) {
  if (error) {
    return {
      outcome: 'error',
      status: 'failed_precharge',
      stage: String(error.stage || 'failed_precharge'),
      code: String(error.code || error.message || 'engine_error').slice(0, 80),
      message: String(error.message || '').slice(0, 200),
      hasPi: false,
      completed: false,
    };
  }
  const completed = result?.completed === true;
  const pending = result?.subscriptionPending === true || result?.stage === 'paid_pending_subscription';
  const declined = result?.stage === 'declined';
  let outcome = 'failed_precharge';
  if (completed) outcome = 'completed';
  else if (pending) outcome = 'pending';
  else if (declined) outcome = 'declined';
  else if (result?.stage === 'requires_action') outcome = 'requires_action';
  else if (result?.stage === 'dry_run') outcome = 'dry_run';
  return {
    outcome,
    status: completed ? 'completed' : (declined ? 'declined' : (pending ? 'pending' : 'failed_precharge')),
    stage: String(result?.stage || ''),
    code: String(result?.code || result?.stage || '').slice(0, 80),
    message: String(result?.message || result?.failure?.message || '').slice(0, 200),
    hasPi: Boolean(result?.paymentIntent || result?.paymentEvidence?.paymentIntent),
    completed,
    sessionPrefix: String(result?.checkoutSessionId || result?.paymentEvidence?.checkoutSessionId || '').slice(0, 16),
  };
}

export {
  listPaymentFpProfiles,
  getPaymentFpProfile,
  PAYMENT_FP_PROFILES,
};
