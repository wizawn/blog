/**
 * 支付协议上下文工具 —— 对齐 Java PaymentContext.prepareExternalCheckoutRetry
 * 与 BrowserFingerprint variant（同 checkout 换浏览器环境）。
 */
import { createHash } from 'node:crypto';
import { uuid } from './shared.js';

/** 同会话换环境次数（含首次）。默认 3 = variant 0/1/2。 */
export function externalCheckoutEnvRetries(opts = {}) {
  const raw = opts.externalCheckoutEnvRetries
    ?? opts.envRetries
    ?? process.env.PAYMENT_EXTERNAL_ENV_RETRIES
    ?? 3;
  const n = Number(raw);
  if (!Number.isFinite(n)) return 3;
  return Math.max(1, Math.min(5, Math.floor(n)));
}

/**
 * 一号确定性 x-vendor-device / x-vendor-session；variant>0 时追加 -env-N（对齐 Java）。
 */
export function paymentEnvironmentIds(accountOrSeed, variant = 0) {
  let seed = 'default';
  if (typeof accountOrSeed === 'string') seed = accountOrSeed || 'default';
  else if (accountOrSeed && typeof accountOrSeed === 'object') {
    seed = accountOrSeed.accountId
      || accountOrSeed.email
      || accountOrSeed.sessionToken
      || 'default';
  }
  const v = Math.max(0, Math.floor(Number(variant) || 0));
  const seedKey = v > 0 ? `${String(seed).trim()}|env-${v}` : String(seed).trim() || 'default';
  return {
    seed: seedKey,
    variant: v,
    deviceId: stableUuidFromLabel('x-vendor-device-', seedKey),
    sessionId: stableUuidFromLabel('x-vendor-session-', seedKey),
  };
}

function stableUuidFromLabel(label, seed) {
  const buf = createHash('sha1').update(String(label || '') + String(seed || 'default')).digest();
  buf[6] = (buf[6] & 0x0f) | 0x50;
  buf[8] = (buf[8] & 0x3f) | 0x80;
  const h = buf.toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20, 32)}`;
}

/**
 * 同 checkout 换环境：保留会话身份，清空 Stripe/Elements/卡 token/PI。
 * @param {object} ctx 可复用字段（session / pk / customer_session / billing 等）
 * @param {number} environmentVariant
 */
export function prepareExternalCheckoutRetry(ctx = {}, environmentVariant = 1) {
  const v = Math.max(0, Math.floor(Number(environmentVariant) || 0));
  const keep = {
    checkoutSessionId: ctx.checkoutSessionId || ctx.sessionId || null,
    publishableKey: ctx.publishableKey || ctx.pk || null,
    processorEntity: ctx.processorEntity || 'vendor_entity',
    customerSessionClientSecret: ctx.customerSessionClientSecret || null,
    amount: ctx.amount,
    currency: ctx.currency,
    billing: ctx.billing || null,
    plan: ctx.plan || null,
    targetPlan: ctx.targetPlan || null,
    accessToken: ctx.accessToken || null,
    platformAccountId: ctx.platformAccountId || ctx.accountId || null,
    checkoutBody: ctx.checkoutBody || null,
    knownInvoiceIds: ctx.knownInvoiceIds || null,
    paymentStartedAt: ctx.paymentStartedAt || null,
    returnUrl: ctx.returnUrl || null,
  };
  return {
    ...keep,
    browserEnvironmentVariant: v,
    stripeJsId: uuid(),
    elementsSessionId: null,
    elementsConfigId: null,
    stripeCustomerId: null,
    confirmationToken: null,
    confirmationTokenId: null,
    paymentIntentId: null,
    paymentIntentClientSecret: null,
    guid: null,
    muid: null,
    sid: null,
    passiveCaptchaToken: null,
    hcaptchaToken: null,
  };
}

/**
 * 支付结果是否适合「同 checkout 换环境」再试（未扣款、非明确银行拒卡/账号死）。
 */
export function isSafeToRetryWithNewEnvironment(result = {}, error = null) {
  if (error) {
    if (error.paymentRejected) return false;
    if (error.code === 'currency_mismatch' || error.code === 'account_delinquent'
      || error.code === 'zero_amount_trial' || error.code === 'external_checkout_session'
      || error.code === 'already_subscribed') {
      return false;
    }
    if (error.code === 'payment_confirm_ambiguous') return false;
    if (error.noProxyRetry && error.code !== 'taxes_failed' && !String(error.code || '').startsWith('taxes_http_')) {
      // 账号级 noProxy 一般不换环境；taxes 可换环境再试
      if (/swap_account|delinquent|blocked|currency/i.test(String(error.action || error.code || ''))) {
        return false;
      }
    }
    // 扣款前错误可换环境
    if (error.preCharge === true) return true;
    if (error.code === 'checkout_confirm_failed' || error.code === 'checkout_blocked') return true;
    if (String(error.code || '').startsWith('taxes_')) return true;
    return false;
  }
  if (!result || typeof result !== 'object') return false;
  if (result.ok === true || result.paymentConfirmed || result.paymentEvidence?.confirmed) return false;
  if (result.stage === 'paid_pending_subscription' || result.stage === 'done') return false;
  if (result.code === 'payment_confirm_ambiguous' || result.code === 'currency_mismatch') return false;
  if (result.code === 'bank_declined' || result.failureClass?.declineSource === 'bank') return false;
  if (result.stage === 'declined' && result.failureClass?.declineSource === 'bank') return false;
  // 明确禁止再扣款
  if (result.paymentRetryBlocked === true && result.retryPayment === false) return false;
  // 结论明确指向「卡」而非「环境」时不得换环境重跑整条链。
  // 对齐 Java doPollPaid 的 cs_unpaid 语义：勿换号，可复用会话换卡重试。
  // 换环境要重开会话 + 重打 approve，既慢又会加速账号被风控标记。
  if (result.envRetry === false) return false;
  // 未扣款可重试的环境类失败
  if (result.retryPayment === true) return true;
  if (result.stage === 'failed_precharge' || result.stage === 'cs_live_failed') return true;
  if (result.code === 'merchant_blocked' || result.failureClass?.declineSource === 'merchant') return true;
  if (result.code === 'vendor_blocked' || result.failureClass?.declineSource === 'vendor') return true;
  return false;
}
