export function protocolPaceDelay(baseMs, random = Math.random) {
  const base = Math.max(0, Math.min(8000, Number(baseMs) || 0));
  if (!base) return 0;
  const sample = Math.max(0, Math.min(1, Number(random()) || 0));
  return Math.round(base * (0.75 + sample * 0.5));
}

export async function waitForProtocolPace(baseMs, { signal = null, random = Math.random } = {}) {
  const delayMs = protocolPaceDelay(baseMs, random);
  if (!delayMs) return 0;
  if (signal?.aborted) throw new Error('已停止');
  await new Promise((resolve, reject) => {
    const timer = setTimeout(done, delayMs);
    function done() {
      signal?.removeEventListener('abort', aborted);
      resolve();
    }
    function aborted() {
      clearTimeout(timer);
      signal?.removeEventListener('abort', aborted);
      reject(new Error('已停止'));
    }
    signal?.addEventListener('abort', aborted, { once: true });
  });
  return delayMs;
}
