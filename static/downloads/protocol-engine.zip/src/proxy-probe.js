// 付款代理弹活失败阶梯：1h → 6h → 24h → 48h → 删除。
// 纯逻辑，供健康巡检 / 单测 / 结果补丁共用（不依赖 store）。

const HOUR = 60 * 60 * 1000;

/** 第 1～4 次弹活失败的冷却时长（ms）；第 5 次删除。 */
export const PROBE_COOLDOWN_STAGES_MS = Object.freeze([
  1 * HOUR,
  6 * HOUR,
  24 * HOUR,
  48 * HOUR,
]);

export function normalizeProbeFailStage(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.min(4, Math.floor(n));
}

function formatCooldownHuman(ms) {
  const h = Math.round(ms / HOUR);
  if (h >= 24 && h % 24 === 0) return `${h / 24} 天`;
  return `${h} 小时`;
}

/**
 * 弹活成功：清冷却、阶梯归零、标 healthy。
 * @param {number} [now]
 */
export function probeSuccessPatch(now = Date.now()) {
  return {
    health: 'healthy',
    probeFailStage: 0,
    cooldownUntil: 0,
    failCount: 0,
    lastSuccessAt: now,
    testedAt: now,
    testNote: '通',
  };
}

/**
 * 弹活（或等效链路）失败：推进阶梯。
 * - stage 0 失败 → 冷却 1h，stage=1
 * - stage 1 失败 → 冷却 6h，stage=2
 * - stage 2 失败 → 冷却 24h，stage=3
 * - stage 3 失败 → 冷却 48h，stage=4
 * - stage 4 失败 → 删除
 *
 * @param {{ probeFailStage?: number, failCount?: number }} row
 * @param {number} [now]
 * @returns {{ action: 'cooldown'|'delete', patch: object, cooldownMs?: number, stage?: number }}
 */
export function probeFailureAction(row = {}, now = Date.now()) {
  const stage = normalizeProbeFailStage(row.probeFailStage);
  const failCount = (Number(row.failCount) || 0) + 1;

  if (stage >= 4) {
    return {
      action: 'delete',
      stage: 5,
      patch: {
        health: 'bad',
        probeFailStage: 5,
        cooldownUntil: 0,
        failCount,
        lastFailureAt: now,
        testedAt: now,
        testNote: '弹活连续失败，删除出口',
      },
    };
  }

  const cooldownMs = PROBE_COOLDOWN_STAGES_MS[stage];
  const nextStage = stage + 1;
  return {
    action: 'cooldown',
    stage: nextStage,
    cooldownMs,
    patch: {
      health: 'bad',
      probeFailStage: nextStage,
      cooldownUntil: now + cooldownMs,
      failCount,
      lastFailureAt: now,
      testedAt: now,
      testNote: `弹活失败，进入第 ${nextStage} 档冷却 ${formatCooldownHuman(cooldownMs)}`,
    },
  };
}

/** 是否仍在冷却中（冷却期内跳过弹活、不可被选中）。 */
export function isPaymentProxyCooling(row, now = Date.now()) {
  const until = Number(row?.cooldownUntil) || 0;
  return until > now;
}
