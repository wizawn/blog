// Vendor Plus/Pro direct Stripe recharge orchestration (rechargePhp).
// Extracted from platform.js (zero behavior change).
import {
  BASE, PLAN, accountFp, emitPaymentState, resolvePaymentPricing, apiPlanName, uuid, buildSessionCookie,
} from './shared.js';
import { refreshAccountSession } from './session.js';
import {
  normalizePlan, resolveAccountContext, querySubscription, queryInvoices,
  getAccountId, reconcilePaymentOutcome, pollSubscriptionActivation,
} from './billing.js';
import {
  createCheckout, getCheckoutPricing, checkoutErrorText, isBillingCountryMismatch,
  upgradeRequestHeaders, oaiGatewayHeaders, paymentAccountFp, paymentPlatformHeaders,
  vendorCheckoutLeanHeaders,
  stableOaiId, assertCheckoutSessionUsable, paymentBillingName, logPaymentDiag,
  withPaymentFailureClass, profileDiagFields,
  assertCheckoutAccountAllowed, markBadFromCheckoutError,
  fingerprintRunSnapshot, appendPaymentFpRun,
} from './checkout.js';
import { outcomeFromPaymentResult } from './payment-fp-experiment.js';
import { JA3_HASH_EXPECTED } from './browser-profile.js';
import {
  SITEKEY_CTOKEN, SITEKEY_PAYMENT, deviceFingerprint, elementsSession,
  createConfirmationToken, confirmPaymentIntent, retrievePaymentIntent, stripeFailure,
  fetchStripeMids,
} from './stripe-client.js';
import { getStripeJsBuild } from './stripe-build.js';
import { noteOaiDeployHtml } from './x-vendor-deploy.js';
import { generateTaxFreeAddress } from './address.js';
import { getHcaptchaToken, stripeConfirmCardPayment, harvestStripeFingerprint } from './hcaptcha.js';
import { ctlsFetch, applyFp, browserHeaders } from './ctls.js';
import { setProtocolPhase } from './traffic-capture.js';
import { blocksPaymentRetry, findNewPaidInvoice, planMatches } from './payment-state.js';
import { amountWithinRange } from './payment-config.js';
import { normalizePaymentRegion, quoteWithinTolerance } from './payment-regions.js';
import { withPaymentProxyGate } from './payment-proxy-gate.js';
import {
  externalCheckoutEnvRetries,
  paymentEnvironmentIds,
  isSafeToRetryWithNewEnvironment,
} from './payment-protocol-context.js';

/** 对齐 Java TaxesStep.SUBMIT_ATTEMPTS：免税地址提交可安全重试（无副作用） */
export const TAXES_SUBMIT_ATTEMPTS = 4;

/**
 * Vendor confirm 币种与账号既有账单账户不兼容（Java PaymentResult.CURRENCY_MISMATCH）。
 * 发生在 Stripe 扣款前，与卡/代理无关。
 */
function checkoutErrorBlob(messageOrBody) {
  if (messageOrBody == null) return '';
  if (typeof messageOrBody === 'string') return messageOrBody;
  if (typeof messageOrBody === 'object') {
    return [
      messageOrBody.detail,
      messageOrBody.message,
      messageOrBody.error?.message,
      messageOrBody.error?.detail,
      typeof messageOrBody.body === 'string' ? messageOrBody.body : '',
    ].filter(Boolean).join(' ');
  }
  return String(messageOrBody);
}

export function isCheckoutCurrencyIncompatible(messageOrBody) {
  const text = checkoutErrorBlob(messageOrBody);
  if (!text) return false;
  const lower = text.toLowerCase();
  return lower.includes('currency is incompatible')
    || lower.includes('incompatible currency')
    || lower.includes('currency_incompatible')
    || (lower.includes('currency') && lower.includes('existing billing account'))
    || text.includes('币种不兼容');
}

/**
 * Vendor checkout 返回账号已付/已开通（subscriptions 可能仍短暂显示 free）。
 * 对齐 Java：本单标「已有同档」失败，禁止当成功核销，也禁止当 proxy_down 换线。
 */
export function isCheckoutUserAlreadyPaid(messageOrBody) {
  const text = checkoutErrorBlob(messageOrBody);
  if (!text) return false;
  const lower = text.toLowerCase();
  return lower.includes('user is already paid')
    || lower.includes('already paid')
    || lower.includes('already_subscribed')
    || lower.includes('already has an active')
    || text.includes('已经是付费')
    || text.includes('已是会员')
    || text.includes('已开通');
}

/**
 * Vendor checkout/confirm 鉴权拒绝（401/403），且未进入扣款成功信号。
 * 仅此时可刷新 accessToken 后安全重放一次（对齐 Java confirmWithCredentialRetry）。
 */
export function isVendorConfirmCredentialRejection(status, body = null) {
  const code = Number(status) || 0;
  if (code !== 401 && code !== 403) return false;
  if (body && typeof body === 'object') {
    const hasSuccess = !!(body.status || body.type || body.client_secret || body.payment_intent
      || body.payment_intent_client_secret);
    if (hasSuccess && !body.detail) return false;
  }
  return true;
}

function sleepMs(ms) {
  return new Promise((resolve) => setTimeout(resolve, Math.max(0, Number(ms) || 0)));
}

/** checkout 深链 Referer（taxes / snapshot / confirm / approve 共用） */
function checkoutReferer(processorEntity, sessionId) {
  const entity = processorEntity || 'vendor_entity';
  return `${BASE}/checkout/${entity}/${sessionId}`;
}

/**
 * 从 checkout create / taxes 响应取 deferred_intent 金额（最小货币单位）。
 * 对齐 Java CheckoutAmountSupport（d2d2751：税后 Elements 需带最终 amount）。
 * @returns {number} 正整数 minor units；取不到返回 -1
 */
export function extractCheckoutTotalMinorUnits(body) {
  if (!body || typeof body !== 'object') return -1;
  const asNum = (v) => {
    if (v == null || v === '') return -1;
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.round(n) : -1;
  };
  const direct = asNum(body.amount_total);
  if (direct > 0) return direct;

  const session = body.checkout_session && typeof body.checkout_session === 'object'
    ? body.checkout_session
    : null;
  if (session) {
    const nested = asNum(session.amount_total);
    if (nested > 0) return nested;
  }

  let checkoutState = body.checkout_state;
  if (!checkoutState && session) checkoutState = session.checkout_state;
  if (!checkoutState || typeof checkoutState !== 'object') return -1;
  const totalMap = checkoutState.total && typeof checkoutState.total === 'object'
    ? checkoutState.total
    : null;
  if (!totalMap) return -1;

  const moneyMinor = (value) => {
    if (value == null) return -1;
    if (typeof value === 'number') return asNum(value);
    if (typeof value === 'object') {
      const m = asNum(value.minorUnitsAmount ?? value.amount ?? value.value);
      if (m > 0) return m;
    }
    return asNum(value);
  };

  for (const key of ['total', 'taxInclusive', 'subtotal']) {
    const m = moneyMinor(totalMap[key]);
    if (m > 0) return m;
  }
  return -1;
}

/**
 * 是否需要 Vendor checkout/approve（custom_checkout_manual_approval 路径）。
 * 注意：oaics 内部会话即使 requires_manual_approval 也不应乱调 approve（易 500）。
 * 浏览器 req-522：仅 cs_live + payment_pages/confirm 后 approve → {"result":"approved"}。
 */
export function needsCheckoutApprove(checkoutBody = null, confirmBody = null) {
  const b = confirmBody && typeof confirmBody === 'object' ? confirmBody : {};
  if (b.requires_approval === true || b.needs_approval === true || b.manual_approval_required === true) {
    return true;
  }
  const st = String(b.status || b.state || b.approval_status || '').toLowerCase();
  if (st && /requires_?approval|pending_approval|awaiting_approval/.test(st)) return true;
  // create 上的 requires_manual_approval  alone 不够（oaics 也会带）
  if (checkoutBody?.requires_manual_approval === true) {
    const sid = String(checkoutBody?.checkout_session_id || '').trim();
    if (sid.startsWith('cs_live_') || sid.startsWith('cs_test_')) return true;
  }
  return false;
}

// 通知 Platform 服务端用账单地址重算税额(在 checkout/confirm 前调用)
// 对齐 Java TaxesStep(a52df58)：billing_country 跟随地址国；失败最多 4 次重试后硬失败（ctoken 前中止，不扣款）。
export async function checkoutTaxes({
  accessToken, sessionId, processorEntity, planName, billing, currency,
  oaiDeviceId, oaiSessionId, accountId = null, checkoutEmail = null,
  proxy = null, tlsFp = null, log = () => {},
  attempts = TAXES_SUBMIT_ATTEMPTS,
} = {}) {
  const entity = processorEntity || 'vendor_entity';
  const addressCountry = String(billing?.country || 'US').trim().toUpperCase() || 'US';
  const payload = {
    checkout_session_id: sessionId,
    processor_entity: entity,
    plan_name: planName || 'basic_plan',
    // 必须与 billing_address.country 一致；写死 US 会在改免税地区时自相矛盾
    billing_country: addressCountry,
    currency: String(currency || 'PHP').toLowerCase(),
    billing_name: billing?.name || '',
    ...(checkoutEmail ? { checkout_email: checkoutEmail } : {}),
    billing_address: {
      line1: billing?.line1 || '',
      city: billing?.city || '',
      state: billing?.state || '',
      postal_code: billing?.postalCode || billing?.postal_code || '',
      country: addressCountry,
    },
  };
  // 对齐 Java TaxesStep：精简头 + x-vendor-language=zh-CN + 深 Referer（无 x-vendor-device/telemetry/CH）
  // oaiDeviceId/oaiSessionId 保留入参兼容调用方，精简头不再发送。
  const headers = vendorCheckoutLeanHeaders({
    accessToken,
    accountId,
    fp: tlsFp,
    referer: checkoutReferer(entity, sessionId),
    oaiLanguage: 'zh-CN',
  });
  const maxAttempts = Math.max(1, Math.min(8, Number(attempts) || TAXES_SUBMIT_ATTEMPTS));
  let lastReason = '未知原因';
  let lastStatus = 0;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const r = await ctlsFetch(`${BASE}/api/v1/payments/checkout/taxes`, {
        method: 'POST',
        headers,
        ja3: tlsFp?.ja3,
        body: JSON.stringify(payload),
      }, proxy);
      const d = await r.json().catch(() => ({}));
      lastStatus = r.status;
      log(`[DEBUG] checkout/taxes status=${r.status} attempt=${attempt}/${maxAttempts} body=${JSON.stringify(payload).length}b resp=${JSON.stringify(d).slice(0, 150)}`);
      if (r.status >= 400) {
        const err = new Error(`checkout/taxes status=${r.status}`);
        err.code = `taxes_http_${r.status}`;
        err.status = r.status;
        err.body = d;
        throw err;
      }
      return { status: r.status, ok: true, body: d, billingCountry: addressCountry };
    } catch (e) {
      lastReason = e?.message || String(e);
      lastStatus = e?.status || lastStatus;
      if (attempt < maxAttempts) {
        log(`[taxes] 免税地址提交失败(${lastReason})，第 ${attempt}/${maxAttempts} 次后重试`);
        await sleepMs(400 + attempt * 600);
        continue;
      }
      const err = new Error(
        `免税地址连续 ${maxAttempts} 次提交失败(${lastReason})，继续扣款会按 ${addressCountry} 地区补交税费，已在提交卡信息前停止`,
      );
      err.code = e?.code?.startsWith?.('taxes_http_') ? e.code : 'taxes_failed';
      err.status = lastStatus || e?.status || 0;
      err.noProxyRetry = false; // 403/5xx 上层可换代理；业务 4xx 由调用方决定
      err.cause = e;
      throw err;
    }
  }
  // unreachable
  throw new Error('checkout/taxes failed');
}

/**
 * Vendor checkout/snapshot —— taxes 后、payment_pages/confirm 前。
 * 真抓包 req-522/req-800 (cs_live 204)：
 *   {"snapshot":{"billing_address":{"name":"...","address":{line1,city,country,postal_code,state}}}}
 * 失败默认不阻断主路径（与 taxes 一致）。
 */
export async function checkoutSnapshot({
  accessToken, sessionId, processorEntity = 'vendor_entity', planName = 'basic_plan',
  currency = 'PHP', billing = null, oaiDeviceId, oaiSessionId, accountId = null,
  proxy = null, tlsFp = null, log = () => {},
} = {}) {
  const entity = processorEntity || 'vendor_entity';
  const name = String(billing?.name || paymentBillingName(sessionId) || 'John Smith').trim();
  const addr = {
    line1: String(billing?.line1 || '').trim(),
    city: String(billing?.city || '').trim(),
    country: String(billing?.country || 'US').trim() || 'US',
    postal_code: String(billing?.postalCode || billing?.postal_code || '').trim(),
    state: String(billing?.state || '').trim(),
  };
  // 真抓包形态（req-522）：仅 snapshot.billing_address；无 session/plan 字段
  const payload = {
    snapshot: {
      billing_address: {
        name,
        address: addr,
      },
    },
  };
  const headers = paymentPlatformHeaders({
    accessToken,
    accountId,
    deviceId: oaiDeviceId,
    sessionId: oaiSessionId,
    fp: tlsFp,
    referer: checkoutReferer(entity, sessionId),
    extra: { targetPath: '/api/v1/payments/checkout/snapshot' },
  });
  const r = await ctlsFetch(`${BASE}/api/v1/payments/checkout/snapshot`, {
    method: 'POST',
    headers,
    ja3: tlsFp?.ja3,
    body: JSON.stringify(payload),
  }, proxy);
  // 204 无 body 视为成功
  let d = {};
  if (r.status !== 204) d = await r.json().catch(() => ({}));
  const ok = r.ok || r.status === 204;
  log(`[DEBUG] checkout/snapshot status=${r.status} body=${JSON.stringify(payload).length}b ok=${ok}`);
  return { status: r.status, ok, body: d };
}

/**
 * 对齐 Java PaymentPagesStep.doApprove 的 plan_type hint（vendor_plan_type_hint）。
 * plus / pro / prolite；其它一律 plus。
 */
export function approvePlanTypeHint(plan) {
  const p = String(plan || '').toLowerCase();
  if (p.includes('prolite') || p === 'pro_5x' || p === 'standard_plan' || p === 'prolite') {
    return 'prolite';
  }
  if (
    p === 'pro'
    || p === 'pro_20x'
    || p === 'premium_plan'
    || p === 'premium_planplan'
    || (p.includes('pro') && !p.includes('plus'))
  ) {
    return 'pro';
  }
  return 'plus';
}

/**
 * Vendor checkout/approve —— cs_live + manual_approval 路径。
 * 对齐 Java PaymentPagesStep.doApprove：
 *   req: {"checkout_session_id","processor_entity","plan_type"}
 *   resp: {"result":"approved"} | {"result":"blocked"}
 * oaic 内部会话不应乱调（易 500）；由 shouldCheckoutApprove 把关。
 */
export async function checkoutApprove({
  accessToken, sessionId, processorEntity = 'vendor_entity',
  planType = null, plan = null,
  oaiDeviceId, oaiSessionId, accountId = null, sentinelToken = null,
  proxy = null, tlsFp = null, log = () => {},
} = {}) {
  const entity = processorEntity || 'vendor_entity';
  const payload = {
    checkout_session_id: sessionId,
    processor_entity: entity,
    // Java: body.put("plan_type", ctx.getPlanTypeHint() != null ? … : "plus")
    plan_type: approvePlanTypeHint(planType || plan || 'plus'),
  };
  // 对齐 Java PaymentPagesStep.doApprove：精简头 + Referer=/（无指纹/telemetry）
  // sentinel 默认不带；仅调用方显式传入时附加。oaiDeviceId/oaiSessionId 保留入参兼容。
  const headers = vendorCheckoutLeanHeaders({
    accessToken,
    accountId,
    fp: tlsFp,
    referer: `${BASE}/`,
    accept: 'application/json',
    extra: sentinelToken ? { 'vendor-sentinel-token': sentinelToken } : {},
  });
  const r = await ctlsFetch(`${BASE}/api/v1/payments/checkout/approve`, {
    method: 'POST',
    headers,
    ja3: tlsFp?.ja3,
    body: JSON.stringify(payload),
    timeoutMs: 60000,
  }, proxy);
  const d = await r.json().catch(() => ({}));
  log(`[DEBUG] checkout/approve status=${r.status} has_sentinel=${!!sentinelToken} resp=${JSON.stringify(d).slice(0, 200)}`);
  // approve 被风控拦：真实响应是 {"result":"blocked"}（字段是 result，不是 status），
  // 也兼容 {"status":"blocked"} / 403。漏判会导致不 fail-fast、白跑 verify_checkout+换环境重试。
  const blockedSignal = String(d.result || d.status || '').toLowerCase() === 'blocked';
  if (blockedSignal || r.status === 403) {
    return { status: r.status, ok: false, body: d, blocked: true, approved: false };
  }
  // 真抓包成功：{"result":"approved"}
  const approved = String(d.result || '').toLowerCase() === 'approved'
    || String(d.status || '').toLowerCase() === 'approved'
    || d.approved === true;
  return {
    status: r.status,
    ok: r.ok && (approved || Object.keys(d).length === 0),
    body: d,
    blocked: false,
    approved,
  };
}

/** 是否应对本会话调用 checkout/approve（cs_live 真路径 / 显式要求） */
export function shouldCheckoutApprove(sessionId, checkoutBody = null, confirmBody = null, opts = {}) {
  if (opts.forceCheckoutApprove === true) return true;
  if (opts.skipCheckoutApprove === true) return false;
  const sid = String(sessionId || checkoutBody?.checkout_session_id || '').trim();
  // oaic 内部会话：浏览器抓包不走 approve；乱调易 500
  if (sid.startsWith('oaics_')) return false;
  if (sid.startsWith('cs_live_') || sid.startsWith('cs_test_')) return true;
  // 无会话 id 时：仅当 confirm/create 明确要求审批
  return needsCheckoutApprove(checkoutBody, confirmBody);
}

/** GET /api/v1/payments/checkout/{entity}/{sessionId} —— 成功页对账查询（幂等、不扣款） */
export async function fetchCheckoutSessionStatus({
  accessToken, sessionId, processorEntity = 'vendor_entity',
  oaiDeviceId, oaiSessionId, proxy = null, tlsFp = null, log = () => {},
} = {}) {
  const entity = processorEntity || 'vendor_entity';
  const statusPath = `/api/v1/payments/checkout/${entity}/${sessionId}`;
  const r = await ctlsFetch(`${BASE}${statusPath}`, {
    headers: upgradeRequestHeaders({
      fp: tlsFp, accessToken, deviceId: oaiDeviceId, sessionId: oaiSessionId,
    }, statusPath),
    ja3: tlsFp?.ja3,
    timeoutMs: 60000,
  }, proxy);
  const text = await r.text().catch(() => '');
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text.slice(0, 200) }; }
  log(`[payment] checkout status GET status=${r.status}`);
  return { status: r.status, ok: r.ok, body };
}

// Platform 侧确认结账 → 返回 payment_intent client_secret
export async function checkoutConfirm({
  accessToken, sessionId, confirmationTokenId, oaiDeviceId, oaiSessionId,
  sentinelToken, accountId = null, processorEntity = 'vendor_entity',
  proxy = null, tlsFp = null, log = () => {},
} = {}) {
  const payload = {
    checkout_session_id: sessionId,
    confirm_token: confirmationTokenId,
    selected_payment_method_type: 'card',
  };
  const sentinelHdr = sentinelToken ? { 'vendor-sentinel-token': sentinelToken } : {};
  const headers = paymentPlatformHeaders({
    accessToken,
    accountId,
    deviceId: oaiDeviceId,
    sessionId: oaiSessionId,
    fp: tlsFp,
    referer: checkoutReferer(processorEntity, sessionId),
    extra: {
      targetPath: '/api/v1/payments/checkout/confirm',
      ...sentinelHdr,
    },
  });
  const r = await ctlsFetch(`${BASE}/api/v1/payments/checkout/confirm`, {
    method: 'POST',
    headers,
    ja3: tlsFp?.ja3,
    body: JSON.stringify(payload),
  }, proxy);
  const d = await r.json().catch(() => ({}));
  log(`[DEBUG] checkout/confirm status=${r.status} resp=${JSON.stringify(d).slice(0, 200)}`);
  // 友方：detail 拒绝且无成功信号 → 不当成功
  const hasSuccess = !!(d.status || d.type || d.client_secret || d.payment_intent
    || d.payment_intent_client_secret);
  if ((r.status >= 400 || (d.detail && !hasSuccess))) {
    return { status: r.status, ok: false, clientSecret: null, body: d };
  }
  if (String(d.status || '') === 'blocked') {
    return { status: r.status, ok: false, clientSecret: null, body: d };
  }
  const cs = d.payment_intent_client_secret || d.client_secret || d.payment_intent?.client_secret
    || d.intent?.client_secret || d.stripe_payment_intent_client_secret || null;
  return {
    status: r.status,
    ok: r.ok && !!cs,
    clientSecret: cs,
    body: d,
    needsApprove: needsCheckoutApprove(null, d),
  };
}
export async function notifyCheckoutSuccess({ account, accessToken, sessionId, processorEntity, plan, paymentIntent, clientSecret, tlsFp, oaiDeviceId, oaiSessionId, proxy = null, log = () => {} }) {
  const params = new URLSearchParams({
    stripe_session_id: sessionId,
    processor_entity: processorEntity || 'vendor_entity',
    plan_type: normalizePlan(plan),
    payment_intent: paymentIntent,
    payment_intent_client_secret: clientSecret,
    redirect_status: 'succeeded',
    refresh_account: 'true',
  });
  // 仅 AT 模式：不带 session Cookie（避免空/伪造 Cookie）；有 session 时保持 Cookie+Bearer 兼容
  const sessionTok = String(account?.sessionToken || '').trim();
  // Referer 用完整 verify 深链（对齐 Java PaymentPagesStep.oaiHeaders），Origin 不可省
  const verifyHeaders = {
    'Authorization': `Bearer ${accessToken}`,
    'Origin': BASE,
    'Referer': `${BASE}/checkout/verify?${params}`,
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'navigate', 'sec-fetch-dest': 'document',
  };
  if (sessionTok) verifyHeaders.Cookie = buildSessionCookie(sessionTok);
  const verify = await ctlsFetch(`${BASE}/checkout/verify?${params}`, {
    headers: applyFp(browserHeaders(verifyHeaders), tlsFp),
    ja3: tlsFp?.ja3, timeoutMs: 60000,
  }, proxy);
  log(`[payment] checkout/verify callback status=${verify.status}`);
  // 顺手收割 <html data-build/data-seq>，供下一单的 x-vendor-client-version 使用（见 x-vendor-deploy.js）
  if (verify.status === 200) {
    try {
      noteOaiDeployHtml(await verify.text(), log);
    } catch (e) {
      log(`[oai] deploy 收割跳过: ${e.message}`);
    }
  }

  // 浏览器成功页会查询此接口，Vendor 以它返回的结账状态完成内部对账。它是幂等 GET，
  // 即使回调页面已经执行过也可安全重放，不会再次向 Stripe 扣款。
  const status = await fetchCheckoutSessionStatus({
    accessToken, sessionId, processorEntity, oaiDeviceId, oaiSessionId, proxy, tlsFp, log,
  });
  return { verifyStatus: verify.status, checkoutStatus: status.status, checkoutStatusBody: status.body };
}

/**
 * Stripe 已 succeeded/processing 后的收尾。
 * 默认对齐友方：关键路径尽快返回（deferReconciliation=true / waitForSubscription 非 true），
 * 套餐轮询与 notify 不挡「支付成功」；retryPayment 恒 false，禁止双扣。
 * 传 waitForSubscription:true → 同步长 poll（对齐 Java PollStep full ~10 轮）。
 */
export async function finishSuccessfulCheckout({
  account, accessToken, sessionId, processorEntity, plan, paymentIntent, clientSecret,
  amount, currency, billing, knownInvoiceIds, submittedAt, tlsFp, oaiDeviceId, oaiSessionId,
  proxy = null, log = () => {}, paymentOpts = {},
}) {
  const targetPlan = normalizePlan(plan);
  const evidence = {
    confirmed: true, source: 'stripe_payment_intent', confirmedAt: Date.now(),
    plan: targetPlan, paymentIntent, checkoutSessionId: sessionId,
    amount, currency,
  };
  const waitForSubscription = paymentOpts.waitForSubscription === true;
  const deferReconciliation = !waitForSubscription && paymentOpts.deferReconciliation !== false;

  await emitPaymentState(paymentOpts, {
    ok: true, completed: false, stage: 'paid_pending_subscription',
    paymentStatus: 'succeeded', paymentConfirmed: true,
    subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
    finalPlan: normalizePlan(account.plan), amount, currency, billing,
    paymentIntent, checkoutSessionId: sessionId, paymentEvidence: evidence,
  });

  // 支付后 Vendor 会轮换凭证且旧票立即作废。每次换票都回调调用方落库，
  // 否则库里留的是已作废的票，后续对账/拉账单必然 401（对齐 Java 把新票写回 order）。
  const persistRotated = async () => {
    try {
      await paymentOpts.onCredentialRotated?.(account);
    } catch (e) {
      log(`[session-keep] 回写失败(不影响支付): ${e?.message || e}`);
    }
  };
  // 对齐 Java refreshOrderSessionWithRetry：换票最多 4 次，不是 1 次
  const refreshAttempts = Math.max(1, Number(process.env.PAYMENT_SESSION_REFRESH_ATTEMPTS) || 4);

  const runNotifyAndReconcile = async () => {
    let liveAccessToken = accessToken;
    if (paymentOpts.skipSessionRefresh !== true && account?.sessionToken) {
      const refreshed = await refreshAccountSession(account, {
        proxy,
        fp: tlsFp,
        log,
        reason: 'post_payment',
        attempts: refreshAttempts,
      });
      if (refreshed.accessToken) liveAccessToken = refreshed.accessToken;
      logPaymentDiag(log, 'session_refresh', {
        ok: !!refreshed.ok,
        rotated: !!refreshed.rotated,
        skipped: !!refreshed.skipped,
        reason: refreshed.reason || 'post_payment',
      });
      if (refreshed.rotated) await persistRotated();
    }

    // cs_live 真路径：payment_pages/confirm 后 approve；oaics 默认不调。
    // 已扣款：approve 失败只记日志，禁止当作可重扣。
    if (paymentOpts.skipCheckoutApprove !== true) {
      const shouldApprove = shouldCheckoutApprove(
        sessionId,
        paymentOpts.checkoutCreateBody || null,
        paymentOpts.checkoutConfirmBody || null,
        paymentOpts,
      ) || paymentOpts.checkoutApproveOnSuccess === true;
      if (shouldApprove) {
        try {
          let approveSentinel = paymentOpts.approveSentinelToken || null;
          if (!approveSentinel && paymentOpts.useApproveSentinel !== false && paymentOpts.tokenProvider) {
            try {
              approveSentinel = await paymentOpts.tokenProvider.sentinel(
                oaiDeviceId, 'checkout_session_approval',
              );
            } catch (e) {
              log(`[sentinel] checkout/approve 令牌失败: ${e.message}`);
            }
          }
          const appr = await checkoutApprove({
            accessToken: liveAccessToken, sessionId, processorEntity,
            planType: plan,
            oaiDeviceId, oaiSessionId,
            accountId: paymentOpts.platformAccountId || account?.accountId || null,
            sentinelToken: approveSentinel, proxy, tlsFp, log,
          });
          logPaymentDiag(log, 'approve', {
            status: appr.status, ok: appr.ok, blocked: !!appr.blocked,
            has_sentinel: !!approveSentinel,
          });
        } catch (e) {
          log(`[payment] checkout/approve 跳过(继续对账): ${e.message}`);
        }
      }
    }

    let callback = null;
    try {
      callback = await notifyCheckoutSuccess({
        account, accessToken: liveAccessToken, sessionId, processorEntity, plan, paymentIntent, clientSecret,
        tlsFp, oaiDeviceId, oaiSessionId, proxy, log,
      });
    } catch (e) {
      // Stripe succeeded 已经是不可撤销的支付事实。回调/查询失败只能进入待对账，绝不能回到扣款步骤。
      log(`[payment] 支付已成功，但 Platform 回调失败: ${e.message};已禁止重试扣款`);
    }

    let reconciled;
    if (waitForSubscription) {
      // Java PollStep full：accounts/check 长轮询；401 时 poll 内只刷一次
      const polled = await pollSubscriptionActivation(account, targetPlan, {
        mode: 'full', proxy, log, allowAuthRefresh: paymentOpts.skipSessionRefresh !== true,
      });
      reconciled = {
        activated: polled.activated,
        finalPlan: polled.finalPlan,
        paidInvoice: null,
        subscriptionChecked: polled.subscriptionChecked,
        invoicesChecked: false,
        lastError: polled.lastError || null,
      };
      if (!polled.activated) {
        // 补查账单证据（不延长 forceRefresh）
        const inv = await reconcilePaymentOutcome(account, targetPlan, {
          knownInvoiceIds, submittedAt, attempts: 1, delayMs: 0,
        }, log, proxy);
        if (inv.activated) reconciled = inv;
        else if (inv.paidInvoice) {
          reconciled = {
            ...reconciled,
            paidInvoice: inv.paidInvoice,
            invoicesChecked: true,
            finalPlan: inv.finalPlan || reconciled.finalPlan,
          };
        }
      }
    } else {
      // 后置轻量：1 轮；仅鉴权失败才 refresh + 短 poll（对齐 pollWithRecovery）
      reconciled = await reconcilePaymentOutcome(account, targetPlan, {
        knownInvoiceIds, submittedAt, attempts: 1, delayMs: 800,
      }, log, proxy);
      if (!reconciled.activated && account?.sessionToken && paymentOpts.skipSessionRefresh !== true) {
        const errText = String(reconciled.lastError || '');
        const maybeAuthFail = !reconciled.subscriptionChecked
          || /401|403|token|unauthorized|鉴权|access_token/i.test(errText);
        if (maybeAuthFail) {
          const r401 = await refreshAccountSession(account, {
            proxy, fp: tlsFp, log, reason: 'poll_401', attempts: refreshAttempts,
          });
          if (r401?.rotated) await persistRotated();
          await new Promise((r) => setTimeout(r, 400));
          // 对齐 Java：poll 内遇 401 仍可换票，写死 false 会让轮询空转到超时
          const polled = await pollSubscriptionActivation(account, targetPlan, {
            mode: 'fast', proxy, log, allowAuthRefresh: true,
          });
          if (polled.activated) {
            reconciled = {
              activated: true,
              finalPlan: polled.finalPlan,
              paidInvoice: reconciled.paidInvoice || null,
              subscriptionChecked: true,
              invoicesChecked: reconciled.invoicesChecked,
            };
          } else {
            reconciled = await reconcilePaymentOutcome(account, targetPlan, {
              knownInvoiceIds, submittedAt, attempts: 1, delayMs: 0,
            }, log, proxy);
          }
        }
      }
    }

    // 激活后再刷一次：cancel 路径用新 AT（Java：订阅激活后 refresh）
    if (reconciled.activated && account?.sessionToken && paymentOpts.skipSessionRefresh !== true) {
      const rAct = await refreshAccountSession(account, {
        proxy, fp: tlsFp, log, reason: 'post_activation', attempts: refreshAttempts,
      });
      if (rAct?.rotated) await persistRotated();
    }

    if (reconciled.paidInvoice) evidence.invoiceId = reconciled.paidInvoice.id || null;
    return { callback, reconciled };
  };

  const platformAccountId = paymentOpts.platformAccountId || account?.accountId || account?.platformAccountId || null;
  if (platformAccountId) {
    evidence.platformAccountId = platformAccountId;
    account.platformAccountId = platformAccountId;
    account.accountId = account.accountId || platformAccountId;
  }

  if (deferReconciliation) {
    // 对齐 Java：payment_status=paid + 真实 PI 即判成功，套餐核验后置。
    // 否则订单要多等一轮 refresh/verify/reconcile（实测约 12s）才收口。
    const completeOnPaid = paymentOpts.completeOnStripePaid === true
      && String(paymentIntent || '').startsWith('pi_')
      && !/^(0|false|no|off)$/i.test(String(process.env.PAYMENT_COMPLETE_ON_STRIPE_PAID ?? '1').trim());
    const early = completeOnPaid
      ? {
        ok: true, completed: true, stage: 'done',
        paymentStatus: 'succeeded', paymentConfirmed: true,
        retryPayment: false, pendingPlan: targetPlan, finalPlan: targetPlan,
        amount, currency, billing,
        paymentIntent, checkoutSessionId: sessionId, paymentEvidence: evidence,
        platformAccountId: platformAccountId || undefined,
        deferredReconciliation: true,
        message: 'Stripe 已确认扣款（payment_status=paid）；套餐核验后置。',
      }
      : {
        ok: true, completed: false, stage: 'paid_pending_subscription',
        paymentStatus: 'succeeded', paymentConfirmed: true,
        subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
        finalPlan: normalizePlan(account.plan), amount, currency, billing,
        paymentIntent, checkoutSessionId: sessionId, paymentEvidence: evidence,
        platformAccountId: platformAccountId || undefined,
        deferredReconciliation: true,
        message: 'Stripe 扣款已成功；套餐同步后置，禁止再次扣款。',
      };
    await emitPaymentState(paymentOpts, early);
    // 后置：不 await；激活后补一次 done 状态（仍 retryPayment=false）
    Promise.resolve().then(async () => {
      try {
        const { callback, reconciled } = await runNotifyAndReconcile();
        if (reconciled.activated) {
          await emitPaymentState(paymentOpts, {
            ok: true, completed: true, stage: 'done', paymentStatus: 'succeeded',
            paymentConfirmed: true, retryPayment: false, finalPlan: reconciled.finalPlan,
            amount, currency, billing, paymentIntent, checkoutSessionId: sessionId,
            paymentEvidence: evidence, callback, deferredReconciliation: true,
            platformAccountId: platformAccountId || undefined,
          });
        } else if (reconciled.paidInvoice) {
          await emitPaymentState(paymentOpts, {
            ...early, paymentEvidence: evidence, callback,
            message: '已查到成功账单，套餐待同步；禁止再次扣款。',
          });
        }
      } catch (e) {
        log(`[payment] 后置对账异常(已付不重扣): ${e.message}`);
      }
    }).catch(() => {});
    return early;
  }

  const { callback, reconciled } = await runNotifyAndReconcile();
  if (reconciled.activated) {
    const result = {
      ok: true, completed: true, stage: 'done', paymentStatus: 'succeeded',
      paymentConfirmed: true, retryPayment: false, finalPlan: reconciled.finalPlan,
      amount, currency, billing, paymentIntent, checkoutSessionId: sessionId,
      paymentEvidence: evidence, callback,
      platformAccountId: platformAccountId || undefined,
    };
    await emitPaymentState(paymentOpts, result);
    return result;
  }

  const result = {
    ok: true, completed: false, stage: 'paid_pending_subscription',
    paymentStatus: 'succeeded', paymentConfirmed: true,
    subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
    finalPlan: reconciled.finalPlan || 'free', amount, currency, billing,
    paymentIntent, checkoutSessionId: sessionId, paymentEvidence: evidence, callback,
    platformAccountId: platformAccountId || undefined,
    message: 'Stripe 和支付回调已成功，但 Platform 套餐尚未同步；付款已记录，禁止再次扣款。',
  };
  await emitPaymentState(paymentOpts, result);
  return result;
}

/** 拒卡且 PI 回到 requires_payment_method 时可复用 checkout/elements（对齐友方 canReuseCheckoutSession） */
export function canReuseCheckoutSession(ctx, result) {
  if (!ctx || !result) return false;
  const code = String(result.code || result.failureClass?.code || '');
  const msg = String(result.message || result.failure?.message || '');
  const piStatus = String(result.piStatus || result.failure?.piStatus || '');
  const declined = code === 'card_declined' || /card_declined|generic_decline/i.test(msg);
  const rpm = piStatus === 'requires_payment_method' || /pi_status=requires_payment_method/i.test(msg);
  const present = (v) => v != null && String(v).trim() !== '';
  return declined && rpm
    && present(ctx.checkoutSessionId)
    && present(ctx.publishableKey)
    && present(ctx.elementsSessionId)
    && present(ctx.elementsConfigId)
    && present(ctx.paymentIntentId)
    && present(ctx.paymentIntentClientSecret);
}

export async function finishAmbiguousCheckout({
  account, plan, paymentIntent, sessionId, amount, currency, billing,
  knownInvoiceIds, submittedAt, proxy = null, log = () => {}, error = null, paymentOpts = {},
}) {
  const targetPlan = normalizePlan(plan);
  await emitPaymentState(paymentOpts, {
    ok: true, completed: false, stage: 'submitted_pending_reconciliation',
    subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
    finalPlan: normalizePlan(account.plan), amount, currency, billing,
    paymentIntent, checkoutSessionId: sessionId,
    paymentEvidence: {
      confirmed: false, source: 'stripe_submission', submittedAt,
      plan: targetPlan, paymentIntent, checkoutSessionId: sessionId, amount, currency,
    },
  });
  const reconciled = await reconcilePaymentOutcome(account, targetPlan, {
    knownInvoiceIds, submittedAt, attempts: 3, delayMs: 3000,
  }, log, proxy);
  const confirmed = reconciled.activated || !!reconciled.paidInvoice;
  const evidence = {
    confirmed, source: reconciled.paidInvoice ? 'paid_invoice' : (reconciled.activated ? 'subscription' : 'stripe_submission'),
    submittedAt, confirmedAt: confirmed ? Date.now() : null,
    plan: targetPlan, paymentIntent, checkoutSessionId: sessionId,
    invoiceId: reconciled.paidInvoice?.id || null, amount, currency,
  };

  if (reconciled.activated) {
    const result = {
      ok: true, completed: true, stage: 'done', paymentStatus: 'succeeded',
      paymentConfirmed: true, retryPayment: false, finalPlan: reconciled.finalPlan,
      amount, currency, billing, paymentIntent, checkoutSessionId: sessionId,
      paymentEvidence: evidence,
    };
    await emitPaymentState(paymentOpts, result);
    return result;
  }

  const result = {
    ok: true, completed: false,
    stage: confirmed ? 'paid_pending_subscription' : 'submitted_pending_reconciliation',
    paymentConfirmed: confirmed, subscriptionPending: true, retryPayment: false,
    pendingPlan: targetPlan, finalPlan: reconciled.finalPlan || 'free',
    amount, currency, billing, paymentIntent, checkoutSessionId: sessionId,
    paymentEvidence: evidence, submissionError: error?.message || null,
    message: confirmed
      ? '已查到成功账单，但套餐尚未同步；禁止再次扣款。'
      : '最终扣款请求已提交但响应不确定；必须先对账，禁止再次扣款。',
  };
  await emitPaymentState(paymentOpts, result);
  return result;
}

export async function finishDeclinedCheckout(paymentOpts, result) {
  await emitPaymentState(paymentOpts, result);
  return result;
}

function attachFpMeta(result, opts = {}) {
  if (!result || typeof result !== 'object') return result;
  if (!opts.browserProfileId && !opts.browserProfileMeta) return result;
  return {
    ...result,
    browserProfileId: opts.browserProfileId || result.browserProfileId || '',
    browserProfileMeta: opts.browserProfileMeta || result.browserProfileMeta || null,
  };
}

async function finalizeFpRun(opts, result, error, log = () => {}, ctx = {}) {
  const snap = opts?.browserProfileMeta || null;
  if (!snap?.profileId) return;
  // 抛错路径：把画像 id 挂到 error 上，便于 direct-payments 写入 job
  if (error && typeof error === 'object') {
    error.browserProfileId = snap.profileId;
    error.browserProfileMeta = snap;
  }
  const outcome = outcomeFromPaymentResult(result, error);
  const record = {
    jobId: opts.jobId || ctx.jobId || 0,
    externalOrderId: opts.externalOrderId || '',
    profileId: snap.profileId,
    profile: snap,
    proxyId: opts.paymentProxyId || ctx.proxyId || 0,
    proxyExitIp: opts.paymentProxyExitIp || ctx.proxyExitIp || '',
    plan: opts.plan || result?.pendingPlan || '',
    ...outcome,
    midsSrc: opts.midsSrc || '',
    dryRun: opts.dryRun === true,
  };
  logPaymentDiag(log, 'fp_outcome', {
    id: record.profileId,
    outcome: record.outcome,
    code: record.code,
    has_pi: record.hasPi,
  });
  await appendPaymentFpRun(record);
}

// 编排: 菲律宾 PHP 真实充值
/** 结果或异常是否为 Vendor 账单币种锁（未扣款，可走 payment_pages 绕过） */
export function isCurrencyMismatchOutcome(resultOrError) {
  if (!resultOrError) return false;
  const code = String(resultOrError.code || resultOrError.failureClass?.code || '').toLowerCase();
  if (code === 'currency_mismatch') return true;
  return isCheckoutCurrencyIncompatible(resultOrError.message || resultOrError)
    || isCheckoutCurrencyIncompatible(resultOrError);
}

/**
 * 是否启用账单锁绕过（对齐 Java：confirm 币种失败 → 立即 payment_pages）。
 * 默认开；PAYMENT_BILLING_LOCK_BYPASS=0/false 可关。
 */
export function isBillingLockBypassEnabled(opts = {}) {
  if (opts.billingLockBypass === false) return false;
  if (opts.billingLockBypass === true) return true;
  const raw = String(process.env.PAYMENT_BILLING_LOCK_BYPASS ?? '1').trim();
  return !/^(0|false|no|off)$/i.test(raw);
}

/**
 * 本次是否走 payment_pages 长链（对齐 Java force_payment_pages / csLivePayment）。
 * opts.forceHostedCheckout=true 可显式关掉（测试/探针用）。
 */
export function isForceCustomCheckout(opts = {}) {
  if (opts.forceHostedCheckout === true) return false;
  if (opts.csLivePayment === true) return true;
  return /^(1|true|yes|on)$/i.test(String(process.env.PAYMENT_CS_LIVE_FORCE_CUSTOM || '').trim());
}

export async function rechargePhp(account, card, opts = {}, log = () => {}, proxy = null) {
  const run = async () => {
    // 同 checkout 换环境外层循环（variant 0..N-1）；cs_live 内部自管 env，此处不再套
    if (opts._skipEnvLoop) {
      try {
        const result = await rechargePhpInner(account, card, opts, log, proxy);
        await finalizeFpRun(opts, result, null, log, {
          proxyId: Number(proxy?.id) || 0,
          proxyExitIp: String(proxy?.exitIp || ''),
        });
        return attachFpMeta(result, opts);
      } catch (e) {
        await finalizeFpRun(opts, null, e, log, {
          proxyId: Number(proxy?.id) || 0,
          proxyExitIp: String(proxy?.exitIp || ''),
        });
        throw e;
      }
    }
    const maxEnv = externalCheckoutEnvRetries(opts);
    let reuse = opts.reuseCheckoutSession || null;
    let lastResult = null;
    for (let v = 0; v < maxEnv; v++) {
      const attemptOpts = {
        ...opts,
        _skipEnvLoop: true,
        browserEnvironmentVariant: v,
        reuseCheckoutSession: v === 0 ? (opts.reuseCheckoutSession || null) : reuse,
      };
      try {
        const result = await rechargePhpInner(account, card, attemptOpts, log, proxy);
        if (attemptOpts.__capturedCheckoutSession) reuse = attemptOpts.__capturedCheckoutSession;
        await finalizeFpRun(attemptOpts, result, null, log, {
          proxyId: Number(proxy?.id) || 0,
          proxyExitIp: String(proxy?.exitIp || ''),
        });
        lastResult = attachFpMeta(result, attemptOpts);
        // cs_live 路径内部已做过 env 轮换
        if (lastResult?.path === 'cs_live_payment_pages' || String(lastResult?.code || '').startsWith('cs_live_')) {
          return lastResult;
        }
        if (!isSafeToRetryWithNewEnvironment(lastResult) || v >= maxEnv - 1) return lastResult;
        log(`[payment] 同会话换环境 env=${v}→${v + 1} stage=${lastResult.stage || '-'} code=${lastResult.code || '-'}`);
      } catch (e) {
        if (attemptOpts.__capturedCheckoutSession) reuse = attemptOpts.__capturedCheckoutSession;
        await finalizeFpRun(attemptOpts, null, e, log, {
          proxyId: Number(proxy?.id) || 0,
          proxyExitIp: String(proxy?.exitIp || ''),
        });
        if (!isSafeToRetryWithNewEnvironment(null, e) || v >= maxEnv - 1) throw e;
        log(`[payment] 同会话换环境 env=${v}→${v + 1} err=${e.code || e.message}`);
      }
    }
    return lastResult;
  };

  // 对齐 Java OrderProcessingService：oaics 主路径撞币种锁 → 立即 cs_live payment_pages 绕过一次。
  // 已在长链（FORCE_CUSTOM / csLivePayment）/ 已绕过 / 无裸卡 / 显式关闭时不再套。
  // 不回退短链（Java force_payment_pages 失败即失败）。
  const shouldBypassWrap = isBillingLockBypassEnabled(opts)
    && opts.csLivePayment !== true
    && !isForceCustomCheckout(opts)
    && opts._billingLockBypassAttempted !== true
    && !!card?.number;

  const gatedRun = async () => {
    if (opts.skipProxyGate) return run();
    return withPaymentProxyGate(proxy, run, { log });
  };

  if (!shouldBypassWrap) return gatedRun();

  let shortResult = null;
  try {
    shortResult = await gatedRun();
  } catch (e) {
    if (!isCurrencyMismatchOutcome(e)) throw e;
    log(`[账单锁] currency_mismatch → cs_live payment_pages 绕过（对齐 Java）: ${String(e.message || e.code || '').slice(0, 120)}`);
    const bypass = await rechargePhp(account, card, {
      ...opts,
      csLivePayment: true,
      _billingLockBypassAttempted: true,
      _skipEnvLoop: false,
      reuseCheckoutSession: null,
    }, log, proxy);
    if (bypass && (bypass.paymentConfirmed || bypass.completed || bypass.ok)) {
      return { ...bypass, billingLockBypass: true, priorCode: 'currency_mismatch' };
    }
    return withPaymentFailureClass({
      ...(bypass && typeof bypass === 'object' ? bypass : {}),
      ok: false,
      completed: false,
      stage: bypass?.stage || 'failed_precharge',
      code: bypass?.code || 'currency_mismatch',
      retryPayment: false,
      noProxyRetry: true,
      billingLockBypass: true,
      message: `结账币种与账号既有账单账户不一致（payment_pages 绕过亦失败: ${
        String(bypass?.message || e.message || 'currency_mismatch').slice(0, 180)
      }）`,
    });
  }

  if (!isCurrencyMismatchOutcome(shortResult) || shortResult?.paymentConfirmed) return shortResult;
  log(`[账单锁] currency_mismatch → cs_live payment_pages 绕过（对齐 Java）: ${String(shortResult.message || shortResult.code || '').slice(0, 120)}`);
  const bypass = await rechargePhp(account, card, {
    ...opts,
    csLivePayment: true,
    _billingLockBypassAttempted: true,
    _skipEnvLoop: false,
    reuseCheckoutSession: null,
  }, log, proxy);
  if (bypass && (bypass.paymentConfirmed || bypass.completed || bypass.ok)) {
    return { ...bypass, billingLockBypass: true, priorCode: 'currency_mismatch' };
  }
  return withPaymentFailureClass({
    ...(bypass && typeof bypass === 'object' ? bypass : {}),
    ok: false,
    completed: false,
    stage: bypass?.stage || shortResult.stage || 'failed_precharge',
    code: bypass?.code || 'currency_mismatch',
    retryPayment: false,
    noProxyRetry: true,
    billingLockBypass: true,
    message: `结账币种与账号既有账单账户不一致（payment_pages 绕过亦失败: ${
      String(bypass?.message || shortResult.message || 'currency_mismatch').slice(0, 180)
    }）`,
  });
}

async function rechargePhpInner(account, card, opts = {}, log = () => {}, proxy = null) {
  // 子步骤计时(墙钟仅用于时长测量;不记任何凭据/卡号)。用于验证提速与定位瓶颈。
  const _t0 = Date.now(); let _tPrev = _t0;
  const mark = (s) => { const n = Date.now(); log(`[timing] ${s} +${n - _tPrev}ms total=${n - _t0}ms`); _tPrev = n; setProtocolPhase(s); };
  // 坏号池：近期 cs_live/欠费/试用 直接换号，不进支付、不换 IP
  if (!opts.skipCheckoutGuard) {
    assertCheckoutAccountAllowed(account, log);
  }
  // 同 checkout 换环境：variant 0..N-1（对齐 Java BrowserFingerprint + prepareExternalCheckoutRetry）
  const envVariant = Math.max(0, Math.floor(Number(opts.browserEnvironmentVariant ?? opts.environmentVariant) || 0));
  // 支付强制 Win 画像 + 多画像实验；variant 偏移画像池
  const tlsFp = paymentAccountFp(account, {
    browserProfileId: opts.browserProfileId || account?.browserProfileId || '',
    fpSelectMode: opts.fpSelectMode,
    environmentVariant: envVariant,
  });
  const envIds = paymentEnvironmentIds(account, envVariant);
  const fpSnap = fingerprintRunSnapshot(tlsFp);
  opts.browserProfileId = fpSnap.profileId;
  opts.browserProfileMeta = fpSnap;
  opts.browserEnvironmentVariant = envVariant;
  logPaymentDiag(log, 'fp_profile', {
    id: fpSnap.profileId,
    mode: fpSnap.selectMode,
    chrome: fpSnap.chromeFull,
    plat: fpSnap.platformVersion,
    lang: fpSnap.oaiLanguage,
    env: envVariant,
    coherent: fpSnap.coherent ? 'yes' : 'no',
  });
  const plan = apiPlanName(opts.plan || PLAN.PLUS);
  const targetPlan = normalizePlan(plan);
  const { config: paymentConfig, pricing } = await resolvePaymentPricing(plan, opts);
  opts = { ...opts, paymentConfig };
  const region = normalizePaymentRegion(opts.region?.country || opts.country, opts.region?.currency || opts.currency);
  const currency = region.currency;
  // 一号稳定 device/session；variant 时换 env 身份（对齐 Java deviceId(account, variant)）
  const idSeed = envIds.seed;
  const oaiDeviceId = opts.oaiDeviceId || envIds.deviceId;
  const oaiSessionId = opts.oaiSessionId || envIds.sessionId;

  // 上一次已拿到 Stripe 成功/成功账单/结果不确定时,绝不能因 Platform 订阅缓存仍显示 free/plus 而重扣。
  // 纯本地判断,放最前面短路:已付待同步则不查任何网络直接返回。
  if (!opts.dryRun && blocksPaymentRetry(account, targetPlan)) {
    log(`[payment] ${targetPlan} 已有付款凭证且套餐待同步，阻止重复扣款`);
    return withPaymentFailureClass({
      ok: true, completed: false, skipped: true, stage: 'paid_pending_subscription',
      paymentConfirmed: !!account.lastPaymentConfirmedAt,
      subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
      finalPlan: normalizePlan(account.plan),
      paymentEvidence: account.lastPaymentConfirmedAt ? {
        confirmed: true, source: account.lastPaymentSource || 'stored_payment_evidence',
        confirmedAt: account.lastPaymentConfirmedAt, plan: targetPlan,
        paymentIntent: account.lastPaymentIntent || null,
        checkoutSessionId: account.lastCheckoutSessionId || null,
        invoiceId: account.lastInvoiceId || null,
        amount: account.lastPaymentAmount ?? null, currency: account.lastPaymentCurrency || null,
      } : null,
      message: '检测到已付款但套餐待同步，已禁止再次扣款。',
    });
  }

  // 0) 一次账号上下文(accessToken + /accounts/check),报价/套餐/账单三路并行、复用同一 token,
  //    避免各自重换 token。幂等防重复扣款:套餐或近期成功账单任一显示已付/已订阅都停止扣款。
  // payment_pages 长链：accounts/check 鉴权失败硬停（对齐 Java expired 硬失败，勿吞掉后继续 checkout）。
  const forceCustomEarly = isForceCustomCheckout(opts);
  const preCtx = await resolveAccountContext(account, proxy).catch((e) => {
    if (forceCustomEarly && e?.noProxyRetry) throw e;
    return null;
  });
  const [quoteRes, curRes, beforeInvRes] = await Promise.allSettled([
    getCheckoutPricing(account, plan, region, log, proxy, tlsFp, preCtx),
    querySubscription(account, log, proxy, preCtx),
    opts.dryRun ? Promise.resolve({ invoices: [] }) : queryInvoices(account, () => {}, proxy, preCtx),
  ]);
  if (quoteRes.status !== 'fulfilled') throw quoteRes.reason;
  const liveQuote = quoteRes.value;
  let amount = liveQuote.amountMinor;
  if (region.country === 'PH' && !amountWithinRange(amount, pricing)) {
    const error = new Error(`实时价格 ${amount} ${currency} 超出管理员允许范围，未提交扣款`);
    error.code = 'checkout_quote_out_of_range';
    throw error;
  }
  await emitPaymentState(opts, {
    ok: true, completed: false, stage: 'pricing_checked', retryPayment: true,
    pendingPlan: targetPlan, amount, currency,
  });
  if (curRes.status === 'fulfilled') {
    const cur = curRes.value;
    const currentPlan = normalizePlan(cur.plan_type);
    const targetSatisfied = planMatches(currentPlan, targetPlan)
      || currentPlan === 'pro'
      || (targetPlan === 'plus' && currentPlan === 'prolite');
    if (targetSatisfied) {
      log(`已是 ${currentPlan} 会员，目标 ${targetPlan} 已满足 → 跳过开通(幂等·未扣款)`);
      return { ok: true, skipped: true, completed: true, stage: 'already_subscribed', plan_type: cur.plan_type, finalPlan: cur.plan_type, accountId: cur.accountId };
    }
    if (currentPlan !== 'free') {
      return withPaymentFailureClass({
        ok: false, completed: false, stage: 'failed_precharge', retryPayment: true,
        code: 'plan_transition_unsupported',
        message: `当前套餐 ${currentPlan} 不能通过直接结账切换为 ${targetPlan}，未提交扣款`,
      });
    }
    log(`当前套餐 ${cur.plan_type || 'free'} → 检查近期账单`);
  } else {
    log(`[WARN] 套餐预检失败(${String(curRes.reason?.message).slice(0, 50)}),继续用账单做防重检查`);
  }

  const beforeInvoices = beforeInvRes.status === 'fulfilled' ? beforeInvRes.value : { invoices: [] };
  const knownInvoiceIds = (beforeInvoices.invoices || []).map((invoice) => invoice.id).filter(Boolean);
  const recentPaidInvoice = findNewPaidInvoice(beforeInvoices.invoices, [], Date.now() - 24 * 60 * 60 * 1000);
  const recentAmount = Number(recentPaidInvoice?.amount_paid ?? recentPaidInvoice?.amount ?? 0);
  const amountMatches = !recentAmount || Math.abs(recentAmount - amount) <= Math.max(2, amount * 0.02);
  if (!opts.dryRun && recentPaidInvoice && amountMatches) {
    log(`[payment] 套餐未同步但检测到近期成功账单 ${recentPaidInvoice.id || '(无ID)'}，阻止重复扣款`);
    return withPaymentFailureClass({
      ok: true, completed: false, skipped: true, stage: 'paid_pending_subscription',
      paymentConfirmed: true, subscriptionPending: true, retryPayment: false,
      pendingPlan: targetPlan, finalPlan: normalizePlan(account.plan), amount, currency,
      paymentEvidence: {
        confirmed: true, source: 'paid_invoice', confirmedAt: Date.now(), plan: targetPlan,
        invoiceId: recentPaidInvoice.id || null, amount: recentAmount || amount, currency: recentPaidInvoice.currency || currency,
      },
      message: '检测到近期成功账单但套餐仍未同步，已禁止再次扣款。',
    });
  }

  // 确实要开通(未跳过):必须裸卡号生成 Stripe token。
  mark('preflight');
  if (!card?.number) throw new Error('开 Plus 需提供卡片(裸卡号);仅"已开 Plus 升 Pro"可省略卡、走原绑定卡');
  // 友方 CTokenStep：号/月/年/CVV 残缺直接失败，避免白跑 checkout
  if (!card.cvv || card.expMonth == null || card.expYear == null) {
    const err = new Error('Card details incomplete: number/exp_month/exp_year/cvc missing');
    err.code = 'card_incomplete';
    throw err;
  }

  const paymentStartedAt = Date.now();

  // 友方默认不求解 hCaptcha（CToken 有 token 才带）；Playwright 解验证码是 ACC 最慢瓶颈。
  // 默认 autoHcaptcha=false；显式 true 或传入 hcaptchaToken 才启用。
  // token-only PI 不再需要 payment sitekey 令牌②；仅 legacy 二次交卡时再取。
  const autoHcaptcha = opts.autoHcaptcha === true;
  const resubmitCardOnPi = opts.resubmitCardOnPi === true;
  const _hcaptchaPromise1 = (opts.hcaptchaToken || autoHcaptcha)
    ? (opts.hcaptchaToken
      ? Promise.resolve(opts.hcaptchaToken)
      : getHcaptchaToken({ sitekey: SITEKEY_CTOKEN, log }).catch((e) => {
        log(`[WARN] hCaptcha①预生成失败: ${e.message}`); return null;
      }))
    : Promise.resolve(null);
  const _hcaptchaPromise2 = (resubmitCardOnPi && (opts.hcaptchaToken2 || autoHcaptcha))
    ? (opts.hcaptchaToken2
      ? Promise.resolve(opts.hcaptchaToken2)
      : getHcaptchaToken({ sitekey: SITEKEY_PAYMENT, log }).catch((e) => {
        log(`[WARN] hCaptcha②预生成失败: ${e.message}`); return null;
      }))
    : Promise.resolve(opts.hcaptchaToken2 || null);

  // 1) 免税账单地址 + 一号确定性持卡人名（对齐友方 nameFor）
  let billing = opts.billing;
  if (!billing) {
    try {
      billing = await generateTaxFreeAddress(opts.taxFreeState);
      log(`免税地址: ${billing.formatted}`);
    } catch (e) {
      log(`[WARN] 免税地址失败: ${e.message}`);
    }
  }
  if (billing && !opts.billing?.name) {
    billing = { ...billing, name: paymentBillingName(idSeed) };
  }
  // CToken 需 billing_details.email 挂到既有 billing account（Java a52df58）
  if (billing && !billing.email && account?.email) {
    billing = { ...billing, email: String(account.email).trim() };
  }

  // 2) 创建结账会话
  // 对齐 Java CheckoutStep：请求必须 hosted → 倾向 oaics_ 内部会话。
  // PAYMENT_CS_LIVE_ENABLED 只表示「若 Vendor 返回 cs_live_ 则走 payment_pages 分支」；
  // 不得把全局 env 当成默认发 custom（发 custom 再走 oaic confirm 是半截路径，易 PI 侧 generic_decline）。
  // opts.csLivePayment / PAYMENT_CS_LIVE_FORCE_CUSTOM → 对齐 Java force_payment_pages：
  //   PaymentPagesCheckoutStep 精简头 + settings_upsell/custom/PH/PHP，且必须拿到 cs_live_。
  const { isCsLivePaymentEnabled, isCsLiveSessionId, payViaCsLivePaymentPages } = await import('./cslive-checkout.js');
  const forceCustomCheckout = isForceCustomCheckout(opts);
  // FORCE_CUSTOM ≡ 强制走 payment_pages（与 Java force_payment_pages 一致），勿半截 oaic confirm
  const csLiveOn = isCsLivePaymentEnabled(opts) || forceCustomCheckout;
  const checkoutUiMode = forceCustomCheckout ? 'custom' : 'hosted';
  log(`[checkout] ui_mode_req=${checkoutUiMode} csLiveHandle=${csLiveOn} forceCustom=${forceCustomCheckout} paymentPages=${forceCustomCheckout}`);
  const checkoutCtx = {
    ...(preCtx || {}),
    fp: tlsFp,
    deviceId: oaiDeviceId,
    sessionId: oaiSessionId,
    accountId: preCtx?.accountId || account?.accountId || null,
    accessToken: preCtx?.accessToken,
    priceInterval: 'month',
    checkoutUiMode,
    // 对齐 reference-impl PaymentPagesCheckoutStep
    paymentPagesCheckout: forceCustomCheckout,
    checkoutEntryPoint: forceCustomCheckout
      ? (opts.checkoutEntryPoint || 'settings_upsell')
      : (opts.checkoutEntryPoint || undefined),
  };
  // 同会话换环境：跳过 createCheckout，复用上一环境的 checkout body
  let co;
  if (opts.reuseCheckoutSession?.body && opts.reuseCheckoutSession?.sessionId) {
    co = {
      ok: true,
      body: opts.reuseCheckoutSession.body,
      meta: opts.reuseCheckoutSession.meta || {
        accessToken: preCtx?.accessToken || opts.reuseCheckoutSession.accessToken,
      },
    };
    log(`[checkout] 复用会话 env=${envVariant} session=${String(opts.reuseCheckoutSession.sessionId).slice(0, 28)}…`);
    mark('checkout_reuse');
  } else {
    co = await createCheckout(account, plan, region, log, proxy, tlsFp, checkoutCtx);
    mark('checkout');
  }
  // 反应式双IP:撞「Billing country must match request country」时用 billing 出口拉账单,
  // 失败则持续换 billing IP（失败出口由 release 进 6h 冷却），直到成功或池耗尽。
  // 后续 elements/确认/扣款仍走原 payment proxy。其它 400 抛给上层换支付出口。
  if (!co.ok && co.status === 400) {
    const msg400 = String(checkoutErrorText(co.body)).slice(0, 200);
    log(`[checkout] 400 msg="${msg400}"`);
    if (isBillingCountryMismatch(co.body)) {
      let bp = opts.billingProxy || null;
      let label = bp ? 'billing#1' : null;
      let attempt = 0;
      const maxBilling = Math.max(1, Math.min(32, Number(process.env.BILLING_PROXY_MAX_ROTATIONS) || 16));
      while (attempt < maxBilling) {
        if (!bp) {
          if (typeof opts.getAlternateBillingProxy !== 'function') {
            log('[checkout] 账单国家不匹配但无 billing 代理可用(usage=billing 池为空/非区未配)');
            break;
          }
          try {
            bp = await opts.getAlternateBillingProxy();
          } catch (e) {
            log(`[checkout] 取 billing 代理失败: ${e.message}`);
            break;
          }
          if (!bp) {
            log('[checkout] billing 池已耗尽，无法再换出口');
            break;
          }
          label = `billing#${attempt + 1}`;
        }
        log(`[checkout] 账单国家不匹配 → 用 ${label} 拉账单(后续扣款仍走原支付代理)`);
        const retry = await createCheckout(account, plan, region, log, bp, tlsFp, checkoutCtx);
        mark('checkout_ph_retry');
        if (retry.ok) {
          co = retry;
          log(`[checkout] ${label} 成功,已拉到账单`);
          break;
        }
        log(`[checkout] ${label} 仍失败(${retry.status}) msg="${String(checkoutErrorText(retry.body)).slice(0, 120)}"`);
        // 当前 billing 失败，下一轮换新 IP（getAlternate 会 release 并冷却当前）
        bp = null;
        label = null;
        attempt += 1;
        if (typeof opts.getAlternateBillingProxy !== 'function') break;
      }
    }
  }
  if (!co.ok) {
    // 对齐 Java OrderProcessingService：checkout「User is already paid」→ 本单失败「已有同档」。
    // 不是本单 Stripe paid 的成功证据；一单一结，禁止标 completed 核销。不换代理、不重扣。
    if (co.status === 400 && isCheckoutUserAlreadyPaid(co.body)) {
      const cur = curRes.status === 'fulfilled' ? curRes.value : null;
      const livePlan = normalizePlan(cur?.plan_type);
      log(`[checkout] User is already paid → 已有同档失败(未扣款) live=${livePlan || 'free'} target=${targetPlan}`);
      return withPaymentFailureClass({
        ok: false,
        completed: false,
        stage: 'failed_precharge',
        code: 'already_subscribed',
        retryPayment: false,
        noProxyRetry: true,
        envRetry: false,
        plan_type: livePlan || cur?.plan_type || null,
        finalPlan: livePlan || null,
        accountId: cur?.accountId || null,
        message: '已有同档: 账号已有目标订阅 (User is already paid)，本次未扣款',
      });
    }
    const detail = String(checkoutErrorText(co.body) || '').slice(0, 180);
    const err = new Error(
      forceCustomCheckout
        ? `settings_upsell checkout 失败 HTTP ${co.status}${detail ? `: ${detail}` : ''}`
        : `创建结账会话失败(${co.status})`,
    );
    err.status = co.status;
    err.checkoutBody = co.body;
    if (co.status === 400 && isBillingCountryMismatch(co.body)) {
      err.code = 'billing_country_mismatch';
    } else if (co.status === 400) {
      err.code = 'checkout_http_400';
    } else if (co.status === 403 || co.status === 401) {
      // payment_pages 建会话 401/403：对齐 Java 文案，不当泛化 CF（避免乱换付款 IP）
      if (forceCustomCheckout) {
        err.code = co.status === 401 ? 'checkout_http_401' : 'checkout_http_403';
        err.noProxyRetry = co.status === 401;
      } else {
        err.code = 'cf_blocked';
        err.cfBlocked = true;
      }
    }
    // 供上层识别：扣款前、可换 IP 再试(勿当卡拒)
    err.preCharge = true;
    throw err;
  }
  const cb = co.body;
  const earlySessionId = String(cb?.checkout_session_id || cb?.checkout_session?.id || '');
  // 供外层 env 轮换复用同一 checkout（Java prepareExternalCheckoutRetry 保留 session）
  if (typeof opts === 'object' && earlySessionId) {
    opts.__capturedCheckoutSession = {
      body: cb,
      meta: co.meta || {},
      sessionId: earlySessionId,
      accessToken: co.meta?.accessToken || preCtx?.accessToken || null,
    };
  }
  // 强制 payment_pages：必须 cs_live_（对齐 Java PaymentPagesCheckoutStep），禁止落入 oaic 半截路径
  if (forceCustomCheckout && !isCsLiveSessionId(earlySessionId)) {
    const err = new Error(
      earlySessionId
        ? `settings_upsell 未返回 cs_live session: ${earlySessionId.slice(0, 48)}`
        : 'settings_upsell 未返回 cs_live session',
    );
    err.code = 'cs_live_session_required';
    err.preCharge = true;
    err.noProxyRetry = true;
    throw err;
  }
  // cs_live 隔离路径：仅 opt-in / FORCE_CUSTOM 时走 payment_pages，不进 oaic confirm，不记「外部会话坏号」
  if (csLiveOn && isCsLiveSessionId(earlySessionId)) {
    log(`[checkout] cs_live 会话 ${earlySessionId.slice(0, 24)}… → payment_pages 路径 (opt-in)`);
    // 欠费 / $0 仍拒绝（不调用 assertCheckoutSessionUsable 的 cs_live 换号分支）
    if (typeof cb === 'object' && cb) {
      if (cb.is_delinquent === true || cb.isDelinquent === true) {
        const err = new Error('账号已欠费(isDelinquent)，无法出账单，请更换账号');
        err.code = 'account_delinquent';
        err.action = 'swap_account';
        err.noProxyRetry = true;
        markBadFromCheckoutError(account, err, log);
        throw err;
      }
      const amountTotal = Number(cb.amount_total ?? cb.amountTotal);
      if (amountTotal === 0) {
        const err = new Error('该账号有免费试用资格(计费$0)，无法使用虚拟卡支付');
        err.code = 'zero_amount_trial';
        err.action = 'swap_account';
        err.noProxyRetry = true;
        markBadFromCheckoutError(account, err, log);
        throw err;
      }
    }
    mark('cs_live_branch');
    log(`[cs_live] branch job=${opts.jobId || '-'} session=${earlySessionId.slice(0, 28)}… amount=${amount} ${currency}`);
    return payViaCsLivePaymentPages({
      account,
      card,
      billing,
      checkoutBody: cb,
      accessToken: co.meta?.accessToken || preCtx?.accessToken,
      accountId: checkoutCtx.accountId || cb.account_id || account?.accountId || null,
      oaiDeviceId,
      oaiSessionId,
      amount,
      currency,
      plan,
      region,
      proxy,
      tlsFp,
      log,
      opts: { ...opts, jobId: opts.jobId || opts.traceId || null },
      knownInvoiceIds,
      paymentStartedAt: Date.now(),
    });
  }
  // 友方门禁：cs_live / 欠费 / $0 试用 → 立即失败换号 + 记坏号池（默认路径不变）
  try {
    assertCheckoutSessionUsable(cb, log, account);
  } catch (gateErr) {
    markBadFromCheckoutError(account, gateErr, log);
    throw gateErr;
  }
  const pk = cb.publishable_key;
  const sessionId = cb.checkout_session_id;
  const customerSessionSecret = cb.customer_session_client_secret;
  const platformAccountId = checkoutCtx.accountId || cb.account_id || account?.accountId || null;
  // pk / checkout_session_id 硬性必须；customer_session_client_secret 【可选】。
  // Platform 对部分账号返回 requires_manual_approval=true 且不下发 customer_session_client_secret，
  // 这只是拿不到 Elements 会话——与朋友项目一致：跳过 elements、用降级值继续 confirm，
  // 让真实卡决定成败（有效卡照扣、空卡/风控则由 Stripe/银行拒付），而非在此硬失败标「需人工处理」。
  if (!pk || !sessionId) {
    let _cbStr; try { _cbStr = JSON.stringify(cb); } catch { _cbStr = String(cb); }
    log(`[checkout] 200 缺 pk/session body=${String(_cbStr).slice(0, 300)}`);
    throw new Error('结账会话缺少 pk/session');
  }
  logPaymentDiag(log, 'checkout', {
    ui_mode_req: 'hosted',
    session_prefix: String(sessionId).slice(0, 12),
    internal: String(sessionId).startsWith('oaics_'),
    ua: String(tlsFp?.ua || '').match(/Chrome\/[\d.]+/)?.[0],
    platform: tlsFp?.platform,
    vendor_device: String(oaiDeviceId).slice(0, 13),
    account_id: platformAccountId ? String(platformAccountId).slice(0, 12) : '',
    amount_total: cb.amount_total ?? '',
    ...profileDiagFields(tlsFp),
    ja3_hash_expect: String(JA3_HASH_EXPECTED).slice(0, 8),
  });
  await emitPaymentState(opts, {
    ok: true, completed: false, stage: 'checkout_created', retryPayment: true,
    pendingPlan: targetPlan, checkoutSessionId: sessionId,
    paymentEvidence: { confirmed: false, source: 'checkout_created', plan: targetPlan, checkoutSessionId: sessionId },
  });

  // 2b) Stripe 真 mids（对齐 StripeEnvironment；失败回退随机）
  const stripeJsId = uuid();
  let stripeMids = await fetchStripeMids({ pk, proxy, tlsFp, log });
  mark('stripe_mids');

  // 2c) 对齐 Java d2d2751 GptPaymentProtocol：
  //     Checkout → mids → Elements(预税) → Taxes → Elements(税后金额刷新) → CToken → Confirm
  // 浏览器 deferred Elements 先用 checkout 总额 init，地址/税返回后再 init 一次最终金额。
  let deferredIntentAmount = extractCheckoutTotalMinorUnits(cb);
  if (!(deferredIntentAmount > 0) && Number(amount) > 0) {
    deferredIntentAmount = Math.round(Number(amount));
  }

  const emptyElements = { sessionId: null, customer: null, configId: null };
  const runElements = async (amt, phase) => {
    if (!customerSessionSecret) return emptyElements;
    const out = await elementsSession({
      pk,
      customerSessionSecret,
      amount: amt > 0 ? amt : null,
      currency,
      proxy,
      tlsFp,
      log,
      stripeJsId,
    });
    logPaymentDiag(log, 'elements', {
      phase,
      amount: amt > 0 ? amt : null,
      session: String(out.sessionId || '').slice(0, 18),
      customer: out.customer ? String(out.customer).slice(0, 12) : '',
    });
    return out;
  };

  let es = emptyElements;
  if (customerSessionSecret) {
    es = await runElements(deferredIntentAmount, 'pre_tax');
  } else {
    log(`[checkout] 无 customer_session_client_secret (requires_manual_approval=${!!cb.requires_manual_approval})，跳过 elements 继续 confirm`);
  }
  mark('elements_pre_tax');

  // Taxes：刷新最终金额；对齐 Java a52df58 硬失败（ctoken 前中止，不扣款）
  {
    const taxAccess = preCtx?.accessToken || co.meta?.accessToken
      || (await getAccountId(account, proxy, tlsFp).catch(() => ({}))).accessToken;
    if (!taxAccess) {
      const err = new Error('checkout/taxes 缺少 accessToken，已在提交卡信息前停止');
      err.code = 'taxes_no_access_token';
      throw err;
    }
    const taxRes = await checkoutTaxes({
      accessToken: taxAccess, sessionId, processorEntity: cb.processor_entity || 'vendor_entity',
      planName: plan, billing, currency, oaiDeviceId, oaiSessionId,
      accountId: platformAccountId, checkoutEmail: account?.email || billing?.email || null,
      proxy, tlsFp, log,
    });
    const taxAmount = extractCheckoutTotalMinorUnits(taxRes.body);
    if (taxAmount > 0) deferredIntentAmount = taxAmount;
    logPaymentDiag(log, 'taxes', {
      status: taxRes.status,
      email: account?.email || billing?.email ? 'yes' : 'no',
      currency: String(currency).toLowerCase(),
      billing_country: taxRes.billingCountry || billing?.country || 'US',
      deferred_amount: deferredIntentAmount > 0 ? deferredIntentAmount : null,
    });
    // HAR：taxes → snapshot →（填卡）confirm；snapshot 失败不阻断
    if (opts.skipCheckoutSnapshot !== true) {
      try {
        const snap = await checkoutSnapshot({
          accessToken: taxAccess,
          sessionId,
          processorEntity: cb.processor_entity || 'vendor_entity',
          planName: plan,
          currency,
          billing,
          oaiDeviceId,
          oaiSessionId,
          accountId: platformAccountId,
          proxy,
          tlsFp,
          log,
        });
        logPaymentDiag(log, 'snapshot', { status: snap.status, ok: snap.ok });
      } catch (snapErr) {
        log(`[snapshot] 跳过(继续): ${snapErr.message}`);
      }
    }
    mark('taxes');
  }

  // 3) 税后 Elements 刷新（带最终 deferred amount；无 secret 则保持空）
  if (customerSessionSecret) {
    es = await runElements(deferredIntentAmount, 'post_tax');
  }
  mark('elements');
  // return_url 优先用 Vendor confirm 响应（友方 ConfirmStep）；checkout 预填作 fallback
  let returnUrl = cb.confirm_return_url || `${BASE}/checkout/verify?stripe_session_id=${sessionId}&processor_entity=${cb.processor_entity || 'vendor_entity'}&plan_type=${targetPlan === 'pro' ? 'pro' : 'plus'}`;

  // ⑥ 设备指纹采集(默认关闭,opt-in)。实测反直觉结论:
  //    用真Stripe.js从headless Playwright打 m.stripe.com/6 信标注册的 muid,会被 Vendor checkout/confirm
  //    风控门 BLOCKED(headless遥测像机器人);而「匿名随机uuid+6hex」反而放行(无遥测可查) → 到达真实扣款。
  //    ∴ 默认用随机指纹(过风控门);采集仅在 harvestFingerprint===true 时启用(需配合有头/更强stealth才有意义)。
  let fpStorageState = null;
  const _harvestPromise = (opts.harvestFingerprint === true && !opts.dryRun)
    ? harvestStripeFingerprint({ pk, card, billing, proxy, log }).catch(e => { log(`[WARN] 指纹采集异常: ${e.message}`); return null; })
    : Promise.resolve(null);

  // 4) hCaptcha（仅 autoHcaptcha=true 时求解；默认友方路径无 captcha）
  let hcaptchaToken = await _hcaptchaPromise1;
  mark('hcaptcha1');
  if (!hcaptchaToken && autoHcaptcha) {
    log('[hcaptcha] 令牌①预生成为空，兜底再取一次…');
    hcaptchaToken = await getHcaptchaToken({ sitekey: SITEKEY_CTOKEN, log }).catch((e) => {
      log(`[hcaptcha] 令牌①兜底再取失败: ${e.message}`); return null;
    });
  }
  if (!hcaptchaToken) {
    log(autoHcaptcha
      ? '[hcaptcha] 仍无令牌 → 按友方继续 ctoken（不带 radar hcaptcha）'
      : '[hcaptcha] autoHcaptcha=off → ctoken 不带 radar hcaptcha');
  }

  // ⑥ 取采集到的真实指纹(失败回退随机);storageState(含 __stripe_mid cookie + m.stripe.network localStorage)
  //    供最终 Playwright confirm 复用 —— 确保「confirmation_tokens/payment_intents/最终扣款」是同一台已注册设备。
  const harvestedFp = await _harvestPromise;
  // 优先：m.stripe.com 真 mids → Playwright harvest → 随机
  const fp = harvestedFp
    ? { guid: harvestedFp.guid, muid: harvestedFp.muid, sid: harvestedFp.sid, clientSessionId: stripeJsId }
    : stripeMids
      ? { ...stripeMids, clientSessionId: stripeJsId }
      : { ...deviceFingerprint(), clientSessionId: stripeJsId };
  if (harvestedFp?.storageState) fpStorageState = harvestedFp.storageState;
  const midsSrc = harvestedFp ? 'playwright' : stripeMids ? 'm.stripe.com/6' : 'random';
  opts.midsSrc = midsSrc;
  logPaymentDiag(log, 'fp', {
    mids_src: midsSrc,
    muid: String(fp.muid).slice(0, 14),
    ua: String(tlsFp?.ua || '').match(/Chrome\/[\d.]+/)?.[0],
    profile: tlsFp?.profileId || opts.browserProfileId || '',
    stripe_js: await getStripeJsBuild({ proxy, tlsFp, log }),
  });

  // 5) confirmation_tokens(此步会让 Stripe 校验 hCaptcha 令牌 + 卡,但不扣款)
  const confirmationTokenId = await createConfirmationToken({
    pk, card, billing, customer: es.customer, currency,
    elementsSessionId: es.sessionId, configId: es.configId, fp, hcaptchaToken,
    paymentMethodTypes: es.orderedPaymentMethodTypes, proxy, tlsFp, log,
  });
  mark('confirmation_token');
  logPaymentDiag(log, 'ctoken', { token: String(confirmationTokenId).slice(0, 16), has_hcaptcha: !!hcaptchaToken });

  // dryRun: 验证到 confirmation_tokens 为止,不进行真实扣款
  if (opts.dryRun) {
    return {
      ok: true, stage: 'dry_run', message: 'hCaptcha 令牌与卡已通过 Stripe confirmation_tokens 校验,未扣款。',
      confirmationTokenId, amount, currency, billing, customer: es.customer,
    };
  }

  // 6) Vendor confirm（taxes + 税后 Elements 已完成）
  let accessToken = preCtx?.accessToken || co.meta?.accessToken
    || (await getAccountId(account, proxy, tlsFp)).accessToken;
  // 友方 Confirm 不强制 sentinel；默认关，opts.useConfirmSentinel=true 才生成
  let confirmSentinel = opts.confirmSentinelToken || null;
  if (!confirmSentinel && opts.useConfirmSentinel === true && opts.tokenProvider) {
    try { confirmSentinel = await opts.tokenProvider.sentinel(oaiDeviceId, 'checkout_session_approval'); }
    catch (e) { log(`[sentinel] checkout/confirm 令牌失败: ${e.message}`); }
  }

  // 6b) Platform checkout/confirm → pi client_secret
  // 对齐 Java confirmWithCredentialRetry：仅 Vendor 鉴权 401/403 时刷新 AT 重放一次（未进 Stripe 扣款）
  let conf = await checkoutConfirm({
    accessToken, sessionId, confirmationTokenId, oaiDeviceId, oaiSessionId,
    sentinelToken: confirmSentinel, accountId: platformAccountId,
    processorEntity: cb.processor_entity || 'vendor_entity',
    proxy, tlsFp, log,
  });
  if (!conf.clientSecret && isVendorConfirmCredentialRejection(conf.status, conf.body)
      && opts.skipConfirmCredentialRefresh !== true) {
    log(`[checkout] Vendor confirm 鉴权拒绝 HTTP ${conf.status}，刷新 accessToken 后重放一次`);
    try {
      const refreshed = await refreshAccountSession(account, {
        proxy, fp: tlsFp, log, reason: 'payment_confirm_401', attempts: 1,
      });
      if (refreshed?.accessToken) {
        accessToken = refreshed.accessToken;
        account.accessToken = accessToken;
      } else {
        // AT-only：再走 getAccountId（可能仍是旧 token，但保持兼容）
        accessToken = (await getAccountId(account, proxy, tlsFp)).accessToken;
      }
    } catch (refreshErr) {
      log(`[checkout] confirm 后凭证刷新失败: ${refreshErr.message}`);
    }
    await sleepMs(400);
    conf = await checkoutConfirm({
      accessToken, sessionId, confirmationTokenId, oaiDeviceId, oaiSessionId,
      sentinelToken: confirmSentinel, accountId: platformAccountId,
      processorEntity: cb.processor_entity || 'vendor_entity',
      proxy, tlsFp, log,
    });
    log(`[checkout] 凭证刷新后 confirm status=${conf.status} has_cs=${!!conf.clientSecret}`);
  }
  mark('checkout_confirm');
  logPaymentDiag(log, 'confirm', {
    status: conf.status,
    has_cs: !!conf.clientSecret,
    has_sentinel: !!confirmSentinel,
    vendor_status: conf.body?.status || '',
    needs_approve: shouldCheckoutApprove(sessionId, cb, conf.body, opts),
  });
  // 把 create/confirm 上下文带进成功收尾，供 approve 决策
  opts.checkoutCreateBody = cb;
  opts.checkoutConfirmBody = conf.body;
  opts.platformAccountId = platformAccountId;
  // 友方：PI return_url 优先用 confirm 响应里的 confirm_return_url
  const confReturn = conf.body?.confirm_return_url || conf.body?.return_url;
  if (confReturn) returnUrl = String(confReturn);

  if (!conf.clientSecret) {
    const body = conf.body || {};
    log(`[checkout] confirm 无 client_secret status=${conf.status} body=${JSON.stringify(body).slice(0, 300)}`);
    // 币种不兼容：未扣款，独立码位（Java CURRENCY_MISMATCH）
    if (isCheckoutCurrencyIncompatible(body) || isCheckoutCurrencyIncompatible(JSON.stringify(body))) {
      const e = new Error(String(body.detail || body.message || 'Checkout currency is incompatible with your existing billing account.'));
      e.code = 'currency_mismatch';
      e.noProxyRetry = true;
      e.action = 'rebuild_checkout';
      throw e;
    }
    // 仅 cs_live / 显式审批：尝试 approve（不扣款）；oaics 不走
    if (shouldCheckoutApprove(sessionId, cb, body, opts) && opts.skipCheckoutApprove !== true) {
      try {
        let approveSentinel = opts.approveSentinelToken || confirmSentinel || null;
        if (!approveSentinel && opts.useApproveSentinel !== false && opts.tokenProvider) {
          try {
            approveSentinel = await opts.tokenProvider.sentinel(oaiDeviceId, 'checkout_session_approval');
          } catch (e) {
            log(`[sentinel] pre-pi approve 令牌失败: ${e.message}`);
          }
        }
        const appr = await checkoutApprove({
          accessToken, sessionId, processorEntity: cb.processor_entity || 'vendor_entity',
          planType: targetPlan,
          oaiDeviceId, oaiSessionId, accountId: platformAccountId,
          sentinelToken: approveSentinel, proxy, tlsFp, log,
        });
        mark('checkout_approve_pre_pi');
        // approve 后若 body 带出 client_secret，继续主路径
        const apprCs = appr.body?.payment_intent_client_secret || appr.body?.client_secret
          || appr.body?.payment_intent?.client_secret || null;
        if (apprCs) {
          conf.clientSecret = apprCs;
          conf.body = { ...body, ...appr.body };
          conf.ok = true;
          log('[checkout] approve 后拿到 client_secret，继续 Stripe 扣款');
        } else if (appr.ok) {
          // 仍无 PI：按人工审核挂起，禁止当代理故障换 IP 重扣
          const e = new Error('需要人工处理：该账号付款被 Platform 要求人工审核（需手动过验证），请联系客服或更换账号');
          e.code = 'requires_manual_approval';
          e.noProxyRetry = true;
          e.action = 'manual_or_swap';
          throw e;
        }
      } catch (apprErr) {
        if (apprErr?.code === 'requires_manual_approval') throw apprErr;
        log(`[checkout] pre-pi approve 失败: ${apprErr.message}`);
      }
    }
  }

  if (!conf.clientSecret) {
    const body = conf.body || {};
    // 友方：无 PI 但 status=success/succeeded/complete/paid 视为直接完成（罕见，跳过 Stripe verify）
    const directOk = /^(success|succeeded|complete|paid)$/i.test(String(body.status || ''));
    if (directOk) {
      log(`[checkout] confirm 无 PI 但 status=${body.status} → 直接成功，仅对账套餐`);
      const reconciled = await reconcilePaymentOutcome(account, targetPlan, {
        knownInvoiceIds, submittedAt: paymentStartedAt, attempts: 3, delayMs: 3000,
      }, log, proxy);
      const evidence = {
        confirmed: true, source: 'vendor_confirm_direct', confirmedAt: Date.now(),
        plan: targetPlan, checkoutSessionId: sessionId, amount, currency,
        invoiceId: reconciled.paidInvoice?.id || null,
      };
      const result = reconciled.activated
        ? {
          ok: true, completed: true, stage: 'done', paymentStatus: 'succeeded',
          paymentConfirmed: true, retryPayment: false, finalPlan: reconciled.finalPlan,
          amount, currency, billing, checkoutSessionId: sessionId, paymentEvidence: evidence,
        }
        : {
          ok: true, completed: false, stage: 'paid_pending_subscription',
          paymentStatus: 'succeeded', paymentConfirmed: true, subscriptionPending: true,
          retryPayment: false, pendingPlan: targetPlan,
          finalPlan: reconciled.finalPlan || 'free', amount, currency, billing,
          checkoutSessionId: sessionId, paymentEvidence: evidence,
          message: 'Vendor confirm 已成功但套餐尚未同步；禁止再次扣款。',
        };
      await emitPaymentState(opts, result);
      return result;
    }
    const e = new Error();
    if (String(body.status || '') === 'blocked' || conf.status === 403) {
      e.code = 'checkout_blocked';
      e.message = '该账号本次支付被风控拦截，请更换账号重试，不要在1日内重复提交，请手动充值';
      e.noProxyRetry = true;
      e.action = 'swap_account';
      // 立即记入坏号池（1h），后续同号在 preflight/job 入口直接拦截
      try { markBadFromCheckoutError(account, e, log); } catch { /* ignore */ }
    } else if (/internal checkout sessions/i.test(String(body.detail || ''))) {
      e.code = 'external_checkout_session';
      e.message = '该账号结账会话异常(cs_live)，请更换账号重试';
      e.noProxyRetry = true;
      e.action = 'swap_account';
      // cs_live：立即 1h 冷却，后续同号入口直接拦截
      try { markBadFromCheckoutError(account, e, log); } catch { /* ignore */ }
    } else if (shouldCheckoutApprove(sessionId, cb, body, opts)) {
      e.code = 'requires_manual_approval';
      e.message = '需要人工处理：该账号付款被 Platform 要求人工审核（需手动过验证），请联系客服或更换账号';
      e.noProxyRetry = true;
      e.action = 'manual_or_swap';
    } else {
      e.code = 'checkout_confirm_failed';
      e.message = '支付结账未通过，请稍后重试或更换账号';
    }
    throw e;
  }

  // checkout/confirm creates the Payment Intent but has not confirmed the charge yet. Read its
  // server-side amount now so FX/upstream changes are checked before the irreversible confirm.
  const liveIntent = await retrievePaymentIntent({ pk, clientSecret: conf.clientSecret, proxy, tlsFp }).catch(() => null);
  const liveAmount = Number(liveIntent?.amount);
  const liveCurrency = String(liveIntent?.currency || currency).toUpperCase();
  if (Number.isSafeInteger(liveAmount) && liveAmount > 0) {
    const allowedQuote = quoteWithinTolerance(liveAmount, liveQuote.amountMinor);
    const allowedAdminRange = region.country !== 'PH' || amountWithinRange(liveAmount, pricing);
    if (liveCurrency !== currency || !allowedQuote || !allowedAdminRange) {
      return finishDeclinedCheckout(opts, withPaymentFailureClass({
        ok: false, completed: false, stage: 'failed_precharge', retryPayment: true,
        code: 'checkout_quote_out_of_range', checkoutSessionId: sessionId,
        message: `实时支付金额 ${liveAmount} ${liveCurrency} 超出管理员允许范围，未提交扣款`,
      }));
    }
    amount = liveAmount;
    log(`[payment] 实时 Payment Intent 金额已确认: ${amount} ${liveCurrency}`);
  } else {
    log(`[payment] Payment Intent 暂未返回实时金额，使用配置版本的预期金额 ${amount} ${currency}`);
  }

  // 7) 令牌②仅 legacy 二次交卡需要
  const hcaptchaToken2 = resubmitCardOnPi ? ((await _hcaptchaPromise2) || hcaptchaToken) : null;
  mark('pi_prepare');

  // 8) 最终扣款：默认 token-only（友方 ConfirmStep）；opts.resubmitCardOnPi 可回滚旧形态
  const paymentIntentId = conf.clientSecret.split('_secret_')[0];
  const reuseContext = {
    checkoutSessionId: sessionId,
    publishableKey: pk,
    processorEntity: cb.processor_entity || 'vendor_entity',
    customerSessionClientSecret: customerSessionSecret || null,
    elementsSessionId: es.sessionId,
    elementsConfigId: es.configId,
    stripeCustomerId: es.customer,
    orderedPaymentMethodTypes: es.orderedPaymentMethodTypes,
    stripeJsId,
    guid: fp.guid, muid: fp.muid, sid: fp.sid,
    oaiDeviceId, oaiSessionId,
    platformAccountId,
    paymentIntentId,
    paymentIntentClientSecret: conf.clientSecret,
    returnUrl,
    amount, currency, billing, plan, targetPlan,
    tlsFp, accessToken,
    knownInvoiceIds, paymentStartedAt,
  };
  await emitPaymentState(opts, {
    ok: true, completed: false, stage: 'submitted_pending_reconciliation',
    subscriptionPending: true, retryPayment: false, pendingPlan: targetPlan,
    finalPlan: normalizePlan(account.plan), amount, currency, billing,
    paymentIntent: paymentIntentId, checkoutSessionId: sessionId,
    paymentEvidence: {
      confirmed: false, source: 'stripe_submission', submittedAt: paymentStartedAt,
      plan: targetPlan, paymentIntent: paymentIntentId, checkoutSessionId: sessionId,
      amount, currency,
    },
  });
  let pi;
  try {
    logPaymentDiag(log, 'pi_confirm', {
      mode: resubmitCardOnPi ? 'legacy-resubmit' : 'token-only',
      pi: paymentIntentId,
      stripe_sec_fetch: 'same-site',
      hcaptcha: !!hcaptchaToken,
    });
    pi = await confirmPaymentIntent({
      pk,
      clientSecret: conf.clientSecret,
      confirmationTokenId,
      returnUrl,
      fp,
      proxy,
      tlsFp,
      log,
      resubmitCard: resubmitCardOnPi,
      card, billing, customer: es.customer, currency,
      elementsSessionId: es.sessionId, configId: es.configId,
      hcaptchaToken: hcaptchaToken2,
      paymentMethodTypes: es.orderedPaymentMethodTypes,
    });
    mark('payment_submitted');
    logPaymentDiag(log, 'pi_result', { status: pi?.status, pi: paymentIntentId });
  } catch (e) {
    if (e.paymentRejected) {
      const fail = e.paymentFailure || { message: e.message };
      const piStatus = e.piStatus || fail.piStatus || null;
      const msg = `${fail.message || e.message}${piStatus ? ` pi_status=${piStatus}` : ''}`;
      logPaymentDiag(log, 'pi_decline', {
        pi: paymentIntentId,
        pi_status: piStatus,
        code: fail.code,
        decline: fail.declineCode,
        outcome: fail.outcomeType,
        network: fail.networkStatus,
        risk: fail.riskLevel,
        has_charge: fail.hasCharge,
        seller: fail.sellerMessage ? String(fail.sellerMessage).slice(0, 80) : '',
      });
      return finishDeclinedCheckout(opts, withPaymentFailureClass({
        ok: false, completed: false, stage: 'declined', paymentStatus: 'failed',
        retryPayment: true, failure: { ...fail, piStatus },
        code: fail.declineCode || fail.code === 'card_declined' || !fail.code ? 'card_declined' : fail.code,
        message: msg, amount, currency, billing,
        paymentIntent: paymentIntentId, piStatus, reuseContext,
      }));
    }
    log(`[payment] payment_intent 响应不确定: ${e.message};先查套餐/账单，不重发扣款`);
    return finishAmbiguousCheckout({
      account, plan, paymentIntent: paymentIntentId, sessionId, amount, currency, billing,
      knownInvoiceIds, submittedAt: paymentStartedAt, proxy, log, error: e, paymentOpts: opts,
    });
  }

  if (pi.status === 'requires_action') {
    const na = pi._nextAction;
    // 3DS 回落会起 Playwright，是支付链上最后一个浏览器触点。
    // reference-impl 无此回落（requires_action 直接判失败换卡）且长链 100/100，
    // 故默认关闭；PAYMENT_3DS_BROWSER=1 可恢复。
    const allow3dsBrowser = /^(1|true|yes|on)$/i.test(String(process.env.PAYMENT_3DS_BROWSER || '').trim());
    if (na?.type === 'use_stripe_sdk' && !allow3dsBrowser) {
      log('requires_action/use_stripe_sdk → 已禁用浏览器回落(PAYMENT_3DS_BROWSER=1 可开)，判定需换卡');
    } else if (na?.type === 'use_stripe_sdk') {
      log('requires_action/use_stripe_sdk → 改用 Playwright Stripe Elements 完成…');
      try {
        const piResult = await stripeConfirmCardPayment({
          pk, clientSecret: conf.clientSecret, card, billing, returnUrl, proxy, storageState: fpStorageState, userAgent: fp.ua, fp, log,
        });
        if (piResult.ok && piResult.status === 'succeeded') {
          const paymentIntent = conf.clientSecret.split('_secret_')[0];
          return finishSuccessfulCheckout({
            account, accessToken, sessionId, processorEntity: cb.processor_entity || 'vendor_entity',
            plan, paymentIntent, clientSecret: conf.clientSecret, amount, currency, billing,
            knownInvoiceIds, submittedAt: paymentStartedAt, tlsFp, oaiDeviceId, oaiSessionId, proxy, log, paymentOpts: opts,
          });
        }
        // Stripe Elements 处理完成但卡被拒绝(银行侧失败,非系统问题)
        return finishDeclinedCheckout(opts, withPaymentFailureClass({
          ok: false, stage: 'declined', paymentStatus: piResult.status || 'declined',
          retryPayment: true,
          code: 'card_declined',
          failure: stripeFailure({
            message: piResult.error, code: piResult.code, decline_code: piResult.declineCode,
            type: piResult.errType, network_advice_code: piResult.network,
          }),
          message: `扣款失败(银行拒绝): ${piResult.error}`,
          amount, currency, billing, paymentIntent: paymentIntentId,
        }));
      } catch (e) {
        log(`[payment] 3DS 提交后结果不确定: ${e.message};先查套餐/账单，不重发扣款`);
        return finishAmbiguousCheckout({
          account, plan, paymentIntent: paymentIntentId, sessionId, amount, currency, billing,
          knownInvoiceIds, submittedAt: paymentStartedAt, proxy, log, error: e, paymentOpts: opts,
        });
      }
    }
    const redirectUrl = na?.redirect_to_url?.url || null;
    return withPaymentFailureClass({
      ok: false, stage: 'requires_action', paymentStatus: 'requires_action',
      code: 'three_ds',
      paymentIntent: pi.id, clientSecret: conf.clientSecret,
      redirectUrl, nextActionType: na?.type || 'unknown',
      message: redirectUrl ? `需要3DS认证，请访问 ${redirectUrl}` : `需要3DS认证(${na?.type})`,
      amount, currency, billing,
    });
  }
  // 友方：succeeded 或 processing 都算扣款成功（processing = 银行处理中）
  if (pi.status === 'succeeded' || pi.status === 'processing') {
    return finishSuccessfulCheckout({
      account, accessToken, sessionId, processorEntity: cb.processor_entity || 'vendor_entity',
      plan, paymentIntent: pi.id, clientSecret: conf.clientSecret, amount, currency, billing,
      knownInvoiceIds, submittedAt: paymentStartedAt, tlsFp, oaiDeviceId, oaiSessionId, proxy, log, paymentOpts: opts,
    });
  }
  if (['requires_payment_method', 'canceled', 'failed'].includes(pi.status)) {
    const failure = stripeFailure(pi.last_payment_error || { message: `Stripe 状态 ${pi.status}` });
    return finishDeclinedCheckout(opts, withPaymentFailureClass({
      ok: false, completed: false, stage: 'declined', paymentStatus: pi.status,
      retryPayment: true, code: 'card_declined', failure: { ...failure, piStatus: pi.status },
      message: `${failure.message} pi_status=${pi.status}`,
      amount, currency, billing, paymentIntent: pi.id, piStatus: pi.status, reuseContext,
    }));
  }
  return finishAmbiguousCheckout({
    account, plan, paymentIntent: pi.id || paymentIntentId, sessionId, amount, currency, billing,
    knownInvoiceIds, submittedAt: paymentStartedAt, proxy, log, paymentOpts: opts,
    error: new Error(`Stripe 返回非终态 ${pi.status || 'unknown'}`),
  });
}

/**
 * 拒卡后复用 checkout/elements/PI：只重跑 CToken + Vendor confirm + PI confirm（友方 executeCheckoutRetry）。
 * 调用方应先 canReuseCheckoutSession(prev.reuseContext, prev) 为 true。
 */
export async function rechargePhpCheckoutRetry(account, card, reuseContext, opts = {}, log = () => {}, proxy = null) {
  if (opts.skipProxyGate) {
    return rechargePhpCheckoutRetryInner(account, card, reuseContext, opts, log, proxy);
  }
  return withPaymentProxyGate(proxy, () => rechargePhpCheckoutRetryInner(account, card, reuseContext, opts, log, proxy), { log });
}

async function rechargePhpCheckoutRetryInner(account, card, reuseContext, opts = {}, log = () => {}, proxy = null) {
  const _t0 = Date.now(); let _tPrev = _t0;
  const mark = (s) => { const n = Date.now(); log(`[timing] retry_${s} +${n - _tPrev}ms total=${n - _t0}ms`); _tPrev = n; setProtocolPhase(s); };
  if (!reuseContext?.checkoutSessionId || !reuseContext?.publishableKey) {
    throw new Error('reuseContext 不完整，无法会话内重试');
  }
  if (!card?.number || !card?.cvv || card.expMonth == null || card.expYear == null) {
    const err = new Error('Card details incomplete: number/exp_month/exp_year/cvc missing');
    err.code = 'card_incomplete';
    throw err;
  }
  const tlsFp = reuseContext.tlsFp || paymentAccountFp(account);
  const pk = reuseContext.publishableKey;
  const sessionId = reuseContext.checkoutSessionId;
  const plan = reuseContext.plan || apiPlanName(opts.plan || PLAN.PLUS);
  const targetPlan = normalizePlan(plan);
  const currency = reuseContext.currency || 'PHP';
  const amount = reuseContext.amount;
  let billing = reuseContext.billing || opts.billing;
  if (billing && !billing.email && account?.email) {
    billing = { ...billing, email: String(account.email).trim() };
  }
  const oaiDeviceId = reuseContext.oaiDeviceId || stableOaiId('x-vendor-device-', account?.accountId || account?.email);
  const oaiSessionId = reuseContext.oaiSessionId || stableOaiId('x-vendor-session-', account?.accountId || account?.email);
  const autoHcaptcha = opts.autoHcaptcha === true;
  let hcaptchaToken = opts.hcaptchaToken || null;
  if (!hcaptchaToken && autoHcaptcha) {
    hcaptchaToken = await getHcaptchaToken({ sitekey: SITEKEY_CTOKEN, log }).catch(() => null);
  }
  mark('retry_hcaptcha');
  const rndFp = (!reuseContext.guid || !reuseContext.muid || !reuseContext.sid) ? deviceFingerprint() : null;
  const fp = {
    guid: reuseContext.guid || rndFp.guid,
    muid: reuseContext.muid || rndFp.muid,
    sid: reuseContext.sid || rndFp.sid,
    clientSessionId: reuseContext.stripeJsId || uuid(),
  };
  const confirmationTokenId = await createConfirmationToken({
    pk, card, billing, customer: reuseContext.stripeCustomerId, currency,
    elementsSessionId: reuseContext.elementsSessionId, configId: reuseContext.elementsConfigId,
    fp, hcaptchaToken, paymentMethodTypes: reuseContext.orderedPaymentMethodTypes, proxy, tlsFp, log,
  });
  mark('retry_ctoken');
  let accessToken = reuseContext.accessToken
    || (await getAccountId(account, proxy, tlsFp)).accessToken;
  let conf = await checkoutConfirm({
    accessToken, sessionId, confirmationTokenId, oaiDeviceId, oaiSessionId,
    sentinelToken: null, accountId: reuseContext.platformAccountId,
    processorEntity: reuseContext.processorEntity || 'vendor_entity',
    proxy, tlsFp, log,
  });
  if (!conf.clientSecret && isVendorConfirmCredentialRejection(conf.status, conf.body)
      && opts.skipConfirmCredentialRefresh !== true) {
    log(`[retry] Vendor confirm 鉴权拒绝 HTTP ${conf.status}，刷新 accessToken 后重放一次`);
    try {
      const refreshed = await refreshAccountSession(account, {
        proxy, fp: tlsFp, log, reason: 'payment_confirm_401_retry', attempts: 1,
      });
      if (refreshed?.accessToken) {
        accessToken = refreshed.accessToken;
        account.accessToken = accessToken;
      }
    } catch (refreshErr) {
      log(`[retry] confirm 凭证刷新失败: ${refreshErr.message}`);
    }
    await sleepMs(400);
    conf = await checkoutConfirm({
      accessToken, sessionId, confirmationTokenId, oaiDeviceId, oaiSessionId,
      sentinelToken: null, accountId: reuseContext.platformAccountId,
      processorEntity: reuseContext.processorEntity || 'vendor_entity',
      proxy, tlsFp, log,
    });
  }
  mark('retry_confirm');
  const clientSecret = conf.clientSecret || reuseContext.paymentIntentClientSecret;
  if (!clientSecret) {
    if (isCheckoutCurrencyIncompatible(conf.body)) {
      return withPaymentFailureClass({
        ok: false, stage: 'failed_precharge', code: 'currency_mismatch',
        message: String(conf.body?.detail || '结账币种与账号账单账户不兼容'),
        retryPayment: false, noProxyRetry: true,
      });
    }
    return withPaymentFailureClass({
      ok: false, stage: 'checkout_confirm_failed', code: 'checkout_confirm_failed',
      message: '会话复用 confirm 未返回 client_secret',
    });
  }
  const paymentIntentId = clientSecret.split('_secret_')[0];
  let returnUrl = conf.body?.confirm_return_url || reuseContext.returnUrl
    || `${BASE}/checkout/verify?stripe_session_id=${sessionId}&processor_entity=${reuseContext.processorEntity || 'vendor_entity'}&plan_type=${targetPlan === 'pro' ? 'pro' : 'plus'}`;
  try {
    const pi = await confirmPaymentIntent({
      pk, clientSecret, confirmationTokenId, returnUrl, fp, proxy, tlsFp, log,
      resubmitCard: false,
    });
    mark('retry_pi');
    if (pi.status === 'succeeded' || pi.status === 'processing') {
      return finishSuccessfulCheckout({
        account, accessToken, sessionId, processorEntity: reuseContext.processorEntity || 'vendor_entity',
        plan, paymentIntent: pi.id || paymentIntentId, clientSecret, amount, currency, billing,
        knownInvoiceIds: reuseContext.knownInvoiceIds || [],
        submittedAt: reuseContext.paymentStartedAt || Date.now(),
        tlsFp, oaiDeviceId, oaiSessionId, proxy, log, paymentOpts: opts,
      });
    }
    if (['requires_payment_method', 'canceled', 'failed'].includes(pi.status)) {
      const failure = stripeFailure(pi.last_payment_error || { message: `Stripe 状态 ${pi.status}` });
      return finishDeclinedCheckout(opts, withPaymentFailureClass({
        ok: false, completed: false, stage: 'declined', paymentStatus: pi.status,
        retryPayment: true, code: 'card_declined',
        failure: { ...failure, piStatus: pi.status },
        message: `${failure.message} pi_status=${pi.status}`,
        amount, currency, billing, paymentIntent: paymentIntentId,
        piStatus: pi.status, reuseContext: { ...reuseContext, paymentIntentClientSecret: clientSecret },
      }));
    }
    return finishAmbiguousCheckout({
      account, plan, paymentIntent: paymentIntentId, sessionId, amount, currency, billing,
      knownInvoiceIds: reuseContext.knownInvoiceIds || [],
      submittedAt: reuseContext.paymentStartedAt || Date.now(),
      proxy, log, paymentOpts: opts,
      error: new Error(`retry PI 非终态 ${pi.status || 'unknown'}`),
    });
  } catch (e) {
    if (e.paymentRejected) {
      const fail = e.paymentFailure || { message: e.message };
      const piStatus = e.piStatus || null;
      return finishDeclinedCheckout(opts, withPaymentFailureClass({
        ok: false, completed: false, stage: 'declined', paymentStatus: 'failed',
        retryPayment: true, failure: { ...fail, piStatus },
        code: 'card_declined',
        message: `${fail.message || e.message}${piStatus ? ` pi_status=${piStatus}` : ''}`,
        amount, currency, billing, paymentIntent: paymentIntentId, piStatus,
        reuseContext: { ...reuseContext, paymentIntentClientSecret: clientSecret },
      }));
    }
    return finishAmbiguousCheckout({
      account, plan, paymentIntent: paymentIntentId, sessionId, amount, currency, billing,
      knownInvoiceIds: reuseContext.knownInvoiceIds || [],
      submittedAt: reuseContext.paymentStartedAt || Date.now(),
      proxy, log, error: e, paymentOpts: opts,
    });
  }
}
