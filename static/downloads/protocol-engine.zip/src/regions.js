export const PAYMENT_REGIONS = Object.freeze({
  US: Object.freeze({ country: 'US', currency: 'USD', pricingKey: 'US' }),
  JP: Object.freeze({ country: 'JP', currency: 'JPY', pricingKey: 'JPY' }),
  IN: Object.freeze({ country: 'IN', currency: 'INR', pricingKey: 'INR' }),
  KR: Object.freeze({ country: 'KR', currency: 'KRW', pricingKey: 'KRW' }),
  PH: Object.freeze({ country: 'PH', currency: 'PHP', pricingKey: 'PHP' }),
  EG: Object.freeze({ country: 'EG', currency: 'EGP', pricingKey: 'EGP' }),
  SE: Object.freeze({ country: 'SE', currency: 'SEK', pricingKey: 'SEK' }),
});

export function normalizePaymentRegion(country = 'PH', currency = '') {
  const normalizedCountry = String(country || 'PH').trim().toUpperCase();
  const region = PAYMENT_REGIONS[normalizedCountry];
  if (!region) {
    const error = new Error('unsupported_payment_region');
    error.code = 'unsupported_payment_region';
    throw error;
  }
  const normalizedCurrency = String(currency || region.currency).trim().toUpperCase();
  if (normalizedCurrency !== region.currency) {
    const error = new Error('payment_region_currency_mismatch');
    error.code = 'payment_region_currency_mismatch';
    throw error;
  }
  return { ...region };
}

export function quoteWithinTolerance(actual, expected, toleranceBps = 500) {
  const current = Number(actual);
  const quoted = Number(expected);
  if (!Number.isSafeInteger(current) || current <= 0 || !Number.isSafeInteger(quoted) || quoted <= 0) return false;
  const delta = Math.max(2, Math.ceil((quoted * toleranceBps) / 10000));
  return current >= quoted - delta && current <= quoted + delta;
}
