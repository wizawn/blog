// Stripe.js 构建盐（payment_user_agent 里的 stripe.js/<salt>）。
//
// 逆向依据（research/stripe-rv/js，2026-08-06 快照 + 2026-08-07 线上核对）：
//   bundle 模块 781 / 30781 导出 h = /*! STRIPE_JS_BUILD_SALT xxxxxxxxxx*/"xxxxxxxxxx"
//   payment_user_agent = "stripe.js/".concat(h) + "; stripe-js-v3/".concat(h) + 后缀
// h 是当前部署 revision 的前 10 位。同一模块另一个导出是 40 位全量 revision，
// 与 .deploy_status_henson.json 里 deployedRevisions 的元素逐字符相同。
//
// 版本判定（bundle 模块 34018 导出 w）：
//   canaryRevision 前缀命中 -> "canary"；deployedRevisions[0] -> "main"；[1] -> "previous"
// 2026-08-07 HAR 的 r.stripe.com 遥测自报 deploy_status="main" 且 version="572ee5cc22"，
// 与当日 deployedRevisions[0].slice(0,10) 一致，故取 [0]。
//
// 硬编码这个盐追不上 Stripe 的发布节奏（8-06 外层 b01c5e72b9 / 内层 3704557c13 曾错位一天），
// 所以运行时拉取 + 缓存 + 兜底，取不到绝不阻断支付。

const DEPLOY_STATUS_URL = 'https://js.stripe.com/v3/.deploy_status_henson.json';

// 兜底值：Java e9b357f / platform.example.com5.har 已验证盐。仅在拉取失败且无缓存时使用。
export const STRIPE_BUILD_FALLBACK = '692f102a8f';

const TTL_MS = Math.max(60_000, Number(process.env.STRIPE_BUILD_TTL_MS) || 6 * 3600_000);
const REVISION_RE = /^[0-9a-f]{10,}$/;

let cache = { build: null, at: 0, source: 'none' };
let inflight = null;

/** 环境变量钉死时直接返回，便于回滚到某个已验证的盐。 */
function envPinned() {
  const v = String(process.env.STRIPE_JS_BUILD || '').trim();
  return REVISION_RE.test(v) ? v.slice(0, 10) : null;
}

/** 从 .deploy_status_henson.json 的响应体取当前 main revision 的前 10 位。 */
export function pickBuildFromDeployStatus(body) {
  if (!body || typeof body.canaryPercentage !== 'number') return null;
  const revisions = Array.isArray(body.deployedRevisions) ? body.deployedRevisions : [];
  const main = String(revisions[0] || '').trim();
  return REVISION_RE.test(main) ? main.slice(0, 10) : null;
}

export function stripePaymentUserAgent(build, suffix = 'payment-element; deferred-intent') {
  const b = REVISION_RE.test(String(build || '')) ? String(build).slice(0, 10) : STRIPE_BUILD_FALLBACK;
  return `stripe.js/${b}; stripe-js-v3/${b}; ${suffix}`;
}

async function fetchDeployStatus({ proxy, tlsFp, log }) {
  // 延迟 import：让上面的纯函数可以脱离 CycleTLS 单测
  const { ctlsFetch, UA } = await import('./ctls.js');
  const r = await ctlsFetch(DEPLOY_STATUS_URL, {
    headers: {
      'User-Agent': tlsFp?.ua || UA,
      Accept: '*/*',
      Origin: 'https://js.stripe.com',
      Referer: 'https://js.stripe.com/',
      'sec-fetch-site': 'same-origin',
      'sec-fetch-mode': 'cors',
      'sec-fetch-dest': 'empty',
    },
    ja3: tlsFp?.ja3,
    timeoutMs: 8000,
  }, proxy);
  if (r.status !== 200) throw new Error(`deploy_status status=${r.status}`);
  const build = pickBuildFromDeployStatus(await r.json().catch(() => null));
  if (!build) throw new Error('deploy_status 无可用 revision');
  log(`[stripe] js build=${build}（deployedRevisions[0]）`);
  return build;
}

/**
 * 当前 Stripe.js 构建盐。优先级：env 钉死 > 新鲜缓存 > 线上拉取 > 陈旧缓存 > 兜底常量。
 * 任何失败都只降级不抛错——支付路径不该因为一个 UA 字段拿不到就中断。
 */
export async function getStripeJsBuild({ proxy = null, tlsFp = null, log = () => {} } = {}) {
  const pinned = envPinned();
  if (pinned) return pinned;

  const fresh = cache.build && (Date.now() - cache.at) < TTL_MS;
  if (fresh) return cache.build;

  if (!inflight) {
    inflight = fetchDeployStatus({ proxy, tlsFp, log })
      .then((build) => {
        cache = { build, at: Date.now(), source: 'deploy_status' };
        return build;
      })
      .catch((e) => {
        // 拉取失败：陈旧缓存也比兜底常量新，优先续用
        log(`[stripe] js build 拉取失败(${e.message})，用 ${cache.build ? '陈旧缓存' : '兜底常量'}`);
        return cache.build || STRIPE_BUILD_FALLBACK;
      })
      .finally(() => { inflight = null; });
  }
  return inflight;
}

/** 诊断用：当前缓存状态。 */
export function stripeBuildState() {
  return { ...cache, envPinned: envPinned(), ttlMs: TTL_MS };
}

// ───── cs_live custom-checkout 的 rv_timestamp 常量（模块 1028）─────
//
// 模块 1028 导出 sK / dG / QJ，压缩后长这样：
//   1028:function(e,t,n){...n.d(t,{QJ:...,dG:...,sK:...});
//   var r="2024-01-01 00:00:00 -0000",
//       o=/*! STRIPE_JS_BUILD_SALT <build>*/"<40位 rv>",
//       a=/*! STRIPE_JS_BUILD_SALT <build>*/"<64位 sv>"
// rv 恒等于 deployedRevisions 里的全量 revision，sv 只能从 bundle 抠。
// 只有 outer bundle(basil/stripe.js)带这个模块，内层 shared/controller chunk 没有。

const OUTER_BUNDLE_URL = 'https://js.stripe.com/basil/stripe.js';
const RV_CONSTS_RE = /"2024-01-01 00:00:00 -0000"\s*,\s*\w+\s*=\s*\/\*![^*]*\*\/"([0-9a-f]{40})"\s*,\s*\w+\s*=\s*\/\*![^*]*\*\/"([0-9a-f]{64})"/;

let rvCache = { version: null, rv: null, sv: null, at: 0 };
let rvInflight = null;

/** 从 basil/stripe.js 正文抠 { version, rv, sv }；抠不到返回 null。 */
export function parseRvConsts(jsText) {
  const s = String(jsText || '');
  const m = s.match(RV_CONSTS_RE);
  if (!m) return null;
  const salt = (s.match(/STRIPE_JS_BUILD_SALT ([0-9a-f]{10})/) || [])[1] || m[1].slice(0, 10);
  // rv 必须以该 build 的盐开头，否则说明抓串抓错了模块
  if (!m[1].startsWith(salt)) return null;
  return { version: salt, rv: m[1], sv: m[2] };
}

async function fetchRvConsts({ proxy, tlsFp, log }) {
  const { ctlsFetch, UA } = await import('./ctls.js');
  const r = await ctlsFetch(OUTER_BUNDLE_URL, {
    headers: {
      'User-Agent': tlsFp?.ua || UA,
      Accept: '*/*',
      Referer: 'https://platform.example.com/',
      'sec-fetch-site': 'cross-site',
      'sec-fetch-mode': 'no-cors',
      'sec-fetch-dest': 'script',
    },
    ja3: tlsFp?.ja3,
    timeoutMs: 25000,
  }, proxy);
  if (r.status !== 200) throw new Error(`basil/stripe.js status=${r.status}`);
  const parsed = parseRvConsts(await r.text());
  if (!parsed) throw new Error('未从 basil/stripe.js 抠到模块 1028 常量');
  log(`[stripe] rv 常量 build=${parsed.version} sv=${parsed.sv.slice(0, 12)}…`);
  return parsed;
}

/**
 * 当前 build 的 { version, rv, sv }。失败返回 null，由调用方回退 stripe-rv.js 的静态表。
 * 拉的是 1MB 的 bundle，所以缓存周期跟构建盐一致。
 */
export async function getStripeRvConsts({ proxy = null, tlsFp = null, log = () => {} } = {}) {
  const fresh = rvCache.sv && (Date.now() - rvCache.at) < TTL_MS;
  if (fresh) return { ...rvCache };

  if (!rvInflight) {
    rvInflight = fetchRvConsts({ proxy, tlsFp, log })
      .then((v) => {
        rvCache = { ...v, at: Date.now() };
        return { ...rvCache };
      })
      .catch((e) => {
        log(`[stripe] rv 常量拉取失败(${e.message})，${rvCache.sv ? '用陈旧缓存' : '回退静态表'}`);
        return rvCache.sv ? { ...rvCache } : null;
      })
      .finally(() => { rvInflight = null; });
  }
  return rvInflight;
}
