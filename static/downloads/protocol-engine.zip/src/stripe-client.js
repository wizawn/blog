// Vendor Stripe Elements primitives (confirmation token / PI / setup intent).
// Extracted from platform.js (zero behavior change).
import { BASE, uuid, stripeId } from './shared.js';
import { ctlsFetch, applyFp, UA, SEC_CH_UA } from './ctls.js';
import { getStripeJsBuild, stripePaymentUserAgent, STRIPE_BUILD_FALLBACK } from './stripe-build.js';

export const STRIPE = 'https://api.stripe.com';
export const STRIPE_VERSION = '2025-03-31.basil; checkout_server_update_beta=v1; checkout_manual_approval_preview=v1';
// 2026-08-07 oaics_ 短链成功单 HAR：confirmation_tokens / payment_intents-confirm 只发纯版本号，
// beta 标志仅出现在 elements/sessions（07-03 HAR）。env 可回滚成带 beta 的 STRIPE_VERSION。
export const STRIPE_VERSION_CONFIRM = String(process.env.STRIPE_VERSION_CONFIRM || '2025-03-31.basil').trim()
  || '2025-03-31.basil';
// payment_user_agent 的构建盐运行时从 js.stripe.com 取（见 stripe-build.js）；
// 这里只保留取不到时的兜底串，不再作为常规值。
export const STRIPE_JS_BUILD = STRIPE_BUILD_FALLBACK;
export const STRIPE_PAYMENT_USER_AGENT = stripePaymentUserAgent(STRIPE_BUILD_FALLBACK);
export const SITEKEY_CTOKEN  = 'YOUR_SITEKEY';
export const SITEKEY_PAYMENT = 'YOUR_SITEKEY';

// 支付方式顺序不写死：优先用 elements/sessions 响应回的 ordered_payment_method_types；
// 缺省对齐浏览器抓包的 [link, card]（env STRIPE_PM_TYPES 可覆盖）。只是「允许的支付方式集合+顺序」。
const DEFAULT_PM_TYPES = String(process.env.STRIPE_PM_TYPES || 'link,card')
  .split(',').map((s) => s.trim()).filter(Boolean);
function normalizePmTypes(order) {
  const list = Array.isArray(order) && order.length ? order : DEFAULT_PM_TYPES;
  const seen = new Set();
  const out = [];
  for (const t of list) {
    const v = String(t || '').trim();
    if (v && !seen.has(v)) { seen.add(v); out.push(v); }
  }
  return out.length ? out : DEFAULT_PM_TYPES;
}
/** 写 client_context[payment_method_types][i] / deferred_intent[payment_method_types][i]。 */
function setPmTypes(form, order, prefix = 'client_context[payment_method_types]') {
  normalizePmTypes(order).forEach((t, i) => form.set(`${prefix}[${i}]`, t));
}
/** 从 elements/sessions 响应抽取有序支付方式（浏览器据此定序），无则 null。 */
export function extractOrderedPmTypes(d) {
  const cand = d?.payment_method_preference?.ordered_payment_method_types
    || d?.ordered_payment_method_types
    || d?.payment_method_types
    || d?.config?.ordered_payment_method_types;
  return Array.isArray(cand) && cand.length ? cand.map((x) => String(x)) : null;
}

// 与 platform 支付路径语言一致（VENDOR_LANGUAGE 默认 en-US，见 checkout.js）
const STRIPE_ACCEPT_LANG = (process.env.VENDOR_LANGUAGE || 'en-US').startsWith('zh')
  ? 'zh-CN,zh;q=0.9,en;q=0.8'
  : 'en-US,en;q=0.9';

export function stripeHeaders(extra = {}) {
  return {
    'User-Agent': UA,
    'Accept': 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept-Language': STRIPE_ACCEPT_LANG,
    'Origin': 'https://js.stripe.com',   // 真实 Stripe.js 从 js.stripe.com 域发(非 platform.example.com)
    'Referer': 'https://js.stripe.com/',
    // 注:真实 Stripe 请求【无】Stripe-Version 头,版本只在 body/query 的 _stripe_version 传。
    // 之前发该头(值含分号)会被 cycletls 传输破坏 → elements/sessions 报"specify Stripe API version"400。
    'sec-ch-ua': SEC_CH_UA,
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    // 友方/浏览器：js.stripe.com → api.stripe.com 为 same-site（同 eTLD+1 stripe.com）
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'priority': 'u=1, i',
    ...extra,
  };
}

// api.stripe.com 不回 Accept-CH，真实 Chrome 只发 3 个低熵 Client Hints（2026-08-07 HAR 核对）。
// applyFp 默认会补 arch/bitness/model/full-version(-list)/platform-version，这里剥掉。
const HIGH_ENTROPY_CLIENT_HINTS = [
  'sec-ch-ua-arch', 'sec-ch-ua-bitness', 'sec-ch-ua-model',
  'sec-ch-ua-full-version', 'sec-ch-ua-full-version-list', 'sec-ch-ua-platform-version',
];
export function stripeFpHeaders(tlsFp = null, extra = {}) {
  const h = applyFp(stripeHeaders(extra), tlsFp);
  for (const k of HIGH_ENTROPY_CLIENT_HINTS) delete h[k];
  return h;
}

// 设备指纹(guid/muid/sid)。真实由 m.stripe.com 下发,这里生成兼容值。
export function deviceFingerprint() {
  return { guid: stripeId(), muid: stripeId(), sid: stripeId() };
}

/**
 * 对齐 StripeEnvironment.java：POST m.stripe.com/6 取真 guid/muid/sid，再可选 radar/session。
 * 失败返回 null，调用方回退随机指纹。
 */
export async function fetchStripeMids({ pk = null, proxy = null, tlsFp = null, log = () => {} } = {}) {
  try {
    const body = JSON.stringify({
      v2: 1,
      id: uuid(),
      t: Date.now() % 100000,
      tag: '4.5.45',
      src: 'js',
      a: null,
      b: { a: 'https://platform.example.com/', b: 'https://platform.example.com/checkout', c: 'Platform' },
      h: uuid(),
    });
    const r = await ctlsFetch('https://m.stripe.com/6', {
      method: 'POST',
      headers: applyFp({
        'User-Agent': UA,
        Accept: '*/*',
        'Content-Type': 'text/plain;charset=UTF-8',
        Origin: 'https://m.stripe.network',
        Referer: 'https://m.stripe.network/',
        'sec-fetch-site': 'cross-site',
        'sec-fetch-mode': 'cors',
        'sec-fetch-dest': 'empty',
      }, tlsFp),
      ja3: tlsFp?.ja3,
      body,
      timeoutMs: 12000,
    }, proxy);
    const d = await r.json().catch(() => ({}));
    if (!d?.guid && !d?.muid) {
      log(`[fp] m.stripe.com/6 无 mids status=${r.status}`);
      return null;
    }
    const mids = {
      guid: d.guid || stripeId(),
      muid: d.muid || stripeId(),
      sid: d.sid || stripeId(),
    };
    if (pk) {
      try {
        const form = new URLSearchParams({
          guid: mids.guid, muid: mids.muid, sid: mids.sid,
          key: pk, _stripe_version: STRIPE_VERSION,
        });
        const rr = await ctlsFetch(`${STRIPE}/v1/radar/session`, {
          method: 'POST',
          headers: stripeFpHeaders(tlsFp),
          ja3: tlsFp?.ja3,
          body: form.toString(),
          timeoutMs: 10000,
        }, proxy);
        const rd = await rr.json().catch(() => ({}));
        if (rr.status === 200 && rd?.id) {
          log(`[fp] radar/session ok id=${String(rd.id).slice(0, 24)}`);
        } else {
          log(`[fp] radar/session 非200 status=${rr.status}`);
        }
      } catch (e) {
        log(`[fp] radar/session 跳过: ${e.message}`);
      }
    }
    log(`[fp] Stripe mids 真采集 ok muid=${String(mids.muid).slice(0, 14)}…`);
    return mids;
  } catch (e) {
    log(`[fp] m.stripe.com/6 失败: ${e.message}`);
    return null;
  }
}

// Stripe elements/sessions (deferred_intent) → { sessionId, customer, configId }
// 对齐 Java ElementsStep (d2d2751)：预生成 session_id；locale 跟 VENDOR_LANGUAGE 走，
// 避免 Stripe locale 与 platform accept-language 不一致。
// 预税可不带 amount，税后刷新时带 deferred_intent[amount]（最终总额 minor units）。
export async function elementsSession({
  pk, customerSessionSecret, amount = null, currency, proxy = null, tlsFp = null, log = () => {},
  stripeJsId = null, locale = process.env.VENDOR_LANGUAGE || 'en-US',
} = {}) {
  const preSessionId = `elements_session_${uuid().replace(/-/g, '').slice(0, 11)}`;
  const q = new URLSearchParams();
  q.set('client_betas[0]', 'custom_checkout_server_updates_1');
  q.set('client_betas[1]', 'custom_checkout_manual_approval_1');
  q.set('customer_session_client_secret', customerSessionSecret);
  q.set('deferred_intent[mode]', 'subscription');
  // Java：tax 后 deferredIntentAmount>0 才写入 amount
  if (amount != null && amount !== '' && Number(amount) > 0) {
    q.set('deferred_intent[amount]', String(amount));
  }
  q.set('deferred_intent[currency]', currency.toLowerCase());
  q.set('deferred_intent[setup_future_usage]', 'off_session');
  setPmTypes(q, DEFAULT_PM_TYPES, 'deferred_intent[payment_method_types]');
  q.set('key', pk);
  q.set('_stripe_version', STRIPE_VERSION);
  q.set('elements_init_source', 'stripe.elements');
  q.set('referrer_host', 'platform.example.com');
  q.set('session_id', preSessionId);
  q.set('stripe_js_id', stripeJsId || uuid());
  q.set('locale', locale);
  q.set('type', 'deferred_intent');

  const r = await ctlsFetch(`${STRIPE}/v1/elements/sessions?${q.toString()}`, { headers: stripeFpHeaders(tlsFp), ja3: tlsFp?.ja3 }, proxy);
  const d = await r.json().catch(() => ({}));
  if (r.status !== 200 || d.error) {
    // 友方：elements 失败降级 UUID 继续，不硬死
    log(`[WARN] elements/sessions 失败(${r.status})，降级继续: ${JSON.stringify(d.error || d).slice(0, 160)}`);
    return { sessionId: preSessionId, customer: null, configId: uuid() };
  }
  const customer = d.customer?.customer_session?.customer
    || (typeof d.customer === 'string' ? d.customer : null)
    || d.customer?.id || null;
  const out = {
    sessionId: d.session_id || d.config?.session_id || d.id || preSessionId,
    customer,
    configId: d.config_id || d.config?.id || d.config?.config_id || uuid(),
    orderedPaymentMethodTypes: extractOrderedPmTypes(d),
  };
  log(`[DEBUG] elements/sessions ok session=${out.sessionId} customer=${out.customer} pm_types=${(out.orderedPaymentMethodTypes || DEFAULT_PM_TYPES).join(',')}`);
  return out;
}

// 【回滚实验 2ee55c2】client_attribution_metadata(归因头)疑触发 Stripe/商户风控拦截(generic_decline,商户侧拦、非银行)。
// 置 true = 去掉这批头,回到"加头之前可正常扣款"的干净请求。验证 OK 后可清理。
const SKIP_ATTRIBUTION = false;
const SKIP_STRIPE_SDK = false;
// 公共 payment_method_data 字段(卡 + 免税账单地址 + 归因)
// 对齐 Java CTokenStep(a52df58)：billing email 必带；guid/muid/sid 空则不传（空串会 parameter_invalid_empty）。
export function pmDataFields(card, billing, { elementsSessionId, configId, fp, paymentUserAgent = null }) {
  const f = {};
  f['payment_method_data[type]'] = 'card';
  f['payment_method_data[card][number]'] = card.number;
  f['payment_method_data[card][cvc]'] = card.cvv;
  // 2026-07 现网浏览器抓包用 4 位年(如 2030),不再截成 2 位(对齐友方 b76757b)
  let expYear4 = parseInt(card.expYear, 10);
  if (expYear4 < 100) expYear4 += 2000;
  // 字段顺序对齐 2026-08-07 HAR：number, cvc, exp_year, exp_month
  f['payment_method_data[card][exp_year]'] = String(expYear4);
  f['payment_method_data[card][exp_month]'] = String(card.expMonth).padStart(2, '0');
  f['payment_method_data[allow_redisplay]'] = 'limited';
  if (billing) {
    f['payment_method_data[billing_details][address][line1]'] = billing.line1;
    f['payment_method_data[billing_details][address][city]'] = billing.city;
    f['payment_method_data[billing_details][address][country]'] = billing.country;
    f['payment_method_data[billing_details][address][postal_code]'] = billing.postalCode;
    f['payment_method_data[billing_details][address][state]'] = billing.state;
    f['payment_method_data[billing_details][name]'] = billing.name;
    // 2026-08-07 oaics_ 成功单 HAR 不带 billing_details[email]（此前为规避 confirm 币种不兼容才加的）。
    // 若币种不兼容复发，先查 client_context[customer] 是否透传，再考虑加回。
    f['payment_method_data[billing_details][phone]'] = '';
  }
  // 行为信号：模拟用户手动输入卡号(vs 自动填充)；顺序对齐 HAR（pasted_fields 在 payment_user_agent 前）
  f['payment_method_data[pasted_fields]'] = 'number,exp,cvc';
  f['payment_method_data[payment_user_agent]'] = paymentUserAgent || STRIPE_PAYMENT_USER_AGENT;
  f['payment_method_data[referrer]'] = BASE;
  f['payment_method_data[time_on_page]'] = String(
    Math.max(12000, Math.floor(Number(process.env.STRIPE_TIME_ON_PAGE) || (38000 + Math.floor(Math.random() * 4000)))),
  );
  if (!SKIP_ATTRIBUTION) {
    f['payment_method_data[client_attribution_metadata][client_session_id]'] = fp.clientSessionId;
    f['payment_method_data[client_attribution_metadata][merchant_integration_source]'] = 'elements';
    f['payment_method_data[client_attribution_metadata][merchant_integration_subtype]'] = 'payment-element';
    f['payment_method_data[client_attribution_metadata][merchant_integration_version]'] = '2021';
    f['payment_method_data[client_attribution_metadata][payment_intent_creation_flow]'] = 'deferred';
    f['payment_method_data[client_attribution_metadata][payment_method_selection_flow]'] = 'merchant_specified';
    // merchant_integration_additional_elements (来自 HAR 真实请求)
    f['payment_method_data[client_attribution_metadata][merchant_integration_additional_elements][0]'] = 'expressCheckout';
    f['payment_method_data[client_attribution_metadata][merchant_integration_additional_elements][1]'] = 'payment';
    f['payment_method_data[client_attribution_metadata][merchant_integration_additional_elements][2]'] = 'address';
    if (elementsSessionId) f['payment_method_data[client_attribution_metadata][elements_session_id]'] = elementsSessionId;
    if (configId) f['payment_method_data[client_attribution_metadata][elements_session_config_id]'] = configId;
  }
  const guid = String(fp?.guid || '').trim();
  const muid = String(fp?.muid || '').trim();
  const sid = String(fp?.sid || '').trim();
  if (guid) f['payment_method_data[guid]'] = guid;
  if (muid) f['payment_method_data[muid]'] = muid;
  if (sid) f['payment_method_data[sid]'] = sid;
  return f;
}

// Stripe confirmation_tokens（友方：有真 hcaptcha 才带，空串会 parameter_invalid_empty）
export async function createConfirmationToken({ pk, card, billing, customer, currency, elementsSessionId, configId, fp, hcaptchaToken, paymentMethodTypes = null, proxy = null, tlsFp = null, log = () => {} }) {
  const paymentUserAgent = stripePaymentUserAgent(await getStripeJsBuild({ proxy, tlsFp, log }));
  const form = new URLSearchParams(pmDataFields(card, billing, { elementsSessionId, configId, fp, paymentUserAgent }));
  if (hcaptchaToken) {
    form.set('payment_method_data[radar_options][hcaptcha_token]', hcaptchaToken);
  } else {
    log('[WARN] confirmation_tokens 无 hcaptcha_token，仍尝试提交（对齐友方可空）');
  }
  form.set('setup_future_usage', 'off_session');
  form.set('client_context[currency]', currency.toLowerCase());
  form.set('client_context[mode]', 'subscription');
  setPmTypes(form, paymentMethodTypes);
  if (customer) form.set('client_context[customer]', customer);
  // 顶层 client_attribution_metadata(真实抓包 confirmation_tokens 也带一份,与 payment_intents/confirm 同)
  if (!SKIP_ATTRIBUTION) {
    form.set('client_attribution_metadata[client_session_id]', fp.clientSessionId);
    form.set('client_attribution_metadata[merchant_integration_source]', 'elements');
    form.set('client_attribution_metadata[merchant_integration_subtype]', 'payment-element');
    form.set('client_attribution_metadata[merchant_integration_version]', '2021');
    form.set('client_attribution_metadata[payment_intent_creation_flow]', 'deferred');
    form.set('client_attribution_metadata[payment_method_selection_flow]', 'merchant_specified');
    if (elementsSessionId) form.set('client_attribution_metadata[elements_session_id]', elementsSessionId);
    if (configId) form.set('client_attribution_metadata[elements_session_config_id]', configId);
    form.set('client_attribution_metadata[merchant_integration_additional_elements][0]', 'expressCheckout');
    form.set('client_attribution_metadata[merchant_integration_additional_elements][1]', 'payment');
    form.set('client_attribution_metadata[merchant_integration_additional_elements][2]', 'address');
  }
  form.set('set_as_default_payment_method', 'false');
  form.set('key', pk);
  form.set('_stripe_version', STRIPE_VERSION_CONFIRM);

  const r = await ctlsFetch(`${STRIPE}/v1/confirmation_tokens`, { method: 'POST', headers: stripeFpHeaders(tlsFp), ja3: tlsFp?.ja3, body: form.toString() }, proxy);
  const d = await r.json().catch(() => ({}));
  if (r.status !== 200 || d.error) throw new Error(`confirmation_tokens 失败(${r.status}): ${JSON.stringify(d.error || d).slice(0, 200)}`);
  log(`[DEBUG] confirmation_token=${d.id}`);
  return d.id;
}

// taxes/confirm 已迁至 recharge.js（paymentPlatformHeaders + checkout_email + 深链 Referer）

// Stripe payment_intents/{pi}/confirm —— 最终扣款(需 hcaptcha_token)
/**
 * 从 Stripe error / PI 抽拒付细节，便于区分银行拒付 vs Radar/商户拦。
 * outcome.type: issuer_declined=发卡行；blocked=Stripe Radar/商户规则。
 */
export function stripeFailure(error = {}, piBody = null) {
  const pe = error.payment_intent || piBody || {};
  // 优先 last_payment_error（GET PI / 部分 confirm 形态）
  const lpe = (pe.last_payment_error && typeof pe.last_payment_error === 'object')
    ? pe.last_payment_error
    : (error.last_payment_error && typeof error.last_payment_error === 'object' ? error.last_payment_error : null);
  const src = lpe || error || {};
  const charges = pe.charges?.data || (Array.isArray(pe.charges) ? pe.charges : []);
  const charge = charges[0] || (typeof pe.latest_charge === 'object' ? pe.latest_charge : null) || {};
  const outcome = charge.outcome || pe.outcome || src.outcome || error.outcome || {};
  const hasCharge = !!(charge && (charge.id || charge.outcome || charge.failure_code));
  return {
    message: src.message || error.message || error.user_message || '支付被拒绝',
    code: src.code || error.code || null,
    declineCode: src.decline_code || error.decline_code || charge.failure_code || null,
    type: src.type || error.type || null,
    networkAdviceCode: src.network_advice_code || error.network_advice_code
      || error.network_decline_code || outcome.network_status || null,
    // 银行 vs 风控：issuer_declined / declined_by_network ≈ 银行；blocked ≈ Stripe/商户
    outcomeType: outcome.type || null,
    outcomeReason: outcome.reason || null,
    networkStatus: outcome.network_status || null,
    sellerMessage: outcome.seller_message || null,
    riskLevel: outcome.risk_level || null,
    adviceCode: src.advice_code || error.advice_code || outcome.advice_code || null,
    // 无 charge/outcome：更可能未到发卡行（Radar/协议形态拦截）
    hasCharge,
    piStatus: pe.status || null,
  };
}

/**
 * Stripe payment_intents/{pi}/confirm
 * 2026-07-27 默认对齐友方 ConfirmStep：卡只在 confirmation_tokens 提交，
 * PI confirm 只带 confirmation_token（禁止二次 payment_method_data）。
 * 传 resubmitCard:true 可回滚旧形态。
 */
export async function confirmPaymentIntent({
  pk, clientSecret, confirmationTokenId = null,
  card = null, billing = null, customer = null, currency = null,
  elementsSessionId = null, configId = null, fp = null, hcaptchaToken = null,
  returnUrl, paymentMethodTypes = null, proxy = null, tlsFp = null, log = () => {},
  resubmitCard = false,
} = {}) {
  const pi = clientSecret.split('_secret_')[0];
  let form;
  if (confirmationTokenId && !resubmitCard) {
    // token-only（友方 2026-07-26 浏览器路径）
    form = new URLSearchParams();
    form.set('return_url', returnUrl);
    form.set('confirmation_token', confirmationTokenId);
    form.set('key', pk);
    form.set('_stripe_version', STRIPE_VERSION_CONFIRM);
    form.set('client_attribution_metadata[client_session_id]', fp?.clientSessionId || uuid());
    form.set('client_attribution_metadata[merchant_integration_source]', 'l1');
    form.set('client_secret', clientSecret);
    log('[payment] PI confirm mode=token-only');
  } else {
    // 旧路径：二次交卡（兼容回滚）
    const paymentUserAgent = stripePaymentUserAgent(await getStripeJsBuild({ proxy, tlsFp, log }));
    form = new URLSearchParams(pmDataFields(card, billing, { elementsSessionId, configId, fp, paymentUserAgent }));
    form.set('return_url', returnUrl);
    form.set('expected_payment_method_type', 'card');
    form.set('client_attribution_metadata[client_session_id]', fp.clientSessionId);
    form.set('client_attribution_metadata[merchant_integration_additional_elements][0]', 'expressCheckout');
    form.set('client_attribution_metadata[merchant_integration_additional_elements][1]', 'payment');
    form.set('client_attribution_metadata[merchant_integration_additional_elements][2]', 'address');
    form.set('client_attribution_metadata[merchant_integration_source]', 'elements');
    form.set('client_attribution_metadata[merchant_integration_subtype]', 'payment-element');
    form.set('client_attribution_metadata[merchant_integration_version]', '2021');
    form.set('client_attribution_metadata[payment_intent_creation_flow]', 'deferred');
    form.set('client_attribution_metadata[payment_method_selection_flow]', 'merchant_specified');
    if (elementsSessionId) form.set('client_attribution_metadata[elements_session_id]', elementsSessionId);
    if (configId) form.set('client_attribution_metadata[elements_session_config_id]', configId);
    if (currency) {
      form.set('client_context[currency]', currency.toLowerCase());
      form.set('client_context[mode]', 'subscription');
      setPmTypes(form, paymentMethodTypes);
      form.set('client_context[setup_future_usage]', 'off_session');
    }
    if (customer) form.set('client_context[customer]', customer);
    if (hcaptchaToken) form.set('radar_options[hcaptcha_token]', hcaptchaToken);
    form.set('set_as_default_payment_method', 'false');
    if (!SKIP_STRIPE_SDK) form.set('use_stripe_sdk', 'true');
    form.set('client_secret', clientSecret);
    form.set('key', pk);
    form.set('_stripe_version', STRIPE_VERSION);
    log('[payment] PI confirm mode=legacy-resubmit-card');
  }

  // 对齐 Java ConfirmStep(09a9461)：confirm 响应丢失时反查 PI，避免已扣款当失败重试。
  let d;
  try {
    const r = await ctlsFetch(`${STRIPE}/v1/payment_intents/${pi}/confirm`, {
      method: 'POST',
      headers: stripeFpHeaders(tlsFp),
      ja3: tlsFp?.ja3,
      body: form.toString(),
    }, proxy);
    d = await r.json().catch(() => ({}));
  } catch (confirmErr) {
    log(`[payment] PI confirm 响应丢失，反查 ${pi}: ${confirmErr.message}`);
    let lastQueryErr = null;
    for (let attempt = 1; attempt <= 3; attempt++) {
      if (attempt > 1) {
        await new Promise((resolve) => setTimeout(resolve, attempt === 2 ? 500 : 1000));
      }
      try {
        const piBody = await retrievePaymentIntent({ pk, clientSecret, proxy, tlsFp });
        if (piBody?.status) {
          log(`[payment] PI reconcile ${attempt}/3 status=${piBody.status}`);
          d = piBody;
          // GET PI 的 decline 在 last_payment_error，归一到 error 形态供下方分支处理
          if (piBody.last_payment_error && !piBody.error) {
            d = {
              ...piBody,
              error: {
                ...piBody.last_payment_error,
                payment_intent: piBody,
              },
            };
          }
          lastQueryErr = null;
          break;
        }
      } catch (queryErr) {
        lastQueryErr = queryErr;
        log(`[payment] PI reconcile ${attempt}/3 失败: ${queryErr.message}`);
      }
    }
    if (!d?.status && !d?.error) {
      const detail = [
        confirmErr.message || confirmErr.name,
        lastQueryErr?.message ? `reconcile=${lastQueryErr.message}` : null,
      ].filter(Boolean).join('; ');
      const error = new Error(
        `payment_confirm_ambiguous: Stripe 确认响应丢失，扣款状态待核实 pi=${pi}; ${detail}`,
      );
      error.code = 'payment_confirm_ambiguous';
      error.paymentIntent = pi;
      throw error;
    }
  }

  // 友方：error.payment_intent.status 也要认（declined 时）；反查路径可能用 last_payment_error
  if (d.error) {
    const errPi = d.error.payment_intent || (d.id ? d : null);
    const piStatus = errPi?.status || d.status || null;
    const fail = stripeFailure(d.error, errPi || d);
    const error = new Error(`扣款失败: ${d.error.message || JSON.stringify(d.error).slice(0, 200)}${piStatus ? ` pi_status=${piStatus}` : ''}`);
    error.paymentRejected = true;
    error.paymentFailure = fail;
    error.piStatus = piStatus;
    throw error;
  }
  log(`[DEBUG] payment_intent ${pi} status=${d.status}`);
  if (d.status === 'requires_action' && d.next_action) {
    const na = d.next_action;
    log(`[DEBUG] next_action: ${JSON.stringify(na).slice(0, 300)}`);
    const redirectUrl = na.redirect_to_url?.url || na.use_stripe_sdk?.stripe_js_url || na.url;
    if (redirectUrl) log(`[DEBUG] 3DS URL: ${redirectUrl}`);
    d._redirectUrl = typeof redirectUrl === 'string' ? redirectUrl : null;
    d._nextAction = na;
  }
  // 友方：processing 与 succeeded 都算支付成功路径
  return d;
}

export async function retrievePaymentIntent({ pk, clientSecret, proxy = null, tlsFp = null }) {
  const paymentIntent = String(clientSecret || '').split('_secret_')[0];
  if (!paymentIntent) return null;
  const query = new URLSearchParams({ client_secret: clientSecret, key: pk });
  const requestHeaders = stripeFpHeaders(tlsFp);
  delete requestHeaders['Content-Type'];
  const response = await ctlsFetch(`${STRIPE}/v1/payment_intents/${paymentIntent}?${query}`, {
    headers: requestHeaders,
    ja3: tlsFp?.ja3,
  }, proxy);
  const body = await response.json().catch(() => null);
  return response.status === 200 && body && !body.error ? body : null;
}

export const VENDOR_PK = 'pk_live_YOUR_KEY';
export const STRIPE_VERSION_SETUP = STRIPE_VERSION_CONFIRM; // setup_intents 同样用纯版本号(无 checkout beta 标志)

// Stripe setup_intents/{seti}/confirm —— 绑卡(校验卡,不扣款)。body 结构同 payment_intents/confirm。
export async function confirmSetupIntent({ pk, setupClientSecret, card, billing, elementsSessionId, configId, fp, hcaptchaToken, proxy = null, tlsFp = null, log = () => {} }) {
  const seti = setupClientSecret.split('_secret_')[0];
  const paymentUserAgent = stripePaymentUserAgent(await getStripeJsBuild({ proxy, tlsFp, log }));
  const form = new URLSearchParams(pmDataFields(card, billing, { elementsSessionId, configId, fp, paymentUserAgent }));
  form.set('return_url', `${BASE}/payment-methods`);
  form.set('expected_payment_method_type', 'card');
  form.set('client_attribution_metadata[client_session_id]', fp.clientSessionId);
  form.set('client_attribution_metadata[merchant_integration_additional_elements][0]', 'expressCheckout');
  form.set('client_attribution_metadata[merchant_integration_additional_elements][1]', 'payment');
  form.set('client_attribution_metadata[merchant_integration_additional_elements][2]', 'address');
  form.set('client_attribution_metadata[merchant_integration_source]', 'elements');
  form.set('client_attribution_metadata[merchant_integration_subtype]', 'payment-element');
  form.set('client_attribution_metadata[merchant_integration_version]', '2021');
  form.set('client_attribution_metadata[payment_intent_creation_flow]', 'deferred');
  form.set('client_attribution_metadata[payment_method_selection_flow]', 'merchant_specified');
  if (elementsSessionId) form.set('client_attribution_metadata[elements_session_id]', elementsSessionId);
  if (configId) form.set('client_attribution_metadata[elements_session_config_id]', configId);
  form.set('radar_options[hcaptcha_token]', hcaptchaToken);
  form.set('use_stripe_sdk', 'true');
  form.set('client_secret', setupClientSecret);
  form.set('key', pk);
  form.set('_stripe_version', STRIPE_VERSION_SETUP);

  const r = await ctlsFetch(`${STRIPE}/v1/setup_intents/${seti}/confirm`, { method: 'POST', headers: stripeFpHeaders(tlsFp), ja3: tlsFp?.ja3, body: form.toString() }, proxy);
  const d = await r.json().catch(() => ({}));
  if (d.error) throw new Error(`绑卡失败: ${d.error.message || JSON.stringify(d.error).slice(0, 200)}`);
  log(`[DEBUG] setup_intents/confirm status=${d.status} pm=${d.payment_method}`);
  return { status: d.status, paymentMethod: d.payment_method, nextAction: d.next_action, body: d };
}
