function safeNonNegativeMinor(value) {
  const amount = Number(value);
  return Number.isSafeInteger(amount) && amount >= 0 ? amount : null;
}

function taxPreviewError(code, details = {}) {
  const error = new Error(code);
  error.code = code;
  error.taxStatus = String(details.status || '').slice(0, 80);
  error.taxErrorReason = String(details.errorReason || '').slice(0, 120);
  return error;
}

function failureCode(error) {
  const code = String(error?.code || error?.message || 'tax_preview_failed')
    .trim()
    .toLowerCase();
  return /^[a-z0-9_-]{1,80}$/.test(code) ? code : 'tax_preview_failed';
}

export function appendStripeTaxRegion(form, location) {
  const country = String(location?.country || '').trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(country)) {
    throw taxPreviewError('tax_preview_location_unavailable');
  }
  const result = new URLSearchParams();
  for (const [name, value] of new URLSearchParams(form)) {
    if (name === 'key'
        || name === '_stripe_version'
        || name.startsWith('elements_session_client[')
        || name.startsWith('elements_options_client[')) {
      result.append(name, value);
    }
  }
  result.set('tax_region[country]', country);
  const postalCode = String(location?.postalCode || '').trim();
  if (postalCode) result.set('tax_region[postal_code]', postalCode.slice(0, 20));
  return result;
}

/**
 * Parse the exact pre-tax and tax-inclusive totals rendered by Stripe Checkout.
 * A preview with discounts, balance credit, or incomplete automatic tax is rejected
 * because it cannot represent the public country price.
 */
export function parseStripeCheckoutTaxPreview(body) {
  const taxStatus = String(body?.tax_meta?.status || '').toLowerCase();
  if (taxStatus !== 'complete') {
    throw taxPreviewError('tax_preview_incomplete', {
      status: taxStatus,
      errorReason: body?.tax_meta?.error_reason,
    });
  }
  const summary = body?.recurring_details?.total_summary
    || body?.total_summary
    || body?.invoice;
  if (!summary || typeof summary !== 'object') {
    throw taxPreviewError('tax_preview_summary_missing');
  }

  const subtotalMinor = safeNonNegativeMinor(summary.subtotal);
  const totalMinor = safeNonNegativeMinor(summary.total ?? summary.due);
  if (!subtotalMinor) throw taxPreviewError('tax_preview_amount_invalid');

  const discountAggregate = safeNonNegativeMinor(summary.total_discount_amount_aggregate) || 0;
  const discountAmounts = Array.isArray(summary.total_discount_amounts)
    ? summary.total_discount_amounts
    : [];
  const appliedBalance = safeNonNegativeMinor(summary.applied_balance) || 0;
  if (discountAggregate > 0
      || discountAmounts.some((entry) => (safeNonNegativeMinor(entry?.amount) || 0) > 0)
      || appliedBalance > 0
      || summary.amount_due_applied_to_balance === true) {
    throw taxPreviewError('tax_preview_adjusted');
  }

  const taxAmounts = Array.isArray(summary.total_tax_amounts)
    ? summary.total_tax_amounts
    : [];
  let inclusiveTaxMinor = 0;
  let exclusiveTaxMinor = 0;
  for (const entry of taxAmounts) {
    const amount = safeNonNegativeMinor(entry?.amount);
    if (amount == null) throw taxPreviewError('tax_preview_tax_invalid');
    if (entry?.inclusive === true) inclusiveTaxMinor += amount;
    else exclusiveTaxMinor += amount;
  }

  const taxExclusiveAmountMinor = subtotalMinor - inclusiveTaxMinor;
  const taxInclusiveAmountMinor = subtotalMinor + exclusiveTaxMinor;
  if (taxExclusiveAmountMinor <= 0
      || taxInclusiveAmountMinor < taxExclusiveAmountMinor
      || (totalMinor != null && Math.abs(totalMinor - taxInclusiveAmountMinor) > 1)) {
    throw taxPreviewError('tax_preview_totals_invalid');
  }

  return {
    taxExclusiveAmountMinor,
    taxInclusiveAmountMinor,
    inclusiveTaxMinor,
    exclusiveTaxMinor,
  };
}

function roundedRatio(amount, numerator, denominator) {
  if (!Number.isSafeInteger(amount) || amount <= 0
      || !Number.isSafeInteger(numerator) || numerator <= 0
      || !Number.isSafeInteger(denominator) || denominator <= 0) {
    throw taxPreviewError('tax_preview_ratio_invalid');
  }
  const projected = Math.round((amount * numerator) / denominator);
  if (!Number.isSafeInteger(projected) || projected <= 0) {
    throw taxPreviewError('tax_preview_ratio_invalid');
  }
  return projected;
}

export function applyTaxPreviewToGlobalPricingCountry(country, preview) {
  const representativeKey = String(preview?.representativePlan || 'plus');
  const representative = country?.plans?.[representativeKey];
  const previewExclusive = safeNonNegativeMinor(preview?.taxExclusiveAmountMinor);
  const previewInclusive = safeNonNegativeMinor(preview?.taxInclusiveAmountMinor);
  if (!representative || !previewExclusive || !previewInclusive
      || previewInclusive < previewExclusive) {
    throw taxPreviewError('tax_preview_amount_invalid');
  }

  let representativeBasis = String(representative.taxMode || '').toLowerCase();
  if (representativeBasis === 'inclusive') {
    if (Math.abs(representative.amountMinor - previewInclusive) > 1) {
      throw taxPreviewError('tax_preview_amount_mismatch');
    }
  } else if (representativeBasis === 'exclusive') {
    if (Math.abs(representative.amountMinor - previewExclusive) > 1) {
      throw taxPreviewError('tax_preview_amount_mismatch');
    }
  } else if (Math.abs(representative.amountMinor - previewExclusive) <= 1) {
    representativeBasis = 'exclusive';
  } else if (Math.abs(representative.amountMinor - previewInclusive) <= 1) {
    representativeBasis = 'inclusive';
  } else {
    throw taxPreviewError('tax_preview_amount_mismatch');
  }

  const plans = Object.fromEntries(Object.entries(country.plans || {}).map(([key, plan]) => {
    if (!plan) return [key, null];
    const taxMode = String(plan.taxMode || '').toLowerCase();
    const basis = taxMode === 'inclusive' || taxMode === 'exclusive'
      ? taxMode
      : representativeBasis;
    const amountMinor = Number(plan.amountMinor);
    const taxExclusiveAmountMinor = basis === 'exclusive'
      ? amountMinor
      : roundedRatio(amountMinor, previewExclusive, previewInclusive);
    const taxInclusiveAmountMinor = basis === 'inclusive'
      ? amountMinor
      : roundedRatio(amountMinor, previewInclusive, previewExclusive);
    if (taxInclusiveAmountMinor < taxExclusiveAmountMinor) {
      throw taxPreviewError('tax_preview_totals_invalid');
    }
    return [key, {
      ...plan,
      taxExclusiveAmountMinor,
      taxInclusiveAmountMinor,
    }];
  }));
  return { ...country, plans };
}

export async function enrichGlobalCheckoutTaxPrices(
  account,
  countries,
  log = () => {},
  proxy = null,
  fp = null,
  ctx = null,
  { concurrency = 5, fetchPreview, retryDelayMs = 350 } = {},
) {
  if (typeof fetchPreview !== 'function') throw taxPreviewError('tax_preview_fetcher_required');
  const source = Array.isArray(countries) ? countries : [];
  const safeConcurrency = Math.max(1, Math.min(5, Number(concurrency) || 5));
  const safeRetryDelayMs = Math.max(0, Math.min(5000, Number(retryDelayMs) || 0));
  const retryableFailures = new Set([
    'tax_preview_checkout_failed',
    'tax_preview_payment_page_failed',
    'tax_preview_location_update_failed',
  ]);
  const results = new Array(source.length);
  let cursor = 0;

  async function worker() {
    for (;;) {
      const index = cursor++;
      if (index >= source.length) return;
      const country = source[index];
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const preview = await fetchPreview(account, country, log, proxy, fp, ctx);
          results[index] = {
            ok: true,
            country: applyTaxPreviewToGlobalPricingCountry(country, preview),
          };
          break;
        } catch (error) {
          const code = failureCode(error);
          if (attempt === 0 && retryableFailures.has(code)) {
            if (safeRetryDelayMs) {
              await new Promise((resolve) => setTimeout(resolve, safeRetryDelayMs));
            }
            continue;
          }
          results[index] = {
            ok: false,
            country,
            failure: {
              countryCode: String(country?.countryCode || '').toUpperCase(),
              code,
            },
          };
          break;
        }
      }
    }
  }

  await Promise.all(Array.from(
    { length: Math.min(safeConcurrency, source.length) },
    () => worker(),
  ));
  const enrichedCountries = results.map((result) => (
    result?.ok ? result.country : result?.country
  ));
  const failures = results.filter((result) => result && !result.ok).map((result) => result.failure);
  return {
    countries: enrichedCountries,
    successfulCountries: source.length - failures.length,
    failures,
  };
}
