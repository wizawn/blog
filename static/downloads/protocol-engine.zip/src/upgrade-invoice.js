// Hosted-invoice Pro upgrade pay path (ported from reference-impl GptUpgradeProtocol).
// Flow when subscriptions/update does not auto-charge the default card:
//   fetch payable hosted_invoice_url → invoicedata → create source → attach → confirm_payment
import { STRIPE } from './stripe-client.js';
import { ctlsFetch, applyFp, UA, SEC_CH_UA } from './ctls.js';
import { queryInvoices } from './billing.js';
import { paymentAccountFp } from './checkout.js';
import { getStripeJsBuild, stripePaymentUserAgent } from './stripe-build.js';

const INVOICE_ORIGIN = 'https://invoice.stripe.com';
const DEFAULT_ACCT = 'acct_1HOrSwC6h1nxGoI3';

function invoiceBrowserHeaders(extra = {}) {
  return {
    'User-Agent': UA,
    Accept: 'application/json',
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept-Language': 'en-US,en;q=0.9',
    Origin: INVOICE_ORIGIN,
    Referer: `${INVOICE_ORIGIN}/`,
    'sec-ch-ua': SEC_CH_UA,
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-site': 'same-site',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    ...extra,
  };
}

export function buildInvoiceDataUrl(hostedUrl) {
  const raw = String(hostedUrl || '').trim();
  if (!raw) throw new Error('hosted_invoice_url 为空');
  let path;
  try {
    path = new URL(raw).pathname;
  } catch {
    throw new Error(`无法解析 hosted_invoice_url: ${raw.slice(0, 80)}`);
  }
  let invoicePath;
  if (path.startsWith('/i/')) invoicePath = `/hosted_invoice_page/${path.slice(3)}`;
  else if (path.startsWith('/hosted_invoice_page/')) invoicePath = path;
  else throw new Error(`无法解析 hosted_invoice_url 路径: ${path}`);
  return `https://invoicedata.stripe.com${invoicePath}`;
}

export function stripeAccountFromHostedUrl(hostedUrl, fallback = DEFAULT_ACCT) {
  const s = String(hostedUrl || '');
  const idx = s.indexOf('acct_');
  if (idx < 0) return fallback;
  let end = s.indexOf('/', idx);
  if (end < 0) end = s.indexOf('?', idx);
  if (end < 0) end = s.length;
  return s.slice(idx, end) || fallback;
}

export function isPayableHostedInvoice(inv = {}) {
  const url = inv.hosted_invoice_url || inv.hostedInvoiceUrl || null;
  if (!url) return false;
  const status = String(inv.status || '').toLowerCase();
  if (status === 'paid' || status === 'void') return false;
  const remaining = inv.amount_remaining ?? inv.amountRemaining;
  if (remaining != null && Number(remaining) <= 0) return false;
  if (inv.paid === true) return false;
  return true;
}

export function pickPayableHostedInvoice(invoices = [], { knownInvoiceIds = [] } = {}) {
  const known = new Set((knownInvoiceIds || []).filter(Boolean).map(String));
  const list = Array.isArray(invoices) ? invoices : [];
  // Prefer brand-new invoices first, then any payable.
  const ordered = [
    ...list.filter((i) => i?.id && !known.has(String(i.id))),
    ...list.filter((i) => !i?.id || known.has(String(i.id))),
  ];
  for (const inv of ordered) {
    if (isPayableHostedInvoice(inv)) {
      return {
        id: inv.id || null,
        hosted_invoice_url: inv.hosted_invoice_url || inv.hostedInvoiceUrl,
        amount_remaining: inv.amount_remaining ?? inv.amountRemaining ?? null,
        status: inv.status || null,
      };
    }
  }
  return null;
}

export function isUpgradeSoftFailBody(body, status) {
  const text = typeof body === 'string'
    ? body
    : JSON.stringify(body || {});
  const lower = text.toLowerCase();
  if (lower.includes('plans could not be compared') || lower.includes('unable to update plan from')) {
    return { soft: true, alreadyAtTarget: true };
  }
  if (
    lower.includes('card_declined')
    || lower.includes('payment_method_failed')
    || lower.includes('generic_decline')
    || lower.includes('payment_failed')
  ) {
    return { soft: true, alreadyAtTarget: false };
  }
  // HTTP 200 always ok; 4xx without soft markers are hard.
  if (Number(status) >= 400) return { soft: false, alreadyAtTarget: false };
  return { soft: false, alreadyAtTarget: false };
}

async function stripeForm(url, { headers, body, proxy, fp, timeoutMs = 60000 }) {
  const resp = await ctlsFetch(url, {
    method: 'POST',
    headers: applyFp(headers, fp),
    ja3: fp?.ja3,
    body,
    timeoutMs,
  }, proxy);
  const json = await resp.json().catch(async () => {
    const t = await resp.text().catch(() => '');
    return { _raw: t };
  });
  return { status: resp.status, body: json };
}

async function stripeGet(url, { headers, proxy, fp, timeoutMs = 60000 }) {
  const resp = await ctlsFetch(url, {
    method: 'GET',
    headers: applyFp(headers, fp),
    ja3: fp?.ja3,
    timeoutMs,
  }, proxy);
  const json = await resp.json().catch(async () => {
    const t = await resp.text().catch(() => '');
    return { _raw: t };
  });
  return { status: resp.status, body: json };
}

/**
 * Load ephemeral_key / publishable_key / payment_intent from hosted invoice URL.
 * Mirrors portal InvoiceDataStep.
 */
export async function loadHostedInvoiceData(hostedUrl, { proxy = null, fp = null, log = () => {} } = {}) {
  const dataUrl = buildInvoiceDataUrl(hostedUrl);
  log(`[upgrade-invoice] invoicedata ${dataUrl.slice(0, 90)}…`);
  const dataResp = await stripeGet(dataUrl, {
    headers: invoiceBrowserHeaders(),
    proxy,
    fp,
  });
  if (dataResp.status >= 400) {
    throw new Error(`invoicedata 加载失败 HTTP ${dataResp.status}`);
  }
  const ephemeralKey = dataResp.body?.ephemeral_key || null;
  const publishableKey = dataResp.body?.publishable_key || null;
  const invoiceId = dataResp.body?.invoice_id || null;
  if (!ephemeralKey) throw new Error('invoicedata 未返回 ephemeral_key');
  if (!invoiceId) throw new Error('invoicedata 未返回 invoice_id');

  const detailUrl = `${STRIPE}/v1/invoices/${invoiceId}/hosted?expand[0]=payment_intent&expand[1]=customer`;
  const detail = await stripeGet(detailUrl, {
    headers: invoiceBrowserHeaders({
      Authorization: `Bearer ${ephemeralKey}`,
      'stripe-version': '2020-03-02',
    }),
    proxy,
    fp,
  });
  if (detail.status >= 400) {
    throw new Error(`invoice details 加载失败 HTTP ${detail.status}`);
  }
  const customerObj = detail.body?.customer;
  const customerId = (customerObj && typeof customerObj === 'object')
    ? (customerObj.id || null)
    : (customerObj ? String(customerObj) : null);
  const piObj = detail.body?.payment_intent;
  const paymentIntentId = (piObj && typeof piObj === 'object')
    ? (piObj.id || null)
    : (piObj ? String(piObj) : null);
  if (!customerId) throw new Error('invoice 未返回 customer_id');
  if (!paymentIntentId) throw new Error('invoice 未返回 payment_intent');

  return {
    hostedUrl,
    ephemeralKey,
    publishableKey,
    invoiceId,
    customerId,
    paymentIntentId,
    stripeAccount: stripeAccountFromHostedUrl(hostedUrl),
  };
}

function cardFields(card = {}) {
  const number = String(card.number || card.cardNumber || '').replace(/\s+/g, '');
  const cvc = String(card.cvv || card.cvc || '');
  const expMonth = String(card.expMonth ?? card.exp_month ?? '').padStart(2, '0');
  let expYear = String(card.expYear ?? card.exp_year ?? '');
  if (expYear.length === 2) expYear = `20${expYear}`;
  if (!number || !cvc || !expMonth || !expYear) {
    throw new Error('升级账单付款缺少完整卡号/CVV/有效期');
  }
  return { number, cvc, expMonth, expYear };
}

/**
 * Pay a hosted upgrade invoice with a card (portal InvoicePayStep).
 */
export async function payHostedUpgradeInvoice(hostedUrl, card, {
  proxy = null, fp = null, log = () => {}, maxConfirmRetries = 3,
} = {}) {
  const fields = cardFields(card);
  const data = await loadHostedInvoiceData(hostedUrl, { proxy, fp, log });
  const pk = data.publishableKey;
  if (!pk) throw new Error('invoicedata 未返回 publishable_key');

  // 1) create source（payment_user_agent 盐动态跟随线上 stripe.js）
  const stripeUa = stripePaymentUserAgent(
    await getStripeJsBuild({ proxy, tlsFp: fp, log }),
    'payment-element; deferred-intent',
  );
  log(`[upgrade-invoice] create source for invoice ${data.invoiceId} ua=${stripeUa.slice(0, 48)}…`);
  const sourceBody = new URLSearchParams({
    type: 'card',
    'card[number]': fields.number,
    'card[cvc]': fields.cvc,
    'card[exp_month]': fields.expMonth,
    'card[exp_year]': fields.expYear,
    _stripe_account: data.stripeAccount,
    key: pk,
    payment_user_agent: stripeUa,
  }).toString();
  const sourceResp = await stripeForm(`${STRIPE}/v1/sources`, {
    headers: invoiceBrowserHeaders(),
    body: sourceBody,
    proxy,
    fp,
  });
  if (sourceResp.status >= 400) {
    const errMsg = sourceResp.body?.error?.message || sourceResp.body?.message || '';
    throw new Error(`创建 source 失败 HTTP ${sourceResp.status}: ${errMsg}`);
  }
  const sourceId = sourceResp.body?.id;
  const sourceStatus = sourceResp.body?.status;
  if (!sourceId) throw new Error('创建 source 未返回 id');
  if (sourceStatus && sourceStatus !== 'chargeable') {
    throw new Error(`source 状态异常: ${sourceStatus}`);
  }
  log(`[upgrade-invoice] source ${sourceId} status=${sourceStatus || 'ok'}`);

  // 2) attach to customer
  const attachBody = new URLSearchParams({ source: sourceId, validate: 'false' }).toString();
  const attachResp = await stripeForm(`${STRIPE}/v1/customers/${data.customerId}/sources`, {
    headers: invoiceBrowserHeaders({
      Authorization: `Bearer ${data.ephemeralKey}`,
      'stripe-version': '2020-03-02',
    }),
    body: attachBody,
    proxy,
    fp,
  });
  if (attachResp.status >= 400) {
    throw new Error(`绑定 source 到 customer 失败 HTTP ${attachResp.status}`);
  }

  // 3) confirm_payment (retry lock_timeout)
  let lastErr = null;
  for (let attempt = 1; attempt <= maxConfirmRetries; attempt++) {
    try {
      const confirmBody = new URLSearchParams({
        payment_method: sourceId,
        payment_intent: data.paymentIntentId,
      }).toString();
      const confirmResp = await stripeForm(
        `${STRIPE}/v1/invoices/${data.invoiceId}/hosted/confirm_payment`,
        {
          headers: invoiceBrowserHeaders({
            Authorization: `Bearer ${data.ephemeralKey}`,
            'stripe-version': '2020-03-02',
          }),
          body: confirmBody,
          proxy,
          fp,
        },
      );
      const piStatus = confirmResp.body?.status || null;
      log(`[upgrade-invoice] confirm_payment HTTP ${confirmResp.status} status=${piStatus}`);

      if (piStatus === 'succeeded' || piStatus === 'processing') {
        return {
          ok: true,
          invoiceId: data.invoiceId,
          paymentIntentId: data.paymentIntentId,
          sourceId,
          piStatus,
          hostedUrl,
        };
      }

      const lastPaymentError = confirmResp.body?.last_payment_error;
      if (lastPaymentError && typeof lastPaymentError === 'object') {
        const errCode = lastPaymentError.code || '';
        const declineCode = lastPaymentError.decline_code || '';
        if (errCode === 'card_declined' || declineCode) {
          throw new Error(`card_declined:${declineCode || errCode}`);
        }
        throw new Error(`invoice 支付失败: ${errCode} ${lastPaymentError.message || ''}`);
      }

      if (confirmResp.status >= 400) {
        const e = confirmResp.body?.error || {};
        const msg = e.message || '';
        if (String(msg).includes('lock_timeout') || String(e.code || '').includes('lock_timeout')) {
          throw Object.assign(new Error(`lock_timeout: ${msg}`), { lockTimeout: true });
        }
        if (e.code === 'card_declined') throw new Error(`card_declined:${msg}`);
        throw new Error(`invoice confirm 失败: ${e.code || ''} ${msg}`.trim());
      }

      if (piStatus === 'requires_payment_method') {
        throw new Error('card_declined:requires_payment_method');
      }
      if (piStatus === 'requires_action') {
        throw new Error('invoice 支付需要 3DS 验证');
      }
      if (!piStatus && confirmResp.status < 300) {
        log('[upgrade-invoice] confirm_payment 无 status，视为成功');
        return {
          ok: true,
          invoiceId: data.invoiceId,
          paymentIntentId: data.paymentIntentId,
          sourceId,
          piStatus: 'unknown',
          hostedUrl,
        };
      }
      throw new Error(`invoice 支付异常: status=${piStatus}`);
    } catch (e) {
      lastErr = e;
      if (e.lockTimeout || /lock_timeout/i.test(e.message || '')) {
        if (attempt < maxConfirmRetries) {
          const wait = attempt * 3000;
          log(`[upgrade-invoice] lock_timeout，${wait}ms 后重试 ${attempt}/${maxConfirmRetries}`);
          await new Promise((r) => setTimeout(r, wait));
          continue;
        }
      }
      throw e;
    }
  }
  throw lastErr || new Error('invoice confirm 失败');
}

/**
 * After subscriptions/update: find a payable hosted invoice and pay it with card.
 * Returns null when no payable invoice (caller treats as auto-paid / already applied).
 */
export async function payUpgradeHostedInvoiceIfNeeded(account, card, {
  knownInvoiceIds = [],
  proxy = null,
  log = () => {},
  retries = 2,
  delayMs = 2000,
  /** 换卡重试时复用已有 hosted URL（Java：卡 swap 跳过重新拉单） */
  hostedInvoiceUrl = null,
  invoiceId = null,
} = {}) {
  if (!card) return { paid: false, reason: 'no_card' };
  const fp = paymentAccountFp(account);
  const reuseUrl = String(hostedInvoiceUrl || '').trim();
  if (reuseUrl) {
    log(`[upgrade-invoice] 复用 hosted_invoice_url 付升级差价 id=${invoiceId || '-'}`);
    const pay = await payHostedUpgradeInvoice(reuseUrl, card, { proxy, fp, log });
    return {
      paid: true,
      payable: { id: invoiceId, hosted_invoice_url: reuseUrl },
      pay,
      reused: true,
      invoices: [],
    };
  }
  let lastScan = null;
  for (let attempt = 1; attempt <= retries; attempt++) {
    const inv = await queryInvoices(account, log, proxy).catch((e) => {
      log(`[upgrade-invoice] 查账单失败: ${e.message}`);
      return null;
    });
    lastScan = inv;
    const payable = pickPayableHostedInvoice(inv?.invoices || [], { knownInvoiceIds });
    if (payable?.hosted_invoice_url) {
      log(`[upgrade-invoice] 发现待付升级账单 ${payable.id || ''} → 走 hosted 付款`);
      const pay = await payHostedUpgradeInvoice(payable.hosted_invoice_url, card, { proxy, fp, log });
      return { paid: true, payable, pay, invoices: inv?.invoices || [] };
    }
    // all paid / zero remaining → Vendor auto-charged
    const list = inv?.invoices || [];
    if (list.length && list.every((i) => !isPayableHostedInvoice(i))) {
      log('[upgrade-invoice] 账单均已结清/无余额 — 视为已自动扣款');
      return { paid: false, autoPaid: true, invoices: list };
    }
    if (attempt < retries) {
      log(`[upgrade-invoice] 暂无待付账单，重试 ${attempt}/${retries}`);
      await new Promise((r) => setTimeout(r, delayMs * attempt));
    }
  }
  log('[upgrade-invoice] 无待付 hosted 账单 — 视为升级已生效或无需再付');
  return { paid: false, autoPaid: true, invoices: lastScan?.invoices || [] };
}
