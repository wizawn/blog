// Vendor Plus→Pro upgrade (preview/update orchestration).
// Extracted from platform.js (zero behavior change).
//
// gpt8.1 HAR（2026-08-01 取消续费+查订阅+plus升级20x）:
//   preview(updated_plan=premium_plan)
//   → POST /subscriptions/renew {"account_id"}   // 若曾 cancel：先恢复 will_renew
//   → POST /subscriptions/update {"account_id","updated_plan":"premium_plan"}
//   → 401 token_expired → /api/auth/session?refresh=true
//   → GET /subscriptions plan=pro
//   →（可选）POST /subscriptions/cancel 关续费
import {
  BASE, PLAN, resolvePaymentPricing, emitPaymentState,
} from './shared.js';
import { refreshAccountSession } from './session.js';
import {
  normalizePlan, querySubscription, queryInvoices, resolveAccountContext,
  reconcilePendingPayment, reconcileAfterProUpgradeResponse,
  pollSubscriptionActivation,
} from './billing.js';
import {
  upgradeRequestHeaders, getCheckoutPricing, paymentAccountFp, stableOaiId,
} from './checkout.js';
import { rechargePhp } from './recharge.js';
import { addPaymentMethod } from './cards.js';
import { ctlsFetch } from './ctls.js';
import { blocksPaymentRetry } from './payment-state.js';
import { amountWithinRange } from './payment-config.js';
import { normalizePaymentRegion, quoteWithinTolerance } from './payment-regions.js';
import {
  isUpgradeSoftFailBody,
  payUpgradeHostedInvoiceIfNeeded,
} from './upgrade-invoice.js';
import { withPaymentProxyGate } from './payment-proxy-gate.js';

// ───── 订阅升级(Plus→Pro，用已绑定的支付方式，无需 hCaptcha/Stripe) ─────
// 抓包结论: Pro 不能直接开通，必须先有 Plus(已绑卡)，再 subscriptions/update。
// 若 Plus 已关续费(will_renew=false)，浏览器会先 renew 再 update。

async function createUpgradeRequestContext(account, proxy = null) {
  // 与直充一致：支付画像 + resolveAccountContext（401 自动 forceRefresh）
  const fp = paymentAccountFp(account);
  const resolved = await resolveAccountContext(account, proxy, fp);
  const accountId = resolved.accountId;
  if (!accountId) throw new Error('无法获取 account_id');
  if (resolved.accessToken && account && typeof account === 'object') {
    account.accessToken = resolved.accessToken;
  }
  const seed = accountId || account?.email || 'default';
  return {
    fp,
    accessToken: resolved.accessToken,
    accountId,
    deviceId: stableOaiId('x-vendor-device-', seed),
    sessionId: stableOaiId('x-vendor-session-', seed),
  };
}

/**
 * 恢复自动续费。gpt8.1：已 cancel 的 Plus 升 Pro 前浏览器会先调此接口。
 * POST /api/v1/subscriptions/renew  body {"account_id"}
 * 成功常返回 {}，随后 GET /subscriptions 可见 will_renew=true。
 */
export async function renewSubscription(account, log = () => {}, proxy = null, context = null) {
  const ctx = context || await createUpgradeRequestContext(account, proxy);
  const path = '/api/v1/subscriptions/renew';
  const resp = await ctlsFetch(`${BASE}${path}`, {
    method: 'POST',
    headers: upgradeRequestHeaders(ctx, path, true),
    ja3: ctx.fp.ja3,
    timeoutMs: 60000,
    body: JSON.stringify({ account_id: ctx.accountId }),
  }, proxy);
  const text = await resp.text().catch(() => '');
  let body = {};
  try { body = text ? JSON.parse(text) : {}; } catch { body = { raw: text.slice(0, 200) }; }
  log(`[subscription-renew] status=${resp.status} body=${JSON.stringify(body).slice(0, 120)}`);
  if (!resp.ok) {
    const err = new Error(`恢复自动续费失败: ${resp.status} ${text.slice(0, 160)}`);
    err.status = resp.status;
    err.code = 'subscription_renew_failed';
    err.body = body;
    throw err;
  }
  return { ok: true, status: resp.status, accountId: ctx.accountId, body };
}

export async function previewUpgrade(account, plan = PLAN.PRO, log = () => {}, proxy = null, context = null) {
  const ctx = context || await createUpgradeRequestContext(account, proxy);
  const path = '/api/v1/subscriptions/update/preview';
  const pv = await ctlsFetch(`${BASE}${path}?account_id=${ctx.accountId}&updated_plan=${plan}`, {
    headers: upgradeRequestHeaders(ctx, path), ja3: ctx.fp.ja3, timeoutMs: 60000,
  }, proxy);
  const body = await pv.json().catch(() => pv.text());
  log(`[DEBUG] upgrade preview status=${pv.status} total=${body?.total_amount}`);
  return { accountId: ctx.accountId, status: pv.status, ok: pv.status === 200, preview: body };
}

export async function doUpgrade(account, plan = PLAN.PRO, log = () => {}, proxy = null, context = null) {
  const ctx = context || await createUpgradeRequestContext(account, proxy);
  const path = '/api/v1/subscriptions/update';
  const r = await ctlsFetch(`${BASE}${path}`, {
    method: 'POST',
    headers: upgradeRequestHeaders(ctx, path, true), ja3: ctx.fp.ja3, timeoutMs: 60000,
    body: JSON.stringify({ account_id: ctx.accountId, updated_plan: plan }),
  }, proxy);
  const body = await r.json().catch(() => r.text());
  log(`[DEBUG] subscriptions/update status=${r.status} resp=${JSON.stringify(body).slice(0, 200)}`);
  // portal: card_declined / payment_method_failed 在 update 时是预期 soft-fail，仍会生成升级账单
  const soft = isUpgradeSoftFailBody(body, r.status);
  const ok = r.status === 200 || soft.alreadyAtTarget || soft.soft;
  return {
    accountId: ctx.accountId,
    status: r.status,
    ok,
    softFail: soft.soft && !soft.alreadyAtTarget,
    alreadyAtTarget: soft.alreadyAtTarget,
    body,
  };
}

export async function upgradeToProViaPlus(account, card, opts = {}, log = () => {}, proxy = null) {
  const run = () => upgradeToProViaPlusInner(account, card, opts, log, proxy);
  if (opts.skipProxyGate) return run();
  return withPaymentProxyGate(proxy, run, { log });
}

async function upgradeToProViaPlusInner(account, card, opts = {}, log = () => {}, proxy = null) {
  const { config: paymentConfig, pricing } = await resolvePaymentPricing(PLAN.PRO, opts);
  const region = normalizePaymentRegion(opts.region?.country || opts.country, opts.region?.currency || opts.currency);
  opts = { ...opts, paymentConfig, region };
  if (blocksPaymentRetry(account, PLAN.PRO)) {
    log('[payment] Pro 已有收费提交/付款凭证，先对账并阻止重复升级扣款');
    return reconcilePendingPayment(account, log, proxy);
  }
  // Step 1: 检查当前套餐，避免重复扣款
  log('Step 1: 检查当前订阅状态…');
  let currentPlan = 'free';
  let plusResult = null;
  try {
    const sub = await querySubscription(account, log, proxy);
    currentPlan = normalizePlan(sub.plan_type);
    log(`当前套餐: ${currentPlan} (原始: ${sub.plan_type})`);
  } catch (e) {
    log(`[WARN] 查询订阅失败，假设未订阅: ${e.message}`);
  }

  if (currentPlan === 'pro') {
    return { ok: true, stage: 'already_pro', completed: true, finalPlan: 'pro', message: '已是 Pro 套餐，无需再次升级' };
  }

  if (currentPlan !== 'plus') {
    // 当前不是 Plus，需要先开通 Plus
    log(`Step 1b: 当前未开通 Plus，先开通 Plus(${region.country}/${region.currency})…`);
    // Pro 编排需要尽快看到 plus：短同步对账（避免 defer 直接 pending 短路整单）
    plusResult = await rechargePhp(account, card, {
      ...opts,
      plan: PLAN.PLUS,
      waitForSubscription: true,
      deferReconciliation: false,
    }, log, proxy);
    if (!plusResult.ok && !plusResult.paymentConfirmed && !plusResult.paymentEvidence?.confirmed) {
      return { ok: false, stage: 'plus_failed', retryPayment: true, message: '开通 Plus 失败，可绑新卡设为默认后重试', plusResult };
    }
    log(plusResult.paymentConfirmed || plusResult.paymentEvidence?.confirmed
      ? 'Plus 扣款成功 ✓，核对订阅查询…'
      : 'Plus 流程结束，核对订阅查询…');
    // waitForSubscription 路径已在 finishSuccessfulCheckout 做过 1 次 post_payment 刷新；
    // 对齐 Java：此处不再连刷，直接长 poll（401 时 poll 内最多再刷 1 次）。
    if (account?.sessionToken && opts.skipSessionRefresh !== true
      && !(plusResult?.paymentConfirmed || plusResult?.paymentEvidence?.confirmed)) {
      await refreshAccountSession(account, {
        proxy, log, reason: 'plus_checkout_complete', attempts: 1,
      });
    } else {
      log('[upgrade] Plus 已付：跳过重复 forceRefresh，进入长 poll');
    }
    currentPlan = normalizePlan(plusResult.finalPlan || 'free');
    // 对齐 Java PollStep full：accounts/check 长轮询等 plus，勿 3×2.5s 就 subscription_query_stale
    if (currentPlan === 'free' || currentPlan === '') {
      const polled = await pollSubscriptionActivation(account, PLAN.PLUS, {
        mode: 'full', proxy, log,
        allowAuthRefresh: opts.skipSessionRefresh !== true,
      });
      currentPlan = normalizePlan(polled.finalPlan || 'free');
      log(`[upgrade] 长 poll 结束 activated=${polled.activated} plan=${currentPlan}`
        + (polled.lastError ? ` err=${String(polled.lastError).slice(0, 80)}` : ''));
    }
  } else {
    log('已有 Plus 订阅，跳过开通 Plus…');
    // 已有 Plus:若提供新卡,先绑卡+设默认。因 subscriptions/update 只扣「默认卡」,
    // 不绑的话会用账号上开 Plus 时的旧默认卡(可能已失效)。绑+设默认后升级即扣新卡。
    if (card && opts.attachCard !== false) {
      try {
        log('提供了新卡 → 绑卡 + 设为默认(升级将扣这张卡)…');
        const added = await addPaymentMethod(account, card, opts, log, proxy);
        log(`新卡已绑定并设为默认: *${added.last4}`);
      } catch (e) {
        log(`[upgrade] 绑新卡失败: ${e.message}`);
        return { ok: false, stage: 'attach_card_failed', retryPayment: true, message: '绑新卡失败，请更换卡片后重试' };
      }
    }
  }

  // 已扣款但订阅查询仍 free：多半官方查询滞后/异常 — 禁止空转对账，提示手升 Pro
  const plusPaid = !!(plusResult?.paymentConfirmed || plusResult?.paymentEvidence?.confirmed
    || plusResult?.paymentIntent || plusResult?.paymentEvidence?.paymentIntent);
  if (currentPlan !== 'plus' && currentPlan !== 'pro' && currentPlan !== 'prolite') {
    if (plusPaid) {
      // 对齐 Java AMBIGUOUS：支付已成功、激活确认超时；勿伪装 Pro 完成
      const msg = '支付已成功但订阅激活确认超时（官方查询仍 free）。请登录 Platform 核实套餐；勿重复自动扣款。Pro 请手动升级或人工处理。';
      log(`[upgrade] ${msg}`);
      const fail = {
        ok: false,
        completed: false, // engineResultPatch 会按 stage 升为 completed + 人工 Pro
        stage: 'plus_paid_manual_pro_required',
        code: 'subscription_query_stale',
        paymentConfirmed: true,
        subscriptionPending: false,
        retryPayment: false,
        pendingPlan: null,
        finalPlan: currentPlan || 'plus',
        paymentEvidence: plusResult?.paymentEvidence || null,
        billing: plusResult?.billing || null,
        paymentIntent: plusResult?.paymentIntent || plusResult?.paymentEvidence?.paymentIntent || null,
        checkoutSessionId: plusResult?.checkoutSessionId || plusResult?.paymentEvidence?.checkoutSessionId || null,
        amount: plusResult?.amount ?? plusResult?.paymentEvidence?.amount,
        currency: plusResult?.currency || plusResult?.paymentEvidence?.currency,
        // 交付最新 cookie（poll 过程可能轮换）
        sessionToken: account?.sessionToken || undefined,
        accessToken: account?.accessToken || undefined,
        message: msg,
        plusResult,
      };
      await emitPaymentState(opts, fail);
      return fail;
    }
    return {
      ok: false, stage: 'plus_failed', retryPayment: true,
      message: '开通 Plus 后套餐未生效且未见扣款凭证，可换卡重试',
      plusResult,
    };
  }

  // gpt8.1 浏览器顺序: preview → (若已 cancel 则 renew) → update。
  // preview 同时确认应付金额和默认支付方式。
  log('Step 2: 获取 Pro 升级预览…');
  const beforeInvoices = await queryInvoices(account, () => {}, proxy).catch(() => ({ invoices: [] }));
  const knownInvoiceIds = (beforeInvoices.invoices || []).map((invoice) => invoice.id).filter(Boolean);
  const requestContext = await createUpgradeRequestContext(account, proxy);
  // 再读一次 will_renew（前面可能只取了 plan_type）
  let subSnap = null;
  try {
    subSnap = await querySubscription(account, log, proxy);
  } catch (e) {
    log(`[upgrade] 升级前订阅快照失败: ${e.message}`);
  }
  const preview = await previewUpgrade(account, PLAN.PRO, log, proxy, requestContext);
  if (!preview.ok) {
    log(`[upgrade] 预览失败 status=${preview.status} body=${JSON.stringify(preview.preview).slice(0, 300)}`);
    return {
      ok: false, stage: 'upgrade_preview_failed', retryPayment: true,
      message: '升级校验未通过，未扣款；可绑新卡设为默认后重试',
      plusResult, preview,
    };
  }
  if (preview.preview?.default_payment_method === null && Number(preview.preview?.amount_due?.amount ?? preview.preview?.total_amount) > 0) {
    return { ok: false, stage: 'no_default_payment_method', retryPayment: true, message: '升级没有可用的默认支付方式，未扣款；请绑新卡设为默认后重试', plusResult, preview };
  }

  const previewAmount = Number(preview.preview?.amount_due?.amount ?? preview.preview?.total_amount);
  const previewCurrency = String(preview.preview?.currency || region.currency).toUpperCase();
  const proQuote = await getCheckoutPricing(account, PLAN.PRO, region, log, proxy);
  const allowedUpgrade = region.country === 'PH'
    ? amountWithinRange(previewAmount, pricing, 'upgrade')
    : Number.isSafeInteger(previewAmount) && previewAmount > 0 && previewAmount <= Math.ceil(proQuote.amountMinor * 1.05);
  if (previewCurrency !== region.currency || !allowedUpgrade) {
    return {
      ok: false, completed: false, stage: 'failed_precharge', retryPayment: true,
      code: 'upgrade_quote_out_of_range',
      message: `Pro 实时升级金额 ${Number.isFinite(previewAmount) ? previewAmount : 'unknown'} ${previewCurrency} 超出安全范围，未提交扣款`,
      plusResult, preview,
    };
  }
  const plusOrderAmount = Number(plusResult?.amount || plusResult?.paymentEvidence?.amount || 0);
  const totalPreviewAmount = plusOrderAmount + previewAmount;
  const allowedTotal = region.country === 'PH'
    ? amountWithinRange(totalPreviewAmount, pricing)
    : !plusResult || quoteWithinTolerance(totalPreviewAmount, proQuote.amountMinor, 1000);
  if (!allowedTotal) {
    return {
      ok: false, completed: false, stage: 'failed_precharge', retryPayment: true,
      code: 'total_quote_out_of_range',
      message: `Plus 与 Pro 实时合计金额 ${totalPreviewAmount} ${region.currency} 超出安全范围，未提交 Pro 扣款`,
      plusResult, preview,
    };
  }

  // 已关自动续费的 Plus：HAR 在 update 前必调 renew，否则差价升级可能异常
  const needRenew = subSnap
    && (subSnap.will_renew === false || String(subSnap.cancellation_outcome || '') === 'deactivate');
  if (needRenew && opts.skipRenewBeforeUpgrade !== true) {
    log('Step 2b: 检测到 will_renew=false / 已 cancel → POST /subscriptions/renew 恢复续费后再升级…');
    try {
      await renewSubscription(account, log, proxy, requestContext);
    } catch (e) {
      log(`[upgrade] renew 失败: ${e.message}`);
      return {
        ok: false,
        stage: 'subscription_renew_failed',
        retryPayment: true,
        message: '账号已关闭自动续费，恢复续费失败，未提交 Pro 升级；请稍后重试或手开续费后再升',
        plusResult,
        preview,
        error: e.message,
      };
    }
  }

  log(`Step 3: 单次提交 Pro 升级，应付 ${preview.preview?.total_amount ?? '?'} ${preview.preview?.currency || ''}…`);
  const submittedAt = Date.now();
  await emitPaymentState(opts, {
    ok: true, completed: false, stage: 'submitted_pending_reconciliation',
    subscriptionPending: true, retryPayment: false, pendingPlan: 'pro', finalPlan: 'plus',
    paymentEvidence: {
      confirmed: false, source: 'upgrade_submission', submittedAt, plan: 'pro',
      amount: previewAmount, currency: previewCurrency,
    },
  });
  let upgrade = null;
  let submissionError = null;
  try {
    upgrade = await doUpgrade(account, PLAN.PRO, log, proxy, requestContext);
  } catch (e) {
    submissionError = e;
    log(`[WARN] Pro 提交结果不确定: ${e.message};先对账，禁止直接重试收费请求`);
  }

  // sub_update 后强制 refresh（Java：失败则停止拉账单；这里至少刷 AT 再对账/拉 invoice）
  if (account?.sessionToken && opts.skipSessionRefresh !== true) {
    const upRefresh = await refreshAccountSession(account, {
      proxy, log, reason: 'subscription_update', attempts: 1, requireRotated: false,
    });
    if (!upRefresh.ok && !upRefresh.skipped) {
      log(`[upgrade] session_refresh after sub_update 未成功: ${upRefresh.reason || 'unknown'}，继续对账兜底`);
    }
  }

  // 默认卡自动扣款成功路径（短对账）
  let reconciled = await reconcileAfterProUpgradeResponse(
    account, knownInvoiceIds, submittedAt, upgrade?.ok === true && !upgrade?.softFail, opts, log, proxy,
  );

  // portal 路径：update soft-fail / 未激活时，拉 hosted_invoice 用当前卡付升级差价
  // 换卡重试可传入 opts.reuseHostedInvoiceUrl（对齐 Java：卡 swap 跳过 sub_update 直付同一 invoice）
  let hostedPay = null;
  if (!reconciled.activated && !reconciled.paidInvoice && card && opts.hostedInvoicePay !== false) {
    try {
      log('Step 3b: 默认卡未自动结清 → 尝试 hosted 升级账单付款(portal Pro 路径)…');
      hostedPay = await payUpgradeHostedInvoiceIfNeeded(account, card, {
        knownInvoiceIds,
        proxy,
        log,
        hostedInvoiceUrl: opts.reuseHostedInvoiceUrl || opts.hostedInvoiceUrl || null,
        invoiceId: opts.reuseInvoiceId || null,
      });
      if (hostedPay?.paid || hostedPay?.autoPaid) {
        reconciled = await reconcileAfterProUpgradeResponse(
          account, knownInvoiceIds, submittedAt, true, {
            ...opts,
            // hosted 付完再给一轮短对账
            upgradeReconcileDelaysMs: opts.upgradeReconcileDelaysMs || [5_000, 15_000, 25_000],
          }, log, proxy,
        );
      }
    } catch (e) {
      log(`[upgrade-invoice] hosted 付款失败: ${e.message}`);
      hostedPay = { paid: false, error: e.message };
    }
  }

  const common = {
    plusAmount: plusResult?.amount || 0, plusCurrency: plusResult?.currency || 'PHP',
    skippedPlus: !plusResult, billing: plusResult?.billing || null,
    plusResult, preview, upgrade, hostedPay,
  };

  // 1) 对账已见 Pro
  if (reconciled.activated) {
    const result = {
      ok: true, completed: true, stage: 'done', finalPlan: 'pro',
      paymentEvidence: {
        confirmed: true,
        source: hostedPay?.paid
          ? 'hosted_invoice'
          : (reconciled.paidInvoice ? 'paid_invoice' : 'subscription'),
        confirmedAt: Date.now(), plan: 'pro',
        invoiceId: hostedPay?.pay?.invoiceId || reconciled.paidInvoice?.id || null,
        amount: preview.preview?.total_amount ?? previewAmount,
        currency: preview.preview?.currency || previewCurrency,
      },
      ...common,
    };
    await emitPaymentState(opts, result);
    return result;
  }

  // 2) 账单已付但 plan 尚未同步
  if (reconciled.paidInvoice || hostedPay?.paid) {
    const result = {
      ok: true, completed: false, stage: 'paid_pending_subscription',
      subscriptionPending: true, retryPayment: false, pendingPlan: 'pro', finalPlan: 'plus',
      paymentEvidence: {
        confirmed: true,
        source: hostedPay?.paid ? 'hosted_invoice' : 'paid_invoice',
        confirmedAt: Date.now(), plan: 'pro',
        invoiceId: hostedPay?.pay?.invoiceId || reconciled.paidInvoice?.id || null,
        amount: preview.preview?.total_amount ?? previewAmount,
        currency: preview.preview?.currency || previewCurrency,
      },
      message: 'Pro 升级账单已付款，但订阅仍显示 Plus；已禁止再次扣款，请稍后对账。',
      ...common,
    };
    await emitPaymentState(opts, result);
    return result;
  }

  // 3) 已在目标档 / 无待付账单（portal auto-paid）
  if (upgrade?.alreadyAtTarget || hostedPay?.autoPaid) {
    const result = {
      ok: true, completed: true, stage: 'done', finalPlan: 'pro',
      paymentEvidence: {
        confirmed: true, source: 'upgrade_auto_paid', confirmedAt: Date.now(), plan: 'pro',
        amount: preview.preview?.total_amount ?? previewAmount,
        currency: preview.preview?.currency || previewCurrency,
      },
      message: '升级已生效（无待付账单/已在目标档）',
      ...common,
    };
    await emitPaymentState(opts, result);
    return result;
  }

  // 4) update 硬成功且非 soft-fail（默认卡即时扣成功但 plan 查询滞后）
  if (upgrade?.ok === true && !upgrade?.softFail && !submissionError) {
    const result = {
      ok: true, completed: true, stage: 'done', finalPlan: 'pro',
      paymentEvidence: {
        confirmed: true, source: 'upgrade_response', confirmedAt: Date.now(), plan: 'pro',
        amount: preview.preview?.total_amount ?? previewAmount,
        currency: preview.preview?.currency || previewCurrency,
      },
      ...common,
    };
    await emitPaymentState(opts, result);
    return result;
  }

  if (submissionError) {
    const result = {
      ok: true, completed: false, stage: 'submitted_pending_reconciliation',
      subscriptionPending: true, retryPayment: false, pendingPlan: 'pro', finalPlan: 'plus',
      paymentEvidence: {
        confirmed: false, source: 'upgrade_submission', submittedAt, plan: 'pro',
        amount: previewAmount, currency: previewCurrency,
      },
      message: 'Pro 升级响应不确定；已保留付款状态，系统将只做自动对账。',
      ...common, submissionError: submissionError.message,
    };
    await emitPaymentState(opts, result);
    return result;
  }

  log(`[upgrade] 被拒 status=${upgrade?.status} body=${JSON.stringify(upgrade?.body).slice(0, 300)} hosted=${hostedPay?.error || '-'}`);
  const result = {
    ok: false, stage: 'upgrade_rejected', retryPayment: true,
    message: hostedPay?.error
      ? `升级账单付款失败: ${hostedPay.error}`
      : '升级扣款失败，可绑新卡设为默认后重试',
    // 换卡重试时可把 URL 回传：opts.reuseHostedInvoiceUrl
    reuseHostedInvoiceUrl: hostedPay?.payable?.hosted_invoice_url
      || hostedPay?.pay?.hostedUrl
      || null,
    reuseInvoiceId: hostedPay?.payable?.id || hostedPay?.pay?.invoiceId || null,
    ...common,
  };
  await emitPaymentState(opts, result);
  return result;
}
