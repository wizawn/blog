// SpaceX Card 开放 API 客户端
// Base URL: https://virtual-card.com/openapi/v1
// 文档: 资料/virtual-card-openapi.md

const PRIMARY_BASE = process.env.VIRTUAL_CARD_BASE_URL || 'https://virtual-card.com/openapi/v1';
const FALLBACK_BASE = process.env.VIRTUAL_CARD_FALLBACK_BASE_URL
  ?? (process.env.VIRTUAL_CARD_BASE_URL ? '' : 'https://virtual-card.org/openapi/v1');
const BASES = [...new Set([PRIMARY_BASE, FALLBACK_BASE].map(v => v.trim()).filter(Boolean))];
const API_KEY = process.env.VIRTUAL_CARD_API_KEY || 'sk_YOUR_API_KEY';

class CloudflareBlockError extends Error {}

async function request(base, method, path, body, idempotencyKey) {
  const headers = { 'X-API-Key': API_KEY, 'Accept': 'application/json', 'Content-Type': 'application/json' };
  if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);
  const res = await fetch(`${base}${path}`, opts);
  const text = await res.text();
  const contentType = res.headers.get('content-type') || '';
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    const ray = res.headers.get('cf-ray');
    if (res.status === 403 && contentType.includes('text/html')) {
      throw new CloudflareBlockError(`SpaceX API Cloudflare 入口封禁: HTTP 403${ray ? ` cf-ray=${ray}` : ''}`);
    }
    throw new Error(`SpaceX API 非 JSON 响应(${contentType || 'unknown content-type'}): HTTP ${res.status}${ray ? ` cf-ray=${ray}` : ''}`);
  }
  if (!res.ok) throw new Error(data.msg || `SpaceX API HTTP ${res.status}`);
  if (data.code !== 0) throw new Error(data.msg || `SpaceX API error (code ${data.code})`);
  return data.data;
}

async function sx(method, path, body, idempotencyKey) {
  for (let i = 0; i < BASES.length; i++) {
    try {
      return await request(BASES[i], method, path, body, idempotencyKey);
    } catch (error) {
      const cloudflareBlocked = error instanceof CloudflareBlockError;
      const safeGetFallback = method === 'GET' && error?.name === 'TypeError';
      if ((!cloudflareBlocked && !safeGetFallback) || i === BASES.length - 1) throw error;
    }
  }
  throw new Error('SpaceX API 未配置可用地址');
}

export const getBalance = () => sx('GET', '/balance');
export const getVip = () => sx('GET', '/vip');
export const getProducts = () => sx('GET', '/products');
export const getCards = (page = 1, size = 50) => sx('GET', `/cards?page=${page}&page_size=${size}`);
export const getCard = (id) => sx('GET', `/cards/${id}`);
export const openCard = (body, ikey) => sx('POST', '/cards/open', body, ikey);
export const rechargeCard = (cardId, amount, ikey) => sx('POST', '/cards/recharge', { card_id: Number(cardId), amount }, ikey);
export const refundCard = (cardId, amount) => sx('POST', '/cards/refund', { card_id: Number(cardId), amount });
export const freezeCard = (cardId, freeze) => sx('POST', '/cards/freeze', { card_id: Number(cardId), freeze: !!freeze });
export const deleteCard = (id) => sx('DELETE', `/cards/${id}`);
export const getTransactions = (id, page = 1, size = 50) => sx('GET', `/cards/${id}/transactions?page=${page}&page_size=${size}`);
export const getVendorPayments = (id) => sx('GET', `/cards/${id}/vendor-payments`);
export const getBalanceLogs = (page = 1, size = 20) => sx('GET', `/balance-logs?page=${page}&page_size=${size}`);

// 扫描已有卡的 Vendor 消费记录，取最新 Pro 20x (x20 tier, $140-$160) 扣款金额
export async function getProX20Price() {
  try {
    const { list } = await getCards(1, 20);
    for (const card of (list || [])) {
      try {
        const payments = await getVendorPayments(card.id);
        const x20 = (payments || []).find(p => p.tier === 'x20' && p.found && p.amount > 0);
        if (x20) return x20.amount;
      } catch { continue; }
    }
  } catch {}
  return 150; // fallback: Pro 20x 标准价
}

// 解析 "MM/YY" expire → { expMonth, expYear }
export function parseExpire(expire) {
  const [m, y] = (expire || '').split('/');
  return { expMonth: (m || '').trim(), expYear: (y || '').trim() };
}
