# saas-pay-sdk

A Python SDK for automating SaaS subscription checkout flows via the Stripe
payment protocol. It communicates directly over HTTP with the target platform's
billing API and Stripe, without launching a browser.

> **Warning**: This is a payment execution tool. Real charges only occur when
> `commitPayments` is explicitly set to `true`.

## How It Works

1. Read task configuration from `config.json` and verify the account's
   entitlement to prevent duplicate purchases.
2. Query the checkout currency for the target country.
3. Create a checkout session through the platform's billing API and submit
   billing details.
4. Generate a one-time Stripe confirmation token with the provided card.
5. Obtain the PaymentIntent client secret from the platform.
6. Confirm the PaymentIntent only when `commitPayments=true`.
7. Verify the subscription is active; optionally upgrade the plan tier.
8. Cancel auto-renewal and report the result to the callback endpoint.

A `checkout-link` mode is also available: it creates a hosted Stripe checkout
URL that can be opened in a browser for manual payment, without reading card
data or entering the automated payment flow.

## Project Structure

```text
saas_pay/
├── cli.py              # CLI entry point
├── worker.py           # Task execution and result classification
├── payment_flow.py     # Payment state machine
├── platform_client.py  # Platform account, checkout, and subscription APIs
├── stripe_client.py    # Stripe token and PaymentIntent
├── callback_client.py  # Result reporting to callback endpoint
├── http_client.py      # HTTP client with cookie isolation and error handling
├── proxy.py            # HTTP/SOCKS proxy with exit-country verification
├── session.py          # Session token parsing and cookie generation
└── har_inspector.py    # HAR sanitization and inspection
```

## Installation

Requires Python 3.11 or later.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -e .
cp config.example.json config.json
```

Dependencies are managed via `pyproject.toml`. `requests[socks]` provides
HTTP, HTTPS, SOCKS4, SOCKS5, and SOCKS5h proxy support.

## Configuration

See `config.example.json` for a complete example.

| Field | Description |
| --- | --- |
| `planType` | Target plan tier, e.g. `basic`, `premium` |
| `proxyUrl` | Required HTTP/HTTPS/SOCKS proxy URL |
| `sessionJson` | Platform login session object (access token + session token) |
| `card` | Card number, expiry (MM/YY), and CVC |
| `billing` | Cardholder name and billing address |
| `commitPayments` | `false` stops before charging; `true` submits real payment |

`workerId` and `taskId` are auto-generated on each run. `planName` is derived
from `planType`. The proxy has no default value; the program refuses to start
without one and never falls back to a direct connection.

### Environment Variables

```bash
export CALLBACK_URL='http://127.0.0.1:3001'
export CALLBACK_API_KEY='...'
export WORKER_COUNTRY='US'
export UPSTREAM_PROXY_URL='socks5h://username:password@127.0.0.1:10801'
export PROXY_EXPECTED_COUNTRY='US'
export STRIPE_PUBLISHABLE_KEY='pk_...'
export COMMIT_PAYMENTS=1
```

Environment variables take precedence over `config.json`. The config file
contains sensitive account and card data; set `chmod 600 config.json` and
never commit it to version control.

## Usage

```bash
# Execute the configured task once
saas-pay-sdk once --config /path/to/config.json

# Same as once; prevents duplicate payments
saas-pay-sdk start --config /path/to/config.json

# Generate a hosted checkout link without reading card data
saas-pay-sdk checkout-link --config /path/to/config.json

# Verify proxy exit country
saas-pay-sdk proxy-check --config /path/to/config.json

# Inspect a HAR file (sanitized output, no sensitive values)
saas-pay-sdk inspect-har /path/to/capture.har
```

Or run as a module without installing the CLI script:

```bash
python -m saas_pay once --config ./config.json
```

## Safety

- Default `commitPayments=false` -- no PaymentIntent is confirmed.
- Dry-run still creates a checkout and sends the card to Stripe for
  tokenization; it is not an offline simulation.
- Platform and Stripe use separate HTTP sessions; Stripe requests never
  carry platform cookies.
- Proxy failure never falls back to a direct connection.
- Existing active subscriptions are detected and block duplicate purchases.
- External checkout sessions (`cs_` prefix) are treated as high-risk and
  abort before sending any card data.
- Card declines are reported to the callback endpoint. Unknown post-payment
  states are reported as `suspicious`.

## Testing

Unit tests use only the Python standard library `unittest`:

```bash
python -m unittest discover -s tests -v
```

Integration tests are skipped by default. With a valid `config.json`:

```bash
SAAS_PAY_RUN_INTEGRATION=1 python -m unittest tests.test_integration -v
```

Integration tests only check proxy, session, account, and currency -- they
do not submit payments.
