from __future__ import annotations

import time
from typing import Any
from urllib.parse import quote

from .config import Config
from .http_client import HttpClient


class CallbackClient:
    def __init__(self, config: Config, http: HttpClient | None = None) -> None:
        self.config = config
        self.base = config.callback_url.rstrip("/")
        self.http = http or HttpClient(timeout_ms=config.request_timeout_ms)
        self.active_task: dict[str, Any] | None = None
        self.status = ""

    def headers(self) -> dict[str, str]:
        headers = {
            "x-worker-id": self.config.worker_id,
            "x-worker-country": self.config.country,
        }
        if self.config.api_key:
            headers["authorization"] = f"Bearer {self.config.api_key}"
        if self.active_task and self.active_task.get("taskId"):
            headers["x-task-id"] = str(self.active_task["taskId"])
            if self.status:
                headers["x-task-status"] = self.status
        return headers

    def request(self, method: str, path: str, body: Any = None) -> Any:
        return self.http.request(
            f"{self.base}{path}",
            method=method,
            headers=self.headers(),
            json_body=body,
        ).data

    def activate(self, task: dict[str, Any]) -> None:
        self.active_task = task

    def set_status(self, status: str) -> None:
        self.status = status

    def clear(self) -> None:
        self.active_task = None
        self.status = ""

    def done(self, task_id: str, body: dict[str, Any]) -> Any:
        return self.request("POST", f"/task/{quote(task_id, safe='')}/done", body)

    def fail(self, task_id: str, reason: str) -> Any:
        return self.request(
            "POST",
            f"/task/{quote(task_id, safe='')}/fail",
            {"reason": reason, "reactivateCdk": True},
        )

    def card_retry(self, task_id: str, reason: str, session_json: str) -> Any:
        return self.request(
            "POST",
            f"/task/{quote(task_id, safe='')}/card-retry",
            {"reason": reason, "sessionJson": session_json},
        )

    def suspicious(
        self,
        task: dict[str, Any],
        error: BaseException,
        card_number: str,
    ) -> Any:
        return self.request(
            "POST",
            f"/task/{quote(str(task['taskId']), safe='')}/suspicious",
            {
                "taskId": task["taskId"],
                "planType": task.get("planType"),
                "country": task.get("country", ""),
                "cardLast4": str(card_number)[-4:] or "????",
                "status": self.status,
                "reason": f"[{getattr(error, 'code', 'protocol_error')}] {error}",
                "failedAt": int(time.time() * 1000),
                "workerId": self.config.worker_id[:16],
            },
        )

    def recharge_upgrade(self, task_id: str) -> Any:
        return self.request(
            "POST",
            f"/task/{quote(task_id, safe='')}/recharge-upgrade",
            {},
        )


class DisabledCallbackClient:
    """No-op reporter used by standalone config-driven runs."""

    def __init__(self) -> None:
        self.active_task: dict[str, Any] | None = None
        self.status = ""

    def activate(self, task: dict[str, Any]) -> None:
        self.active_task = task

    def set_status(self, status: str) -> None:
        self.status = status

    def clear(self) -> None:
        self.active_task = None
        self.status = ""

    def done(self, task_id: str, body: dict[str, Any]) -> None:
        del task_id, body

    def fail(self, task_id: str, reason: str) -> None:
        del task_id, reason

    def card_retry(self, task_id: str, reason: str, session_json: str) -> None:
        del task_id, reason, session_json

    def suspicious(
        self,
        task: dict[str, Any],
        error: BaseException,
        card_number: str,
    ) -> None:
        del task, error, card_number

    def recharge_upgrade(self, task_id: str) -> None:
        del task_id
