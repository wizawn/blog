from __future__ import annotations

import argparse
import json
import logging
import signal
from pathlib import Path

from .config import load_config
from .har_inspector import inspect_har
from .worker import ProtocolWorker


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="saas-pay-sdk")
    parser.add_argument(
        "command",
        nargs="?",
        default="once",
        choices=("start", "once", "checkout-link", "proxy-check", "inspect-har"),
    )
    parser.add_argument("file", nargs="?", help="inspect-har 使用的 HAR 文件")
    parser.add_argument("--config", help="配置文件路径")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] %(levelname)s %(message)s",
    )
    if args.command == "inspect-har":
        if not args.file:
            build_parser().error("inspect-har 需要 HAR 文件路径")
        inspect_har(Path(args.file))
        return 0

    config = load_config(args.config)
    worker = ProtocolWorker(config)
    signal.signal(signal.SIGINT, lambda _signum, _frame: worker.stop())
    signal.signal(signal.SIGTERM, lambda _signum, _frame: worker.stop())

    if args.command == "start":
        worker.start()
        return 0
    if args.command == "once":
        result = worker.once()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if result.get("status") == "completed":
            print("\n✅ 订阅 + 取消自动续费完成")
            print("📄 新 session 已保存到 .session_refreshed.json")
            print("   把其中的 accessToken 复制到 config.json 的 sessionJson 中即可复用")
        return 0
    if args.command == "checkout-link":
        result = worker.checkout_link()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        checkout_url = result.get("checkoutUrl", "")
        if checkout_url:
            print(f"\nPlatform 支付链接: {checkout_url}")
        hosted_url = result.get("hostedUrl", "")
        if hosted_url:
            print(f"Stripe 托管链接: {hosted_url}")
        return 0
    if args.command == "proxy-check":
        if worker.proxy_verifier is None:
            raise RuntimeError("当前没有配置代理；请设置 proxyUrl 或 UPSTREAM_PROXY_URL")
        result = worker.proxy_verifier.verify(force=True)
        print(
            json.dumps(
                {
                    "proxy": worker.transport.label,
                    "exitIp": result.get("ip", ""),
                    "country": result.get("country", ""),
                    "region": result.get("region", ""),
                    "detectedProxy": result.get("detectedProxy"),
                    "hosting": result.get("hosting"),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    return 2
