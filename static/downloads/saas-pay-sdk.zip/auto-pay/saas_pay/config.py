from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .errors import ProtocolError
from .utils import random_id

DEFAULT_STRIPE_PUBLISHABLE_KEY = "pk_live_YOUR_STRIPE_KEY_HERE"

PLAN_NAME_BY_TYPE = {
    "basic": "basic_plan",
    "premium": "premium_plan",
}


@dataclass(slots=True)
class Config:
    callback_url: str = ""
    api_key: str = ""
    worker_id: str = field(
        default_factory=lambda: f"protocol-{random_id()[:8]}",
        init=False,
    )
    task_id: str = field(
        default_factory=lambda: f"local-{random_id()[:8]}",
        init=False,
    )
    plan_type: str = ""
    country: str = "PH"
    proxy_url: str = ""
    proxy_expected_country: str = ""
    proxy_check_interval_ms: int = 60_000
    proxy_check_timeout_ms: int = 10_000
    request_timeout_ms: int = 20_000
    stripe_publishable_key: str = DEFAULT_STRIPE_PUBLISHABLE_KEY
    session_json: str | dict[str, Any] = field(default_factory=dict, repr=False)
    card: dict[str, Any] = field(default_factory=dict, repr=False)
    billing: dict[str, Any] = field(default_factory=dict, repr=False)
    commit_payments: bool = False
    verify_attempts: int = 12
    verify_interval_ms: int = 10_000
    cancel_initial_delay_ms: int = 0
    cancel_attempts: int = 5
    cancel_retry_interval_ms: int = 2_000
    tls_impersonate: str = "chrome131"
    tls_rotation: bool = True
    tls_rotation_pool: str = ""

    def task(self) -> dict[str, str]:
        plan_type = self.plan_type.strip().lower()
        country = self.country.strip().upper()
        missing = []
        if not plan_type:
            missing.append("planType")
        if not country:
            missing.append("country")
        if missing:
            raise ProtocolError(
                "config_invalid",
                f"配置缺少任务字段: {', '.join(missing)}",
            )

        plan_name = PLAN_NAME_BY_TYPE.get(plan_type, "")
        if not plan_name:
            raise ProtocolError(
                "config_invalid",
                f"不支持的 planType: {plan_type}",
            )
        values = {
            "taskId": self.task_id.strip(),
            "planType": plan_type,
            "planName": plan_name,
            "country": country,
        }
        return values


def _int(value: Any, default: int) -> int:
    return int(default if value is None or value == "" else value)


def _env_bool(name: str, fallback: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return fallback
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _object(value: Any, name: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise ValueError(f"配置项 {name} 必须是 JSON 对象")
    return dict(value)


def _session(value: Any) -> str | dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, (str, dict)):
        raise ValueError("配置项 sessionJson 必须是 JSON 对象或 JSON 字符串")
    return dict(value) if isinstance(value, dict) else value


def load_config(file: str | Path | None = None) -> Config:
    resolved = Path(file or os.getenv("SAAS_PAY_SDK_CONFIG", "./config.json")).expanduser()
    source: dict[str, Any] = {}
    if resolved.exists():
        source = json.loads(resolved.read_text(encoding="utf-8"))

    return Config(
        callback_url=os.getenv("CALLBACK_URL", source.get("callbackUrl", "")),
        api_key=os.getenv("CALLBACK_API_KEY", source.get("apiKey", "")),
        plan_type=str(source.get("planType", "")),
        country=os.getenv("WORKER_COUNTRY", source.get("country", "PH")),
        proxy_url=os.getenv("UPSTREAM_PROXY_URL", source.get("proxyUrl", "")),
        proxy_expected_country=os.getenv(
            "PROXY_EXPECTED_COUNTRY", source.get("proxyExpectedCountry", "")
        ),
        proxy_check_interval_ms=_int(source.get("proxyCheckIntervalMs"), 60_000),
        proxy_check_timeout_ms=_int(source.get("proxyCheckTimeoutMs"), 10_000),
        request_timeout_ms=_int(source.get("requestTimeoutMs"), 20_000),
        stripe_publishable_key=os.getenv(
            "STRIPE_PUBLISHABLE_KEY",
            source.get("stripePublishableKey") or DEFAULT_STRIPE_PUBLISHABLE_KEY,
        ),
        session_json=_session(source.get("sessionJson")),
        card=_object(source.get("card"), "card"),
        billing=_object(source.get("billing"), "billing"),
        commit_payments=_env_bool("COMMIT_PAYMENTS", source.get("commitPayments") is True),
        verify_attempts=_int(source.get("verifyAttempts"), 8),
        verify_interval_ms=_int(source.get("verifyIntervalMs"), 5_000),
        cancel_initial_delay_ms=_int(source.get("cancelInitialDelayMs"), 8_000),
        cancel_attempts=_int(source.get("cancelAttempts"), 5),
        cancel_retry_interval_ms=_int(source.get("cancelRetryIntervalMs"), 5_000),
        tls_impersonate=os.getenv(
            "TLS_IMPERSONATE", source.get("tlsImpersonate", "chrome131")
        ),
        tls_rotation=_env_bool("TLS_ROTATION", source.get("tlsRotation", True)),
        tls_rotation_pool=os.getenv(
            "TLS_ROTATION_POOL", source.get("tlsRotationPool", "")
        ),
    )
