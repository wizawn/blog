from __future__ import annotations

from typing import Any


class ProtocolError(Exception):
    def __init__(
        self,
        code: str,
        message: str,
        *,
        retryable: bool = False,
        payment_submitted: bool = False,
        http_status: int = 0,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code or "protocol_error"
        self.retryable = retryable
        self.payment_submitted = payment_submitted
        self.http_status = http_status
        self.details = details


class HttpError(ProtocolError):
    def __init__(
        self,
        status: int,
        message: str,
        *,
        code: str = "http_error",
        response_body: Any = None,
        retryable: bool | None = None,
    ) -> None:
        super().__init__(
            code,
            message,
            http_status=status,
            retryable=status >= 500 if retryable is None else retryable,
        )
        self.response_body = response_body


def is_card_decline(error: BaseException) -> bool:
    return isinstance(error, ProtocolError) and error.code in {
        "payment_declined",
        "card_declined",
    }

