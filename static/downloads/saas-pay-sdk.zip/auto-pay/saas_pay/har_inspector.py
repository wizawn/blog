from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qsl, urlsplit

TARGETS = (
    "/api/v1/payments/checkout/taxes",
    "/v1/confirmation_tokens",
    "/api/v1/payments/checkout/confirm",
    "/v1/payment_intents/",
)


def sanitize_path(path: str) -> str:
    path = re.sub(r"[0-9a-f]{8}-[0-9a-f-]{27,}", "{uuid}", path, flags=re.I)
    path = re.sub(r"\b(?:oaics|pi|ct|cs|cus|pm|sub|in)_[A-Za-z0-9_-]+", "{id}", path)
    return re.sub(r"/[A-Za-z0-9_-]{24,}(?=/|$)", "/{token}", path)


def body_keys(entry: dict[str, Any]) -> list[str]:
    text = ((entry.get("request") or {}).get("postData") or {}).get("text", "")
    if not text:
        return []
    try:
        data = json.loads(text)
        return list(data) if isinstance(data, dict) else []
    except json.JSONDecodeError:
        return list(dict.fromkeys(key for key, _value in parse_qsl(text, keep_blank_values=True)))


def inspect_har(file: str | Path) -> list[dict[str, Any]]:
    path = Path(file).expanduser().resolve()
    har = json.loads(path.read_text(encoding="utf-8"))
    entries = ((har.get("log") or {}).get("entries") or [])
    selected: list[tuple[int, dict[str, Any]]] = []
    for index, entry in enumerate(entries):
        url = str((entry.get("request") or {}).get("url", ""))
        if any(target in urlsplit(url).path for target in TARGETS):
            selected.append((index, entry))

    print(f"HAR: {path.name} ({len(entries)} requests)")
    print("支付协议关键链路（所有值均不输出，只展示字段名）:")
    output: list[dict[str, Any]] = []
    for index, entry in selected:
        request = entry.get("request") or {}
        url = urlsplit(str(request.get("url", "")))
        header_names = [
            str(header.get("name", "")).lower()
            for header in request.get("headers", [])
            if isinstance(header, dict)
        ]
        result = {
            "index": index,
            "startedAt": entry.get("startedDateTime"),
            "durationMs": round(entry.get("time", 0)),
            "request": f"{request.get('method', '')} {url.hostname}{sanitize_path(url.path)}",
            "status": (entry.get("response") or {}).get("status"),
            "requestBodyKeys": body_keys(entry),
            "dynamicSecurityHeaders": list(
                dict.fromkeys(
                    name
                    for name in header_names
                    if "token" in name or "attestation" in name or name == "authorization"
                )
            ),
        }
        output.append(result)
        print(json.dumps(result, ensure_ascii=False))

    if selected:
        first = selected[0][1]
        last = selected[-1][1]
        first_time = datetime.fromisoformat(str(first["startedDateTime"]).replace("Z", "+00:00"))
        last_time = datetime.fromisoformat(str(last["startedDateTime"]).replace("Z", "+00:00"))
        elapsed_ms = (last_time - first_time).total_seconds() * 1000 + float(last.get("time", 0))
        print(f"关键链路墙钟时间: {round(elapsed_ms)}ms")
    return output

