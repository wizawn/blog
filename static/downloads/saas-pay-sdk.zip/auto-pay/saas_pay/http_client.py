from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, TYPE_CHECKING

import requests

from .errors import HttpError, ProtocolError
from .utils import describe_payload, sanitize_message

if TYPE_CHECKING:
    from .tls_fingerprint import TLSFingerprintManager

logger = logging.getLogger(__name__)

CF_COOKIE_FILE = Path(".") / ".cf_cookies.json"
CF_COOKIE_KEYS = ("__cf_bm", "cf_clearance", "__cflb", "_cfuvid")


@dataclass(slots=True)
class HttpResponse:
    data: Any
    headers: Mapping[str, str]
    ok: bool
    status: int
    text: str
    url: str


def _load_cf_cookies() -> dict[str, str]:
    """加载之前持久化的 Cloudflare 通过 cookie，减少重复挑战。"""
    if CF_COOKIE_FILE.exists():
        try:
            return json.loads(CF_COOKIE_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_cf_cookies(session: requests.Session) -> None:
    """从 session 中提取并持久化 Cloudflare 相关的 cookie。"""
    cookies: dict[str, str] = {}
    for key in CF_COOKIE_KEYS:
        value = session.cookies.get(key, domain="platform.example.com") or session.cookies.get(key)
        if value:
            cookies[key] = value
    if cookies:
        try:
            CF_COOKIE_FILE.write_text(
                json.dumps(cookies, ensure_ascii=False), encoding="utf-8"
            )
        except OSError:
            pass


def clear_cf_cookies() -> None:
    """支付失败时清掉持久化的 CF cookie，避免下次请求带被标记的环境。"""
    try:
        if CF_COOKIE_FILE.exists():
            CF_COOKIE_FILE.unlink()
            logger.info("已清除持久化 CF cookie（避免环境标记累积）")
    except OSError:
        pass


def is_cf_challenge(response: requests.Response) -> bool:
    """检查响应是否是 Cloudflare JS Challenge 页面。"""
    if not response.ok and response.status_code != 200:
        text = getattr(response, "text", "") or ""
        if "_cf_chl_opt" in text or "challenge-error-text" in text:
            return True
        if response.status_code == 403 and "cf-mitigated" in response.headers.get(
            "Cf-Mitigated", ""
        ).lower():
            return True
    return False


class HttpClient:
    def __init__(
        self,
        *,
        session: requests.Session | None = None,
        cookies: Mapping[str, str] | None = None,
        cookies_enabled: bool = True,
        timeout_ms: int = 20_000,
        user_agent: str | None = None,
        default_headers: Mapping[str, str] | None = None,
        impersonate: str | None = None,
        tls_manager: TLSFingerprintManager | None = None,
        cf_cookie_persistence: bool = False,
    ) -> None:
        self.session = session or requests.Session()
        if session is None:
            self.session.trust_env = False
        self.cookies_enabled = cookies_enabled
        self.timeout_ms = timeout_ms
        self.tls_manager = tls_manager
        self.cf_cookie_persistence = cf_cookie_persistence

        # 对 session 应用 TLS 指纹伪装（如果 session 支持）
        if impersonate:
            self._apply_impersonation(impersonate)

        # 同步 User-Agent：优先使用 TLS profile 匹配的 UA
        resolved_ua = user_agent
        if resolved_ua is None and impersonate:
            from .tls_fingerprint import get_user_agent

            resolved_ua = get_user_agent(impersonate)

        self.default_headers = {
            "accept": "application/json, text/plain, */*",
            "accept-language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
            "accept-encoding": "gzip, deflate, br",
            "cache-control": "no-cache",
            "dnt": "1",
            "pragma": "no-cache",
            "sec-ch-ua": (
                '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"'
            ),
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"macOS"',
            "sec-fetch-dest": "empty",
            "sec-fetch-mode": "cors",
            "sec-fetch-site": "same-origin",
            "user-agent": resolved_ua
            or (
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/138.0.0.0 Safari/537.36"
            ),
            **dict(default_headers or {}),
        }
        if cookies_enabled and cookies:
            self.session.cookies.update(cookies)

        # 加载持久化的 CF cookie
        if cookies_enabled and cf_cookie_persistence:
            saved = _load_cf_cookies()
            for key, value in saved.items():
                self.session.cookies.set(key, value, domain="platform.example.com")
            if saved:
                logger.debug("已加载持久化 CF cookie: %s", list(saved.keys()))

        if not cookies_enabled:
            self.session.cookies.clear()

    def _apply_impersonation(self, profile: str) -> None:
        """对 session 设置 TLS 指纹伪装（仅 curl_cffi session 生效）。"""
        if hasattr(self.session, "impersonate"):
            self.session.impersonate = profile
            logger.debug("HttpClient TLS 指纹设为 %s", profile)

    def request(
        self,
        url: str,
        *,
        method: str | None = None,
        headers: Mapping[str, str] | None = None,
        json_body: Any = None,
        form: Mapping[str, Any] | None = None,
        body: str | bytes | None = None,
        allow_error_status: bool = False,
        timeout_ms: int | None = None,
        redirect: bool = True,
    ) -> HttpResponse:
        request_headers = {**self.default_headers, **dict(headers or {})}
        request_method = method or (
            "GET" if json_body is None and form is None and body is None else "POST"
        )

        # 指纹轮换重试循环
        tls = self.tls_manager
        while True:
            if not self.cookies_enabled:
                self.session.cookies.clear()

            try:
                response = self.session.request(
                    request_method,
                    url,
                    headers=request_headers,
                    json=json_body,
                    data=form if form is not None else body,
                    timeout=(timeout_ms or self.timeout_ms) / 1000,
                    allow_redirects=redirect,
                )
            except requests.Timeout as error:
                raise ProtocolError(
                    "network_timeout",
                    f"请求超时: {urlsplit(url).netloc}",
                    retryable=True,
                ) from error
            except requests.RequestException as error:
                raise ProtocolError(
                    "network_error",
                    f"网络请求失败: {sanitize_message(error)}",
                    retryable=True,
                ) from error
            finally:
                if not self.cookies_enabled:
                    self.session.cookies.clear()

            # Cloudflare cookie 持久化
            if (
                self.cookies_enabled
                and self.cf_cookie_persistence
                and response.ok
                and "platform.example.com" in url
            ):
                _save_cf_cookies(self.session)

            # 指纹轮换：收到 403/429 或 Cloudflare Challenge 时自动切换 TLS 指纹重试
            cf_detected = is_cf_challenge(response)
            should_rotate = (
                not allow_error_status
                and not response.ok
                and tls is not None
                and (tls.should_retry(response.status_code) or cf_detected)
            )
            if should_rotate:
                if cf_detected:
                    logger.warning(
                        "检测到 Cloudflare JS Challenge，触发 TLS 指纹轮换"
                    )
                old_profile = tls.profile
                tls.mark_failed(old_profile)
                new_profile = tls.pick()
                tls.record_attempt()
                logger.info(
                    "HTTP %d 触发 TLS 指纹轮换: %s → %s (剩余 %d 次)%s",
                    response.status_code,
                    old_profile,
                    new_profile,
                    tls.remaining_retries(),
                    " [CF Challenge]" if cf_detected else "",
                )
                self._apply_impersonation(new_profile)
                # 同步更新 User-Agent
                from .tls_fingerprint import get_user_agent

                self.default_headers["user-agent"] = get_user_agent(new_profile)
                request_headers["user-agent"] = self.default_headers["user-agent"]
                continue

            if tls is not None and response.ok:
                tls.mark_succeeded()

            # Cloudflare challenge 错误：所有轮换策略均失败时给出明确提示
            if cf_detected and not allow_error_status:
                raise ProtocolError(
                    "cloudflare_challenge",
                    "被 Cloudflare JS Challenge 拦截，所有 TLS 指纹均无法通过",
                    retryable=True,
                )

            break

        text = response.text
        try:
            data = response.json() if text else {}
        except ValueError:
            data = text

        if not response.ok and not allow_error_status:
            upstream = data.get("error", data) if isinstance(data, dict) else data
            if isinstance(upstream, dict):
                code = (
                    upstream.get("decline_code")
                    or upstream.get("code")
                    or data.get("error_code")
                    or data.get("code")
                    or "http_error"
                )
                detail = data.get("detail")
                detail_message = (
                    detail.get("message") if isinstance(detail, dict) else detail
                )
                message = (
                    upstream.get("message")
                    or data.get("message")
                    or detail_message
                    or data.get("error_description")
                )
            else:
                code = "http_error"
                message = upstream if isinstance(upstream, str) else None
            if not isinstance(message, (str, int, float)):
                message = None
            safe_message = sanitize_message(message) if message else ""
            if not safe_message:
                safe_message = (
                    f"HTTP {response.status_code}; "
                    f"响应结构: {describe_payload(data)}"
                )
            safe_code = str(code)
            if not safe_code.replace("_", "").replace("-", "").isalnum():
                safe_code = "http_error"
            raise HttpError(
                response.status_code,
                safe_message[:500],
                code=safe_code[:100],
                response_body=data,
            )

        return HttpResponse(
            data=data,
            headers=response.headers,
            ok=response.ok,
            status=response.status_code,
            text=text,
            url=response.url,
        )
