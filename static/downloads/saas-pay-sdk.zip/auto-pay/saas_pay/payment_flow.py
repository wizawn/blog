from __future__ import annotations

import logging
import re
import time
from typing import Any, Callable

import random as _random

from .platform_client import PlatformClient
from .config import Config

logger = logging.getLogger("saas_pay")
from .errors import ProtocolError
from .http_client import HttpClient
from .proxy import UpstreamTransport, create_upstream_transport
from .session import parse_session_json
from .stripe_client import StripeClient
from .tls_fingerprint import TLSFingerprintManager, parse_rotation_pool, resolve_profile
from .utils import normalize_billing

# API 调用间隔抖动范围（秒），打破零延迟脚本特征
_JITTER_MIN_S = 0.0
_JITTER_MAX_S = 0.0


class PaymentFlow:
    def __init__(
        self,
        config: Config,
        *,
        transport: UpstreamTransport | None = None,
        on_progress: Callable[[str], None] | None = None,
        before_upgrade: Callable[[], None] | None = None,
        sleep_ms: Callable[[int], None] | None = None,
    ) -> None:
        self.config = config
        self.transport = transport or create_upstream_transport(config)
        self.on_progress = on_progress or (lambda _status: None)
        self.before_upgrade = before_upgrade
        self.sleep_ms = sleep_ms or (lambda milliseconds: time.sleep(milliseconds / 1000))

        # 初始化 TLS 指纹管理器：每次运行从轮换池中随机选起始指纹，
        # 避免同一环境指纹被 Vendor 追踪累积标记。
        rotation_pool = parse_rotation_pool(config.tls_rotation_pool)
        if config.tls_impersonate.strip().lower() == "random":
            initial_profile = resolve_profile("random")
        else:
            initial_profile = _random.choice(rotation_pool)
        self.tls_manager = TLSFingerprintManager(
            profile=initial_profile,
            rotation=config.tls_rotation,
            rotation_profiles=rotation_pool,
        )

    @staticmethod
    def _jitter() -> None:
        """添加随机间隔，打破 API 调用之间零延迟的脚本特征。"""
        time.sleep(_random.uniform(_JITTER_MIN_S, _JITTER_MAX_S))

    def _pay_checkout(
        self,
        platform: PlatformClient,
        stripe: StripeClient,
        email: str,
        plan_name: str,
        country: str,
        currency: str,
        billing: dict[str, Any],
        card: dict[str, Any],
    ) -> tuple[str, dict[str, Any], dict[str, Any] | None]:
        """执行 checkout → taxes → token → confirm → payment_intent 完整链。

        Returns (checkout_session_id, confirmation, payment_intent).
        payment_intent 为 None 表示 commit_payments=False。

        Raises ProtocolError("payment_declined", ...) 当卡被拒付。
        """
        self._jitter()
        checkout = platform.create_checkout(plan_name, country, currency)
        checkout_session_id = str(checkout["checkout_session_id"])
        print(f"   ✅ checkout: {checkout_session_id}")
        if checkout.get("external"):
            raise ProtocolError(
                "external_checkout_session",
                "高风险，无法充值",
                payment_submitted=False,
            )

        self.on_progress("checkout")
        self._jitter()
        snapshot = platform.update_taxes(checkout_session_id, str(email), billing, currency)
        total_str = "?"
        total_raw = snapshot.get("total", snapshot.get("amount_total"))
        if isinstance(total_raw, (int, float)):
            total_str = f"{total_raw / 100:.2f}"
        print(f"   ✅ 税费计算完成，金额: {snapshot.get('currency', '').upper()} {total_str}")

        self.on_progress("tokenizing")
        self._jitter()
        confirmation_token = stripe.create_confirmation_token(snapshot, card, billing)
        print(f"   ✅ token: {confirmation_token['id'][:20]}...")
        self._jitter()
        confirmation = platform.confirm_checkout(
            checkout_session_id,
            str(confirmation_token["id"]),
        )
        print(f"   ✅ checkout 确认成功")

        if not self.config.commit_payments:
            return checkout_session_id, confirmation, None

        self.on_progress("submitting")
        self._jitter()
        payment_intent = stripe.confirm_payment_intent(
            str(confirmation["client_secret"]),
            str(confirmation_token["id"]),
            str(confirmation.get("confirm_return_url", "")),
            stripe_publishable_key=stripe.publishable_key,
        )
        pi_id = (payment_intent or {}).get("id", "?")
        pi_status = (payment_intent or {}).get("status", "?")
        if pi_status not in ("succeeded", "processing"):
            raise ProtocolError(
                "payment_unconfirmed",
                f"PaymentIntent 状态异常: {pi_status}",
                payment_submitted=True,
            )
        print(f"   ✅ PaymentIntent: {pi_id} | 状态: {pi_status}")
        return checkout_session_id, confirmation, payment_intent

    def run(self) -> dict[str, Any]:
        task = self.config.task()
        session = parse_session_json(self.config.session_json)

        tls_profile = self.tls_manager.pick()
        platform_http = HttpClient(
            session=self.transport.create_session(impersonate=tls_profile),
            cookies=session.cookies,
            timeout_ms=self.config.request_timeout_ms,
            impersonate=tls_profile,
            tls_manager=self.tls_manager,
            cf_cookie_persistence=True,
        )
        stripe_http = HttpClient(
            session=self.transport.create_session(impersonate=tls_profile),
            cookies_enabled=False,
            timeout_ms=self.config.request_timeout_ms,
            impersonate=tls_profile,
            tls_manager=self.tls_manager,
        )
        platform = PlatformClient(
            http=platform_http,
            access_token=session.access_token,
            session_token=session.raw.get("sessionToken", ""),
        )
        stripe = StripeClient(
            http=stripe_http,
            publishable_key=self.config.stripe_publishable_key,
        )
        billing = normalize_billing(self.config.billing)
        card = self.config.card
        if not card.get("number") or not card.get("expiry") or not card.get("cvc"):
            raise ProtocolError(
                "card_invalid",
                "配置缺少 card.number / expiry / cvc",
            )

        plan_type = str(task.get("planType", ""))
        country = str(task.get("country", ""))
        print(f"\n{'='*50}")
        print(f"🚀 开始支付流程")
        print(f"   计划: {plan_type} | 国家: {country} | TLS: {tls_profile}")
        print(f"   卡号: {card['number'][:4]}****{card['number'][-4:]} | 代理: {self.transport.label}")
        print(f"{'='*50}")

        self.on_progress("prechecking")
        print("[1/7] 刷新 session & 检查账号...")
        platform.refresh_session()
        self._jitter()
        before = platform.assert_can_purchase(plan_type)
        raw_user = session.raw.get("user") if isinstance(session.raw.get("user"), dict) else {}
        email = before.get("email") or raw_user.get("email") or ""
        if not email:
            raise ProtocolError("email_missing", "session/account 响应中没有邮箱")
        print(f"   ✅ 账号 {email} 可以购买")

        self.on_progress("creating_checkout")
        print("[2/7] 获取币种...")
        self._jitter()
        currency = platform.get_currency(country)
        print(f"   币种: {currency}")

        plan_name = str(task.get("planName", ""))

        if plan_type == "premium":
            # Pro-20x: 先尝试直付，被拒则降级 Plus → 升级 Pro
            print("[3/7] Pro checkout + 扣款...")
            try:
                checkout_session_id, confirmation, payment_intent = self._pay_checkout(
                    platform, stripe, email, plan_name, country, currency, billing, card,
                )
            except ProtocolError as e:
                if e.code == "external_checkout_session":
                    return {
                        "status": "high_risk",
                        "code": "external_checkout_session",
                        "message": "高风险，无法充值",
                    }
                if e.code not in ("payment_declined", "card_declined"):
                    raise
                print(f"   ⚠️  Pro 直付被拒，降级 Plus → 升级 Pro...")
                payment_intent = None
            else:
                if payment_intent is None:
                    return {
                        "status": "prepared",
                        "checkoutSessionId": checkout_session_id,
                        "message": "协议链已走到最终扣款前；commitPayments=false，未确认 PaymentIntent",
                    }

            if payment_intent is None:
                print("[4/7] Plus checkout + 扣款（降级）...")
                try:
                    checkout_session_id, confirmation, payment_intent = self._pay_checkout(
                        platform, stripe, email, "basic_plan", country, currency, billing, card,
                    )
                except ProtocolError as e:
                    if e.code == "external_checkout_session":
                        return {
                            "status": "high_risk",
                            "code": "external_checkout_session",
                            "message": "高风险，无法充值",
                        }
                    raise
                if payment_intent is None:
                    return {
                        "status": "prepared",
                        "checkoutSessionId": checkout_session_id,
                        "message": "协议链已走到最终扣款前；commitPayments=false，未确认 PaymentIntent",
                    }
                # Plus 付款成功 → 升级到 Pro
                print("[5/7] 升级到 Pro...")
                self.on_progress("upgrading")
                if self.before_upgrade:
                    self.before_upgrade()
                platform.upgrade_to_pro()

            print("[6/7] 取消自动续费...")
            return self._finish_cancel(platform, payment_intent)
        else:
            # Plus: 正常流程
            print("[3/7] Plus checkout + 扣款...")
            try:
                checkout_session_id, confirmation, payment_intent = self._pay_checkout(
                    platform, stripe, email, plan_name, country, currency, billing, card,
                )
            except ProtocolError as e:
                if e.code == "external_checkout_session":
                    return {
                        "status": "high_risk",
                        "code": "external_checkout_session",
                        "message": "高风险，无法充值",
                    }
                raise
            if payment_intent is None:
                return {
                    "status": "prepared",
                    "checkoutSessionId": checkout_session_id,
                    "message": "协议链已走到最终扣款前；commitPayments=false，未确认 PaymentIntent",
                }
            print("[6/7] 取消自动续费...")
            return self._finish_cancel(platform, payment_intent)

    def checkout_link(self) -> dict[str, Any]:
        """创建 hosted checkout 并返回可点击的支付链接，不读卡也不扣款。"""
        task = self.config.task()
        session = parse_session_json(self.config.session_json)

        tls_profile = self.tls_manager.pick()
        platform_http = HttpClient(
            session=self.transport.create_session(impersonate=tls_profile),
            cookies=session.cookies,
            timeout_ms=self.config.request_timeout_ms,
            impersonate=tls_profile,
            tls_manager=self.tls_manager,
            cf_cookie_persistence=True,
        )
        platform = PlatformClient(
            http=platform_http,
            access_token=session.access_token,
            session_token=session.raw.get("sessionToken", ""),
        )

        self.on_progress("prechecking")
        platform.refresh_session()
        plan_type = str(task.get("planType", ""))
        platform.assert_can_purchase(plan_type)

        self.on_progress("creating_checkout")
        country = str(task.get("country", ""))
        currency = platform.get_currency(country)
        link = platform.create_checkout_link(
            str(task.get("planName", "")),
            country,
            currency,
        )
        return {
            "status": "checkout_link",
            "planType": plan_type,
            "country": country,
            "currency": currency,
            "checkoutSessionId": link["checkout_session_id"],
            "processorEntity": link["processor_entity"],
            "checkoutUrl": link["checkout_url"],
            "hostedUrl": link["hosted_url"],
            "isStripeLive": link["is_stripe_live"],
        }

    def _finish_upgrade_and_cancel(
        self,
        platform: PlatformClient,
        paid: dict[str, Any],
        payment_intent: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self.on_progress("upgrading")
        print("   正在升级到 Pro...")
        if self.before_upgrade:
            self.before_upgrade()
        platform.update_subscription("premium_plan")
        print("   ✅ 升级 API 调用成功，等待同步...")
        platform.verify_paid(
            self.config.plan_type,
            self.config.verify_attempts,
            self.config.verify_interval_ms,
            self.sleep_ms,
            allow_intermediate=False,
        )
        print("   ✅ Pro 订阅已生效")
        return self._finish_cancel(platform, payment_intent)

    def _finish_cancel(
        self,
        platform: PlatformClient,
        payment_intent: dict[str, Any] | None,
    ) -> dict[str, Any]:
        self.on_progress("canceling")
        if self.config.cancel_initial_delay_ms > 0:
            self.sleep_ms(self.config.cancel_initial_delay_ms)

        cancelled: dict[str, Any] | None = None
        last_error: ProtocolError | None = None
        for attempt in range(1, self.config.cancel_attempts + 1):
            try:
                cancelled = platform.cancel_renewal()
                last_error = None
                break
            except ProtocolError as error:
                last_error = error
                if attempt < self.config.cancel_attempts:
                    print(f"   ⚠️  取消失败 (尝试 {attempt}/{self.config.cancel_attempts}): {error}")
                    self.sleep_ms(self.config.cancel_retry_interval_ms)
                    if getattr(error, "http_status", 0) == 401:
                        print("   ⚠️  token 过期，刷新后重试...")
                        try:
                            platform.refresh_session()
                        except Exception:
                            pass
        if last_error:
            raise last_error
        assert cancelled is not None
        subscription = cancelled.get("subscription") or {}
        account = cancelled.get("account") or {}
        print(f"   ✅ 自动续费已取消 | will_renew: {subscription.get('will_renew')}")

        # 取消后刷新并保存最终 session
        try:
            platform.refresh_session()
        except Exception:
            pass
        session_state = platform.save_session()
        print(f"   ✅ 最终 session 已保存到 .session_refreshed.json")
        print(f"{'='*50}")
        print(f"🎉 完成！订阅: {subscription.get('plan_type', subscription.get('planType', '?'))} | 续费: {subscription.get('will_renew')}")
        print(f"   email: {account.get('email', '?')}")
        print(f"   paymentIntent: {(payment_intent or {}).get('id', '?')}")
        print(f"{'='*50}\n")
        return {
            "status": "completed",
            "email": account.get("email") or "",
            "plan": subscription.get("plan_type", subscription.get("planType", "")),
            "paymentIntentId": (payment_intent or {}).get("id", ""),
            "willRenew": subscription.get("will_renew"),
            "sessionRefreshed": session_state.get("accessToken", "")[:20] + "...",
        }
