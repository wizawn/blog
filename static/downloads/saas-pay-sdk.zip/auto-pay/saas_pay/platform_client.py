from __future__ import annotations

import base64
import json as _json
import random
import re
from typing import Any, Callable
from urllib.parse import quote, urlencode

from .errors import ProtocolError
from .http_client import HttpClient
from .utils import first_object_value, random_id

# x-vendor-telemetry 能力位掩码：不同浏览器版本的能力组合不同，固定值会被追踪
_TELEMETRY_VARIANTS = (
    "[1,1,1,1,1,1,1,1]",
    "[1,0,1,1,1,1,1,1]",
    "[1,1,0,1,1,1,1,1]",
    "[1,1,1,0,1,1,1,1]",
    "[1,1,1,1,0,1,1,1]",
    "[1,1,1,1,1,0,1,1]",
)

# 真实浏览器客户端版本号
_VENDOR_CLIENT_BUILD_NUMBER = "0000000"
_VENDOR_CLIENT_VERSION = "prod-0000000000000"

BASE = "https://platform.example.com"
PRO_PLAN = re.compile(r"premium_plan$")
INTERMEDIATE_PLAN = re.compile(r"basic|standard|go")


def _random_observation() -> str:
    """生成 x-vendor-is-client-observation 头，真实浏览器会发这个。"""
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
    token = "".join(random.choice(chars) for _ in range(10))
    return f"v1.r.p.{token}"


def _extract_jwt_iat(token: str) -> str:
    """从 JWT 中提取 iat（issued at）字段，用于 token 过期刷新。"""
    try:
        parts = token.split(".")
        if len(parts) < 2:
            return ""
        payload = parts[1]
        payload += "=" * (4 - len(payload) % 4)
        decoded = base64.urlsafe_b64decode(payload)
        return str(_json.loads(decoded).get("iat", ""))
    except Exception:
        return ""


class PlatformClient:
    def __init__(
        self,
        *,
        http: HttpClient,
        access_token: str = "",
        device_id: str | None = None,
        session_id: str | None = None,
        session_token: str = "",
    ) -> None:
        self.http = http
        self.access_token = access_token
        self.device_id = device_id or random_id()
        self.session_id = session_id or random_id()
        self._session_token = session_token
        self._session_data: dict[str, Any] = {}
        self.me_cache: dict[str, Any] | None = None
        self.account_id_cache: str = ""
        self._cached_account: dict[str, Any] | None = None

    def api_headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        headers = {
            "x-vendor-device-id": self.device_id,
            "x-vendor-session-id": self.session_id,
            "x-vendor-language": "en-US",
            "x-vendor-client-build-number": _VENDOR_CLIENT_BUILD_NUMBER,
            "x-vendor-client-version": _VENDOR_CLIENT_VERSION,
            "origin": BASE,
            "referer": f"{BASE}/",
            "x-vendor-is-client-observation": _random_observation(),
            **(extra or {}),
        }
        if self.access_token:
            headers["authorization"] = f"Bearer {self.access_token}"
        return headers

    def checkout_headers(
        self,
        path: str,
        checkout_session_id: str,
        extra: dict[str, str] | None = None,
    ) -> dict[str, str]:
        return self.api_headers(
            {
                "referer": f"{BASE}/checkout/vendor_entity/{checkout_session_id}",
                "x-vendor-target-path": path,
                "x-vendor-target-route": path,
                **(extra or {}),
            }
        )

    def refresh_session(self) -> dict[str, Any]:
        """刷新 session 获取新 access token 和完整 session 数据。

        调 /auth/session?refresh=true，返回的 JSON 包含 accessToken、
        sessionToken、user、account 等完整信息，可直接作为 config.json 的
        sessionJson 复用。
        """
        params = {
            "refresh": "true",
            "reason": "token_expired",
            "method": "POST",
            "path": "/ces/v1/rgstr",
        }
        query = urlencode(params)
        extra_headers: dict[str, str] = {
            "accept": "application/json",
            "x-vendor-target-path": "/auth/session",
            "x-vendor-target-route": "/auth/session",
        }
        # 有过期 token 时带上 iat，服务端用这个判断是否可以 refresh
        if self.access_token:
            iat = _extract_jwt_iat(self.access_token)
            if iat:
                extra_headers["x-vendor-failed-access-token-iat"] = iat

        response = self.http.request(
            f"{BASE}/auth/session?{query}",
            headers=self.api_headers(extra_headers),
        )
        data = response.data if isinstance(response.data, dict) else {}
        if data.get("accessToken"):
            self.access_token = str(data["accessToken"])
        # /auth/session 返回完整 session，包含 sessionToken
        if data.get("sessionToken"):
            self._session_token = str(data["sessionToken"])
        # 保存完整响应，供 save_session() 写出可复用的 session JSON
        if data:
            self._session_data = dict(data)
        # 清除缓存，token 变了需要重新获取
        self._cached_account = None
        self.me_cache = None
        if not self.access_token:
            raise ProtocolError("session_expired", "无法从 session 获取 accessToken")
        return data

    def get_session_state(self) -> dict[str, Any]:
        """返回完整 session JSON，可直接作为 config.json 的 sessionJson 复用。"""
        # 以 /auth/session 返回的完整数据为基础
        state = dict(self._session_data) if self._session_data else {}
        # 确保 accessToken 和 sessionToken 是最新的
        state["accessToken"] = self.access_token
        if self._session_token:
            state["sessionToken"] = self._session_token
        # 附加当前 HTTP 会话的 cookie
        try:
            state["_cookies"] = self.http.session.cookies.get_dict()
        except Exception:
            pass
        return state

    def save_session(self, path: str = ".session_refreshed.json") -> dict[str, Any]:
        """保存完整 session 到文件，可直接复制到 config.json 的 sessionJson。"""
        state = self.get_session_state()
        try:
            with open(path, "w", encoding="utf-8") as f:
                _json.dump(state, f, ensure_ascii=False, indent=2)
        except OSError:
            pass
        return state

    def account_info(self) -> dict[str, Any]:
        if not self.access_token:
            self.refresh_session()
        extra: dict[str, str] = {
            "x-vendor-target-path": "/api/v1/accounts/check/v4-2023-04-27",
            "x-vendor-target-route": "/api/v1/accounts/check/{version}",
        }
        if self.account_id_cache:
            extra["platform-account-id"] = self.account_id_cache
        response = self.http.request(
            f"{BASE}/api/v1/accounts/check/v4-2023-04-27?timezone_offset_min=-480",
            headers=self.api_headers(extra),
        )
        data = response.data if isinstance(response.data, dict) else {}
        accounts = data.get("accounts") if isinstance(data.get("accounts"), dict) else {}
        entry = accounts.get("default") or first_object_value(accounts) or {}
        account = entry.get("account") if isinstance(entry.get("account"), dict) else {}
        entitlement = (
            entry.get("entitlement") if isinstance(entry.get("entitlement"), dict) else {}
        )
        user = data.get("user") if isinstance(data.get("user"), dict) else {}
        plan = str(entitlement.get("subscription_plan", "")).lower()
        account_id = str(account.get("account_id") or account.get("id", ""))
        self.account_id_cache = account_id or self.account_id_cache
        result = {
            "account_id": account_id,
            "email": user.get("email") or "",
            "entitlement": entitlement,
            "plan": plan,
            "active": entitlement.get("has_active_subscription") is True,
            "cancels_at": entitlement.get("cancels_at") or entitlement.get("cancel_at"),
            "expires_at": entitlement.get("expires_at")
            or entitlement.get("current_period_end"),
            "grace_period_id": account.get("grace_period_id") or account.get("gracePeriodId"),
            "raw": data,
        }
        # 缓存，避免 cancel_renewal 重复调用同一接口
        self._cached_account = result
        return result

    def assert_can_purchase(self, plan_type: str) -> dict[str, Any]:
        info = self.account_info()
        grace_period = info["active"] and bool(
            info["cancels_at"] or info["grace_period_id"]
        )
        if info["active"] and not grace_period:
            # pro-20x: 已有 plus 的账号可以直接买 pro（升级）
            if plan_type == "premium" and INTERMEDIATE_PLAN.search(info["plan"]):
                return {**info, "grace_period": False}
            raise ProtocolError(
                "existing_subscription_not_ours",
                f"账号已有有效订阅 {info['plan'] or 'unknown'}，协议 worker 不会重复扣款",
            )
        return {**info, "grace_period": grace_period}

    def get_currency(self, country: str) -> str:
        response = self.http.request(
            f"{BASE}/api/v1/checkout_pricing_config/configs/{quote(country, safe='')}",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/checkout_pricing_config/configs",
                    "x-vendor-target-route": "/api/v1/checkout_pricing_config/configs/{country_code}",
                }
            ),
        )
        data = response.data if isinstance(response.data, dict) else {}
        currency = data.get("currency_config")
        return currency.get("symbol_code", "USD") if isinstance(currency, dict) else "USD"

    def create_checkout(self, plan_name: str, country: str, currency: str) -> dict[str, Any]:
        response = self.http.request(
            f"{BASE}/api/v1/payments/checkout",
            method="POST",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/payments/checkout",
                    "x-vendor-target-route": "/api/v1/payments/checkout",
                }
            ),
            json_body={
                "entry_point": "all_plans_pricing_modal",
                "plan_name": plan_name,
                "billing_details": {"country": country, "currency": currency},
                "checkout_ui_mode": "custom",
                "processor_entity": "vendor_entity",
            },
        )
        data = response.data if isinstance(response.data, dict) else {}
        nested = data.get("checkout_session") if isinstance(data.get("checkout_session"), dict) else {}
        candidates = [
            ("internal_checkout_session_id", data.get("internal_checkout_session_id")),
            ("internalCheckoutSessionId", data.get("internalCheckoutSessionId")),
            ("checkout_session.id", nested.get("id")),
            ("checkout_session_id", data.get("checkout_session_id")),
        ]
        internal = next(
            (
                (field, value)
                for field, value in candidates
                if isinstance(value, str) and value.startswith("ics_")
            ),
            None,
        )
        selected = internal or next(
            ((field, value) for field, value in candidates if isinstance(value, str) and value),
            ("", ""),
        )
        selected_field, checkout_session_id = selected
        if not checkout_session_id:
            raise ProtocolError(
                "checkout_create_failed",
                "创建 checkout 未返回 checkout_session_id",
            )
        hosted_url_present = any(
            isinstance(data.get(key), str) and data.get(key)
            for key in ("url", "stripe_hosted_url", "checkout_url")
        )
        is_internal = str(checkout_session_id).startswith("ics_")
        external = not is_internal and (
            str(checkout_session_id).startswith("cs_") or hosted_url_present
        )
        return {
            "checkout_session_id": checkout_session_id,
            "session_id_field": selected_field,
            "external": external,
            "response_fields": sorted(data.keys()),
            "raw": data,
        }

    def create_checkout_link(
        self, plan_name: str, country: str, currency: str
    ) -> dict[str, Any]:
        """以 hosted 模式创建 checkout，返回可在浏览器打开的 Stripe 支付链接。

        与 create_checkout 不同，这里请求 hosted UI，让服务端直接返回一个托管
        支付页；不进入内部 ics_ 自动扣款流程，也不读取银行卡。适合把链接交给
        人工在浏览器完成支付。
        """
        response = self.http.request(
            f"{BASE}/api/v1/payments/checkout",
            method="POST",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/payments/checkout",
                    "x-vendor-target-route": "/api/v1/payments/checkout",
                }
            ),
            json_body={
                "cancel_url": f"{BASE}/#pricing",
                "plan_name": plan_name,
                "billing_details": {"country": country, "currency": currency},
                "checkout_ui_mode": "hosted",
            },
        )
        data = response.data if isinstance(response.data, dict) else {}
        session_id = data.get("checkout_session_id") or data.get("checkoutSessionId")
        if not isinstance(session_id, str) or not session_id:
            raise ProtocolError(
                "checkout_create_failed",
                "hosted checkout 未返回 checkout_session_id",
            )
        processor_entity = str(
            data.get("processor_entity") or data.get("processorEntity") or "vendor_entity"
        )
        hosted_url = next(
            (
                data[key]
                for key in ("url", "stripe_hosted_url", "checkout_url")
                if isinstance(data.get(key), str) and data.get(key)
            ),
            "",
        )
        checkout_url = (
            f"{BASE}/checkout/{quote(processor_entity, safe='')}/"
            f"{quote(session_id, safe='')}"
        )
        return {
            "checkout_session_id": session_id,
            "processor_entity": processor_entity,
            "checkout_url": checkout_url,
            "hosted_url": hosted_url,
            "is_stripe_live": session_id.startswith("cs_live_"),
            "raw": data,
        }

    def update_taxes(
        self,
        checkout_session_id: str,
        email: str,
        billing: dict[str, str],
        currency: str,
    ) -> dict[str, Any]:
        endpoint = "/api/v1/payments/checkout/taxes"
        response = self.http.request(
            f"{BASE}{endpoint}",
            method="POST",
            headers=self.checkout_headers(endpoint, checkout_session_id),
            json_body={
                "checkout_session_id": checkout_session_id,
                "checkout_email": email,
                "billing_country": billing["country"],
                "billing_name": billing["name"],
                "currency": currency.lower(),
                "processor_entity": "vendor_entity",
                "billing_address": {
                    "line1": billing["line1"],
                    "line2": billing["line2"],
                    "city": billing["city"],
                    "state": billing["state"],
                    "postal_code": billing["postal_code"],
                    "country": billing["country"],
                },
            },
        )
        data = response.data if isinstance(response.data, dict) else {}
        snapshot = data.get("checkout_session") or data.get("checkoutSession")
        if not isinstance(snapshot, dict):
            raise ProtocolError(
                "checkout_snapshot_invalid",
                "taxes 响应缺少 Stripe checkout 快照；"
                f"响应字段: {', '.join(sorted(data.keys())) or '(empty)'}",
            )
        return snapshot

    def confirm_checkout(
        self,
        checkout_session_id: str,
        confirmation_token: str,
    ) -> dict[str, Any]:
        endpoint = "/api/v1/payments/checkout/confirm"
        response = self.http.request(
            f"{BASE}{endpoint}",
            method="POST",
            headers=self.checkout_headers(
                endpoint,
                checkout_session_id,
                {"x-vendor-telemetry": random.choice(_TELEMETRY_VARIANTS)},
            ),
            json_body={
                "checkout_session_id": checkout_session_id,
                "confirm_token": confirmation_token,
                "selected_payment_method_type": "card",
            },
        )
        data = response.data if isinstance(response.data, dict) else {}
        if data.get("status") != "success" or not data.get("client_secret"):
            raise ProtocolError(
                "checkout_confirm_failed",
                f"checkout confirm 返回异常状态: {data.get('status', 'unknown')}",
            )
        return data

    def invoices(self, account_id: str, limit: int = 4) -> list[dict[str, Any]]:
        query = urlencode({"limit": limit, "account_id": account_id})
        response = self.http.request(
            f"{BASE}/api/v1/invoices?{query}",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/invoices",
                    "x-vendor-target-route": "/api/v1/invoices",
                }
            ),
        )
        data = response.data if isinstance(response.data, dict) else {}
        return data.get("data", []) if isinstance(data.get("data"), list) else []

    def verify_paid(
        self,
        plan_type: str,
        attempts: int,
        interval_ms: int,
        sleep_ms: Callable[[int], None],
        *,
        allow_intermediate: bool = False,
    ) -> dict[str, Any]:
        last: dict[str, Any] | None = None
        for attempt in range(1, attempts + 1):
            try:
                last = self.account_info()
            except Exception as e:
                # token 过期时尝试刷新并继续
                if getattr(e, "http_status", 0) == 401 and attempt < attempts:
                    try:
                        self.refresh_session()
                    except Exception:
                        pass
                    sleep_ms(interval_ms)
                    continue
                raise
            plan = (last or {}).get("plan", "free")
            active = (last or {}).get("active", False)
            print(f"   [{attempt}/{attempts}] plan={plan} active={active}")
            if last["active"]:
                if plan_type != "premium":
                    return last
                if PRO_PLAN.search(last["plan"]):
                    return last
                if allow_intermediate and INTERMEDIATE_PLAN.search(last["plan"]):
                    return last
            if attempt < attempts:
                sleep_ms(interval_ms)
        raise ProtocolError(
            "payment_unverified",
            f"PaymentIntent 已提交，但 {attempts} 次回查仍未发现有效订阅",
            payment_submitted=True,
            details={"lastPlan": (last or {}).get("plan", "")},
        )

    def update_subscription(self, target_plan: str) -> dict[str, Any]:
        account = self.account_info()
        if not account["account_id"]:
            raise ProtocolError("account_id_missing", "账号缺少 account_id")
        response = self.http.request(
            f"{BASE}/api/v1/subscriptions/update",
            method="POST",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/subscriptions/update",
                    "x-vendor-target-route": "/api/v1/subscriptions/update",
                }
            ),
            json_body={
                "account_id": account["account_id"],
                "updated_plan": target_plan,
            },
        )
        data = response.data if isinstance(response.data, dict) else {}
        status = str(data.get("status", "")).lower()
        if re.search(r"failed|declined|error", status):
            raise ProtocolError(
                "upgrade_failed",
                data.get("payment_method_failure_reason") or f"升级失败: {status}",
                payment_submitted=True,
            )
        return data

    def preview_upgrade(self, account_id: str, updated_plan: str) -> dict[str, Any]:
        """预检升级是否可行，返回预估费用等信息。"""
        query = urlencode({"account_id": account_id, "updated_plan": updated_plan})
        response = self.http.request(
            f"{BASE}/api/v1/subscriptions/update/preview?{query}",
            headers=self.api_headers(
                {
                    "x-vendor-target-path": "/api/v1/subscriptions/update/preview",
                    "x-vendor-target-route": "/api/v1/subscriptions/update/preview",
                }
            ),
        )
        return response.data if isinstance(response.data, dict) else {}

    def _call_upgrade_api(self, account_id: str, updated_plan: str) -> dict[str, Any]:
        """调升级接口，带 401 自动刷新重试。"""
        for attempt in range(2):
            try:
                response = self.http.request(
                    f"{BASE}/api/v1/subscriptions/update",
                    method="POST",
                    headers=self.api_headers(
                        {
                            "x-vendor-target-path": "/api/v1/subscriptions/update",
                            "x-vendor-target-route": "/api/v1/subscriptions/update",
                        }
                    ),
                    json_body={
                        "account_id": account_id,
                        "updated_plan": updated_plan,
                    },
                )
                data = response.data if isinstance(response.data, dict) else {}
                status = str(data.get("status", "")).lower()
                if re.search(r"failed|declined|error", status):
                    raise ProtocolError(
                        "upgrade_failed",
                        data.get("payment_method_failure_reason") or f"升级 {updated_plan} 失败: {status}",
                        payment_submitted=True,
                    )
                return data
            except ProtocolError as e:
                if getattr(e, "http_status", 0) == 401 and attempt == 0:
                    self.refresh_session()
                    continue
                raise
        return {}

    def _check_subscription(self, account_id: str) -> dict[str, Any]:
        """查询当前订阅状态，用于升级后验证。"""
        query = urlencode({"account_id": account_id})
        for attempt in range(2):
            try:
                response = self.http.request(
                    f"{BASE}/api/v1/subscriptions?{query}",
                    headers=self.api_headers(
                        {
                            "x-vendor-target-path": "/api/v1/subscriptions",
                            "x-vendor-target-route": "/api/v1/subscriptions",
                        }
                    ),
                )
                return response.data if isinstance(response.data, dict) else {}
            except Exception as e:
                if getattr(e, "http_status", 0) == 401 and attempt == 0:
                    self.refresh_session()
                    continue
                raise

    def upgrade_to_pro(self) -> dict[str, Any]:
        """完整 Pro 升级策略，带多层降级重试。

        策略：
        1. 先尝试直接升 premium_plan（20x）
        2. 失败则先升 standard_plan（5x），等 10s，再升 premium_plan
        3. 每轮失败检查是否有未支付账单
        4. 3 轮后仍失败才抛异常
        """
        import time as _time

        account = self._cached_account or self.account_info()
        account_id = str(account.get("account_id", ""))
        if not account_id:
            raise ProtocolError("account_id_missing", "升级需要 account_id")

        pro_plan = "premium_plan"
        lite_plan = "standard_plan"

        for round_num in range(1, 4):
            print(f"   升级第 {round_num}/3 轮...")

            # 每轮先预检
            preview = self.preview_upgrade(account_id, pro_plan)
            print(f"   预检 {pro_plan}: {preview.get('status', preview.get('plan_type', '?'))}")

            # 尝试直接升 pro
            try:
                result = self._call_upgrade_api(account_id, pro_plan)
                print(f"   ✅ 直接升级 {pro_plan} 成功")
                # 验证
                sub = self._check_subscription(account_id)
                plan = sub.get("plan_type", sub.get("planType", ""))
                print(f"   当前订阅: {plan}")
                if "pro" in str(plan).lower():
                    return result
                # plan 不是 pro，等一会再查
                _time.sleep(2)
                sub = self._check_subscription(account_id)
                plan = sub.get("plan_type", sub.get("planType", ""))
                print(f"   再查订阅: {plan}")
                if "pro" in str(plan).lower():
                    return result
            except ProtocolError as e:
                print(f"   ⚠️  直接升级 {pro_plan} 失败: {e}")

            # 降级：先升 lite 再升 pro
            try:
                print(f"   尝试先升 {lite_plan}...")
                self._call_upgrade_api(account_id, lite_plan)
                print(f"   ✅ {lite_plan} 成功，等 10s 后升 {pro_plan}...")
                _time.sleep(10)
                result = self._call_upgrade_api(account_id, pro_plan)
                print(f"   ✅ {lite_plan} → {pro_plan} 成功")
                sub = self._check_subscription(account_id)
                plan = sub.get("plan_type", sub.get("planType", ""))
                print(f"   当前订阅: {plan}")
                return result
            except ProtocolError as e:
                print(f"   ⚠️  lite→pro 升级失败: {e}")

            # 检查未支付账单
            try:
                invoices = self.invoices(account_id)
                open_invoices = [
                    inv for inv in invoices
                    if inv.get("status") in ("open", "unpaid", "pending")
                ]
                if open_invoices:
                    print(f"   ⚠️  发现 {len(open_invoices)} 笔未支付账单")
            except Exception:
                pass

            if round_num < 3:
                print(f"   等 5s 后重试...")
                _time.sleep(5)

        raise ProtocolError(
            "upgrade_exhausted",
            "3 轮升级均失败，请手动处理",
            payment_submitted=True,
        )

    def cancel_renewal(self) -> dict[str, Any]:
        account = self._cached_account or self.account_info()
        if not account["account_id"]:
            raise ProtocolError("account_id_missing", "账号缺少 account_id")
        account_id = str(account["account_id"])
        cancel_headers = self.api_headers(
            {
                "x-vendor-target-path": "/api/v1/subscriptions/cancel",
                "x-vendor-target-route": "/api/v1/subscriptions/cancel",
            }
        )
        self.http.request(
            f"{BASE}/api/v1/subscriptions/cancel",
            method="POST",
            headers=cancel_headers,
            json_body={"account_id": account_id},
        )
        # 回查订阅状态确认取消生效
        query = urlencode({"account_id": account_id})
        verify_headers = self.api_headers(
            {
                "x-vendor-target-path": "/api/v1/subscriptions",
                "x-vendor-target-route": "/api/v1/subscriptions",
            }
        )
        response = self.http.request(
            f"{BASE}/api/v1/subscriptions?{query}",
            headers=verify_headers,
        )
        subscription = response.data if isinstance(response.data, dict) else {}
        if subscription.get("will_renew") is True:
            raise ProtocolError(
                "cancel_failed",
                "取消 API 返回成功，但回查 will_renew 仍为 true",
                payment_submitted=True,
            )
        return {"account": account, "subscription": subscription}
