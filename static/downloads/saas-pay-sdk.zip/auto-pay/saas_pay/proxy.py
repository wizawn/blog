from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable
from urllib.parse import SplitResult, urlsplit

import requests

from .config import Config
from .errors import ProtocolError
from .utils import sanitize_message

SUPPORTED_PROTOCOLS = {
    "http",
    "https",
    "socks",
    "socks4",
    "socks4a",
    "socks5",
    "socks5h",
}


def parse_proxy_url(value: str | None) -> SplitResult | None:
    raw = str(value or "").strip()
    if not raw:
        return None
    parsed = urlsplit(raw)
    if parsed.scheme.lower() not in SUPPORTED_PROTOCOLS:
        raise ProtocolError(
            "proxy_config_invalid",
            f"不支持的代理协议 {parsed.scheme or '(empty)'}；可用 http/https/socks4/socks5/socks5h",
        )
    try:
        port = parsed.port
    except ValueError as error:
        raise ProtocolError("proxy_config_invalid", "proxyUrl 端口无效") from error
    if not parsed.hostname or not port:
        raise ProtocolError("proxy_config_invalid", "proxyUrl 必须包含 host 和 port")
    return parsed


def safe_proxy_label(proxy: SplitResult | None) -> str:
    if proxy is None:
        return "direct"
    return f"{proxy.scheme}://{proxy.hostname}:{proxy.port}"


@dataclass(slots=True)
class UpstreamTransport:
    proxy_url: str
    label: str
    proxied: bool

    def create_session(self, impersonate: str | None = None) -> "requests.Session | Any":
        from .tls_fingerprint import create_impersonated_session

        return create_impersonated_session(impersonate, self.proxy_url)


def create_upstream_transport(config: Config) -> UpstreamTransport:
    parsed = parse_proxy_url(config.proxy_url)
    if parsed is None:
        raise ProtocolError(
            "proxy_required",
            "代理为必填项，请在 config.json 配置 proxyUrl 或设置 UPSTREAM_PROXY_URL",
        )
    return UpstreamTransport(config.proxy_url, safe_proxy_label(parsed), True)


class ProxyVerifier:
    def __init__(
        self,
        config: Config,
        session_factory: Callable[[], requests.Session],
    ) -> None:
        self.config = config
        self.session_factory = session_factory
        self.last_checked_at = 0.0
        self.last_result: dict[str, Any] | None = None

    def _query(self, url: str, mapper: Callable[[dict[str, Any]], dict[str, Any]]) -> dict[str, Any]:
        session = self.session_factory()
        response = session.get(
            url,
            headers={
                "accept": "application/json",
                "user-agent": "saas-pay-sdk/proxy-preflight",
            },
            timeout=self.config.proxy_check_timeout_ms / 1000,
        )
        response.raise_for_status()
        return mapper(response.json())

    def verify(self, force: bool = False) -> dict[str, Any]:
        interval = self.config.proxy_check_interval_ms / 1000
        now = time.monotonic()
        if not force and self.last_result and now - self.last_checked_at < interval:
            return self.last_result

        checks = [
            (
                "https://ipapi.co/json/",
                lambda data: {
                    "ip": data.get("ip", ""),
                    "country": str(data.get("country_code", "")).upper(),
                    "region": data.get("region", ""),
                },
            ),
            (
                "http://ip-api.com/json/?fields=status,message,countryCode,regionName,query,proxy,hosting",
                self._map_ip_api,
            ),
        ]

        last_error: BaseException | None = None
        for url, mapper in checks:
            try:
                result = self._query(url, mapper)
                if not result.get("ip"):
                    raise ValueError("出口 IP 为空")
                expected = (
                    self.config.proxy_expected_country or self.config.country
                ).strip().upper()
                actual = str(result.get("country", "")).upper()
                if expected and not actual:
                    raise ValueError("出口国家为空")
                if expected and actual != expected:
                    raise ProtocolError(
                        "proxy_country_mismatch",
                        f"代理出口国家 {actual or 'unknown'} 与期望 {expected} 不一致",
                        details={"actual": actual, "expected": expected},
                    )
                self.last_checked_at = time.monotonic()
                self.last_result = result
                return result
            except ProtocolError as error:
                if error.code == "proxy_country_mismatch":
                    raise
                last_error = error
            except (requests.RequestException, ValueError, KeyError) as error:
                last_error = error

        raise ProtocolError(
            "proxy_unavailable",
            f"代理出口检查失败: {sanitize_message(last_error or 'unknown error')}",
            retryable=True,
        ) from last_error

    @staticmethod
    def _map_ip_api(data: dict[str, Any]) -> dict[str, Any]:
        if data.get("status") and data["status"] != "success":
            raise ValueError(data.get("message") or "IP check failed")
        return {
            "ip": data.get("query", ""),
            "country": str(data.get("countryCode", "")).upper(),
            "region": data.get("regionName", ""),
            "detectedProxy": data.get("proxy") is True,
            "hosting": data.get("hosting") is True,
        }
