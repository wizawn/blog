from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping

from .errors import ProtocolError

COOKIE_CHUNK_SIZE = 3_800


@dataclass(slots=True)
class SessionData:
    access_token: str
    cookies: dict[str, str]
    raw: dict[str, Any]


def _chunk_cookie(name: str, value: str) -> dict[str, str]:
    if len(value) <= COOKIE_CHUNK_SIZE:
        return {name: value}
    return {
        f"{name}.{index}": value[index * COOKIE_CHUNK_SIZE : (index + 1) * COOKIE_CHUNK_SIZE]
        for index in range((len(value) + COOKIE_CHUNK_SIZE - 1) // COOKIE_CHUNK_SIZE)
    }


def parse_session_json(value: str | Mapping[str, Any]) -> SessionData:
    parsed: Any = value
    if isinstance(parsed, str):
        try:
            parsed = json.loads(parsed)
        except json.JSONDecodeError as error:
            raise ProtocolError("session_invalid", "sessionJson 不是有效 JSON") from error
    if not isinstance(parsed, Mapping):
        raise ProtocolError("session_invalid", "sessionJson 为空")

    cookies: dict[str, str] = {}
    raw_cookies = parsed.get("cookies", [])
    if isinstance(raw_cookies, list):
        for cookie in raw_cookies:
            if isinstance(cookie, Mapping) and cookie.get("name") and cookie.get("value"):
                cookies[str(cookie["name"])] = str(cookie["value"])

    session_token = str(parsed.get("sessionToken", "")).strip()
    if session_token:
        for base_name in (
            "__Secure-platform-auth.session-token",
            "__Secure-auth.session-token",
        ):
            for name, cookie_value in _chunk_cookie(base_name, session_token).items():
                cookies.setdefault(name, cookie_value)

    access_token = str(parsed.get("accessToken", "")).strip()
    if not access_token and not cookies:
        raise ProtocolError(
            "session_invalid",
            "sessionJson 中没有 accessToken、sessionToken 或 cookies",
        )
    return SessionData(access_token, cookies, dict(parsed))
