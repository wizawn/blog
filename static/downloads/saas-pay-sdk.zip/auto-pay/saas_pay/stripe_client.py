from __future__ import annotations

import random
from typing import Any
from urllib.parse import quote

from .errors import ProtocolError
from .http_client import HttpClient
from .utils import clean_form, parse_expiry, random_id

STRIPE_BASE = "https://api.stripe.com"
STRIPE_VERSION = (
    "2025-03-31.basil; checkout_server_update_beta=v1; "
    "checkout_manual_approval_preview=v1"
)

# 不同 Chrome 版本对应的 stripe.js 指纹哈希，避免固定值被追踪
STRIPE_JS_VERSIONS = (
    "stripe.js/628eb3cacd; stripe-js-v3/628eb3cacd; payment-element; deferred-intent",
    "stripe.js/a44b454c; stripe-js-v3/a44b454c; payment-element; deferred-intent",
    "stripe.js/d21f1cd6; stripe-js-v3/d21f1cd6; payment-element; deferred-intent",
    "stripe.js/9c1e8d52; stripe-js-v3/9c1e8d52; payment-element; deferred-intent",
    "stripe.js/f7a3b211; stripe-js-v3/f7a3b211; payment-element; deferred-intent",
)

# 页面停留时间范围（毫秒），模拟真人浏览行为
_TIME_ON_PAGE_RANGE = (8_000, 30_000)


def _random_time_on_page() -> int:
    return random.randint(*_TIME_ON_PAGE_RANGE)


def _random_stripe_js_ua() -> str:
    return random.choice(STRIPE_JS_VERSIONS)


class StripeClient:
    def __init__(self, *, http: HttpClient, publishable_key: str = "") -> None:
        self.http = http
        self.publishable_key = publishable_key

    @staticmethod
    def stripe_headers() -> dict[str, str]:
        return {
            "accept": "application/json",
            "origin": "https://js.stripe.com",
            "referer": "https://js.stripe.com/",
        }

    def create_confirmation_token(
        self,
        snapshot: dict[str, Any],
        card: dict[str, Any],
        billing: dict[str, str],
        **options: Any,
    ) -> dict[str, Any]:
        month, year = parse_expiry(card.get("expiry"))
        publishable_key = options.get("stripe_publishable_key") or self.publishable_key
        if not publishable_key:
            raise ProtocolError(
                "stripe_key_missing",
                "缺少 stripePublishableKey，请在 config 或环境变量中提供",
            )
        client_session_id = options.get("stripe_client_session_id") or random_id()
        # 每次生成随机的 elements session/config ID，避免空值被识别为脚本
        elements_session_id = (
            options.get("stripe_elements_session_id")
            or "ses_" + random_id().replace("-", "")
        )
        elements_config_id = (
            options.get("stripe_elements_config_id")
            or "cfg_" + random_id().replace("-", "")
        )
        ids = {
            "guid": random_id().replace("-", ""),
            "muid": random_id().replace("-", ""),
            "sid": random_id().replace("-", ""),
        }
        attribution = {
            "merchant_integration_source": "elements",
            "merchant_integration_subtype": "payment-element",
            "merchant_integration_version": "2021",
            "payment_intent_creation_flow": "deferred",
            "payment_method_selection_flow": "merchant_specified",
        }
        # 页面停留时间随机化：真人不会在固定秒数后提交
        time_on_page = options.get(
            "time_on_page_ms", _random_time_on_page()
        )
        # stripe.js 指纹哈希随机化
        payment_ua = options.get(
            "stripe_payment_user_agent", _random_stripe_js_ua()
        )
        fields: dict[str, Any] = {
            "payment_method_data[type]": "card",
            "payment_method_data[card][number]": "".join(str(card.get("number", "")).split()),
            "payment_method_data[card][cvc]": card.get("cvc"),
            "payment_method_data[card][exp_year]": year,
            "payment_method_data[card][exp_month]": month,
            "payment_method_data[allow_redisplay]": "limited",
            "payment_method_data[billing_details][address][line1]": billing["line1"],
            "payment_method_data[billing_details][address][line2]": billing["line2"],
            "payment_method_data[billing_details][address][city]": billing["city"],
            "payment_method_data[billing_details][address][country]": billing["country"],
            "payment_method_data[billing_details][address][postal_code]": billing["postal_code"],
            "payment_method_data[billing_details][address][state]": billing["state"],
            "payment_method_data[billing_details][name]": billing["name"],
            "payment_method_data[billing_details][phone]": billing["phone"],
            "payment_method_data[pasted_fields]": "number",
            "payment_method_data[payment_user_agent]": payment_ua,
            "payment_method_data[referrer]": "https://platform.example.com",
            "payment_method_data[time_on_page]": time_on_page,
            "payment_method_data[client_attribution_metadata][client_session_id]": client_session_id,
            "payment_method_data[client_attribution_metadata][elements_session_id]": elements_session_id,
            "payment_method_data[client_attribution_metadata][elements_session_config_id]": elements_config_id,
            "payment_method_data[guid]": ids["guid"],
            "payment_method_data[muid]": ids["muid"],
            "payment_method_data[sid]": ids["sid"],
            "setup_future_usage": "off_session",
            "client_context[currency]": snapshot.get("currency"),
            "client_context[mode]": snapshot.get("mode", "subscription"),
            "client_context[payment_method_types][0]": "card",
            "client_context[payment_method_types][1]": "link",
            "client_context[customer]": snapshot.get("customer"),
            "client_attribution_metadata[client_session_id]": client_session_id,
            "client_attribution_metadata[elements_session_id]": elements_session_id,
            "client_attribution_metadata[elements_session_config_id]": elements_config_id,
            "set_as_default_payment_method": "false",
            "key": publishable_key,
            "_stripe_version": STRIPE_VERSION,
        }
        for key, value in attribution.items():
            fields[f"payment_method_data[client_attribution_metadata][{key}]"] = value
            fields[f"client_attribution_metadata[{key}]"] = value

        response = self.http.request(
            f"{STRIPE_BASE}/v1/confirmation_tokens",
            method="POST",
            headers=self.stripe_headers(),
            form=clean_form(fields),
        )
        data = response.data if isinstance(response.data, dict) else {}
        if not data.get("id"):
            raise ProtocolError(
                "stripe_confirmation_token_failed",
                "Stripe 未返回 confirmation token",
            )
        return data

    def confirm_payment_intent(
        self,
        client_secret: str,
        confirmation_token: str,
        return_url: str,
        **options: Any,
    ) -> dict[str, Any]:
        payment_intent_id = str(client_secret or "").split("_secret_", 1)[0]
        if not payment_intent_id.startswith("pi_"):
            raise ProtocolError(
                "stripe_client_secret_invalid",
                "无法从 client_secret 提取 PaymentIntent",
            )
        response = self.http.request(
            f"{STRIPE_BASE}/v1/payment_intents/{quote(payment_intent_id, safe='')}/confirm",
            method="POST",
            headers=self.stripe_headers(),
            allow_error_status=True,
            form=clean_form(
                {
                    "return_url": return_url,
                    "confirmation_token": confirmation_token,
                    "key": options.get("stripe_publishable_key") or self.publishable_key,
                    "_stripe_version": STRIPE_VERSION,
                    "client_attribution_metadata[client_session_id]": options.get(
                        "stripe_client_session_id"
                    )
                    or random_id(),
                    "client_attribution_metadata[merchant_integration_source]": "l1",
                    "client_secret": client_secret,
                }
            ),
        )
        data = response.data if isinstance(response.data, dict) else {}
        if not response.ok:
            error = data.get("error") if isinstance(data.get("error"), dict) else {}
            if error.get("code") == "card_declined":
                payment_intent = (
                    error.get("payment_intent")
                    if isinstance(error.get("payment_intent"), dict)
                    else {}
                )
                raise ProtocolError(
                    "payment_declined",
                    f"Stripe 拒付: {error.get('decline_code') or error.get('message') or 'card_declined'}",
                    http_status=response.status,
                    payment_submitted=True,
                    details={
                        "declineCode": error.get("decline_code", ""),
                        "paymentIntentStatus": payment_intent.get("status", ""),
                    },
                )
            raise ProtocolError(
                str(error.get("code") or "stripe_confirm_failed"),
                str(error.get("message") or f"Stripe confirm HTTP {response.status}"),
                http_status=response.status,
                payment_submitted=True,
            )

        status = data.get("status")
        if status == "requires_action":
            next_action = data.get("next_action") if isinstance(data.get("next_action"), dict) else {}
            raise ProtocolError(
                "three_ds_required",
                "PaymentIntent 需要 3DS/额外验证，纯协议 worker 不会绕过交互验证",
                payment_submitted=True,
                details={"nextActionType": next_action.get("type", "")},
            )
        if status not in {"succeeded", "processing", "requires_capture"}:
            raise ProtocolError(
                "stripe_status_unknown",
                f"Stripe 返回未识别状态: {status or 'unknown'}",
                payment_submitted=True,
            )
        return data
