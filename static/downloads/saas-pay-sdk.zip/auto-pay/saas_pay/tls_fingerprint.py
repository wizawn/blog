from __future__ import annotations

import logging
import random
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# curl_cffi 浏览器指纹 profile 映射
# ---------------------------------------------------------------------------
TLS_PROFILES: dict[str, str] = {
    "chrome131": "chrome131",
    "chrome124": "chrome124",
    "chrome123": "chrome123",
    "chrome120": "chrome120",
    "safari18_0": "safari18_0",
    "safari17_0": "safari17_0",
    "firefox117": "firefox117",
    "edge110": "edge110",
}

# 与各浏览器版本匹配的 User-Agent，确保 HTTP 层和 TLS 层一致
PROFILE_USER_AGENTS: dict[str, str] = {
    "chrome131": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Safari/537.36"
    ),
    "chrome124": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36"
    ),
    "chrome123": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/123.0.0.0 Safari/537.36"
    ),
    "chrome120": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "safari18_0": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) "
        "Version/18.0 Safari/605.1.15"
    ),
    "safari17_0": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/605.1.15 (KHTML, like Gecko) "
        "Version/17.0 Safari/605.1.15"
    ),
    "firefox117": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7; rv:109.0) "
        "Gecko/20100101 Firefox/117.0"
    ),
    "edge110": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/110.0.0.0 Safari/537.36 Edg/110.0.1587.57"
    ),
}

DEFAULT_PROFILE = "chrome131"
DEFAULT_CHROME_ROTATION = ("chrome131", "chrome124", "chrome123", "chrome120")

# HTTP 状态码：触发指纹轮换
_ROTATION_TRIGGER_STATUSES = frozenset({403, 429})
_MAX_FINGERPRINT_RETRIES = 3


def resolve_profile(name: str) -> str:
    """将用户配置值解析为标准 profile 名称。支持 "random"。"""
    name = name.strip().lower()
    if name == "random":
        return random.choice(list(TLS_PROFILES.keys()))
    if name in TLS_PROFILES:
        return TLS_PROFILES[name]
    logger.warning("未知 TLS profile %r，回退到 %s", name, DEFAULT_PROFILE)
    return TLS_PROFILES[DEFAULT_PROFILE]


def get_user_agent(profile: str) -> str:
    """获取与 TLS profile 匹配的 User-Agent。"""
    return PROFILE_USER_AGENTS.get(profile, PROFILE_USER_AGENTS[DEFAULT_PROFILE])


def parse_rotation_pool(raw: str) -> tuple[str, ...]:
    """解析逗号分隔的轮换池字符串。空字符串返回默认 Chrome 池。"""
    raw = raw.strip()
    if not raw:
        return DEFAULT_CHROME_ROTATION
    profiles: list[str] = []
    for part in raw.split(","):
        name = part.strip().lower()
        if name in TLS_PROFILES:
            profiles.append(TLS_PROFILES[name])
        elif name:
            logger.warning("轮换池中未知 profile %r，跳过", name)
    if not profiles:
        return DEFAULT_CHROME_ROTATION
    return tuple(profiles)


def is_curl_cffi_available() -> bool:
    """检测 curl_cffi 是否可用。"""
    try:
        import curl_cffi  # noqa: F401
        return True
    except ImportError:
        return False


def create_impersonated_session(
    profile: str | None = None,
    proxy_url: str = "",
) -> Any:
    """创建带 TLS 指纹伪装的 session。

    如果 curl_cffi 不可用，回退为普通 requests.Session。
    """
    profile = profile or DEFAULT_PROFILE

    try:
        from curl_cffi import requests as curl_requests

        session = curl_requests.Session()
        session.impersonate = profile
        session.trust_env = False
        if proxy_url:
            session.proxies.update({"http": proxy_url, "https": proxy_url})
        return session
    except ImportError:
        import requests

        logger.debug("curl_cffi 不可用，回退为 requests.Session（无 TLS 伪装）")
        session = requests.Session()
        session.trust_env = False
        if proxy_url:
            session.proxies.update({"http": proxy_url, "https": proxy_url})
        return session


@dataclass(slots=True)
class TLSFingerprintManager:
    """管理 TLS 指纹的选择和轮换。

    Attributes:
        profile: 当前使用的指纹 profile。
        rotation: 是否在遇到 403/429 时自动轮换指纹。
        rotation_profiles: 轮换候选池。
        exclude_on_failure: 是否在失败后排除当前 profile。
    """

    profile: str = DEFAULT_PROFILE
    rotation: bool = True
    rotation_profiles: tuple[str, ...] = DEFAULT_CHROME_ROTATION
    exclude_on_failure: bool = True

    _failed: set[str] = field(default_factory=set)
    _attempts: int = 0

    def current_user_agent(self) -> str:
        """当前 profile 对应的 User-Agent。"""
        return get_user_agent(self.profile)

    def pick(self) -> str:
        """选取下一个要使用的 profile。

        不启用轮换时直接返回当前 profile。
        轮换池中所有 profile 都失败后自动重置。
        """
        if not self.rotation:
            return self.profile

        available = [p for p in self.rotation_profiles if p not in self._failed]
        if not available:
            logger.info("轮换池中所有 profile 均失败，重置失败集合")
            self._failed.clear()
            available = list(self.rotation_profiles)

        picked = random.choice(available)
        self.profile = picked
        return picked

    def mark_failed(self, profile: str | None = None) -> None:
        """标记指定 profile 为失败（被 403/429）。"""
        target = profile or self.profile
        if self.exclude_on_failure:
            self._failed.add(target)
            logger.debug("TLS profile %s 已标记为失败（已排除: %s）", target, self._failed)

    def mark_succeeded(self, profile: str | None = None) -> None:
        """标记指定 profile 为成功（可扩展为成功率统计）。"""
        # 当前为简单实现，仅记录日志
        target = profile or self.profile
        logger.debug("TLS profile %s 请求成功", target)

    def reset(self) -> None:
        """重置失败集合和计数。"""
        self._failed.clear()
        self._attempts = 0

    def should_retry(self, status_code: int) -> bool:
        """根据 HTTP 状态码判断是否应触发指纹轮换重试。"""
        if not self.rotation:
            return False
        if self._attempts >= _MAX_FINGERPRINT_RETRIES:
            return False
        return status_code in _ROTATION_TRIGGER_STATUSES

    def record_attempt(self) -> None:
        self._attempts += 1

    def remaining_retries(self) -> int:
        return max(0, _MAX_FINGERPRINT_RETRIES - self._attempts)
