from __future__ import annotations

import re
import uuid
from typing import Any, Mapping

from .errors import ProtocolError

SECRET_KEY = re.compile(
    r"authorization|cookie|token|secret|password|card|cvc|number|email|address|session",
    re.IGNORECASE,
)


def random_id() -> str:
    return str(uuid.uuid4())


def redact(value: Any, key: str = "") -> Any:
    if SECRET_KEY.search(key):
        return f"<redacted:{len(value)}>" if isinstance(value, str) else "<redacted>"
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, Mapping):
        return {child_key: redact(child, child_key) for child_key, child in value.items()}
    if isinstance(value, str) and len(value) > 240:
        return f"<string:{len(value)}>"
    return value


def sanitize_message(value: Any) -> str:
    message = str(value)
    message = re.sub(r"([a-z][a-z0-9+.-]*://)[^/@\s]+@", r"\1***@", message, flags=re.I)
    message = re.sub(
        r"\b(Bearer\s+)[A-Za-z0-9._~+/-]+=*",
        r"\1<redacted>",
        message,
        flags=re.I,
    )
    message = re.sub(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b", "<redacted-email>", message)
    message = re.sub(r"\b\d{13,19}\b", "<redacted-number>", message)
    return re.sub(
        r"\b(oaics|pi|ct|cs|cus|pm|sub|pk)_[A-Za-z0-9_-]+",
        r"\1_<redacted>",
        message,
    )


def describe_payload(value: Any, depth: int = 0) -> str:
    """Describe response structure without returning scalar values."""
    if depth >= 2:
        return type(value).__name__
    if isinstance(value, Mapping):
        items = list(value.items())
        children = ", ".join(
            f"{str(key)[:80]}:{describe_payload(child, depth + 1)}"
            for key, child in items[:12]
        )
        suffix = ", ..." if len(items) > 12 else ""
        return f"object({children}{suffix})"
    if isinstance(value, list):
        child = describe_payload(value[0], depth + 1) if value else "empty"
        return f"array(length={len(value)}, item={child})"
    if isinstance(value, str):
        return f"string(length={len(value)})"
    return type(value).__name__


def safe_error(error: BaseException) -> dict[str, Any]:
    return {
        "name": type(error).__name__,
        "code": getattr(error, "code", ""),
        "message": sanitize_message(str(error))[:500],
        "httpStatus": getattr(error, "http_status", 0),
        "retryable": getattr(error, "retryable", False) is True,
        "paymentSubmitted": getattr(error, "payment_submitted", False) is True,
    }


def parse_expiry(expiry: Any) -> tuple[str, str]:
    digits = re.sub(r"\D", "", str(expiry or ""))
    if len(digits) not in {4, 6}:
        raise ProtocolError("card_invalid", "卡片 expiry 必须是 MM/YY 或 MM/YYYY")
    month = digits[:2]
    year = f"20{digits[2:]}" if len(digits) == 4 else digits[2:]
    if not 1 <= int(month) <= 12:
        raise ProtocolError("card_invalid", "卡片 expiry 月份无效")
    return month, year


def normalize_billing(billing: Mapping[str, Any] | None) -> dict[str, str]:
    source = billing or {}
    full_name = str(
        source.get("fullName")
        or source.get("name")
        or " ".join(
            str(source.get(key, "")) for key in ("firstName", "lastName") if source.get(key)
        )
    ).strip()
    normalized = {
        "name": full_name,
        "line1": str(source.get("line1") or source.get("addressLine1") or "").strip(),
        "line2": str(source.get("line2") or source.get("addressLine2") or "").strip(),
        "city": str(source.get("city") or source.get("locality") or "").strip(),
        "state": str(source.get("state") or source.get("region") or "").strip(),
        "postal_code": str(source.get("zip") or source.get("postalCode") or "").strip(),
        "country": str(source.get("country") or "").strip().upper(),
        "phone": str(source.get("phone") or "").strip(),
    }
    required = ("name", "line1", "city", "state", "postal_code", "country")
    missing = [key for key in required if not normalized[key]]
    if missing:
        raise ProtocolError(
            "billing_address_required",
            f"账单地址缺少字段: {', '.join(missing)}",
        )
    return normalized


def first_object_value(value: Any) -> Any:
    if not isinstance(value, Mapping):
        return None
    return next(iter(value.values()), None)


def clean_form(fields: Mapping[str, Any]) -> dict[str, str]:
    return {
        key: str(value)
        for key, value in fields.items()
        if value is not None and value != ""
    }
