from __future__ import annotations

import json
import logging
from typing import Any, Callable

from .config import Config
from .callback_client import CallbackClient, DisabledCallbackClient
from .errors import is_card_decline
from .http_client import clear_cf_cookies
from .payment_flow import PaymentFlow
from .proxy import ProxyVerifier, UpstreamTransport, create_upstream_transport
from .utils import safe_error

LOGGER = logging.getLogger("saas_pay")


class ProtocolWorker:
    def __init__(
        self,
        config: Config,
        *,
        transport: UpstreamTransport | None = None,
        callback: CallbackClient | DisabledCallbackClient | None = None,
        proxy_verifier: ProxyVerifier | None = None,
        flow_factory: Callable[..., PaymentFlow] = PaymentFlow,
    ) -> None:
        self.config = config
        self.transport = transport or create_upstream_transport(config)
        self.callback = callback or (
            CallbackClient(config) if config.callback_url else DisabledCallbackClient()
        )
        self.proxy_verifier = proxy_verifier or (
            ProxyVerifier(config, self.transport.create_session)
            if self.transport.proxied
            else None
        )
        self.flow_factory = flow_factory
        self.proxy_state: dict[str, Any] | None = None
        self.stopped = False

    @staticmethod
    def _log(level: int, message: str, extra: dict[str, Any] | None = None) -> None:
        suffix = f" {json.dumps(extra, ensure_ascii=False)}" if extra else ""
        LOGGER.log(level, "%s%s", message, suffix)

    def _progress(self, status: str) -> None:
        self.callback.set_status(status)

    def _session_json_text(self) -> str:
        session_json = self.config.session_json
        if isinstance(session_json, str):
            return session_json
        return json.dumps(
            session_json,
            ensure_ascii=False,
            separators=(",", ":"),
        )

    def _report(self, operation: str, callback: Callable[[], Any]) -> None:
        try:
            callback()
        except Exception as error:
            self._log(
                logging.WARNING,
                f"callback {operation} 上报失败，已保留原始任务结果",
                safe_error(error),
            )

    def handle(self) -> dict[str, Any]:
        task = self.config.task()
        task_id = task["taskId"]
        self.callback.activate(task)
        flow = self.flow_factory(
            self.config,
            transport=self.transport,
            on_progress=self._progress,
            before_upgrade=lambda: self._report(
                "recharge-upgrade",
                lambda: self.callback.recharge_upgrade(task_id),
            ),
        )
        try:
            self._log(logging.INFO, f"领取任务 {task_id} ({task.get('planType', '')})")
            result = flow.run()
            if result.get("status") == "high_risk":
                self._log(
                    logging.WARNING,
                    f"任务 {task_id} 高风险，无法充值",
                    {"code": result.get("code", "high_risk")},
                )
                self._report(
                    "fail",
                    lambda: self.callback.fail(
                        task_id,
                        f"[high_risk] {result.get('message', '无法充值')}",
                    ),
                )
                return result
            if result.get("status") == "prepared":
                self._log(logging.WARNING, f"任务 {task_id} 已停在最终扣款前", {"status": "prepared"})
                self._report(
                    "fail",
                    lambda: self.callback.fail(
                        task_id,
                        "[dry_run] 协议链验证完成，未提交最终扣款",
                    ),
                )
                return result
            self._report(
                "done",
                lambda: self.callback.done(task_id, {"email": result.get("email", "")}),
            )
            self._log(
                logging.INFO,
                f"任务 {task_id} 完成",
                {"plan": result.get("plan"), "willRenew": result.get("willRenew")},
            )
            return result
        except Exception as error:
            self._log(logging.ERROR, f"任务 {task_id} 失败", safe_error(error))
            if getattr(error, "code", "") == "task_aborted":
                raise
            if is_card_decline(error):
                self._report(
                    "card-retry",
                    lambda: self.callback.card_retry(
                        task_id,
                        f"[payment_declined] {error}",
                        self._session_json_text(),
                    ),
                )
            elif getattr(error, "payment_submitted", False):
                self._report(
                    "suspicious",
                    lambda: self.callback.suspicious(
                        task,
                        error,
                        str(self.config.card.get("number", "")),
                    ),
                )
            else:
                self._report(
                    "fail",
                    lambda: self.callback.fail(
                        task_id,
                        f"[{getattr(error, 'code', 'protocol_error')}] {error}",
                    ),
                )
            # 支付失败后清掉 CF cookie，避免环境指纹被 Vendor 累积标记
            clear_cf_cookies()
            raise
        finally:
            self.callback.clear()

    def once(self) -> dict[str, Any]:
        return self.handle()

    def checkout_link(self) -> dict[str, Any]:
        """只生成 hosted 支付链接，不进入扣款流程，也不向 callback 上报任务结果。"""
        if self.proxy_verifier:
            self.proxy_state = self.proxy_verifier.verify()
        flow = self.flow_factory(
            self.config,
            transport=self.transport,
            on_progress=self._progress,
        )
        task = self.config.task()
        self._log(
            logging.INFO,
            f"生成支付链接 {task['taskId']} ({task.get('planType', '')})",
        )
        result = flow.checkout_link()
        self._log(
            logging.INFO,
            f"支付链接已生成 {task['taskId']}",
            {"checkoutSessionId": result.get("checkoutSessionId", "")},
        )
        return result

    def start(self) -> dict[str, Any] | None:
        if self.proxy_verifier:
            self.proxy_state = self.proxy_verifier.verify(force=True)
        self._log(
            logging.INFO,
            f"协议 worker 已启动: {self.config.worker_id}",
            {
                "upstream": self.transport.label,
                "exitIp": (self.proxy_state or {}).get("ip", "unchecked"),
                "exitCountry": (self.proxy_state or {}).get("country", ""),
            },
        )
        if self.stopped:
            return None
        return self.handle()

    def stop(self) -> None:
        self.stopped = True
