from __future__ import annotations

import json
from typing import Any, Callable

import requests


class FakeResponse:
    def __init__(self, data: Any, status: int = 200, url: str = "https://example.test") -> None:
        self._data = data
        self.status_code = status
        self.ok = 200 <= status < 400
        self.url = url
        self.headers = {"content-type": "application/json"}
        self.text = json.dumps(data)

    def json(self) -> Any:
        return self._data

    def raise_for_status(self) -> None:
        if not self.ok:
            raise requests.HTTPError(f"HTTP {self.status_code}")


class FakeSession:
    def __init__(self, handler: Callable[..., FakeResponse], session_number: int = 0) -> None:
        self.handler = handler
        self.session_number = session_number
        self.cookies = requests.cookies.RequestsCookieJar()
        self.proxies: dict[str, str] = {}
        self.impersonate: str | None = None

    def request(self, method: str, url: str, **kwargs: Any) -> FakeResponse:
        return self.handler(
            method,
            url,
            session_number=self.session_number,
            cookies=self.cookies.get_dict(),
            **kwargs,
        )

    def get(self, url: str, **kwargs: Any) -> FakeResponse:
        return self.request("GET", url, **kwargs)


class FakeTransport:
    label = "fake"
    proxied = False
    proxy_url = ""

    def __init__(self, handler: Callable[..., FakeResponse]) -> None:
        self.handler = handler
        self.created = 0

    def create_session(self, impersonate: str | None = None) -> FakeSession:
        self.created += 1
        session = FakeSession(self.handler, self.created)
        if impersonate:
            session.impersonate = impersonate
        return session

