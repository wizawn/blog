from __future__ import annotations

import unittest
from typing import Any

from saas_pay.config import Config
from saas_pay.callback_client import CallbackClient
from saas_pay.http_client import HttpClient
from tests.helpers import FakeResponse, FakeSession


class CallbackClientTests(unittest.TestCase):
    def setUp(self) -> None:
        self.calls: list[dict[str, Any]] = []
        self.responses: list[dict[str, Any]] = []

        def handler(method: str, url: str, **kwargs: Any) -> FakeResponse:
            self.calls.append({"method": method, "url": url, **kwargs})
            return FakeResponse(self.responses.pop(0) if self.responses else {}, url=url)

        http = HttpClient(session=FakeSession(handler))
        config = Config(
                callback_url="http://callback:3001",
                country="US",
                api_key="api-key",
            )
        config.worker_id = "worker-1"
        self.client = CallbackClient(
            config,
            http=http,
        )

    def test_activate_uses_config_task_in_headers(self) -> None:
        task = {"taskId": "task-1", "planType": "basic"}
        self.client.activate(task)
        self.assertEqual(self.client.active_task, task)
        headers = self.client.headers()
        self.assertEqual(headers["x-worker-id"], "worker-1")
        self.assertEqual(headers["authorization"], "Bearer api-key")
        self.assertEqual(headers["x-task-id"], "task-1")

    def test_clear_removes_active_config_task(self) -> None:
        self.client.active_task = {"taskId": "task-1"}
        self.client.clear()
        self.assertIsNone(self.client.active_task)

    def test_failure_reactivates_resource(self) -> None:
        self.client.fail("task/1", "failed")
        self.assertTrue(self.calls[0]["url"].endswith("/task/task%2F1/fail"))
        self.assertEqual(
            self.calls[0]["json"],
            {"reason": "failed", "reactivateCdk": True},
        )

    def test_suspicious_only_reports_card_last_four(self) -> None:
        self.client.suspicious(
            {
                "taskId": "task-1",
                "planType": "basic",
            },
            ProtocolErrorForTest(),
            "4242424242424242",
        )
        body = self.calls[0]["json"]
        self.assertEqual(body["cardLast4"], "4242")
        self.assertNotIn("4242424242424242", str(body))


class ProtocolErrorForTest(Exception):
    code = "stripe_status_unknown"


if __name__ == "__main__":
    unittest.main()
