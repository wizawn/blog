from __future__ import annotations

import unittest
from typing import Any

from saas_pay.platform_client import PlatformClient
from saas_pay.errors import ProtocolError
from saas_pay.http_client import HttpResponse
from saas_pay.stripe_client import StripeClient


class StubHttp:
    def __init__(self, responses: list[HttpResponse]) -> None:
        self.responses = responses
        self.calls: list[tuple[str, dict[str, Any]]] = []

    def request(self, url: str, **kwargs: Any) -> HttpResponse:
        self.calls.append((url, kwargs))
        return self.responses.pop(0)


def response(data: dict[str, Any], status: int = 200) -> HttpResponse:
    return HttpResponse(
        data=data,
        headers={},
        ok=200 <= status < 400,
        status=status,
        text="",
        url="https://example.test",
    )


class StripeClientTests(unittest.TestCase):
    def test_decline_is_after_submission_boundary(self) -> None:
        http = StubHttp(
            [
                response(
                    {
                        "error": {
                            "code": "card_declined",
                            "decline_code": "do_not_honor",
                            "message": "declined",
                        }
                    },
                    402,
                )
            ]
        )
        client = StripeClient(http=http, publishable_key="pk_test")  # type: ignore[arg-type]
        with self.assertRaises(ProtocolError) as raised:
            client.confirm_payment_intent("pi_test_secret_x", "ct_test", "https://return")
        self.assertEqual(raised.exception.code, "payment_declined")
        self.assertTrue(raised.exception.payment_submitted)

    def test_3ds_is_not_bypassed(self) -> None:
        http = StubHttp(
            [response({"id": "pi_test", "status": "requires_action", "next_action": {"type": "use_stripe_sdk"}})]
        )
        client = StripeClient(http=http, publishable_key="pk_test")  # type: ignore[arg-type]
        with self.assertRaises(ProtocolError) as raised:
            client.confirm_payment_intent("pi_test_secret_x", "ct_test", "https://return")
        self.assertEqual(raised.exception.code, "three_ds_required")


class PlatformClientTests(unittest.TestCase):
    def test_checkout_requests_internal_mode_and_prefers_internal_id(self) -> None:
        http = StubHttp(
            [
                response(
                    {
                        "checkout_session_id": "cs_external",
                        "internal_checkout_session_id": "ics_internal",
                        "url": "https://checkout.stripe.test/hosted",
                    }
                )
            ]
        )
        client = PlatformClient(http=http, access_token="at")  # type: ignore[arg-type]
        checkout = client.create_checkout("basic_plan", "US", "USD")
        request_body = http.calls[0][1]["json_body"]
        self.assertEqual(request_body["checkout_ui_mode"], "custom")
        self.assertEqual(request_body["processor_entity"], "vendor_entity")
        self.assertEqual(checkout["checkout_session_id"], "ics_internal")
        self.assertFalse(checkout["external"])

    def test_checkout_link_requests_hosted_mode_and_builds_url(self) -> None:
        http = StubHttp(
            [
                response(
                    {
                        "checkout_session_id": "cs_live_abc123",
                        "url": "https://checkout.stripe.test/hosted",
                    }
                )
            ]
        )
        client = PlatformClient(http=http, access_token="at")  # type: ignore[arg-type]
        link = client.create_checkout_link("basic_plan", "PH", "PHP")
        request_body = http.calls[0][1]["json_body"]
        self.assertEqual(request_body["checkout_ui_mode"], "hosted")
        self.assertNotIn("processor_entity", request_body)
        self.assertEqual(link["checkout_session_id"], "cs_live_abc123")
        self.assertTrue(link["is_stripe_live"])
        self.assertEqual(
            link["checkout_url"],
            "https://platform.example.com/checkout/vendor_entity/cs_live_abc123",
        )
        self.assertEqual(link["hosted_url"], "https://checkout.stripe.test/hosted")

    def test_checkout_link_without_session_id_fails(self) -> None:
        http = StubHttp([response({"url": "https://checkout.stripe.test/hosted"})])
        client = PlatformClient(http=http, access_token="at")  # type: ignore[arg-type]
        with self.assertRaises(ProtocolError) as raised:
            client.create_checkout_link("basic_plan", "US", "USD")
        self.assertEqual(raised.exception.code, "checkout_create_failed")

    def test_hosted_checkout_is_classified_as_external(self) -> None:
        http = StubHttp(
            [
                response(
                    {
                        "checkout_session_id": "cs_external",
                        "checkout_url": "https://checkout.stripe.test/hosted",
                    }
                )
            ]
        )
        client = PlatformClient(http=http, access_token="at")  # type: ignore[arg-type]
        checkout = client.create_checkout("basic_plan", "US", "USD")
        self.assertTrue(checkout["external"])

    def test_existing_subscription_is_blocked(self) -> None:
        client = PlatformClient(http=StubHttp([]), access_token="at")  # type: ignore[arg-type]
        client.account_info = lambda: {  # type: ignore[method-assign]
            "active": True,
            "plan": "basic_plan",
            "cancels_at": None,
            "grace_period_id": None,
        }
        with self.assertRaises(ProtocolError) as raised:
            client.assert_can_purchase("basic")
        self.assertEqual(raised.exception.code, "existing_subscription_not_ours")

    def test_pro_upgrade_can_start_from_plus(self) -> None:
        client = PlatformClient(http=StubHttp([]), access_token="at")  # type: ignore[arg-type]
        client.account_info = lambda: {  # type: ignore[method-assign]
            "active": True,
            "plan": "basic_plan",
            "cancels_at": None,
            "grace_period_id": None,
        }
        result = client.assert_can_purchase("premium")
        # pro-20x 允许已有 plus 的账号直接购买（不升级，直接 checkout pro）
        self.assertFalse(result.get("skip_purchase_for_upgrade", False))

    def test_final_pro_verification_rejects_intermediate_plus(self) -> None:
        client = PlatformClient(http=StubHttp([]), access_token="at")  # type: ignore[arg-type]
        client.account_info = lambda: {"active": True, "plan": "basic_plan"}  # type: ignore[method-assign]
        with self.assertRaises(ProtocolError) as raised:
            client.verify_paid("premium", 1, 0, lambda _ms: None)
        self.assertEqual(raised.exception.code, "payment_unverified")


if __name__ == "__main__":
    unittest.main()
