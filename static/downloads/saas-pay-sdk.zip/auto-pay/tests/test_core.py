from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from saas_pay.config import Config, DEFAULT_STRIPE_PUBLISHABLE_KEY, load_config
from saas_pay.errors import HttpError, ProtocolError, is_card_decline
from saas_pay.http_client import HttpClient
from saas_pay.session import COOKIE_CHUNK_SIZE, parse_session_json
from saas_pay.utils import (
    normalize_billing,
    parse_expiry,
    redact,
    sanitize_message,
)
from tests.helpers import FakeResponse, FakeSession


class SessionTests(unittest.TestCase):
    def test_builds_both_compatible_auth_cookies(self) -> None:
        result = parse_session_json({"sessionToken": "token", "accessToken": "access"})
        self.assertEqual(result.cookies["__Secure-platform-auth.session-token"], "token")
        self.assertEqual(result.cookies["__Secure-auth.session-token"], "token")

    def test_splits_long_session_tokens(self) -> None:
        result = parse_session_json({"sessionToken": "x" * (COOKIE_CHUNK_SIZE + 1)})
        self.assertIn("__Secure-platform-auth.session-token.1", result.cookies)

    def test_accepts_cookie_only_session(self) -> None:
        result = parse_session_json({"cookies": [{"name": "a", "value": "b"}]})
        self.assertEqual(result.cookies, {"a": "b"})

    def test_extracts_tokens_from_complete_raw_session_response(self) -> None:
        raw = {
            "WARNING_BANNER": "do not share",
            "user": {"email": "test@example.com"},
            "expires": "2099-01-01T00:00:00.000Z",
            "account": {"planType": "free"},
            "accessToken": "raw-access-token",
            "sessionToken": "raw-session-token",
            "rumViewTags": {"light_account": {"fetched": True}},
        }
        result = parse_session_json(raw)
        self.assertEqual(result.access_token, "raw-access-token")
        self.assertEqual(
            result.cookies["__Secure-platform-auth.session-token"],
            "raw-session-token",
        )
        self.assertEqual(result.raw["user"]["email"], "test@example.com")

    def test_rejects_invalid_or_empty_session(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "有效 JSON"):
            parse_session_json("{")
        with self.assertRaises(ProtocolError):
            parse_session_json({})


class UtilityTests(unittest.TestCase):
    def test_normalizes_callback_billing_fields(self) -> None:
        result = normalize_billing(
            {
                "firstName": "Ada",
                "lastName": "Lovelace",
                "addressLine1": "1 Main St",
                "locality": "Dover",
                "region": "DE",
                "postalCode": "19901",
                "country": "us",
            }
        )
        self.assertEqual(result["name"], "Ada Lovelace")
        self.assertEqual(result["country"], "US")
        self.assertEqual(result["line2"], "")

    def test_billing_requires_all_core_fields(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "缺少字段"):
            normalize_billing({"name": "Only Name"})

    def test_expiry_formats(self) -> None:
        self.assertEqual(parse_expiry("04/30"), ("04", "2030"))
        self.assertEqual(parse_expiry("04/2030"), ("04", "2030"))
        with self.assertRaises(ProtocolError):
            parse_expiry("13/30")

    def test_redaction(self) -> None:
        self.assertEqual(
            redact({"cardNumber": "4242424242424242", "status": "ok"}),
            {"cardNumber": "<redacted:16>", "status": "ok"},
        )
        self.assertEqual(
            sanitize_message("connect socks5h://alice:secret@proxy:1080 failed"),
            "connect socks5h://***@proxy:1080 failed",
        )
        sanitized = sanitize_message(
            "user@example.com 4242424242424242 ct_secret_value"
        )
        self.assertNotIn("user@example.com", sanitized)
        self.assertNotIn("4242424242424242", sanitized)
        self.assertNotIn("ct_secret_value", sanitized)

    def test_card_decline_classification(self) -> None:
        self.assertTrue(is_card_decline(ProtocolError("payment_declined", "no")))
        self.assertFalse(is_card_decline(ProtocolError("network_error", "no")))


class ConfigAndHttpTests(unittest.TestCase):
    def test_uses_original_live_publishable_key_by_default(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            config = load_config("/path/that/does/not/exist.json")
        self.assertEqual(config.stripe_publishable_key, DEFAULT_STRIPE_PUBLISHABLE_KEY)
        self.assertTrue(config.stripe_publishable_key.startswith("pk_live_"))
        self.assertFalse(config.commit_payments)
        self.assertEqual(config.callback_url, "")

    def test_config_env_overrides_file(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "config.json")
            path.write_text(
                json.dumps(
                    {
                        "callbackUrl": "http://file",
                        "planType": "basic",
                        "country": "PH",
                        "commitPayments": False,
                        "sessionJson": {"accessToken": "access-from-config"},
                        "card": {
                            "number": "4242424242424242",
                            "expiry": "04/30",
                            "cvc": "123",
                        },
                        "billing": {"fullName": "Test User"},
                    }
                ),
                encoding="utf-8",
            )
            with patch.dict(
                os.environ,
                {"CALLBACK_URL": "http://env", "COMMIT_PAYMENTS": "1"},
                clear=False,
            ):
                config = load_config(path)
        self.assertEqual(config.callback_url, "http://env")
        self.assertTrue(config.commit_payments)
        self.assertEqual(config.session_json, {"accessToken": "access-from-config"})
        self.assertEqual(config.card["expiry"], "04/30")
        self.assertEqual(config.billing["fullName"], "Test User")
        task = config.task()
        self.assertTrue(task["taskId"].startswith("local-"))
        self.assertEqual(task["planType"], "basic")
        self.assertEqual(task["planName"], "basic_plan")
        self.assertEqual(task["country"], "PH")

    def test_rejects_non_object_card_config(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "config.json")
            path.write_text(json.dumps({"card": "invalid"}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "card"):
                load_config(path)

    def test_task_requires_all_config_fields(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "planType"):
            Config().task()

    def test_task_ids_are_generated_and_pro_plan_name_is_derived(self) -> None:
        config = Config(plan_type="premium", country="us")
        task = config.task()
        self.assertTrue(config.worker_id.startswith("protocol-"))
        self.assertTrue(task["taskId"].startswith("local-"))
        self.assertEqual(task["planName"], "premium_plan")
        self.assertEqual(task["country"], "US")

    def test_unknown_plan_type_is_rejected(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "不支持"):
            Config(plan_type="unknown-plan").task()

    def test_http_client_disables_cookie_persistence(self) -> None:
        seen: list[dict[str, str]] = []

        def handler(_method: str, _url: str, **kwargs: object) -> FakeResponse:
            seen.append(dict(kwargs["cookies"]))  # type: ignore[arg-type]
            return FakeResponse({"ok": True})

        session = FakeSession(handler)
        session.cookies.set("platform", "secret")
        client = HttpClient(session=session, cookies_enabled=False)
        self.assertEqual(client.request("https://api.stripe.com/test").data, {"ok": True})
        self.assertEqual(seen, [{}])

    def test_http_error_extracts_detail_without_dumping_response_values(self) -> None:
        detail_session = FakeSession(
            lambda *_args, **_kwargs: FakeResponse(
                {"detail": "confirmation token invalid"},
                status=400,
            )
        )
        with self.assertRaises(HttpError) as raised:
            HttpClient(session=detail_session).request("https://example.test/confirm")
        self.assertEqual(str(raised.exception), "confirmation token invalid")

        shape_session = FakeSession(
            lambda *_args, **_kwargs: FakeResponse(
                {"request_id": "secret-request-value", "issues": [{"field": "token"}]},
                status=400,
            )
        )
        with self.assertRaises(HttpError) as shaped:
            HttpClient(session=shape_session).request("https://example.test/confirm")
        self.assertIn("响应结构", str(shaped.exception))
        self.assertNotIn("secret-request-value", str(shaped.exception))


if __name__ == "__main__":
    unittest.main()
