from __future__ import annotations

import io
import json
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

from saas_pay.har_inspector import inspect_har


class HarInspectorTests(unittest.TestCase):
    def test_outputs_only_structure_not_sensitive_values(self) -> None:
        har = {
            "log": {
                "entries": [
                    {
                        "startedDateTime": "2026-01-01T00:00:00Z",
                        "time": 25,
                        "request": {
                            "method": "POST",
                            "url": "https://api.stripe.com/v1/confirmation_tokens",
                            "headers": [
                                {"name": "Authorization", "value": "Bearer secret-value"}
                            ],
                            "postData": {
                                "text": "payment_method_data%5Bcard%5D%5Bnumber%5D=4242424242424242&key=pk_live_YOUR_STRIPE_KEY_HERE"
                            },
                        },
                        "response": {"status": 200},
                    }
                ]
            }
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory, "payment.har")
            path.write_text(json.dumps(har), encoding="utf-8")
            output = io.StringIO()
            with redirect_stdout(output):
                result = inspect_har(path)
        rendered = output.getvalue()
        self.assertEqual(result[0]["status"], 200)
        self.assertIn("payment_method_data[card][number]", rendered)
        self.assertNotIn("4242424242424242", rendered)
        self.assertNotIn("pk_live_YOUR_STRIPE_KEY_HERE", rendered)
        self.assertNotIn("secret-value", rendered)


if __name__ == "__main__":
    unittest.main()
