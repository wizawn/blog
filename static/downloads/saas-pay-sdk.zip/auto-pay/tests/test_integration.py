from __future__ import annotations

import os
import unittest
from pathlib import Path

from saas_pay.platform_client import PlatformClient
from saas_pay.config import load_config
from saas_pay.http_client import HttpClient
from saas_pay.proxy import ProxyVerifier, create_upstream_transport
from saas_pay.session import parse_session_json

CONFIG_PATH = Path("config.json")
ENABLED = (
    os.getenv("SAAS_PAY_RUN_INTEGRATION") == "1"
    and CONFIG_PATH.exists()
)


@unittest.skipUnless(ENABLED, "需要 SAAS_PAY_RUN_INTEGRATION=1 和 config.json")
class LiveIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.config = load_config(CONFIG_PATH)
        cls.transport = create_upstream_transport(cls.config)
        session = parse_session_json(cls.config.session_json)
        cls.platform = PlatformClient(
            http=HttpClient(
                session=cls.transport.create_session(),
                cookies=session.cookies,
                timeout_ms=45_000,
            ),
            access_token=session.access_token,
        )

    def test_proxy_exit_country(self) -> None:
        self.assertTrue(self.transport.proxied)
        result = ProxyVerifier(self.config, self.transport.create_session).verify(force=True)
        self.assertTrue(result["ip"])
        if self.config.proxy_expected_country:
            self.assertEqual(result["country"], self.config.proxy_expected_country)

    def test_session_and_account(self) -> None:
        self.platform.refresh_session()
        self.assertTrue(self.platform.access_token)
        account = self.platform.account_info()
        self.assertIn("plan", account)

    def test_us_currency(self) -> None:
        self.assertEqual(self.platform.get_currency("US"), "USD")


if __name__ == "__main__":
    unittest.main()
