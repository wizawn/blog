from __future__ import annotations

import unittest
from typing import Any

from saas_pay.config import Config
from saas_pay.payment_flow import PaymentFlow
from tests.helpers import FakeResponse, FakeTransport


class PaymentFlowTests(unittest.TestCase):
    def test_external_cs_session_returns_high_risk_before_card_tokenization(self) -> None:
        calls: list[str] = []

        def handler(_method: str, url: str, **_kwargs: Any) -> FakeResponse:
            calls.append(url)
            if "/auth/session" in url:
                return FakeResponse({"accessToken": "refreshed"}, url=url)
            if "/accounts/check/" in url:
                return FakeResponse(
                    {
                        "accounts": {
                            "default": {
                                "account": {"account_id": "acct_test"},
                                "entitlement": {
                                    "subscription_plan": "free_plan",
                                    "has_active_subscription": False,
                                },
                            }
                        }
                    },
                    url=url,
                )
            if url.endswith("/api/v1/me"):
                return FakeResponse({"email": "test@example.com"}, url=url)
            if "/checkout_pricing_config/" in url:
                return FakeResponse({"currency_config": {"symbol_code": "USD"}}, url=url)
            if url.endswith("/api/v1/payments/checkout"):
                return FakeResponse(
                    {
                        "checkout_session_id": "cs_external",
                        "checkout_url": "https://checkout.stripe.test/hosted",
                    },
                    url=url,
                )
            raise AssertionError(f"unexpected request: {url}")

        config = Config(
            plan_type="basic",
            session_json={"accessToken": "access", "user": {"email": "test@example.com"}},
            card={"number": "4242424242424242", "expiry": "04/30", "cvc": "123"},
            billing={
                "fullName": "Test User",
                "line1": "1 Test Street",
                "city": "Dover",
                "state": "DE",
                "zip": "19901",
                "country": "US",
            },
        )
        result = PaymentFlow(
            config,
            transport=FakeTransport(handler),  # type: ignore[arg-type]
        ).run()
        self.assertEqual(result["status"], "high_risk")
        self.assertEqual(result["message"], "高风险，无法充值")
        self.assertFalse(any("/checkout/taxes" in url for url in calls))
        self.assertFalse(any("confirmation_tokens" in url for url in calls))

    def test_dry_run_stops_before_payment_intent_confirm(self) -> None:
        calls: list[dict[str, Any]] = []

        def handler(method: str, url: str, **kwargs: Any) -> FakeResponse:
            calls.append({"method": method, "url": url, **kwargs})
            if "/auth/session" in url:
                return FakeResponse({"accessToken": "refreshed-token"}, url=url)
            if "/accounts/check/" in url:
                return FakeResponse(
                    {
                        "accounts": {
                            "default": {
                                "account": {"account_id": "acct_test"},
                                "entitlement": {
                                    "subscription_plan": "free_plan",
                                    "has_active_subscription": False,
                                },
                            }
                        }
                    },
                    url=url,
                )
            if url.endswith("/api/v1/me"):
                return FakeResponse({"email": "test@example.com"}, url=url)
            if "/checkout_pricing_config/" in url:
                return FakeResponse({"currency_config": {"symbol_code": "PHP"}}, url=url)
            if url.endswith("/api/v1/payments/checkout"):
                return FakeResponse({"checkout_session_id": "ics_test"}, url=url)
            if url.endswith("/api/v1/payments/checkout/taxes"):
                self.assertEqual(kwargs["json"]["billing_address"]["line2"], "")
                return FakeResponse(
                    {
                        "checkout_session": {
                            "customer": "cus_test",
                            "currency": "php",
                            "mode": "subscription",
                        }
                    },
                    url=url,
                )
            if url.endswith("/v1/confirmation_tokens"):
                self.assertEqual(kwargs["session_number"], 2)
                self.assertEqual(kwargs["cookies"], {})
                self.assertEqual(
                    kwargs["data"]["payment_method_data[card][number]"],
                    "4242424242424242",
                )
                self.assertNotIn(
                    "payment_method_data[radar_options][hcaptcha_token]",
                    kwargs["data"],
                )
                return FakeResponse({"id": "ct_test"}, url=url)
            if url.endswith("/api/v1/payments/checkout/confirm"):
                self.assertNotIn("vendor-sentinel-token", kwargs["headers"])
                return FakeResponse(
                    {
                        "status": "success",
                        "client_secret": "pi_test_secret_value",
                        "confirm_return_url": "https://platform.example.com/checkout/verify",
                    },
                    url=url,
                )
            raise AssertionError(f"unexpected request: {url}")

        config = Config(
            plan_type="basic",
            country="PH",
            stripe_publishable_key="pk_test",
            session_json={
                "accessToken": "access-test",
                "user": {"email": "test@example.com"},
            },
            card={
                "number": "4242 4242 4242 4242",
                "expiry": "04/30",
                "cvc": "123",
            },
            billing={
                "fullName": "Test User",
                "line1": "1 Test Street",
                "city": "Dover",
                "state": "DE",
                "zip": "19901",
                "country": "US",
            },
            commit_payments=False,
            verify_attempts=1,
        )
        flow = PaymentFlow(config, transport=FakeTransport(handler))  # type: ignore[arg-type]
        result = flow.run()
        self.assertEqual(result["status"], "prepared")
        self.assertFalse(any("/payment_intents/" in call["url"] for call in calls))


if __name__ == "__main__":
    unittest.main()
