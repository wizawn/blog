from __future__ import annotations

import unittest

from saas_pay.config import Config
from saas_pay.errors import ProtocolError
from saas_pay.proxy import (
    create_upstream_transport,
    parse_proxy_url,
    safe_proxy_label,
)


class ProxyTests(unittest.TestCase):
    def test_safe_label_hides_credentials(self) -> None:
        parsed = parse_proxy_url("socks5h://user:pass@127.0.0.1:10801")
        self.assertEqual(safe_proxy_label(parsed), "socks5h://127.0.0.1:10801")

    def test_required_proxy_never_falls_back_to_direct(self) -> None:
        with self.assertRaisesRegex(ProtocolError, "代理为必填项"):
            create_upstream_transport(Config())

    def test_rejects_unsupported_protocol(self) -> None:
        with self.assertRaises(ProtocolError):
            parse_proxy_url("ftp://127.0.0.1:21")

    def test_transport_ignores_ambient_proxy_variables(self) -> None:
        transport = create_upstream_transport(
            Config(proxy_url="socks5h://127.0.0.1:10801")
        )
        session = transport.create_session()
        self.assertFalse(session.trust_env)
        self.assertEqual(session.proxies["https"], "socks5h://127.0.0.1:10801")


if __name__ == "__main__":
    unittest.main()
