from __future__ import annotations

import unittest
from typing import Any

from saas_pay.config import Config
from saas_pay.callback_client import DisabledCallbackClient
from saas_pay.errors import ProtocolError
from saas_pay.worker import ProtocolWorker


class FakeTransport:
    proxied = False
    label = "fake"
    proxy_url = ""


class FakeCallback:
    def __init__(self) -> None:
        self.calls: list[tuple[Any, ...]] = []
        self.status = ""

    def set_status(self, status: str) -> None:
        self.status = status

    def activate(self, task: dict[str, Any]) -> None:
        self.calls.append(("activate", task))

    def fail(self, *args: Any) -> None:
        self.calls.append(("fail", *args))

    def done(self, *args: Any) -> None:
        self.calls.append(("done", *args))

    def card_retry(self, *args: Any) -> None:
        self.calls.append(("card_retry", *args))

    def suspicious(self, *args: Any) -> None:
        self.calls.append(("suspicious", *args))

    def recharge_upgrade(self, *args: Any) -> None:
        self.calls.append(("recharge_upgrade", *args))

    def clear(self) -> None:
        self.status = ""


class FakeFlow:
    result: dict[str, Any] | None = None
    error: ProtocolError | None = None

    def __init__(self, *_args: Any, **_kwargs: Any) -> None:
        pass

    def run(self) -> dict[str, Any]:
        if self.error:
            raise self.error
        assert self.result is not None
        return self.result


class FailingReportCallback(FakeCallback):
    def fail(self, *_args: Any) -> None:
        raise ProtocolError("network_error", "callback unavailable")


class WorkerTests(unittest.TestCase):
    def setUp(self) -> None:
        FakeFlow.result = None
        FakeFlow.error = None
        self.callback = FakeCallback()
        config = Config(
                plan_type="basic",
                country="US",
                session_json={"accessToken": "config-access"},
                card={"number": "4242424242424242", "expiry": "04/30", "cvc": "123"},
            )
        config.worker_id = "test-worker"
        config.task_id = "task-1"
        self.worker = ProtocolWorker(
            config,
            transport=FakeTransport(),  # type: ignore[arg-type]
            callback=self.callback,  # type: ignore[arg-type]
            flow_factory=FakeFlow,  # type: ignore[arg-type]
        )

    def test_dry_run_reports_tagged_failure(self) -> None:
        FakeFlow.result = {"status": "prepared"}
        result = self.worker.handle()
        self.assertEqual(result["status"], "prepared")
        self.assertEqual(self.callback.calls[0][0], "activate")
        self.assertEqual(self.callback.calls[0][1]["planName"], "basic_plan")
        self.assertEqual(self.callback.calls[1][0], "fail")
        self.assertIn("dry_run", self.callback.calls[1][2])

    def test_high_risk_returns_without_reporting_success(self) -> None:
        FakeFlow.result = {
            "status": "high_risk",
            "code": "external_checkout_session",
            "message": "高风险，无法充值",
        }
        result = self.worker.handle()
        self.assertEqual(result["status"], "high_risk")
        self.assertEqual(self.callback.calls[1][0], "fail")
        self.assertIn("high_risk", self.callback.calls[1][2])
        self.assertFalse(any(call[0] == "done" for call in self.callback.calls))

    def test_card_decline_requests_card_retry(self) -> None:
        FakeFlow.error = ProtocolError(
            "payment_declined",
            "do_not_honor",
            payment_submitted=True,
        )
        with self.assertRaises(ProtocolError):
            self.worker.handle()
        self.assertEqual(self.callback.calls[1][0], "card_retry")
        self.assertEqual(self.callback.calls[1][1], "task-1")
        self.assertEqual(self.callback.calls[1][3], '{"accessToken":"config-access"}')

    def test_unknown_submitted_result_is_suspicious(self) -> None:
        FakeFlow.error = ProtocolError(
            "payment_unverified",
            "unknown",
            payment_submitted=True,
        )
        with self.assertRaises(ProtocolError):
            self.worker.handle()
        self.assertEqual(self.callback.calls[1][0], "suspicious")
        self.assertEqual(self.callback.calls[1][3], "4242424242424242")

    def test_stop(self) -> None:
        self.assertFalse(self.worker.stopped)
        self.worker.stop()
        self.assertTrue(self.worker.stopped)

    def test_callback_is_disabled_by_default(self) -> None:
        config = Config(plan_type="basic")
        worker = ProtocolWorker(
            config,
            transport=FakeTransport(),  # type: ignore[arg-type]
            flow_factory=FakeFlow,  # type: ignore[arg-type]
        )
        self.assertIsInstance(worker.callback, DisabledCallbackClient)
        FakeFlow.result = {"status": "prepared"}
        self.assertEqual(worker.handle()["status"], "prepared")

    def test_callback_failure_does_not_mask_original_error(self) -> None:
        FakeFlow.error = ProtocolError("checkout_snapshot_invalid", "original error")
        worker = ProtocolWorker(
            self.worker.config,
            transport=FakeTransport(),  # type: ignore[arg-type]
            callback=FailingReportCallback(),  # type: ignore[arg-type]
            flow_factory=FakeFlow,  # type: ignore[arg-type]
        )
        with self.assertRaises(ProtocolError) as raised:
            worker.handle()
        self.assertEqual(raised.exception.code, "checkout_snapshot_invalid")


if __name__ == "__main__":
    unittest.main()
