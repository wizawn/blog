# Subscription Manager — 快捷支付工具

在页面上填写卡号、有效期、CVV 和 Platform Session，后台自动完成完整支付流程。

## 支付流程

```
普通支付页 `/`
  └─ Free: 创建 Checkout → 设置税费 → 令牌化 → 确认扣款

订阅升级页 `/upgrade`
  └─ 已订阅: 读取升级预览 → 必要时恢复续费 → 更新计划 → 确认扣款/3DS
```

两个页面使用独立接口。普通支付调用 `/api/pay`，已有订阅升级调用
`/api/subscription/upgrade`；账号走错入口时只返回对应页面地址，不会自动切换支付协议。

升级页先调用 `/api/subscription/upgrade/preview` 读取当前计划、应付金额和默认卡，
然后提供两种支付来源：

- `default`：使用账号默认已绑卡，订阅更新请求不传 `payment_method_id`
- `new`：复用普通绑卡接口 `/api/payment-methods/bind`，由后端完成 SetupIntent
  确认并取得 `pm_xxx`，再把该支付方式传给订阅更新

两条升级路径在提交订阅更新后共用相同的 PaymentIntent、3D Secure 和订阅状态验证逻辑。
后端绑卡返回 `requires_action` 时，升级页会先完成 SetupIntent 3D Secure 并确认
`pm_xxx` 已绑定，再继续提交订阅更新。

独立绑卡页 `/bind` 同样使用 Stripe Elements：后端为当前 Platform 账号创建
SetupIntent，浏览器确认后取得 `pm_xxx`，后端再从该账号的支付方式列表确认绑定结果。
原 `/api/payment-methods/bind` 接口继续保留用于兼容已有调用。

计划接口值：Plus 为 `basic_plan`，Standard 为 `standard_plan`，
Premium 为 `premium_plan`。

免费账号新开通 Pro 时可通过 `PRO_CHECKOUT_PROTOCOL` 选择协议：

```env
# 默认值，原有协议：直接创建前端选择的 Standard 或 Premium Checkout
PRO_CHECKOUT_PROTOCOL=legacy

# HAR 对齐协议：Standard 直接创建；Premium 从 Standard Checkout 切换
PRO_CHECKOUT_PROTOCOL=new
```

该设置不影响 Plus、已有订阅升级或 Stripe 3D Secure 验证。

## 启动

```bash
cd /Users/admin/project/platform/stripe-checkout
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
cp .env.example .env
```

在 `.env` 中配置可选的代理：

```env
OUTBOUND_PROXY_URL=http://user:pass@host:port
```

## 运行

```bash
python app.py
```

浏览器打开：

- 普通支付：`http://127.0.0.1:8088/`
- 已有订阅升级：`http://127.0.0.1:8088/upgrade`
- 独立绑卡：`http://127.0.0.1:8088/bind`

## Dokploy / Docker Compose

在 Dokploy 中选择 Compose 部署，使用仓库根目录的 `docker-compose.yml`。
将 `.env.example` 中的变量配置到 Dokploy Environment，至少设置一个稳定的
`APP_SECRET_KEY`。应用在容器内监听 `8088`，域名服务端口也设置为 `8088`。

本地验证部署配置：

```bash
cp .env.example .env
# 设置 APP_SECRET_KEY 和需要的业务配置
docker compose up --build -d
```

健康检查地址为 `/healthz`，支付日志保存在 Compose 命名卷
`stripe-checkout-logs` 中。

## 使用

1. 在 platform.example.com 登录后，访问 `/api/auth/session` 获取 Session JSON
2. 免费账号打开普通支付页，已有付费订阅打开升级页
3. 粘贴 Session，填写卡号、有效期和 CVV
4. 选择计划并提交

## 账单地址工具

配置后端账单地址时，可以使用 [Billing Address Generator](https://billingaddressgenerator.com/)
查看不同国家的地址格式并生成示例地址。将页面生成的字段填写到 Dokploy 环境变量：

| 地址字段 | 环境变量 |
|---|---|
| 姓名 | `DEFAULT_BILLING_NAME` |
| 街道 | `DEFAULT_BILLING_LINE1` |
| 城市 | `DEFAULT_BILLING_CITY` |
| 州/省简称 | `DEFAULT_BILLING_STATE` |
| ZIP/邮编 | `DEFAULT_BILLING_POSTAL_CODE` |
| 两位国家代码 | `DEFAULT_BILLING_COUNTRY` |

生成器适合辅助确认地址格式和准备测试数据。真实支付应优先使用与持卡人、发卡行记录
一致的账单地址，否则可能被 Stripe 或发卡行拒绝。

## 代理

`OUTBOUND_PROXY_URL` 支持 http/https/socks5/socks5h。会影响所有 Python 端发出的 HTTP 请求（Platform API + Stripe API）。

不设置则不使用代理。

### 菲律宾住宅代理

支付请求建议使用纯净的菲律宾住宅（家宽）IP。数据中心代理、多人共享或已有不良记录的
IP 更容易触发风控。推荐使用 [Proxy Provider 菲律宾住宅代理](https://proxy-provider.cn/?r=000000)。

购买和生成代理时建议选择：

- 产品：住宅代理
- 国家/地区：Philippines
- 城市/州省：随机
- 轮换方式：粘性 IP
- TTL：按业务时长选择，例如 7 天

![Proxy Provider 菲律宾住宅代理配置示例](docs/images/proxy-provider-ph-residential-proxy.png)

Dokploy 中只填写代理 URL，不要带 `curl` 的 `-L` 或测试网址。建议使用
`socks5h`，让域名也通过代理解析：

```env
OUTBOUND_PROXY_URL=socks5h://username:password@host:port
```

住宅代理不等于 IP 一定纯净。正式使用前应检查出口国家、ASN/ISP 和 IP 风险记录；
如果出口地区不正确或频繁触发验证，应更换 IP。

### 海外 VPS 服务器

应用可部署在 [RackNerd 海外 VPS](https://my.racknerd.com/aff.php?aff=19432)，
再通过上面的菲律宾住宅代理访问 Platform 和 Stripe。由于镜像内包含 Playwright 和
Chromium，建议选择以下或更高配置：

- 2 vCPU
- 2 GB 内存
- 20 GB SSD
- Ubuntu 22.04/24.04
- 可用的 80、443 端口

VPS 用于运行 Docker、Dokploy 和应用容器，最终支付请求的出口地区由
`OUTBOUND_PROXY_URL` 决定。域名解析到 VPS 公网 IP 后，在 Dokploy 中将容器端口
设置为 `8088` 并开启 HTTPS。

## 安全

- 普通支付的卡号和 CVV 仅在服务器内存中使用，不持久化
- 升级新卡由 Stripe Elements 处理，应用后端不接收卡号和 CVV
- 不存储 Access Token
- 无数据库
- 仅监听 127.0.0.1
