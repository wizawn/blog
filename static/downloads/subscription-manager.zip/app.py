#!/usr/bin/env python3
"""Subscription Manager — 快捷支付工具

在页面上填写卡号、有效期、CVV 和 Platform Session，后台自动发起完整支付流程。

使用 curl_cffi (impersonate=chrome131) 绕过 Cloudflare 检测。
日志记录在 logs/ 目录下，每次支付请求产生一个独立日志文件。
"""

from __future__ import annotations

import datetime
import json
import logging
import os
import re
import secrets
import sys
import traceback
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlencode as _urlencode, urlsplit

try:
    from curl_cffi.requests import Session as CurlSession
except ImportError:
    CurlSession = None  # type: ignore[assignment]

from dotenv import load_dotenv
from flask import Flask, jsonify, request, send_from_directory

try:
    from challenge_solver_client import (
        fetch_payment_metadata,
        get_challenge_context,
        get_challenge_token,
    )
except ImportError:
    get_challenge_token = None  # type: ignore[assignment]
    get_challenge_context = None  # type: ignore[assignment]
    fetch_payment_metadata = None  # type: ignore[assignment]

# ── 路径 ──────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
LOG_DIR = BASE_DIR / "logs"
LOG_DIR.mkdir(exist_ok=True)

load_dotenv(BASE_DIR / ".env")

# ── 日志 ──────────────────────────────────────────────────────────
# Flask/Werkzeug 访问日志也输出到文件
_wsgi_log = logging.getLogger("werkzeug")
_wsgi_log.setLevel(logging.INFO)


def _setup_request_logger(request_id: str) -> tuple[logging.Logger, Path]:
    """为一个支付 request 创建独立的 logger 和日志文件。"""
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{ts}_{request_id[:8]}.log"
    log_path = LOG_DIR / filename

    logger = logging.getLogger(f"pay.{request_id}")
    logger.setLevel(logging.DEBUG)
    logger.handlers.clear()
    logger.propagate = False

    fh = logging.FileHandler(str(log_path), encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(
        "%(asctime)s  [%(levelname)-7s]  %(message)s",
        datefmt="%H:%M:%S",
    ))
    logger.addHandler(fh)

    # 也输出到 stderr（后台进程 stdout 不可见时走 stderr）
    sh = logging.StreamHandler(sys.stderr)
    sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter("[pay] %(levelname)s  %(message)s"))
    logger.addHandler(sh)

    return logger, log_path


# ── 配置 ──────────────────────────────────────────────────────────
OUTBOUND_PROXY_URL = os.environ.get("OUTBOUND_PROXY_URL", "").strip()
STRIPE_PUBLISHABLE_KEY = (
    "pk_live_YOUR_KEY"
)
STRIPE_API_BASE = "https://api.stripe.com/v1"
PLATFORM_BASE = "https://platform.example.com"
STRIPE_VERSION = "2025-03-31.basil"

DEFAULT_BILLING = {
    "name": os.environ.get("DEFAULT_BILLING_NAME", "").strip(),
    "email": os.environ.get("DEFAULT_BILLING_EMAIL", "").strip(),
    "line1": os.environ.get("DEFAULT_BILLING_LINE1", "").strip(),
    "city": os.environ.get("DEFAULT_BILLING_CITY", "").strip(),
    "state": os.environ.get("DEFAULT_BILLING_STATE", "").strip(),
    "postal_code": os.environ.get("DEFAULT_BILLING_POSTAL_CODE", "").strip(),
    "country": os.environ.get("DEFAULT_BILLING_COUNTRY", "PH").strip().upper(),
}
DEFAULT_PLAN = os.environ.get("DEFAULT_PLAN", "premium_plan").strip()
PRO_CHECKOUT_PROTOCOL = os.environ.get(
    "PRO_CHECKOUT_PROTOCOL", "legacy"
).strip().lower()
if PRO_CHECKOUT_PROTOCOL not in {"new", "legacy"}:
    raise RuntimeError(
        "PRO_CHECKOUT_PROTOCOL 只能设置为 new 或 legacy"
    )

PLAN_ALIASES = {
    "plus": "basic_plan",
    "basic": "basic_plan",
    "basic_plan": "basic_plan",
    "standard": "standard_plan",
    "prolite": "standard_plan",
    "standard_plan": "standard_plan",
    "premium": "premium_plan",
    "pro": "premium_plan",
    "premium_plan": "premium_plan",
}
PLAN_SUBSCRIPTION_TYPES = {
    "basic_plan": "basic",
    "standard_plan": "standard",
    "premium_plan": "premium",
}
NEW_PRO_CHECKOUT_PLANS = frozenset({"standard_plan", "premium_plan"})

# ── Flask ────────────────────────────────────────────────────────
app = Flask(__name__, static_folder="static", static_url_path="/static")
app.secret_key = os.environ.get("APP_SECRET_KEY") or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    MAX_CONTENT_LENGTH=128 * 1024,
)


# ── HTTP Session（curl_cffi + 代理）────────────────────────────────
# 用 curl_cffi 的 browser impersonation 绕过 Cloudflare JS Challenge
# Simon 的脚本也用了同样的方案


def make_http_session() -> Any:
    """创建 curl_cffi Session (impersonate=chrome131) 或 fallback requests。"""
    if CurlSession is None:
        import requests as _requests
        s = _requests.Session()
        if OUTBOUND_PROXY_URL:
            s.proxies = {"http": OUTBOUND_PROXY_URL, "https": OUTBOUND_PROXY_URL}
        return s

    s = CurlSession(impersonate="chrome136")
    if hasattr(s, "trust_env"):
        s.trust_env = False
    if OUTBOUND_PROXY_URL:
        s.proxies = {"http": OUTBOUND_PROXY_URL, "https": OUTBOUND_PROXY_URL}
    return s


def _http_get(http: Any, url: str, *, headers: dict[str, str], timeout: int = 45,
              params: Any = None) -> Any:
    """兼容 requests 和 curl_cffi 的 GET。"""
    resp = http.get(url, headers=headers, timeout=timeout, params=params or None)
    return resp


def _http_post_form(http: Any, url: str, *, data: Any, headers: dict[str, str], timeout: int = 45) -> Any:
    """兼容 requests 和 curl_cffi 的表单 POST。"""
    resp = http.post(url, data=data, headers=headers, timeout=timeout)
    return resp


def _http_post_json(http: Any, url: str, *, json_data: dict[str, Any], headers: dict[str, str], timeout: int = 45) -> Any:
    """兼容 requests 和 curl_cffi 的 JSON POST。"""
    # curl_cffi 0.13 用 data=json.dumps() + content-type
    if CurlSession is not None and isinstance(http, CurlSession):
        h = dict(headers)
        h["Content-Type"] = "application/json"
        resp = http.post(url, data=json.dumps(json_data), headers=h, timeout=timeout)
        return resp
    else:
        resp = http.post(url, json=json_data, headers=headers, timeout=timeout)
        return resp


# ── 工具 ──────────────────────────────────────────────────────────
def _uuid() -> str:
    return str(uuid.uuid4())


def _random_hex(n: int = 16) -> str:
    return secrets.token_hex(n)


def _find_in(obj: Any, keys: tuple[str, ...]) -> str:
    """递归查找嵌套字典/列表中的字符串值。"""
    if isinstance(obj, dict):
        for k, v in obj.items():
            if k in keys and isinstance(v, str) and v:
                return v
            found = _find_in(v, keys)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _find_in(item, keys)
            if found:
                return found
    return ""


def _proxy_log_label(proxy_url: str) -> str:
    if not proxy_url:
        return "(未配置)"
    try:
        parsed = urlsplit(proxy_url)
        host = parsed.hostname or "configured"
        port = f":{parsed.port}" if parsed.port else ""
        auth = "***@" if parsed.username or parsed.password else ""
        return f"{parsed.scheme}://{auth}{host}{port}"
    except (TypeError, ValueError):
        return "(已配置)"


def _normalize_plan(value: str) -> str:
    plan = PLAN_ALIASES.get(value.strip().lower(), "")
    if not plan:
        raise ValueError(f"无效计划: {value}")
    return plan


def _subscription_plan_type(value: str) -> str:
    normalized = value.strip().lower()
    if normalized in ("basic", "standard", "premium"):
        return normalized
    return PLAN_SUBSCRIPTION_TYPES.get(PLAN_ALIASES.get(normalized, ""), normalized)


def _safe_headers_for_log(headers: Any) -> dict[str, str]:
    """保留排障所需响应头，同时避免认证信息写入日志。"""
    sensitive = {
        "authorization",
        "cookie",
        "proxy-authorization",
        "set-cookie",
        "x-api-key",
        "vendor-challenge-token",
        "x-vendor-telemetry",
        "x-vendor-web-deployment-attestation",
        "x-vendor-device-id",
        "x-vendor-session-id",
        "platform-account-id",
    }
    return {
        str(key): "***" if str(key).lower() in sensitive else str(value)
        for key, value in dict(headers or {}).items()
    }


def _parse_session(raw: str) -> dict[str, Any]:
    raw = raw.strip()
    if not raw:
        raise ValueError("Session 无效，请填写 Platform Session")
    if raw.startswith("eyJ"):
        return {"accessToken": raw}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        raise ValueError("Session 无效，请粘贴 /api/auth/session 的完整响应")
    if not isinstance(data, dict):
        raise ValueError("Session 无效，需要 JSON 对象或 JWT 字符串")
    return data


def _extract_auth(session_data: dict[str, Any]) -> tuple[str, str, str, str]:
    """从 Session JSON 中提取认证信息，自动生成所需 Cookie。"""
    access_token = session_data.get("accessToken", "")
    if not access_token:
        raise ValueError("Session 中缺少 accessToken")
    email = session_data.get("user", {}).get("email", "") or ""
    user_id = session_data.get("user", {}).get("id", "") or ""

    # 从 session JSON 提取 sessionToken 作为 __Secure-platform.session-token cookie
    session_token = session_data.get("sessionToken", "")
    if not session_token:
        raise ValueError("Session JSON 中缺少 sessionToken，请粘贴完整的 /api/auth/session 响应")

    # 自动构建 Platform 所需的 Cookie（与 HAR 对齐）
    # sessionToken 直接对应 __Secure-platform.session-token
    cookies = (
        f"__Secure-platform.session-token={session_token}; "
        "__Secure-platform.callback-url=https%3A%2F%2Fplatform.example.com%2F"
    )
    return access_token, email, user_id, cookies


@dataclass
class SessionInput:
    access_token: str
    email: str
    user_id: str
    cookies: str


@dataclass
class PaymentInput(SessionInput):
    card: dict[str, str]
    billing: dict[str, str]
    plan: str


def _parse_session_input(payload: dict[str, Any], log: logging.Logger) -> SessionInput:
    """解析各支付页面共用的 Session 输入，不执行任何远程操作。"""
    session_raw = str(payload.get("session", "")).strip()
    if not session_raw:
        raise ValueError("请填写 Platform Session JSON 或 Access Token")

    session_data = _parse_session(session_raw)
    access_token, email, user_id, auto_cookies = _extract_auth(session_data)
    manual_cookies = str(payload.get("cookies", "")).strip()
    if manual_cookies:
        cookies = manual_cookies
        log.info("Cookie: 使用手动提供的 Cookie")
    else:
        cookies = auto_cookies
        log.info("Cookie: 自动从 sessionToken 构建（curl_cffi 会处理 TLS 指纹）")
    log.info("Session 解析成功 — email=%s  user_id=%s", email, user_id)
    return SessionInput(
        access_token=access_token,
        email=email,
        user_id=user_id,
        cookies=cookies,
    )


def _billing_details(payload: dict[str, Any], email: str) -> dict[str, str]:
    return {
        "name": str(payload.get("billing_name", DEFAULT_BILLING["name"])).strip(),
        "email": email or str(payload.get("billing_email", DEFAULT_BILLING["email"])).strip(),
        "line1": str(payload.get("billing_line1", DEFAULT_BILLING["line1"])).strip(),
        "city": str(payload.get("billing_city", DEFAULT_BILLING["city"])).strip(),
        "state": str(payload.get("billing_state", DEFAULT_BILLING["state"])).strip(),
        "postal_code": str(payload.get("billing_postal_code", DEFAULT_BILLING["postal_code"])).strip(),
        "country": str(payload.get("billing_country", DEFAULT_BILLING["country"])).strip().upper(),
        "currency": "php",
    }


def _parse_payment_input(payload: dict[str, Any], log: logging.Logger) -> PaymentInput:
    """解析普通开通所需的 Session、银行卡和计划输入。"""
    session_input = _parse_session_input(payload, log)

    raw_card_number = str(payload.get("card_number", "")).strip().replace(" ", "")
    card = {
        "number": raw_card_number,
        "exp_month": str(payload.get("exp_month", "")).strip(),
        "exp_year": str(payload.get("exp_year", "")).strip(),
        "cvc": str(payload.get("cvc", "")).strip(),
    }
    log.info(
        "卡号: %s···%s  有效期: %s/%s",
        raw_card_number[:6],
        raw_card_number[-4:],
        card["exp_month"],
        card["exp_year"],
    )
    if not card["number"] or not card["number"].isdigit():
        raise ValueError("卡号格式不正确")
    if len(card["number"]) < 13 or len(card["number"]) > 19:
        raise ValueError("卡号长度不正确")
    if not re.fullmatch(r"\d{1,2}", card["exp_month"]) or not (1 <= int(card["exp_month"]) <= 12):
        raise ValueError("有效期月份不正确 (1-12)")
    if len(card["exp_year"]) == 2:
        card["exp_year"] = "20" + card["exp_year"]
    if not re.fullmatch(r"\d{4}", card["exp_year"]):
        raise ValueError("有效期年份不正确 (如 2028)")
    if not re.fullmatch(r"\d{3,4}", card["cvc"]):
        raise ValueError("CVV 格式不正确 (3-4 位数字)")

    billing = _billing_details(payload, session_input.email)
    log.info(
        "账单: %s, %s, %s %s",
        billing["country"],
        billing["city"],
        billing["state"],
        billing["postal_code"],
    )
    plan = _normalize_plan(str(payload.get("plan", DEFAULT_PLAN)))
    log.info("计划: %s", plan)
    return PaymentInput(
        access_token=session_input.access_token,
        email=session_input.email,
        user_id=session_input.user_id,
        cookies=session_input.cookies,
        card=card,
        billing=billing,
        plan=plan,
    )


def _stream_to_dict(resp: Any) -> dict[str, Any]:
    """兼容两种库的 JSON 解析。"""
    if hasattr(resp, "json"):
        return resp.json()
    import json as _json
    return _json.loads(resp.content)


def _log_request(log: logging.Logger, resp: Any, *, label: str = "") -> None:
    log.debug("━━━ %s ━━━", label or "HTTP")
    log.debug("← HTTP %s (%s bytes)", resp.status_code, len(resp.content or b""))
    if not resp.ok:
        try:
            log.debug("  Response: %s", json.dumps(_stream_to_dict(resp), ensure_ascii=False)[:2000])
        except Exception:
            log.debug("  Response: %s", (resp.text or "")[:2000])


# ── Platform API ───────────────────────────────────────────────────
# 完整浏览器指纹（与协议一致，Stripe Radar 风控需要）
BROWSER_MAJOR = "136"
BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    f"Chrome/{BROWSER_MAJOR}.0.0.0 Safari/537.36"
)


@dataclass
class PlatformRequestContext:
    """一次 Platform 操作期间保持不变的浏览器和账户上下文。"""

    device_id: str
    account_id: str = ""
    payment_metadata: dict[str, str] = field(default_factory=dict)


def _cookie_value(cookies: str, name: str) -> str:
    expected = name.lower()
    for item in cookies.split(";"):
        key, separator, value = item.strip().partition("=")
        if separator and key.strip().lower() == expected:
            return value.strip()
    return ""


def _new_platform_context(cookies: str) -> PlatformRequestContext:
    return PlatformRequestContext(
        device_id=_cookie_value(cookies, "x-vendor-did") or _uuid(),
    )


def _cookies_with_device_id(cookies: str, device_id: str) -> str:
    if _cookie_value(cookies, "x-vendor-did"):
        return cookies
    prefix = cookies.strip().rstrip(";")
    return f"{prefix}; x-vendor-did={device_id}" if prefix else f"x-vendor-did={device_id}"


def _platform_headers(
    access_token: str,
    cookies: str = "",
    *,
    path: str = "",
    context: PlatformRequestContext | None = None,
) -> dict[str, str]:
    request_context = context or _new_platform_context(cookies)
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Accept": "*/*",
        "Content-Type": "application/json",
        "Accept-Language": "en-US,en;q=0.9",
        "User-Agent": BROWSER_UA,
        "Origin": PLATFORM_BASE,
        "Referer": f"{PLATFORM_BASE}/",
        "priority": "u=1, i",
        # 完整 sec-ch-ua 指纹（Stripe Radar 依赖）
        "sec-ch-ua": (
            f'"Not;A=Brand";v="8", "Chromium";v="{BROWSER_MAJOR}", '
            f'"Google Chrome";v="{BROWSER_MAJOR}"'
        ),
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-ch-ua-arch": '"x86"',
        "sec-ch-ua-bitness": '"64"',
        "sec-ch-ua-model": '""',
        "sec-ch-ua-full-version": f'"{BROWSER_MAJOR}.0.0.0"',
        "sec-ch-ua-full-version-list": (
            f'"Not;A=Brand";v="8", "Chromium";v="{BROWSER_MAJOR}.0.0.0", '
            f'"Google Chrome";v="{BROWSER_MAJOR}.0.0.0"'
        ),
        "sec-ch-ua-platform-version": '"15.0.0"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        # OAI 头
        "x-vendor-language": "en-US",
        "x-vendor-device-id": request_context.device_id,
    }
    headers["Cookie"] = _cookies_with_device_id(cookies, request_context.device_id)

    metadata_headers = {
        "client_version": "X-Vendor-Client-Version",
        "client_build_number": "X-Vendor-Client-Build-Number",
        "session_id": "X-Vendor-Session-Id",
    }
    for key, header_name in metadata_headers.items():
        value = request_context.payment_metadata.get(key, "")
        if value:
            headers[header_name] = value

    is_subscription_path = (
        path == "/api/v1/subscriptions"
        or path.startswith("/api/v1/subscriptions/")
    )
    if is_subscription_path:
        # 成功升级 HAR 没有 Client Hints；订阅接口严格按捕获到的头发送。
        for header_name in tuple(headers):
            if header_name.startswith("sec-ch-"):
                headers.pop(header_name)

    if path.startswith("/api/v1/payments/") or is_subscription_path:
        headers["x-vendor-target-path"] = path
        headers["x-vendor-target-route"] = path
    return headers


def _platform_get(
    log: logging.Logger, http: Any, access_token: str, cookies: str,
    path: str, context: PlatformRequestContext | None = None, **kwargs: Any
) -> dict[str, Any]:
    url = f"{PLATFORM_BASE}{path}"
    headers = _platform_headers(access_token, cookies, path=path, context=context)
    headers.pop("Content-Type", None)
    headers.pop("Origin", None)
    resp = _http_get(http, url, headers=headers,
                     params=kwargs.pop("params", None), **kwargs)
    _log_request(log, resp, label=f"Platform GET {path}")
    _check_platform_error(log, resp)
    return _stream_to_dict(resp)


def _platform_post(
    log: logging.Logger, http: Any, access_token: str, cookies: str,
    path: str, body: dict[str, Any], extra_headers: dict[str, str] | None = None,
    context: PlatformRequestContext | None = None,
) -> dict[str, Any]:
    url = f"{PLATFORM_BASE}{path}"
    headers = _platform_headers(access_token, cookies, path=path, context=context)
    if extra_headers:
        headers.update({k: v for k, v in extra_headers.items() if v})
    resp = _http_post_json(http, url, json_data=body, headers=headers)
    _log_request(log, resp, label=f"Platform POST {path}")
    _check_platform_error(log, resp)
    return _stream_to_dict(resp)


def _check_platform_error(log: logging.Logger, resp: Any) -> None:
    if resp.status_code == 401:
        raise RuntimeError("Session 已过期（HTTP 401），请重新获取 Access Token")
    if resp.status_code == 429:
        raise RuntimeError("请求过于频繁，请稍后再试")
    if not resp.ok:
        log.debug(
            "响应头: %s",
            json.dumps(
                _safe_headers_for_log(getattr(resp, "headers", {})),
                ensure_ascii=False,
            )[:1000],
        )
        try:
            detail = _stream_to_dict(resp)
        except Exception:
            detail = (resp.text or "")[:500]
        raise RuntimeError(f"Platform API 错误 (HTTP {resp.status_code}): {detail}")


# ── Challenge 风控上下文 ────────────────────────────────────────────
def _load_payment_metadata(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
) -> None:
    """在创建 Checkout 前加载与当前登录会话绑定的网页元数据。"""
    if context.payment_metadata or fetch_payment_metadata is None:
        return
    try:
        metadata = fetch_payment_metadata(
            http,
            access_token,
            _cookies_with_device_id(cookies, context.device_id),
            device_id=context.device_id,
            account_id=context.account_id,
            logger=log.info,
        )
        context.payment_metadata.update({
            key: str(value)
            for key, value in metadata.items()
            if value
        })
        if context.payment_metadata:
            log.info("支付元数据已加载: %s", ", ".join(sorted(context.payment_metadata)))
        else:
            log.warning("支付元数据未从首页提取到")
    except Exception as exc:
        log.warning("支付元数据提取失败: %s", exc)


def _build_challenge_headers(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
) -> dict[str, str]:
    """构建 Checkout 创建和确认阶段复用的 Challenge 风控请求头。

    包括 Vendor-Challenge-Token / X-Vendor-Telemetry / X-Vendor-Web-Deployment-Attestation。
    """
    headers: dict[str, str] = {}

    # 1. 支付元数据（首页 HTML 提取 attestation / client version 等）
    _load_payment_metadata(log, http, access_token, cookies, context)
    metadata = context.payment_metadata

    attestation = metadata.get("attestation", "")
    if attestation:
        headers["X-Vendor-Web-Deployment-Attestation"] = attestation
        log.info("Challenge: X-Vendor-Web-Deployment-Attestation 已加载")

    # 2. Challenge payload（Playwright 获取，带缓存）
    #    浏览器 confirm 用 challenge_solver/req 请求体的 {"p":"..."} 作为头值
    if get_challenge_token is not None:
        try:
            challenge_scope = f"{context.account_id}:{context.device_id}"
            challenge_token = get_challenge_token(
                OUTBOUND_PROXY_URL,
                cache_scope=challenge_scope,
                access_token=access_token,
                cookies=_cookies_with_device_id(cookies, context.device_id),
                device_id=context.device_id,
                account_id=context.account_id,
                logger=log.info,
            )
            if challenge_token:
                headers["Vendor-Challenge-Token"] = challenge_token
                # X-Vendor-Telemetry: 协议 fallback（ChallengeSDK.timing() 返回 null 时）
                # 浏览器完整格式: [1,920.3,7,187,50,2,0,923]，[1,null] 是协议认可的 fallback
                headers["X-Vendor-Telemetry"] = "[1,null]"
                log.info("Challenge: Vendor-Challenge-Token 已加载")
            else:
                log.warning("Challenge: token 获取失败，confirm 可能被 blocked")
        except Exception as exc:
            log.warning("Challenge token 获取异常: %s", exc)

    # 3. OAI client 头
    if metadata.get("client_version"):
        headers["X-Vendor-Client-Version"] = metadata["client_version"]
    if metadata.get("client_build_number"):
        headers["X-Vendor-Client-Build-Number"] = metadata["client_build_number"]
    if metadata.get("session_id"):
        headers["X-Vendor-Session-Id"] = metadata["session_id"]

    return headers


def _is_new_pro_checkout_plan(plan: str) -> bool:
    """仅 Standard/20x 的新开通流程使用浏览器一致的风控协议。"""
    return (
        PRO_CHECKOUT_PROTOCOL == "new"
        and plan in NEW_PRO_CHECKOUT_PLANS
    )


def _new_pro_checkout_create_plan(target_plan: str) -> str:
    """浏览器从 Standard Checkout 创建，再按需切换至 Premium。"""
    return "standard_plan" if target_plan in NEW_PRO_CHECKOUT_PLANS else target_plan


def _new_pro_payment_headers(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    *,
    include_account_id: bool,
) -> dict[str, str]:
    """构建 Pro 新开通 Update/Taxes 阶段的稳定支付上下文。"""
    _load_payment_metadata(log, http, access_token, cookies, context)
    attestation = context.payment_metadata.get("attestation", "")
    if not attestation:
        raise RuntimeError("Pro Checkout 缺少 X-Vendor-Web-Deployment-Attestation")

    headers = {"X-Vendor-Web-Deployment-Attestation": attestation}
    if include_account_id:
        if not context.account_id:
            raise RuntimeError("Pro Checkout 缺少 platform-account-id")
        headers["platform-account-id"] = context.account_id
    return headers


def _new_pro_challenge_headers(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    *,
    flow: str,
    include_account_id: bool,
) -> dict[str, str]:
    """为 Pro 新开通的 Create/Confirm 生成一次性的 flow 上下文。"""
    headers = _new_pro_payment_headers(
        log,
        http,
        access_token,
        cookies,
        context,
        include_account_id=include_account_id,
    )
    if get_challenge_context is None:
        raise RuntimeError("Pro Checkout Challenge 组件不可用")

    challenge_solver = get_challenge_context(
        OUTBOUND_PROXY_URL,
        flow=flow,
        access_token=access_token,
        cookies=_cookies_with_device_id(cookies, context.device_id),
        device_id=context.device_id,
        account_id=context.account_id,
        logger=log.info,
    )
    token = str(challenge_solver.get("token") or "").strip()
    if not token:
        raise RuntimeError(f"Pro Checkout Challenge Token 获取失败: flow={flow}")

    try:
        token_payload = json.loads(token)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Pro Checkout Challenge Token 格式无效") from exc
    if not isinstance(token_payload, dict) or token_payload.get("flow") != flow:
        raise RuntimeError(f"Pro Checkout Challenge Token flow 不匹配: {flow}")

    telemetry = str(challenge_solver.get("telemetry") or "").strip() or "[1,null]"
    try:
        telemetry_payload = json.loads(telemetry)
    except (TypeError, ValueError) as exc:
        raise RuntimeError("Pro Checkout X-Vendor-Telemetry 格式无效") from exc
    if not isinstance(telemetry_payload, list):
        raise RuntimeError("Pro Checkout X-Vendor-Telemetry 必须是 JSON 数组")

    headers["Vendor-Challenge-Token"] = token
    headers["X-Vendor-Telemetry"] = json.dumps(
        telemetry_payload,
        ensure_ascii=False,
        separators=(",", ":"),
    )
    log.info("Pro Checkout Challenge 上下文已加载: flow=%s", flow)
    return headers


# ── Stripe API ────────────────────────────────────────────────────
def _stripe_headers() -> dict[str, str]:
    return {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
        "Origin": "https://js.stripe.com",
        "Referer": "https://js.stripe.com/",
        "User-Agent": BROWSER_UA,
        "priority": "u=1, i",
        # 与 Platform 请求一致的 sec-ch-ua 指纹（Stripe Radar 校验）
        "sec-ch-ua": (
            f'"Not;A=Brand";v="8", "Chromium";v="{BROWSER_MAJOR}", '
            f'"Google Chrome";v="{BROWSER_MAJOR}"'
        ),
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
        "sec-ch-ua-arch": '"x86"',
        "sec-ch-ua-bitness": '"64"',
        "sec-ch-ua-full-version": f'"{BROWSER_MAJOR}.0.0.0"',
        "sec-ch-ua-full-version-list": (
            f'"Not;A=Brand";v="8", "Chromium";v="{BROWSER_MAJOR}.0.0.0", '
            f'"Google Chrome";v="{BROWSER_MAJOR}.0.0.0"'
        ),
        "sec-ch-ua-platform-version": '"15.0.0"',
    }


def _stripe_confirmation_token(
    log: logging.Logger,
    http: Any,
    card: dict[str, str],
    billing: dict[str, str],
) -> dict[str, Any]:
    """POST /v1/confirmation_tokens — 将卡号令牌化。

    零元购模式（promo=True）时额外带上 client_context[customer]，
    与浏览器 HAR 行为一致。
    """
    url = f"{STRIPE_API_BASE}/confirmation_tokens"
    is_promo = billing.get("_promo", False)

    client_session_id = _uuid()
    elements_session_id = "elements_session_" + _random_hex(5)
    # 零元购使用 checkout 返回的 elements config_id（浏览器行为一致）
    elements_config_id = billing.get("_elements_config_id") or _uuid()
    guid = _uuid().replace("-", "") + "fbcd8f"
    muid = _uuid().replace("-", "") + "e77c22"
    sid = _uuid().replace("-", "") + "4e41f2"

    pm_prefix = "payment_method_data"
    form: list[tuple[str, str]] = [
        (f"{pm_prefix}[type]", "card"),
        (f"{pm_prefix}[card][number]", card["number"]),
        (f"{pm_prefix}[card][cvc]", card["cvc"]),
        (f"{pm_prefix}[card][exp_year]", card["exp_year"]),
        (f"{pm_prefix}[card][exp_month]", card["exp_month"]),
        (f"{pm_prefix}[allow_redisplay]", "limited"),
        (f"{pm_prefix}[billing_details][address][line1]", billing.get("line1", "")),
        (f"{pm_prefix}[billing_details][address][city]", billing.get("city", "")),
        (f"{pm_prefix}[billing_details][address][country]", billing.get("country", "PH")),
        (f"{pm_prefix}[billing_details][address][postal_code]", billing.get("postal_code", "")),
        (f"{pm_prefix}[billing_details][address][state]", billing.get("state", "")),
        (f"{pm_prefix}[billing_details][name]", billing.get("name", "")),
        (f"{pm_prefix}[billing_details][phone]", ""),
        (f"{pm_prefix}[payment_user_agent]",
         "stripe.js/0000000000; stripe-js-v3/0000000000; payment-element; deferred-intent"),
        (f"{pm_prefix}[referrer]", PLATFORM_BASE),
        (f"{pm_prefix}[time_on_page]", "375482"),
        (f"{pm_prefix}[guid]", guid),
        (f"{pm_prefix}[muid]", muid),
        (f"{pm_prefix}[sid]", sid),
        # payment_method_data 内归因元数据
        (f"{pm_prefix}[client_attribution_metadata][client_session_id]", client_session_id),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_source]", "elements"),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_subtype]", "payment-element"),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_version]", "2021"),
        (f"{pm_prefix}[client_attribution_metadata][payment_intent_creation_flow]", "deferred"),
        (f"{pm_prefix}[client_attribution_metadata][payment_method_selection_flow]", "merchant_specified"),
        (f"{pm_prefix}[client_attribution_metadata][elements_session_id]", elements_session_id),
        (f"{pm_prefix}[client_attribution_metadata][elements_session_config_id]", elements_config_id),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_additional_elements][0]",
         "expressCheckout"),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_additional_elements][1]",
         "payment"),
        (f"{pm_prefix}[client_attribution_metadata][merchant_integration_additional_elements][2]",
         "address"),
    ]

    cuss_secret = billing.get("_cuss_secret", "")
    if cuss_secret:
        form.extend([
            ("setup_future_usage", "off_session"),
            ("client_context[currency]", billing.get("currency", "php")),
            ("client_context[mode]", "subscription"),
            ("client_context[payment_method_types][0]", "card"),
            ("client_context[payment_method_types][1]", "link"),
        ])
    else:
        # 没有 cuss_secret 也必须带 setup_future_usage，否则 Stripe 在确认时拒绝
        form.append(("setup_future_usage", "off_session"))

    # 零元购：带 Stripe Customer ID（浏览器行为一致）
    if is_promo:
        stripe_customer = billing.get("_stripe_customer")
        if stripe_customer:
            form.append(("client_context[customer]", stripe_customer))
            log.info("confirmation_tokens: 零元购模式 + client_context[customer]=%s", stripe_customer)

    # 顶层归因元数据
    form.extend([
        ("client_attribution_metadata[client_session_id]", client_session_id),
        ("client_attribution_metadata[merchant_integration_source]", "elements"),
        ("client_attribution_metadata[merchant_integration_subtype]", "payment-element"),
        ("client_attribution_metadata[merchant_integration_version]", "2021"),
        ("client_attribution_metadata[payment_intent_creation_flow]", "deferred"),
        ("client_attribution_metadata[payment_method_selection_flow]", "merchant_specified"),
        ("client_attribution_metadata[elements_session_id]", elements_session_id),
        ("client_attribution_metadata[elements_session_config_id]", elements_config_id),
        ("client_attribution_metadata[merchant_integration_additional_elements][0]", "expressCheckout"),
        ("client_attribution_metadata[merchant_integration_additional_elements][1]", "payment"),
        ("client_attribution_metadata[merchant_integration_additional_elements][2]", "address"),
        ("set_as_default_payment_method", "false"),
        ("key", STRIPE_PUBLISHABLE_KEY),
        ("_stripe_version", STRIPE_VERSION),
    ])

    # 构建 URL-encoded 表单字符串（curl_cffi POST data 需要字符串）
    body_str = _urlencode(form)
    resp = _http_post_form(http, url, data=body_str, headers=_stripe_headers())
    _log_request(log, resp, label="Stripe POST /v1/confirmation_tokens")
    result = _stream_to_dict(resp)

    if resp.status_code != 200:
        error = result.get("error", {})
        raise RuntimeError(f"Stripe 令牌化失败: {error.get('message', str(result)[:300])}")

    return result


def _log_payment_intent_summary(
    log: logging.Logger,
    label: str,
    payment_intent: dict[str, Any],
) -> None:
    """记录可排障的 Stripe 状态，不输出 client_secret 或跳转载荷。"""
    if not isinstance(payment_intent, dict):
        log.warning("%s — PaymentIntent 响应格式无效", label)
        return

    next_action = payment_intent.get("next_action") or {}
    error = payment_intent.get("last_payment_error") or {}
    log.info(
        "%s — pi_id=%s status=%s amount=%s currency=%s next_action=%s",
        label,
        payment_intent.get("id", ""),
        payment_intent.get("status", "unknown"),
        payment_intent.get("amount", ""),
        str(payment_intent.get("currency", "")).upper(),
        next_action.get("type", "") if isinstance(next_action, dict) else "",
    )
    if isinstance(error, dict) and error:
        log.warning(
            "%s — error=%s code=%s decline_code=%s",
            label,
            str(error.get("message", ""))[:500],
            error.get("code", ""),
            error.get("decline_code", ""),
        )


def _stripe_user_error(error: Any, fallback: str) -> str:
    """将明确的 Stripe 拒付原因转换为用户可读提示。"""
    if not isinstance(error, dict):
        return fallback
    decline_code = str(error.get("decline_code") or "").lower()
    if decline_code == "insufficient_funds":
        return "银行卡余额不足"
    return str(error.get("message") or fallback)


def _stripe_confirm_payment_intent(
    log: logging.Logger,
    http: Any,
    pi_id: str,
    client_secret: str,
    confirmation_token: str,
    return_url: str,
) -> dict[str, Any]:
    """POST /v1/payment_intents/{id}/confirm — 确认扣款。"""
    url = f"{STRIPE_API_BASE}/payment_intents/{pi_id}/confirm"

    form: list[tuple[str, str]] = [
        ("confirmation_token", confirmation_token),
        ("client_secret", client_secret),
        ("key", STRIPE_PUBLISHABLE_KEY),
        ("return_url", return_url),
        ("_stripe_version", STRIPE_VERSION),
        ("client_attribution_metadata[client_session_id]", _uuid()),
        ("client_attribution_metadata[merchant_integration_source]", "l1"),
    ]

    body_str = _urlencode(form)
    resp = _http_post_form(http, url, data=body_str, headers=_stripe_headers())
    _log_request(log, resp, label=f"Stripe POST /v1/payment_intents/{pi_id}/confirm")
    result = _stream_to_dict(resp)

    if resp.status_code == 200:
        _log_payment_intent_summary(log, "Stripe 确认结果", result)
        status = str(result.get("status", ""))
        if status == "succeeded":
            return {"ok": True, "payment_intent": result}
        error = result.get("last_payment_error") or {}
        return {
            "ok": False,
            "action_required": status == "requires_action",
            "error": _stripe_user_error(
                error, f"PaymentIntent 状态: {status or 'unknown'}",
            ),
            "code": error.get("code", ""),
            "decline_code": error.get("decline_code", ""),
            "payment_intent": result,
        }

    error = result.get("error", {})
    payment_intent = error.get("payment_intent", {})
    if payment_intent:
        _log_payment_intent_summary(log, "Stripe 确认失败", payment_intent)
    else:
        log.warning(
            "Stripe 确认失败 — HTTP=%s error=%s code=%s decline_code=%s",
            resp.status_code,
            str(error.get("message", ""))[:500],
            error.get("code", ""),
            error.get("decline_code", ""),
        )

    return {
        "ok": False,
        "error": _stripe_user_error(error, "支付失败"),
        "code": error.get("code", ""),
        "decline_code": error.get("decline_code", ""),
        "payment_intent": {
            "id": payment_intent.get("id", ""),
            "status": payment_intent.get("status", ""),
        },
    }


def _stripe_confirm_existing_payment_intent(
    log: logging.Logger,
    http: Any,
    payment_intent: dict[str, Any],
) -> dict[str, Any]:
    """确认订阅升级创建的 PaymentIntent，不附加新的支付方式。"""
    pi_id = str(payment_intent.get("id", ""))
    client_secret = str(payment_intent.get("client_secret", ""))
    if not pi_id.startswith("pi_") or not client_secret.startswith(f"{pi_id}_secret_"):
        raise RuntimeError("升级响应缺少有效的 PaymentIntent 凭据")

    form = [
        ("client_secret", client_secret),
        ("expected_payment_method_type", "card"),
        ("use_stripe_sdk", "true"),
        ("key", STRIPE_PUBLISHABLE_KEY),
        ("_stripe_version", STRIPE_VERSION),
        ("client_attribution_metadata[client_session_id]", _uuid()),
        ("client_attribution_metadata[merchant_integration_source]", "l1"),
    ]
    resp = _http_post_form(
        http,
        f"{STRIPE_API_BASE}/payment_intents/{pi_id}/confirm",
        data=_urlencode(form),
        headers=_stripe_headers(),
    )
    _log_request(log, resp, label=f"Stripe POST /v1/payment_intents/{pi_id}/confirm")
    result = _stream_to_dict(resp)
    if resp.status_code == 200:
        _log_payment_intent_summary(log, "Stripe 升级确认结果", result)
        return result

    error = result.get("error") or {}
    failed_intent = error.get("payment_intent") or {}
    if failed_intent:
        _log_payment_intent_summary(log, "Stripe 升级确认失败", failed_intent)
        return failed_intent
    raise RuntimeError(f"Stripe 升级扣款失败: {error.get('message', 'HTTP ' + str(resp.status_code))}")


def _stripe_get_payment_intent(
    log: logging.Logger,
    http: Any,
    pi_id: str,
    client_secret: str,
) -> dict[str, Any]:
    """用客户端密钥读取 3DS 后的 PaymentIntent 最终状态。"""
    if not pi_id.startswith("pi_") or not client_secret.startswith(f"{pi_id}_secret_"):
        raise ValueError("PaymentIntent 凭据格式不正确")
    resp = _http_get(
        http,
        f"{STRIPE_API_BASE}/payment_intents/{pi_id}",
        headers=_stripe_headers(),
        params={
            "client_secret": client_secret,
            "key": STRIPE_PUBLISHABLE_KEY,
            "_stripe_version": STRIPE_VERSION,
            "is_stripe_sdk": "false",
        },
    )
    _log_request(log, resp, label=f"Stripe GET /v1/payment_intents/{pi_id}")
    result = _stream_to_dict(resp)
    if resp.status_code != 200:
        error = result.get("error") or {}
        raise RuntimeError(f"查询 Stripe 支付状态失败: {error.get('message', resp.status_code)}")
    _log_payment_intent_summary(log, "Stripe PaymentIntent 查询结果", result)
    return result


def _checkout_verify_url(
    checkout_id: str,
    processor_entity: str,
    plan: str,
) -> str:
    """重建固定 Platform Verify 地址，避免接受客户端提供的跳转 URL。"""
    if not re.fullmatch(r"oaics_[A-Za-z0-9_-]{8,192}", checkout_id):
        raise ValueError("Checkout ID 格式不正确")
    if not re.fullmatch(r"[a-z0-9_]{2,64}", processor_entity):
        raise ValueError("processor_entity 格式不正确")
    normalized_plan = _normalize_plan(plan)
    plan_type = PLAN_SUBSCRIPTION_TYPES[normalized_plan]
    query = _urlencode({
        'stripe_session_id': checkout_id,
        'processor_entity': processor_entity,
        'plan_type': plan_type,
    })
    return f"{PLATFORM_BASE}/checkout/verify?{query}"


def _prepare_upgrade_payment_method(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    account_id: str,
) -> dict[str, str]:
    """创建由前端 Stripe Elements 完成的新卡 SetupIntent。"""
    publishable_key = STRIPE_PUBLISHABLE_KEY
    try:
        bootstrap = _platform_get(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/payments/stripe_client_bootstrap",
            context=context,
            params={"account_id": account_id},
        )
        publishable_key = _find_in(bootstrap, ("publishable_key", "publishableKey")) or publishable_key
    except Exception as exc:
        log.warning("升级绑卡: Stripe bootstrap 失败，使用默认 key: %s", exc)

    prepared = _platform_post(
        log,
        http,
        access_token,
        cookies,
        "/api/v1/payments/payment_method",
        {"account_id": account_id},
        context=context,
    )
    setup_secret = _find_in(prepared, ("client_secret", "setup_intent_client_secret"))
    setup_id = _find_in(prepared, ("setup_intent", "setup_intent_id", "id"))
    if not setup_id.startswith("seti_") and setup_secret.startswith("seti_"):
        setup_id = setup_secret.split("_secret_")[0]
    if not setup_id.startswith("seti_") or not setup_secret.startswith(f"{setup_id}_secret_"):
        raise RuntimeError("payment_method 响应缺少 SetupIntent 凭据")
    log.info("升级新卡 SetupIntent 已创建: %s", setup_id)
    return {
        "publishable_key": publishable_key,
        "client_secret": setup_secret,
        "setup_intent_id": setup_id,
    }


def _rollback_pending_upgrade(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    account_id: str,
    payment_intent_id: str,
    restore_canceled: bool,
) -> None:
    """撤销失败的 pending upgrade，并恢复升级前的续费状态。"""
    if payment_intent_id.startswith("pi_"):
        try:
            _platform_post(
                log,
                http,
                access_token,
                cookies,
                "/api/v1/subscriptions/update/cancel_pending",
                {
                    "account_id": account_id,
                    "expected_payment_intent_id": payment_intent_id,
                },
                context=context,
            )
            log.info("已撤销 pending upgrade: %s", payment_intent_id)
        except Exception as exc:
            log.warning("撤销 pending upgrade 失败: %s", exc)
    if restore_canceled:
        try:
            _platform_post(
                log,
                http,
                access_token,
                cookies,
                "/api/v1/subscriptions/cancel",
                {"account_id": account_id},
                context=context,
            )
            log.info("已恢复升级前的取消续费状态")
        except Exception as exc:
            log.warning("恢复取消续费状态失败: %s", exc)


def _wait_for_account_payment_method(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    account_id: str,
    payment_method_id: str,
) -> dict[str, Any]:
    """确认前端创建的支付方式已经同步到当前 Platform 账号。"""
    if not re.fullmatch(r"pm_[A-Za-z0-9_-]{8,192}", payment_method_id):
        raise ValueError("payment_method_id 格式不正确")

    import time as _time

    for delay in (0.0, 0.5, 1.0, 2.0, 4.0):
        if delay:
            _time.sleep(delay)
        payload = _platform_get(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/payments/payment_methods",
            context=context,
            params={"account_id": account_id},
        )
        for item in payload.get("payment_methods", []):
            if isinstance(item, dict) and item.get("id") == payment_method_id:
                return item
    raise RuntimeError("新卡尚未同步到当前账号，请稍后重试")


def _wait_for_subscription_plan(
    log: logging.Logger,
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    account_id: str,
    target_plan: str,
) -> tuple[dict[str, Any], bool]:
    """支付成功后等待订阅状态收敛到目标计划。"""
    import time as _time

    target_type = PLAN_SUBSCRIPTION_TYPES[target_plan]
    subscription: dict[str, Any] = {}
    for delay in (0.0, 0.5, 1.0, 2.0, 4.0):
        if delay:
            _time.sleep(delay)
        subscription = _platform_get(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/subscriptions",
            context=context,
            params={"account_id": account_id},
        )
        if _subscription_plan_type(str(subscription.get("plan_type", ""))) == target_type:
            return subscription, True
    return subscription, False


def _upgrade_subscription(
    log: logging.Logger,
    log_path: Path,
    steps: list[dict[str, Any]],
    http: Any,
    access_token: str,
    cookies: str,
    context: PlatformRequestContext,
    account_id: str,
    current_plan: str,
    target_plan: str,
    payment_source: str,
    requested_payment_method_id: str = "",
) -> Any:
    """执行已有个人订阅的续费恢复或计划更新流程。"""
    target_type = PLAN_SUBSCRIPTION_TYPES[target_plan]
    steps.append({"step": 2, "name": "读取订阅状态", "status": "running"})
    subscription = _platform_get(
        log,
        http,
        access_token,
        cookies,
        "/api/v1/subscriptions",
        context=context,
        params={"account_id": account_id},
    )
    live_plan = _subscription_plan_type(str(subscription.get("plan_type", current_plan)))
    will_renew = bool(subscription.get("will_renew"))
    steps[-1].update({
        "status": "ok",
        "detail": f"当前计划: {live_plan} | 自动续费: {'是' if will_renew else '否'}",
    })

    if live_plan == target_type:
        if will_renew:
            steps.append({"step": 3, "name": "确认目标计划", "status": "ok", "detail": "已是目标计划"})
            return jsonify({
                "ok": True,
                "flow": "existing_subscription",
                "message": "当前已是所选计划",
                "subscription": subscription,
                "steps": steps,
                "log_file": str(log_path),
            })
        steps.append({"step": 3, "name": "恢复自动续费", "status": "running"})
        _platform_post(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/subscriptions/renew",
            {"account_id": account_id},
            context=context,
        )
        subscription = _platform_get(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/subscriptions",
            context=context,
            params={"account_id": account_id},
        )
        steps[-1].update({"status": "ok", "detail": "自动续费已恢复"})
        return jsonify({
            "ok": True,
            "flow": "renew",
            "message": "自动续费已恢复",
            "subscription": subscription,
            "steps": steps,
            "log_file": str(log_path),
        })

    steps.append({"step": 3, "name": "获取升级预览", "status": "running"})
    preview = _platform_get(
        log,
        http,
        access_token,
        cookies,
        "/api/v1/subscriptions/update/preview",
        context=context,
        params={"account_id": account_id, "updated_plan": target_plan},
    )
    amount_due = preview.get("amount_due") or {}
    amount = amount_due.get("amount", preview.get("total_amount", 0))
    currency = str(preview.get("currency", "php")).upper()
    steps[-1].update({"status": "ok", "detail": f"应付金额: {int(amount or 0) / 100:,.2f} {currency}"})

    default_card = preview.get("default_payment_method") or {}
    default_last4 = str(default_card.get("card_last4", ""))
    payment_method_id = ""
    if payment_source == "new":
        steps.append({"step": 4, "name": "确认新卡", "status": "running"})
        payment_method = _wait_for_account_payment_method(
            log,
            http,
            access_token,
            cookies,
            context,
            account_id,
            requested_payment_method_id,
        )
        payment_method_id = requested_payment_method_id
        card_data = payment_method.get("card") or payment_method
        new_last4 = str(card_data.get("last4", ""))
        steps[-1].update({
            "status": "ok",
            "detail": f"使用新卡 ····{new_last4}" if new_last4 else "新卡已确认",
        })
    elif payment_source == "default":
        if not default_last4:
            raise RuntimeError("当前账号没有默认已绑卡，请选择使用新卡")
        steps.append({
            "step": 4,
            "name": "确认升级支付卡",
            "status": "ok",
            "detail": f"使用已绑卡 ····{default_last4}",
        })
    else:
        raise ValueError("payment_source 只能是 default 或 new")

    restore_canceled = not will_renew
    if restore_canceled:
        steps.append({"step": 5, "name": "恢复订阅续费", "status": "running"})
        _platform_post(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/subscriptions/renew",
            {"account_id": account_id},
            context=context,
        )
        steps[-1].update({"status": "ok", "detail": "已为计划更新临时恢复续费"})

    step_number = 6 if restore_canceled else 5
    steps.append({"step": step_number, "name": "提交计划更新", "status": "running"})
    update_body = {"account_id": account_id, "updated_plan": target_plan}
    if payment_method_id:
        update_body["payment_method_id"] = payment_method_id
    log.info(
        "提交计划更新: target=%s payment_method_id=%s",
        target_plan,
        "已携带" if payment_method_id else "未携带（使用默认卡）",
    )
    try:
        update_result = _platform_post(
            log,
            http,
            access_token,
            cookies,
            "/api/v1/subscriptions/update",
            update_body,
            context=context,
        )
    except Exception:
        if restore_canceled:
            _rollback_pending_upgrade(
                log, http, access_token, cookies, context,
                account_id, "", restore_canceled=True,
            )
        raise
    update_status = str(update_result.get("status", ""))
    payment_intent = update_result.get("payment_intent") or {}
    if update_status in ("succeeded", "success") and not payment_intent:
        steps[-1].update({"status": "ok", "detail": "计划更新成功"})
        subscription, activated = _wait_for_subscription_plan(
            log, http, access_token, cookies, context, account_id, target_plan,
        )
        steps.append({
            "step": step_number + 1,
            "name": "验证订阅生效",
            "status": "ok" if activated else "running",
            "detail": (
                f"当前计划: {subscription.get('plan_type', target_type)}"
                if activated else "支付已完成，订阅状态仍在同步"
            ),
        })
        return jsonify({
            "ok": activated,
            "flow": "upgrade",
            "pending": not activated,
            "message": "订阅更新成功" if activated else "支付已完成，订阅状态仍在同步",
            "subscription": subscription,
            "steps": steps,
            "log_file": str(log_path),
        })

    if not isinstance(payment_intent, dict) or not payment_intent:
        raise RuntimeError(f"计划更新响应异常: status={update_status or 'unknown'}")
    pi_id = str(payment_intent.get("id", ""))
    try:
        confirmed_intent = _stripe_confirm_existing_payment_intent(log, http, payment_intent)
    except Exception:
        _rollback_pending_upgrade(
            log,
            http,
            access_token,
            cookies,
            context,
            account_id,
            pi_id,
            restore_canceled,
        )
        raise
    pi_status = str(confirmed_intent.get("status", ""))
    if pi_status == "succeeded":
        steps[-1].update({"status": "ok", "detail": "升级扣款成功"})
        subscription, activated = _wait_for_subscription_plan(
            log, http, access_token, cookies, context, account_id, target_plan,
        )
        steps.append({
            "step": step_number + 1,
            "name": "验证订阅生效",
            "status": "ok" if activated else "running",
            "detail": (
                f"当前计划: {subscription.get('plan_type', target_type)}"
                if activated else "扣款成功，订阅状态仍在同步"
            ),
        })
        return jsonify({
            "ok": activated,
            "flow": "upgrade",
            "pending": not activated,
            "message": "订阅升级成功" if activated else "扣款成功，订阅状态仍在同步",
            "payment_intent": confirmed_intent,
            "subscription": subscription,
            "steps": steps,
            "log_file": str(log_path),
        })
    if pi_status == "processing":
        steps[-1].update({"status": "running", "detail": "Stripe 正在处理扣款"})
        return jsonify({
            "ok": False,
            "flow": "upgrade",
            "pending": True,
            "message": "扣款正在处理中，请稍后查询订阅状态",
            "payment_intent": {"id": pi_id, "status": pi_status},
            "steps": steps,
            "log_file": str(log_path),
        })
    if pi_status == "requires_action":
        steps[-1].update({"status": "action_required", "detail": "等待 3D Secure 验证"})
        return jsonify({
            "ok": False,
            "flow": "upgrade",
            "action_required": True,
            "message": "请完成银行卡 3D Secure 验证",
            "payment_intent": {"id": pi_id, "status": pi_status},
            "client_secret": confirmed_intent.get("client_secret", ""),
            "stripe_publishable_key": STRIPE_PUBLISHABLE_KEY,
            "account_id": account_id,
            "target_plan": target_plan,
            "restore_canceled": restore_canceled,
            "steps": steps,
            "log_file": str(log_path),
        })

    last_error = confirmed_intent.get("last_payment_error") or {}
    _rollback_pending_upgrade(
        log,
        http,
        access_token,
        cookies,
        context,
        account_id,
        pi_id,
        restore_canceled,
    )
    message = _stripe_user_error(
        last_error, f"升级扣款失败: {pi_status or 'unknown'}",
    )
    steps[-1].update({"status": "error", "detail": message})
    return jsonify({
        "ok": False,
        "flow": "upgrade",
        "error": message,
        "code": last_error.get("code", ""),
        "decline_code": last_error.get("decline_code", ""),
        "payment_intent": {"id": pi_id, "status": pi_status},
        "steps": steps,
        "log_file": str(log_path),
    })


# ── 路由 ──────────────────────────────────────────────────────────


@app.get("/")
def index() -> Any:
    return send_from_directory(app.static_folder, "index.html")


@app.get("/upgrade")
def upgrade_page() -> Any:
    return send_from_directory(app.static_folder, "upgrade.html")


@app.get("/healthz")
def healthz() -> Any:
    return jsonify({"ok": True})


@app.get("/invoices")
def invoices_page() -> Any:
    return send_from_directory(app.static_folder, "invoices.html")


@app.get("/promo")
def promo_page() -> Any:
    return send_from_directory(app.static_folder, "promo.html")


@app.get("/payment-methods")
def payment_methods_page() -> Any:
    return send_from_directory(app.static_folder, "payment_methods.html")


@app.get("/subscription")
def subscription_page() -> Any:
    return send_from_directory(app.static_folder, "subscription.html")


@app.get("/renew")
def renew_page() -> Any:
    return send_from_directory(app.static_folder, "renew.html")


@app.get("/bind")
def bind_page() -> Any:
    return send_from_directory(app.static_folder, "bind.html")


@app.get("/api/config")
def config() -> Any:
    return jsonify({
        "ok": True,
        "proxy_enabled": bool(OUTBOUND_PROXY_URL),
        "default_plan": DEFAULT_PLAN,
        "pro_checkout_protocol": PRO_CHECKOUT_PROTOCOL,
    })


@app.post("/api/invoices")
def invoices() -> Any:
    """账单列表接口 — 用 Session 查询交易历史，返回发票下载链接。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 新账单查询请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)

        # 获取 account_id — 从 session JSON 的 account.id 或 accounts/check
        account_id = ""
        if isinstance(session_data.get("account"), dict):
            account_id = str(session_data["account"].get("id") or "")
        log.info("Session 解析成功 — email=%s  account_id=%s", email, account_id)

        http = make_http_session()

        # 如果没有 account_id，从 accounts/check 获取
        if not account_id:
            accts = _platform_get(log, http, access_token, cookies,
                                 "/api/v1/accounts/check/v4-2023-04-27",
                                 params={"timezone_offset_min": -480})
            acct_list = list(accts.get("accounts", {}).keys())
            if acct_list:
                account_id = acct_list[0]
            log.info("从 accounts/check 获取 account_id=%s", account_id)

        if not account_id:
            raise ValueError("无法获取 account_id")

        # 查询交易历史
        limit = int(payload.get("limit", 10))
        tx_data = _platform_get(log, http, access_token, cookies,
                               "/api/v1/payments/transaction-history",
                               params={"account_id": account_id, "limit": limit})

        transactions = []
        for tx in tx_data.get("transactions", []):
            item = {
                "type": tx.get("type", ""),
                "id": tx.get("id", ""),
                "created_at": tx.get("created_at", ""),
                "amount": tx.get("amount", 0),
                "currency": tx.get("currency", ""),
                "status": tx.get("status", ""),
                "invoice_url": tx.get("invoice_url", ""),
                "product": tx.get("product", {}),
            }
            transactions.append(item)

        log.info("查询到 %d 条交易记录", len(transactions))
        return jsonify({
            "ok": True,
            "account_id": account_id,
            "transactions": transactions,
            "log_file": str(log_path),
        })

    except ValueError as exc:
        log.error("参数错误: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        log.error("Session JSON 格式不正确")
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        log.error("运行时错误: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.error("未预期错误: %s", exc)
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


# ── 零元购 (plus-1-month-free) ──────────────────────────────────────
PROMO_CAMPAIGN_ID = "plus-1-month-free"


def _check_promo_eligibility(log: logging.Logger, http: Any, access_token: str,
                             cookies: str,
                             context: PlatformRequestContext | None = None,
                             ) -> tuple[bool, dict[str, Any], str]:
    """检查账号是否有 plus-1-month-free 促销资格。

    判断依据（与官方一致）：
    1. accounts/check 的 eligible_promo_campaigns 字段（有则直接确认）
    2. 组合条件：has_previously_paid_subscription=true + plan_type=free + eligible_for_reactivation=true
    3. check_coupon 验证（兜底）
    返回 (eligible, promo_info, account_id)
    """
    accts = _platform_get(log, http, access_token, cookies,
                         "/api/v1/accounts/check/v4-2023-04-27",
                         context=context,
                         params={"timezone_offset_min": -480})
    acct_list = list(accts.get("accounts", {}).keys())
    if not acct_list:
        raise RuntimeError("无法获取账号信息")
    account_id = acct_list[0]

    acct = accts["accounts"].get(account_id, {})
    account = acct.get("account", {})
    eligible = account.get("eligible_promo_campaigns", {})
    promo_meta: dict[str, Any] = {}

    # 1. eligible_promo_campaigns 字段直接确认
    plus_promo = eligible.get("plus")
    if plus_promo and plus_promo.get("id") == PROMO_CAMPAIGN_ID:
        promo_meta = plus_promo.get("metadata", {})
        log.info("资格来源: eligible_promo_campaigns 字段")
        return True, promo_meta, account_id

    # 2. 组合条件判断（老用户回归）
    has_paid = account.get("has_previously_paid_subscription", False)
    plan_type = account.get("plan_type", "")
    eligible_reactivation = account.get("eligible_for_reactivation", False)
    not_gratis = not account.get("is_most_recent_expired_subscription_gratis", True)

    if has_paid and plan_type == "free" and eligible_reactivation and not_gratis:
        promo_meta = {
            "title": "Try Plus free for 1 month",
            "discount": {"percentage": 100},
            "duration": {"num_periods": 1, "period": "month"},
            "source": "reactivation",
        }
        log.info("资格来源: 老用户回归组合条件 (has_paid=%s plan=%s reactivation=%s)",
                 has_paid, plan_type, eligible_reactivation)
        return True, promo_meta, account_id

    log.info("账号条件: has_paid=%s plan=%s reactivation=%s gratis=%s",
             has_paid, plan_type, eligible_reactivation, account.get("is_most_recent_expired_subscription_gratis"))

    # 3. check_coupon 验证（兜底）
    try:
        coupon_resp = _platform_get(log, http, access_token, cookies,
                                   "/api/v1/promo_campaign/check_coupon",
                                   context=context,
                                   params={"coupon": PROMO_CAMPAIGN_ID,
                                           "is_coupon_from_query_param": "true"})
        log.info("check_coupon 响应: %s", json.dumps(coupon_resp, ensure_ascii=False)[:500])
        # 兼容多种响应结构（官方返回 state: "eligible"）
        if (coupon_resp.get("eligible", False)
                or coupon_resp.get("is_eligible", False)
                or coupon_resp.get("valid", False)
                or coupon_resp.get("success", False)
                or coupon_resp.get("status") == "eligible"
                or coupon_resp.get("outcome") == "eligible"
                or coupon_resp.get("state") == "eligible"):
            return True, coupon_resp, account_id
    except Exception as exc:
        log.warning("check_coupon 失败: %s", exc)

    return False, {}, account_id


# ── 支付方式管理（查询 / 解绑）────────────────────────────────────
def _get_account_id(log: logging.Logger, http: Any, access_token: str,
                    cookies: str, session_data: dict[str, Any],
                    context: PlatformRequestContext | None = None) -> str:
    """从 Session 或 accounts/check 获取 account_id。"""
    account_id = ""
    if isinstance(session_data.get("account"), dict):
        account_id = str(session_data["account"].get("id") or "")
    if not account_id:
        accts = _platform_get(log, http, access_token, cookies,
                             "/api/v1/accounts/check/v4-2023-04-27",
                             context=context,
                             params={"timezone_offset_min": -480})
        acct_list = list(accts.get("accounts", {}).keys())
        if acct_list:
            account_id = acct_list[0]
    return account_id


@app.post("/api/payment-methods")
def payment_methods() -> Any:
    """查询已绑定的银行卡列表。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 支付方式查询 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        pm_data = _platform_get(log, http, access_token, cookies,
                               "/api/v1/payments/payment_methods",
                               params={"account_id": account_id})
        log.info("查询到 %d 张银行卡", len(pm_data.get("payment_methods", [])))
        return jsonify({
            "ok": True,
            "account_id": account_id,
            "payment_methods": pm_data.get("payment_methods", []),
            "default_payment_method_id": pm_data.get("default_payment_method_id", ""),
            "log_file": str(log_path),
        })

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/payment-methods/detach")
def payment_method_detach() -> Any:
    """解绑银行卡。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 解绑银行卡请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        payment_method_id = str(payload.get("payment_method_id", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")
        if not payment_method_id or not payment_method_id.startswith("pm_"):
            raise ValueError("payment_method_id 格式不正确")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        # DELETE /api/v1/payments/payment_method/{pm_id}?account_id=xxx
        # 注意：curl_cffi 的 delete 需要单独实现，用 GET 带 method 参数不行
        # 使用 requests 风格的 delete — curl_cffi Session 支持 delete()
        url = f"{PLATFORM_BASE}/api/v1/payments/payment_method/{payment_method_id}"
        if CurlSession is not None and isinstance(http, CurlSession):
            resp = http.delete(url, headers=_platform_headers(access_token, cookies),
                               params={"account_id": account_id}, timeout=45)
        else:
            resp = http.delete(url, headers=_platform_headers(access_token, cookies),
                               params={"account_id": account_id}, timeout=45)
        _log_request(log, resp, label=f"Platform DELETE payment_method {payment_method_id}")

        if resp.status_code != 200:
            raise RuntimeError(f"解绑失败 (HTTP {resp.status_code}): {(resp.text or '')[:300]}")

        result = _stream_to_dict(resp)
        log.info("解绑成功: %s → %s", payment_method_id, json.dumps(result, ensure_ascii=False)[:300])
        return jsonify({"ok": True, "payment_method_id": payment_method_id,
                        "result": result, "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


# ── 绑定银行卡（协议 SetupIntent 流程）────────────────────────────
@app.post("/api/payment-methods/bind")
def payment_method_bind() -> Any:
    """绑定银行卡为默认支付方式。

    协议流程（与零元购相同）：
    1. POST /payments/payment_method → 创建 SetupIntent
    2. POST /v1/setup_intents/{id}/confirm（set_as_default_payment_method: true）→ 绑卡
    3. payment_methods 确认绑卡成功
    """
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    steps: list[dict[str, Any]] = []
    log.info("══════ 绑定银行卡请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}

        # 1. 解析 Session
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")
        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        # 2. 解析卡信息
        raw_card_number = str(payload.get("card_number", "")).strip().replace(" ", "")
        card = {
            "number": raw_card_number,
            "exp_month": str(payload.get("exp_month", "")).strip(),
            "exp_year": str(payload.get("exp_year", "")).strip(),
            "cvc": str(payload.get("cvc", "")).strip(),
        }
        log.info("卡号: %s···%s  有效期: %s/%s",
                 raw_card_number[:6], raw_card_number[-4:],
                 card["exp_month"], card["exp_year"])

        if not card["number"] or not card["number"].isdigit():
            raise ValueError("卡号格式不正确")
        if len(card["number"]) < 13 or len(card["number"]) > 19:
            raise ValueError("卡号长度不正确")
        if not re.fullmatch(r"\d{1,2}", card["exp_month"]) or not (1 <= int(card["exp_month"]) <= 12):
            raise ValueError("有效期月份不正确 (1-12)")
        if len(card["exp_year"]) == 2:
            card["exp_year"] = "20" + card["exp_year"]
        if not re.fullmatch(r"\d{4}", card["exp_year"]):
            raise ValueError("有效期年份不正确 (如 2028)")
        if not re.fullmatch(r"\d{3,4}", card["cvc"]):
            raise ValueError("CVV 格式不正确 (3-4 位数字)")

        # 3. 账单地址（后端固定）
        billing = {
            "name": str(payload.get("billing_name", DEFAULT_BILLING["name"])).strip(),
            "email": email or DEFAULT_BILLING["email"],
            "line1": DEFAULT_BILLING["line1"],
            "city": DEFAULT_BILLING["city"],
            "state": DEFAULT_BILLING["state"],
            "postal_code": DEFAULT_BILLING["postal_code"],
            "country": DEFAULT_BILLING["country"],
            "currency": "php",
        }
        log.info("账单: %s, %s, %s %s", billing["country"], billing["city"], billing["state"], billing["postal_code"])

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        # Step 1: stripe_client_bootstrap 获取账号专属 key
        steps.append({"step": 1, "name": "获取 Stripe 配置", "status": "running"})
        pm_key = STRIPE_PUBLISHABLE_KEY
        try:
            bootstrap = _platform_get(log, http, access_token, cookies,
                                     "/api/v1/payments/stripe_client_bootstrap",
                                     params={"account_id": account_id})
            key = _find_in(bootstrap, ("publishable_key", "publishableKey"))
            if key:
                pm_key = key
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = pm_key[:25] + "…"
            log.info("Step 1 ✓ — bootstrap key=%s", pm_key[:25] + "…")
        except Exception as exc:
            log.warning("bootstrap 失败: %s", exc)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = "使用默认 key"

        # Step 2: 创建 SetupIntent
        steps.append({"step": 2, "name": "创建 SetupIntent", "status": "running"})
        try:
            pm_prepare = _platform_post(log, http, access_token, cookies,
                                       "/api/v1/payments/payment_method",
                                       {"account_id": account_id})
            setup_secret = _find_in(pm_prepare, ("client_secret", "setup_intent_client_secret"))
            setup_id = _find_in(pm_prepare, ("setup_intent", "setup_intent_id", "id"))
            if setup_id.startswith("seti_"):
                pass
            elif setup_secret.startswith("seti_"):
                setup_id = setup_secret.split("_secret_")[0]
            if not setup_id or not setup_secret:
                raise RuntimeError("payment_method 响应缺少 SetupIntent 凭据")
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = setup_id[:20] + "…"
            log.info("Step 2 ✓ — SetupIntent=%s", setup_id[:20] + "…")
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # Step 2.5: Elements session 初始化（协议/HAR 关键步骤）
        # SetupIntent 创建后需调 elements/sessions?client_secret=seti_...&type=setup_intent
        # 拿到 config_id，confirm 时带上
        steps.append({"step": 3, "name": "初始化 Stripe Elements", "status": "running"})
        elements_config_id = ""
        try:
            stripe_js_id = str(uuid.uuid4())
            elements_params = {
                "client_secret": setup_secret,
                "key": pm_key,
                "_stripe_version": STRIPE_VERSION,
                "elements_init_source": "stripe.elements",
                "referrer_host": "platform.example.com",
                "stripe_js_id": stripe_js_id,
                "locale": "fil",
                "type": "setup_intent",
                "expand[0]": "payment_method_preference.setup_intent.payment_method",
            }
            import urllib.parse as _up
            elements_url = f"{STRIPE_API_BASE}/elements/sessions?" + _up.urlencode(elements_params)
            elements_resp = _http_get(http, elements_url, headers={
                "Accept": "application/json",
                "Origin": "https://js.stripe.com",
                "Referer": "https://js.stripe.com/",
                "User-Agent": BROWSER_UA,
            })
            _log_request(log, elements_resp, label="Stripe GET /v1/elements/sessions (setup_intent)")
            if elements_resp.status_code < 400:
                elements_payload = _stream_to_dict(elements_resp)
                elements_config_id = elements_payload.get("config_id", "")
                log.info("Step 2.5 ✓ — elements config_id=%s", elements_config_id)
                steps[-1]["status"] = "ok"
                steps[-1]["detail"] = elements_config_id[:20] + "…" if elements_config_id else "(无)"
            else:
                log.warning("elements/sessions 失败: HTTP %s", elements_resp.status_code)
                steps[-1]["status"] = "ok"
                steps[-1]["detail"] = "跳过"
        except Exception as exc:
            log.warning("elements/sessions 异常: %s", exc)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = "跳过"

        # Step 3: SetupIntent confirm 绑卡
        steps.append({"step": 4, "name": "SetupIntent 绑卡", "status": "running"})
        try:
            guid = _uuid().replace("-", "") + _random_hex(3)
            muid = _uuid().replace("-", "") + _random_hex(3)
            sid = _uuid().replace("-", "") + _random_hex(3)
            setup_body: dict[str, str] = {
                "set_as_default_payment_method": "true",
                "expected_payment_method_type": "card",
                "use_stripe_sdk": "true",
                "key": pm_key,
                "_stripe_version": STRIPE_VERSION,
                "client_attribution_metadata[client_session_id]": stripe_js_id,
                "client_attribution_metadata[merchant_integration_source]": "elements",
                "client_attribution_metadata[merchant_integration_subtype]": "card-element",
                "client_attribution_metadata[merchant_integration_version]": "2017",
                "client_secret": setup_secret,
                "payment_method_data[type]": "card",
                "payment_method_data[billing_details][name]": billing["name"],
                "payment_method_data[allow_redisplay]": "always",
                "payment_method_data[card][number]": card["number"],
                "payment_method_data[card][cvc]": card["cvc"],
                "payment_method_data[card][exp_month]": card["exp_month"],
                "payment_method_data[card][exp_year]": card["exp_year"],
                "payment_method_data[guid]": guid,
                "payment_method_data[muid]": muid,
                "payment_method_data[sid]": sid,
                "payment_method_data[pasted_fields]": "number,exp,cvc",
                "payment_method_data[payment_user_agent]": (
                    "stripe.js/0000000000; stripe-js-v3/0000000000; card-element"
                ),
                "payment_method_data[referrer]": PLATFORM_BASE,
                "payment_method_data[time_on_page]": str(375482),
                "payment_method_data[client_attribution_metadata][client_session_id]": stripe_js_id,
                "payment_method_data[client_attribution_metadata][merchant_integration_source]": "elements",
                "payment_method_data[client_attribution_metadata][merchant_integration_subtype]": "card-element",
                "payment_method_data[client_attribution_metadata][merchant_integration_version]": "2017",
            }
            if billing["email"]:
                setup_body["payment_method_data[billing_details][email]"] = billing["email"]
            for field in ("line1", "city", "state", "postal_code", "country"):
                value = billing.get(field, "")
                if value:
                    setup_body[f"payment_method_data[billing_details][address][{field}]"] = (
                        value.upper() if field == "country" else value
                    )
            if billing.get("postal_code"):
                setup_body["payment_method_data[pasted_fields]"] = "number,exp,cvc,zip"
            # Elements session config_id（HAR 浏览器行为）
            if elements_config_id:
                setup_body["payment_method_data[client_attribution_metadata][elements_session_config_id]"] = elements_config_id
                setup_body["client_attribution_metadata[elements_session_config_id]"] = elements_config_id
                log.info("SetupIntent confirm 带 elements_config_id=%s", elements_config_id[:20])


            setup_form = _urlencode(list(setup_body.items()))
            setup_resp = _http_post_form(
                http,
                f"{STRIPE_API_BASE}/setup_intents/{setup_id}/confirm",
                data=setup_form,
                headers=_stripe_headers(),
            )
            _log_request(log, setup_resp, label=f"Stripe POST /v1/setup_intents/{setup_id[:20]}/confirm")
            setup_payload = _stream_to_dict(setup_resp)
            if setup_resp.status_code != 200:
                err = setup_payload.get("error", {})
                raise RuntimeError(f"SetupIntent 绑卡失败: {err.get('message', str(setup_payload)[:300])}")

            payment_method_id = ""
            si = setup_payload.get("setup_intent", {})
            payment_method_id = si.get("payment_method", "") if isinstance(si, dict) else ""
            if not payment_method_id:
                payment_method_id = setup_payload.get("payment_method", "")
            status = setup_payload.get("status", "") or (si.get("status", "") if isinstance(si, dict) else "")
            if status == "requires_action":
                steps[-1]["status"] = "action_required"
                steps[-1]["detail"] = "需要 3D Secure 验证"
                log.info(
                    "SetupIntent 绑卡需要 3DS: setup_id=%s pm_id=%s",
                    setup_id,
                    payment_method_id or "(等待 Stripe 返回)",
                )
                return jsonify({
                    "ok": False,
                    "flow": "setup_intent",
                    "action_required": True,
                    "message": "需要完成银行卡 3D Secure 验证",
                    "stripe_publishable_key": pm_key,
                    "client_secret": setup_secret,
                    "setup_intent_id": setup_id,
                    "payment_method": payment_method_id,
                    "steps": steps,
                    "log_file": str(log_path),
                })
            if status != "succeeded":
                raise RuntimeError(f"SetupIntent 状态: {status}")

            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"绑卡成功: {payment_method_id[:20]}…"
            log.info("Step 3 ✓ — 绑卡成功 pm_id=%s", payment_method_id)
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # Step 4: 确认 payment_methods 可见
        steps.append({"step": 4, "name": "确认绑卡状态", "status": "running"})
        try:
            import time as _time
            for delay in (0.0, 0.5, 1.0, 2.0):
                if delay > 0:
                    _time.sleep(delay)
                pms = _platform_get(log, http, access_token, cookies,
                                   "/api/v1/payments/payment_methods",
                                   params={"account_id": account_id})
                pm_ids = _find_in(pms, ("id",))
                pm_list = []
                for item in pms.get("payment_methods", []):
                    if isinstance(item, dict) and item.get("id"):
                        pm_list.append(item["id"])
                if payment_method_id in pm_list:
                    break
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = "已确认"
            log.info("Step 4 ✓ — 绑卡已确认")
            log.info("══════ 绑卡完成 — 成功 ══════")
            return jsonify({
                "ok": True,
                "payment_method": payment_method_id,
                "card_last4": card["number"][-4:],
                "steps": steps,
                "log_file": str(log_path),
            })
        except Exception as exc:
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"绑卡已提交 ({exc})"
            log.info("Step 4 ⚠ — %s", exc)
            return jsonify({
                "ok": True,
                "payment_method": payment_method_id,
                "card_last4": card["number"][-4:],
                "steps": steps,
                "log_file": str(log_path),
            })

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "steps": steps, "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "steps": steps, "log_file": str(log_path)}), 500


# ── 订阅管理（查询 / 取消）────────────────────────────────────────
@app.post("/api/subscription")
def subscription_status() -> Any:
    """查询当前订阅状态。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 订阅状态查询 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        subs = _platform_get(log, http, access_token, cookies,
                            "/api/v1/subscriptions",
                            params={"account_id": account_id})
        log.info("订阅状态: plan=%s will_renew=%s", subs.get("plan_type"), subs.get("will_renew"))
        return jsonify({"ok": True, "account_id": account_id, "subscription": subs,
                        "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/subscription/cancel")
def subscription_cancel() -> Any:
    """取消订阅。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 取消订阅请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        # POST /api/v1/subscriptions/cancel
        cancel_result = _platform_post(log, http, access_token, cookies,
                                      "/api/v1/subscriptions/cancel",
                                      {"account_id": account_id})
        log.info("取消结果: %s", json.dumps(cancel_result, ensure_ascii=False)[:300])
        return jsonify({"ok": True, "result": cancel_result, "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


# ── 重新订阅（Renew）───────────────────────────────────────────────
@app.post("/api/subscription/renew/preview")
def subscription_renew_preview() -> Any:
    """查询重新订阅的续费预览（金额、扣款卡、续费日期）。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 续费预览 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        preview = _platform_get(log, http, access_token, cookies,
                               "/api/v1/subscriptions/renew/preview",
                               params={"account_id": account_id})
        log.info("续费预览: %s", json.dumps(preview, ensure_ascii=False)[:300])
        return jsonify({"ok": True, "account_id": account_id, "preview": preview,
                        "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/subscription/renew")
def subscription_renew() -> Any:
    """重新订阅（恢复续费）。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 重新订阅请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        account_id = _get_account_id(log, http, access_token, cookies, session_data)
        if not account_id:
            raise ValueError("无法获取 account_id")

        # POST /api/v1/subscriptions/renew
        renew_result = _platform_post(log, http, access_token, cookies,
                                     "/api/v1/subscriptions/renew",
                                     {"account_id": account_id})
        log.info("重新订阅结果: %s", json.dumps(renew_result, ensure_ascii=False)[:300])

        # 确认订阅状态
        subs = _platform_get(log, http, access_token, cookies,
                            "/api/v1/subscriptions",
                            params={"account_id": account_id})
        log.info("确认订阅: plan=%s will_renew=%s", subs.get("plan_type"), subs.get("will_renew"))
        return jsonify({"ok": True, "result": renew_result, "subscription": subs,
                        "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/promo/check")
def promo_check() -> Any:
    """检查账号是否有零元购资格。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 零元购资格查询 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON")

        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        http = make_http_session()
        platform_context = _new_platform_context(cookies)
        eligible, promo_meta, account_id = _check_promo_eligibility(
            log, http, access_token, cookies, context=platform_context,
        )

        if eligible:
            detail = (
                f"{promo_meta.get('title', 'Try Plus free for 1 month')} · "
                f"折扣 {promo_meta.get('discount', {}).get('percentage', 100)}% · "
                f"{promo_meta.get('duration', {}).get('num_periods', 1)} 个月"
            )
            log.info("✅ 账号有零元购资格 — %s", detail)
            return jsonify({"ok": True, "eligible": True, "detail": detail,
                            "account_id": account_id, "log_file": str(log_path)})
        else:
            log.info("❌ 账号无零元购资格")
            return jsonify({"ok": True, "eligible": False, "account_id": account_id,
                            "log_file": str(log_path)})

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/promo/subscribe")
def promo_subscribe() -> Any:
    """零元购 — 创建带促销的 checkout，首月免费开通 Plus。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    steps: list[dict[str, Any]] = []
    log.info("══════ 零元购请求 %s ══════", request_id[:8])

    try:
        payload = request.get_json(silent=True) or {}

        # ── 1. 解析 Session ──────────────────────────────────────
        session_raw = str(payload.get("session", "")).strip()
        if not session_raw:
            raise ValueError("请填写 Platform Session JSON 或 Access Token")
        session_data = _parse_session(session_raw)
        access_token, email, user_id, cookies = _extract_auth(session_data)
        log.info("Session 解析成功 — email=%s", email)

        # ── 2. 解析卡信息 ─────────────────────────────────────────
        raw_card_number = str(payload.get("card_number", "")).strip().replace(" ", "")
        card = {
            "number": raw_card_number,
            "exp_month": str(payload.get("exp_month", "")).strip(),
            "exp_year": str(payload.get("exp_year", "")).strip(),
            "cvc": str(payload.get("cvc", "")).strip(),
        }
        log.info("卡号: %s···%s  有效期: %s/%s",
                 raw_card_number[:6], raw_card_number[-4:],
                 card["exp_month"], card["exp_year"])

        if not card["number"] or not card["number"].isdigit():
            raise ValueError("卡号格式不正确")
        if len(card["number"]) < 13 or len(card["number"]) > 19:
            raise ValueError("卡号长度不正确")
        if not re.fullmatch(r"\d{1,2}", card["exp_month"]) or not (1 <= int(card["exp_month"]) <= 12):
            raise ValueError("有效期月份不正确 (1-12)")
        if len(card["exp_year"]) == 2:
            card["exp_year"] = "20" + card["exp_year"]
        if not re.fullmatch(r"\d{4}", card["exp_year"]):
            raise ValueError("有效期年份不正确 (如 2028)")
        if not re.fullmatch(r"\d{3,4}", card["cvc"]):
            raise ValueError("CVV 格式不正确 (3-4 位数字)")

        # ── 3. 账单地址（后端固定）────────────────────────────────
        billing = {
            "name": str(payload.get("billing_name", DEFAULT_BILLING["name"])).strip(),
            "email": email or DEFAULT_BILLING["email"],
            "line1": DEFAULT_BILLING["line1"],
            "city": DEFAULT_BILLING["city"],
            "state": DEFAULT_BILLING["state"],
            "postal_code": DEFAULT_BILLING["postal_code"],
            "country": DEFAULT_BILLING["country"],
            "currency": "php",
        }
        log.info("账单: %s, %s, %s %s", billing["country"], billing["city"], billing["state"], billing["postal_code"])

        http = make_http_session()
        platform_context = _new_platform_context(cookies)

        # ── Step 1: 验证资格 ──────────────────────────────────────
        steps.append({"step": 1, "name": "验证零元购资格", "status": "running"})
        try:
            eligible, promo_meta, account_id = _check_promo_eligibility(
                log, http, access_token, cookies, context=platform_context,
            )
            platform_context.account_id = account_id
            if not eligible:
                raise RuntimeError("账号不符合零元购资格（需曾订阅 Plus 且已过期的老用户）")
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"资格确认: {promo_meta.get('title', 'Plus 首月免费')}"
            log.info("Step 1 ✓ — 零元购资格确认")
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 2: 创建 Checkout（带促销）────────────────────────
        steps.append({"step": 2, "name": "创建 Checkout（含促销）", "status": "running"})
        try:
            _load_payment_metadata(
                log, http, access_token, cookies, platform_context,
            )
            checkout_headers = _build_challenge_headers(
                log, http, access_token, cookies, platform_context,
            )
            checkout_body = {
                "entry_point": "all_plans_pricing_modal",
                "plan_name": "basic_plan",
                "billing_details": {"country": "PH", "currency": "PHP"},
                "checkout_ui_mode": "custom",
                "promo_campaign": {
                    "promo_campaign_id": PROMO_CAMPAIGN_ID,
                    "is_coupon_from_query_param": False,
                },
            }
            checkout = _platform_post(log, http, access_token, cookies,
                                     "/api/v1/payments/checkout", checkout_body,
                                     extra_headers=checkout_headers,
                                     context=platform_context)
            checkout_id = checkout["checkout_session_id"]
            cuss_secret = checkout.get("customer_session_client_secret", "")
            billing["_cuss_secret"] = cuss_secret
            billing["_promo"] = True

            # 检查金额是否为 0（确认促销已生效）
            cs = checkout.get("checkout_state", {})
            total = cs.get("total", {}).get("total", {})
            amount = total.get("minorUnitsAmount", 0)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"{checkout_id} · 金额: {amount/100:.2f} PHP"
            log.info("Step 2 ✓ — checkout_id=%s amount=%s", checkout_id, amount)
            if amount != 0:
                log.warning("Step 2 ⚠ — 促销未生效，金额非 0: %s", amount)
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 3: 设置账单地址和税费 ─────────────────────────────
        steps.append({"step": 3, "name": "设置账单地址 & 税费", "status": "running"})
        try:
            tax_body = {
                "checkout_session_id": checkout_id,
                "checkout_email": billing["email"],
                "billing_country": billing["country"],
                "billing_name": billing["name"],
                "currency": billing["currency"],
                "processor_entity": "vendor_entity",
                "billing_address": {
                    "line1": billing["line1"],
                    "city": billing["city"],
                    "country": billing["country"],
                    "postal_code": billing["postal_code"],
                    "state": billing["state"],
                },
            }
            tax_result = _platform_post(log, http, access_token, cookies,
                                       "/api/v1/payments/checkout/taxes", tax_body,
                                       context=platform_context)
            cs = tax_result.get("checkout_session", {})
            amount_total = cs.get("amount_total", 0)
            # 提取 Stripe Customer ID（confirmation_tokens 需要 client_context[customer]）
            stripe_customer = cs.get("customer", "")
            if stripe_customer:
                billing["_stripe_customer"] = stripe_customer
                log.info("Step 3 — customer=%s", stripe_customer)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"应付金额: {amount_total/100:,.2f} {billing['currency'].upper()}"
            log.info("Step 3 ✓ — amount=%d minor_units", amount_total)
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 4: SetupIntent 绑卡（协议方式）────────────────────
        # 协议流程:
        #   a. GET /payments/stripe_client_bootstrap 获取账号专属 Stripe key
        #   b. GET /payments/checkout/{processor}/{checkout_id} 获取 checkout context
        #   c. POST /payments/payment_method 创建 SetupIntent
        #   d. POST /v1/setup_intents/{id}/confirm 绑卡拿 pm_id
        #   e. confirmation_tokens 用 pm_id（不是卡数据）
        steps.append({"step": 4, "name": "SetupIntent 绑卡 (Stripe)", "status": "running"})
        try:
            # 4a. 获取账号专属 Stripe key（协议关键步骤）
            # Checkout-derived key 不可靠，账号可能分布在不同的 Stripe merchant shard
            bootstrap_key = ""
            try:
                bootstrap = _platform_get(log, http, access_token, cookies,
                                         "/api/v1/payments/stripe_client_bootstrap",
                                         context=platform_context,
                                         params={"account_id": account_id})
                bootstrap_key = _find_in(bootstrap, ("publishable_key", "publishableKey"))
                log.info("Step 4a ✓ — stripe_client_bootstrap key=%s",
                         bootstrap_key[:25] + "…" if bootstrap_key else "(未获取)")
            except Exception as exc:
                log.warning("stripe_client_bootstrap 失败: %s，回退用 checkout key", exc)

            # 4b. 获取 checkout context（GET checkout 页面数据）
            processor = checkout.get("processor_entity", "vendor_entity")
            checkout_ctx = {}
            try:
                checkout_context_path = f"/api/v1/payments/checkout/{processor}/{checkout_id}"
                ctx_resp = _http_get(
                    http,
                    f"{PLATFORM_BASE}{checkout_context_path}",
                    headers=_platform_headers(
                        access_token,
                        cookies,
                        path=checkout_context_path,
                        context=platform_context,
                    ),
                )
                _log_request(log, ctx_resp, label=f"Platform GET checkout context {checkout_id[:20]}")
                if ctx_resp.status_code < 400:
                    checkout_ctx = _stream_to_dict(ctx_resp)
            except Exception as exc:
                log.warning("checkout context 获取失败: %s", exc)

            # 4c. POST /api/v1/payments/payment_method 创建 SetupIntent
            pm_prepare = _platform_post(log, http, access_token, cookies,
                                       "/api/v1/payments/payment_method",
                                       {"account_id": account_id},
                                       context=platform_context)
            setup_secret = ""
            setup_id = ""
            setup_secret = _find_in(pm_prepare, ("client_secret", "setup_intent_client_secret"))
            setup_id = _find_in(pm_prepare, ("setup_intent", "setup_intent_id", "id"))
            if setup_id.startswith("seti_"):
                pass
            elif setup_secret.startswith("seti_"):
                setup_id = setup_secret.split("_secret_")[0]
            # 优先用账号专属 key，回退 checkout key
            pm_key = bootstrap_key or _find_in(pm_prepare, ("publishable_key", "publishableKey")) or STRIPE_PUBLISHABLE_KEY
            log.info("Step 4c ✓ — SetupIntent=%s key=%s", setup_id[:20] + "…", pm_key[:25] + "…")

            if not setup_id or not setup_secret:
                raise RuntimeError("payment_method 响应缺少 SetupIntent 凭据")

            # 4b. POST /v1/setup_intents/{id}/confirm 绑卡
            guid = _uuid().replace("-", "") + _random_hex(3)
            muid = _uuid().replace("-", "") + _random_hex(3)
            sid = _uuid().replace("-", "") + _random_hex(3)
            stripe_js_id = str(uuid.uuid4())
            setup_body: dict[str, str] = {
                "set_as_default_payment_method": "true",
                "expected_payment_method_type": "card",
                "use_stripe_sdk": "true",
                "key": pm_key,
                "_stripe_version": STRIPE_VERSION,
                "client_attribution_metadata[client_session_id]": stripe_js_id,
                "client_attribution_metadata[merchant_integration_source]": "elements",
                "client_attribution_metadata[merchant_integration_subtype]": "card-element",
                "client_attribution_metadata[merchant_integration_version]": "2017",
                "client_secret": setup_secret,
                "payment_method_data[type]": "card",
                "payment_method_data[billing_details][name]": billing["name"],
                "payment_method_data[allow_redisplay]": "always",
                "payment_method_data[card][number]": card["number"],
                "payment_method_data[card][cvc]": card["cvc"],
                "payment_method_data[card][exp_month]": card["exp_month"],
                "payment_method_data[card][exp_year]": card["exp_year"],
                "payment_method_data[guid]": guid,
                "payment_method_data[muid]": muid,
                "payment_method_data[sid]": sid,
                "payment_method_data[pasted_fields]": "number,exp,cvc",
                "payment_method_data[payment_user_agent]": (
                    "stripe.js/0000000000; stripe-js-v3/0000000000; card-element"
                ),
                "payment_method_data[referrer]": PLATFORM_BASE,
                "payment_method_data[time_on_page]": str(375482),
                "payment_method_data[client_attribution_metadata][client_session_id]": stripe_js_id,
                "payment_method_data[client_attribution_metadata][merchant_integration_source]": "elements",
                "payment_method_data[client_attribution_metadata][merchant_integration_subtype]": "card-element",
                "payment_method_data[client_attribution_metadata][merchant_integration_version]": "2017",
            }
            if billing["email"]:
                setup_body["payment_method_data[billing_details][email]"] = billing["email"]
            for field in ("line1", "city", "state", "postal_code", "country"):
                value = billing.get(field, "")
                if value:
                    setup_body[f"payment_method_data[billing_details][address][{field}]"] = (
                        value.upper() if field == "country" else value
                    )
            if billing.get("postal_code"):
                setup_body["payment_method_data[pasted_fields]"] = "number,exp,cvc,zip"

            setup_form = _urlencode(list(setup_body.items()))
            setup_resp = _http_post_form(
                http,
                f"{STRIPE_API_BASE}/setup_intents/{setup_id}/confirm",
                data=setup_form,
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Origin": "https://js.stripe.com",
                    "Referer": "https://js.stripe.com/",
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                    ),
                },
            )
            _log_request(log, setup_resp, label=f"Stripe POST /v1/setup_intents/{setup_id[:20]}/confirm")
            setup_payload = _stream_to_dict(setup_resp)
            if setup_resp.status_code != 200:
                err = setup_payload.get("error", {})
                raise RuntimeError(f"SetupIntent 绑卡失败: {err.get('message', str(setup_payload)[:300])}")

            # 从响应提取 pm_id
            payment_method_id = ""
            si = setup_payload.get("setup_intent", {})
            payment_method_id = si.get("payment_method", "") if isinstance(si, dict) else ""
            if not payment_method_id:
                payment_method_id = setup_payload.get("payment_method", "")
            status = setup_payload.get("status", "") or (si.get("status", "") if isinstance(si, dict) else "")
            if status != "succeeded":
                raise RuntimeError(f"SetupIntent 状态: {status}")

            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"绑卡成功: {payment_method_id[:20]}…"
            log.info("Step 4b ✓ — 绑卡成功 pm_id=%s", payment_method_id)

            # 4c. confirmation_tokens 用 pm_id（协议方式，非卡数据）
            token_form: list[tuple[str, str]] = [
                ("payment_method", payment_method_id),
                ("setup_future_usage", "off_session"),
                ("set_as_default_payment_method", "false"),
                ("client_context[currency]", billing.get("currency", "php")),
                ("client_context[mode]", "subscription"),
                ("client_context[payment_method_types][0]", "link"),
                ("client_context[payment_method_types][1]", "card"),
                ("client_attribution_metadata[client_session_id]", stripe_js_id),
                ("client_attribution_metadata[merchant_integration_source]", "elements"),
                ("client_attribution_metadata[merchant_integration_subtype]", "payment-element"),
                ("client_attribution_metadata[merchant_integration_version]", "2021"),
                ("client_attribution_metadata[payment_intent_creation_flow]", "deferred"),
                ("client_attribution_metadata[payment_method_selection_flow]", "merchant_specified"),
                ("client_attribution_metadata[merchant_integration_additional_elements][0]", "expressCheckout"),
                ("client_attribution_metadata[merchant_integration_additional_elements][1]", "payment"),
                ("client_attribution_metadata[merchant_integration_additional_elements][2]", "address"),
                ("key", pm_key),
            ]
            if billing.get("_stripe_customer"):
                token_form.append(("client_context[customer]", billing["_stripe_customer"]))
                log.info("confirmation_tokens: client_context[customer]=%s", billing["_stripe_customer"])

            token_body_str = _urlencode(token_form)
            token_resp = _http_post_form(
                http,
                f"{STRIPE_API_BASE}/confirmation_tokens",
                data=token_body_str,
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Origin": "https://js.stripe.com",
                    "Referer": "https://js.stripe.com/",
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
                    ),
                },
            )
            _log_request(log, token_resp, label="Stripe POST /v1/confirmation_tokens")
            token_payload = _stream_to_dict(token_resp)
            if token_resp.status_code != 200:
                err = token_payload.get("error", {})
                raise RuntimeError(f"confirmation_tokens 失败: {err.get('message', str(token_payload)[:300])}")

            confirm_token = token_payload.get("id", "")
            if not confirm_token:
                confirm_token = token_payload.get("confirmation_token", "")
            if not confirm_token:
                raise RuntimeError("confirmation_tokens 响应缺少 token")
            log.info("Step 4c ✓ — ctoken=%s", confirm_token[:20] + "…")
            steps[-1]["detail"] = f"绑卡成功: {payment_method_id[:20]}… · ctoken: {confirm_token[:20]}…"
            preview = {}
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 5: 确认 Checkout ──────────────────────────────────
        steps.append({"step": 5, "name": "确认 Checkout (Platform)", "status": "running"})
        try:
            # 构建 Challenge 风控上下文（解决 blocked）
            challenge_headers = dict(checkout_headers)
            # 浏览器确认头：x-vendor-target-path / referer 指向 checkout 页面
            challenge_headers["x-vendor-target-path"] = "/api/v1/payments/checkout/confirm"
            challenge_headers["x-vendor-target-route"] = "/api/v1/payments/checkout/confirm"
            challenge_headers["Referer"] = f"{PLATFORM_BASE}/checkout/{checkout.get('processor_entity', 'vendor_entity')}/{checkout_id}"
            if challenge_headers:
                steps[-1]["detail"] = f"Challenge 上下文: {', '.join(k.replace('-', '') for k in challenge_headers)}"
            confirm_result = _platform_post(log, http, access_token, cookies,
                                           "/api/v1/payments/checkout/confirm", {
                                               "checkout_session_id": checkout_id,
                                               "confirm_token": confirm_token,
                                               "selected_payment_method_type": "card",
                                           }, extra_headers=challenge_headers,
                                           context=platform_context)
            status = confirm_result.get("status", "")
            client_secret = confirm_result.get("client_secret", "")
            # 零元购：confirm 可能返回 blocked（无 PaymentIntent），属于正常流程
            # 订阅通过 Stripe SetupIntent 绑卡完成，无需扣款
            if status in ("blocked", "requires_action"):
                log.info("Step 5 ⚠ — confirm status=%s（零元购无扣款，属正常）", status)
                steps[-1]["detail"] = f"状态: {status}（零元购无扣款）"
            else:
                steps[-1]["detail"] = f"状态: {status}"
            steps[-1]["status"] = "ok"
            log.info("Step 5 ✓ — confirm status=%s", status)
        except Exception as exc:
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 6: 验证订阅生效 ────────────────────────────────────
        steps.append({"step": 6, "name": "验证订阅生效", "status": "running"})
        try:
            import time as _time
            _time.sleep(3)
            subs = _platform_get(log, http, access_token, cookies,
                                "/api/v1/subscriptions",
                                context=platform_context,
                                params={"account_id": account_id})
            plan_type = subs.get("plan_type", "unknown")
            active_until = subs.get("active_until", "")
            will_renew = subs.get("will_renew", False)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"订阅: {plan_type} · 续费至 {active_until}"
            log.info("Step 6 ✓ — plan=%s will_renew=%s", plan_type, will_renew)
            log.info("══════ 零元购完成 — 成功 ══════")
            return jsonify({
                "ok": True,
                "steps": steps,
                "checkout_id": checkout_id,
                "plan": plan_type,
                "active_until": active_until,
                "will_renew": will_renew,
                "log_file": str(log_path),
            })
        except Exception as exc:
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = "订阅验证跳过"
            log.info("Step 6 ⚠ — %s", exc)
            log.info("══════ 零元购完成 ══════")
            return jsonify({
                "ok": True,
                "steps": steps,
                "checkout_id": checkout_id,
                "log_file": str(log_path),
            })

    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "steps": steps, "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "steps": steps, "log_file": str(log_path)}), 500


@app.post("/api/subscription/update/finalize")
def subscription_update_finalize() -> Any:
    """确认前端 3DS 完成后的升级结果，失败时撤销 pending upgrade。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 升级 3DS 结果确认 %s ══════", request_id[:8])
    try:
        payload = request.get_json(silent=True) or {}
        session_data = _parse_session(str(payload.get("session", "")))
        access_token, email, user_id, cookies = _extract_auth(session_data)
        pi_id = str(payload.get("payment_intent_id", "")).strip()
        client_secret = str(payload.get("client_secret", "")).strip()
        requested_account_id = str(payload.get("account_id", "")).strip()
        target_plan = _normalize_plan(str(payload.get("target_plan", "")))
        restore_canceled = bool(payload.get("restore_canceled"))
        authentication_failed = bool(payload.get("authentication_failed"))

        http = make_http_session()
        context = _new_platform_context(cookies)
        account_id = _get_account_id(
            log, http, access_token, cookies, session_data, context=context,
        )
        if not account_id or account_id != requested_account_id:
            raise ValueError("account_id 与当前 Session 不匹配")
        context.account_id = account_id
        _load_payment_metadata(log, http, access_token, cookies, context)

        payment_intent = _stripe_get_payment_intent(log, http, pi_id, client_secret)
        status = str(payment_intent.get("status", ""))
        if status == "succeeded":
            subscription, activated = _wait_for_subscription_plan(
                log,
                http,
                access_token,
                cookies,
                context,
                account_id,
                target_plan,
            )
            return jsonify({
                "ok": activated,
                "flow": "upgrade",
                "pending": not activated,
                "message": (
                    "3D Secure 验证完成，订阅升级成功"
                    if activated else "扣款成功，订阅状态仍在同步"
                ),
                "payment_intent": {"id": pi_id, "status": status},
                "subscription": subscription,
                "log_file": str(log_path),
            })

        if status == "processing":
            return jsonify({
                "ok": False,
                "flow": "upgrade",
                "pending": True,
                "message": "扣款正在处理中，请稍后查询订阅状态",
                "payment_intent": {"id": pi_id, "status": status},
                "log_file": str(log_path),
            })

        if status == "requires_action" and not authentication_failed:
            return jsonify({
                "ok": False,
                "action_required": True,
                "message": "3D Secure 验证尚未完成",
                "payment_intent": {"id": pi_id, "status": status},
                "log_file": str(log_path),
            })

        _rollback_pending_upgrade(
            log,
            http,
            access_token,
            cookies,
            context,
            account_id,
            pi_id,
            restore_canceled,
        )
        error = payment_intent.get("last_payment_error") or {}
        fallback_error = (
            "3D Secure 验证未完成"
            if authentication_failed and status == "requires_action"
            else f"升级扣款失败: {status or 'unknown'}"
        )
        return jsonify({
            "ok": False,
            "flow": "upgrade",
            "error": _stripe_user_error(error, fallback_error),
            "code": error.get("code", ""),
            "decline_code": error.get("decline_code", ""),
            "payment_intent": {"id": pi_id, "status": status},
            "log_file": str(log_path),
        })
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "log_file": str(log_path)}), 500


@app.post("/api/pay/finalize")
def pay_finalize() -> Any:
    """复查普通 Checkout 的 3DS 结果，并继续 Platform Verify。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 普通支付 3DS 结果确认 %s ══════", request_id[:8])
    try:
        payload = request.get_json(silent=True) or {}
        session_data = _parse_session(str(payload.get("session", "")))
        access_token, _email, _user_id, cookies = _extract_auth(session_data)
        pi_id = str(payload.get("payment_intent_id", "")).strip()
        client_secret = str(payload.get("client_secret", "")).strip()
        requested_account_id = str(payload.get("account_id", "")).strip()
        checkout_id = str(payload.get("checkout_id", "")).strip()
        processor_entity = str(
            payload.get("processor_entity", "vendor_entity")
        ).strip()
        plan = _normalize_plan(str(payload.get("plan", "")))
        authentication_failed = bool(payload.get("authentication_failed"))
        verify_url = _checkout_verify_url(checkout_id, processor_entity, plan)

        http = make_http_session()
        context = _new_platform_context(cookies)
        account_id = _get_account_id(
            log,
            http,
            access_token,
            cookies,
            session_data,
            context=context,
        )
        if not account_id or account_id != requested_account_id:
            raise ValueError("account_id 与当前 Session 不匹配")
        context.account_id = account_id
        _load_payment_metadata(log, http, access_token, cookies, context)

        payment_intent = _stripe_get_payment_intent(
            log, http, pi_id, client_secret,
        )
        status = str(payment_intent.get("status", ""))
        log.info(
            "普通支付 3DS finalize — status=%s authentication_failed=%s",
            status or "unknown",
            authentication_failed,
        )
        if status == "succeeded":
            verify_response = _http_get(
                http,
                verify_url,
                headers=_platform_headers(
                    access_token,
                    cookies,
                    context=context,
                ),
            )
            log.info("Platform Verify HTTP %s", verify_response.status_code)

            subscription: dict[str, Any] = {}
            subscription_warning = ""
            try:
                subscription = _platform_get(
                    log,
                    http,
                    access_token,
                    cookies,
                    "/api/v1/subscriptions",
                    context=context,
                    params={"account_id": account_id},
                )
            except Exception as exc:
                subscription_warning = str(exc)
                log.info("3DS 后订阅状态暂未更新: %s", exc)

            log.info(
                "普通支付 3DS 完成 — checkout_id=%s plan=%s subscription_plan=%s",
                checkout_id,
                PLAN_SUBSCRIPTION_TYPES[plan],
                subscription.get("plan_type", "") if subscription else "",
            )

            return jsonify({
                "ok": True,
                "flow": "checkout",
                "message": "3D Secure 验证完成，支付成功",
                "payment_intent": {
                    "id": pi_id,
                    "status": status,
                    "amount": payment_intent.get("amount", 0),
                    "currency": payment_intent.get("currency", "php"),
                },
                "checkout_id": checkout_id,
                "subscription": subscription,
                "subscription_warning": subscription_warning,
                "log_file": str(log_path),
            })

        if status == "processing":
            log.info("普通支付 3DS 后 Stripe 仍在处理: pi_id=%s", pi_id)
            return jsonify({
                "ok": False,
                "flow": "checkout",
                "pending": True,
                "message": "3D Secure 已完成，Stripe 正在处理扣款",
                "payment_intent": {"id": pi_id, "status": status},
                "log_file": str(log_path),
            })

        if status == "requires_action" and not authentication_failed:
            log.warning("普通支付 3DS 尚未完成: pi_id=%s", pi_id)
            return jsonify({
                "ok": False,
                "flow": "checkout",
                "action_required": True,
                "message": "3D Secure 验证尚未完成",
                "payment_intent": {"id": pi_id, "status": status},
                "log_file": str(log_path),
            })

        error = payment_intent.get("last_payment_error") or {}
        fallback_error = (
            "3D Secure 验证未完成"
            if authentication_failed and status == "requires_action"
            else f"支付失败: {status or 'unknown'}"
        )
        log.warning(
            "普通支付 3DS 失败 — pi_id=%s status=%s error=%s code=%s decline_code=%s",
            pi_id,
            status or "unknown",
            str(error.get("message") or fallback_error)[:500],
            error.get("code", ""),
            error.get("decline_code", ""),
        )
        return jsonify({
            "ok": False,
            "flow": "checkout",
            "error": _stripe_user_error(error, fallback_error),
            "code": error.get("code", ""),
            "decline_code": error.get("decline_code", ""),
            "payment_intent": {"id": pi_id, "status": status},
            "log_file": str(log_path),
        })
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)}), 502
    except Exception as exc:
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({
            "ok": False,
            "error": f"未预期错误: {exc}",
            "log_file": str(log_path),
        }), 500


def _load_upgrade_account(
    log: logging.Logger,
    payload: dict[str, Any],
) -> tuple[SessionInput, str, Any, PlatformRequestContext, str, str]:
    """加载升级接口共用的 Session、账号和目标计划上下文。"""
    session_input = _parse_session_input(payload, log)
    target_plan = _normalize_plan(str(payload.get("plan", DEFAULT_PLAN)))
    http = make_http_session()
    context = _new_platform_context(session_input.cookies)
    accounts = _platform_get(
        log,
        http,
        session_input.access_token,
        session_input.cookies,
        "/api/v1/accounts/check/v4-2023-04-27",
        context=context,
        params={"timezone_offset_min": -480},
    )
    account_id = next(iter(accounts.get("accounts", {})), "")
    if not account_id:
        raise RuntimeError("账号检查响应中缺少 account_id")
    account = accounts.get("accounts", {}).get(account_id, {})
    current_plan = str(account.get("account", {}).get("plan_type", "unknown"))
    context.account_id = account_id
    return session_input, target_plan, http, context, account_id, current_plan


def _upgrade_requires_paid_subscription(current_plan: str) -> bool:
    return _subscription_plan_type(current_plan) in ("basic", "standard", "premium")


def _prepare_payment_method_elements(
    log: logging.Logger,
    payload: dict[str, Any],
    *,
    require_paid_subscription: bool,
) -> dict[str, Any]:
    """创建绑定到当前 Platform 账号的浏览器 SetupIntent。"""
    session_input, _target_plan, http, context, account_id, current_plan = (
        _load_upgrade_account(log, payload)
    )
    if require_paid_subscription and not _upgrade_requires_paid_subscription(current_plan):
        raise ValueError("当前账号没有可更新的付费订阅")

    billing = _billing_details(payload, session_input.email)
    required_billing = ("line1", "city", "postal_code", "country")
    if any(not billing.get(field) for field in required_billing):
        raise RuntimeError("后端账单地址配置不完整，无法初始化新卡输入")

    _load_payment_metadata(
        log, http, session_input.access_token, session_input.cookies, context,
    )
    setup = _prepare_upgrade_payment_method(
        log,
        http,
        session_input.access_token,
        session_input.cookies,
        context,
        account_id,
    )
    return {
        "ok": True,
        "stripe_publishable_key": setup["publishable_key"],
        "client_secret": setup["client_secret"],
        "billing_details": {
            "name": billing["name"],
            "email": billing["email"],
            "address": {
                "line1": billing["line1"],
                "city": billing["city"],
                "state": billing["state"],
                "postal_code": billing["postal_code"],
                "country": billing["country"],
            },
        },
    }


@app.post("/api/payment-methods/bind/prepare")
def payment_method_bind_prepare() -> Any:
    """为独立绑卡页创建由 Stripe Elements 确认的 SetupIntent。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 浏览器绑卡准备 %s ══════", request_id[:8])
    try:
        payload = request.get_json(silent=True) or {}
        result = _prepare_payment_method_elements(
            log, payload, require_paid_subscription=False,
        )
        result.update({
            "flow": "payment_method_bind",
            "log_file": str(log_path),
        })
        return jsonify(result)
    except (ValueError, RuntimeError) as exc:
        log.error("浏览器绑卡准备失败: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)})
    except Exception as exc:
        log.exception("浏览器绑卡准备发生未预期错误")
        return jsonify({
            "ok": False,
            "error": f"未预期错误: {exc}",
            "log_file": str(log_path),
        }), 500


@app.post("/api/payment-methods/bind/complete")
def payment_method_bind_complete() -> Any:
    """确认 Stripe Elements 返回的支付方式已绑定到当前账号。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 浏览器绑卡确认 %s ══════", request_id[:8])
    steps: list[dict[str, Any]] = []
    try:
        payload = request.get_json(silent=True) or {}
        session_input, _target_plan, http, context, account_id, current_plan = (
            _load_upgrade_account(log, payload)
        )
        steps.append({
            "step": 1,
            "name": "验证 Platform 账号",
            "status": "ok",
            "detail": f"当前计划: {current_plan}",
        })

        payment_method_id = str(payload.get("payment_method_id", "")).strip()
        steps.append({"step": 2, "name": "确认绑卡状态", "status": "running"})
        payment_method = _wait_for_account_payment_method(
            log,
            http,
            session_input.access_token,
            session_input.cookies,
            context,
            account_id,
            payment_method_id,
        )
        card = payment_method.get("card") or payment_method
        last4 = str(card.get("last4", ""))
        steps[-1].update({
            "status": "ok",
            "detail": f"绑卡成功: ····{last4}" if last4 else "绑卡成功",
        })
        log.info("浏览器绑卡已确认: pm_id=%s last4=%s", payment_method_id, last4)
        return jsonify({
            "ok": True,
            "flow": "payment_method_bind",
            "payment_method": payment_method_id,
            "card_last4": last4,
            "steps": steps,
            "log_file": str(log_path),
        })
    except (ValueError, RuntimeError) as exc:
        log.error("浏览器绑卡确认失败: %s", exc)
        if steps and steps[-1].get("status") == "running":
            steps[-1].update({"status": "error", "detail": str(exc)})
        return jsonify({
            "ok": False,
            "error": str(exc),
            "steps": steps,
            "log_file": str(log_path),
        })
    except Exception as exc:
        log.exception("浏览器绑卡确认发生未预期错误")
        if steps and steps[-1].get("status") == "running":
            steps[-1].update({"status": "error", "detail": str(exc)})
        return jsonify({
            "ok": False,
            "error": f"未预期错误: {exc}",
            "steps": steps,
            "log_file": str(log_path),
        }), 500


@app.post("/api/subscription/upgrade/preview")
def subscription_upgrade_preview() -> Any:
    """查询升级价格、当前计划和默认支付卡。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 订阅升级预览 %s ══════", request_id[:8])
    try:
        payload = request.get_json(silent=True) or {}
        session_input, target_plan, http, context, account_id, current_plan = (
            _load_upgrade_account(log, payload)
        )
        if not _upgrade_requires_paid_subscription(current_plan):
            return jsonify({
                "ok": False,
                "flow": "checkout_required",
                "error": "当前账号没有可更新的付费订阅，请使用普通支付页面",
                "checkout_url": "/",
                "log_file": str(log_path),
            })

        _load_payment_metadata(
            log, http, session_input.access_token, session_input.cookies, context,
        )
        subscription = _platform_get(
            log,
            http,
            session_input.access_token,
            session_input.cookies,
            "/api/v1/subscriptions",
            context=context,
            params={"account_id": account_id},
        )
        live_plan = _subscription_plan_type(str(subscription.get("plan_type", current_plan)))
        target_type = PLAN_SUBSCRIPTION_TYPES[target_plan]
        preview: dict[str, Any] = {}
        if live_plan != target_type:
            preview = _platform_get(
                log,
                http,
                session_input.access_token,
                session_input.cookies,
                "/api/v1/subscriptions/update/preview",
                context=context,
                params={"account_id": account_id, "updated_plan": target_plan},
            )

        methods = _platform_get(
            log,
            http,
            session_input.access_token,
            session_input.cookies,
            "/api/v1/payments/payment_methods",
            context=context,
            params={"account_id": account_id},
        )
        default_id = str(methods.get("default_payment_method_id", ""))
        default_method: dict[str, Any] = {}
        for item in methods.get("payment_methods", []):
            if isinstance(item, dict) and item.get("id") == default_id:
                default_method = item
                break
        default_card = default_method.get("card") or default_method
        preview_default = preview.get("default_payment_method") or {}
        amount_due = preview.get("amount_due") or {}
        amount = amount_due.get("amount", preview.get("total_amount", 0))
        default_summary = {
            "brand": str(default_card.get("brand", "")),
            "last4": str(default_card.get("last4") or preview_default.get("card_last4", "")),
            "exp_month": default_card.get("exp_month"),
            "exp_year": default_card.get("exp_year"),
        }
        has_default = bool(default_id and default_summary["last4"])
        log.info(
            "升级预览完成: current=%s target=%s default_card=%s",
            live_plan,
            target_type,
            "存在" if has_default else "不存在",
        )
        return jsonify({
            "ok": True,
            "flow": "upgrade_preview",
            "current_plan": live_plan,
            "target_plan": target_plan,
            "target_plan_type": target_type,
            "same_plan": live_plan == target_type,
            "will_renew": bool(subscription.get("will_renew")),
            "amount": int(amount or 0),
            "currency": str(preview.get("currency", "php")).lower(),
            "default_payment_method": default_summary if has_default else None,
            "log_file": str(log_path),
        })
    except (ValueError, RuntimeError) as exc:
        log.error("订阅升级预览失败: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)})
    except Exception as exc:
        log.exception("订阅升级预览发生未预期错误")
        return jsonify({
            "ok": False,
            "error": f"未预期错误: {exc}",
            "log_file": str(log_path),
        }), 500


@app.post("/api/subscription/upgrade/payment-method/prepare")
def subscription_upgrade_payment_method_prepare() -> Any:
    """为升级页创建由 Stripe Elements 确认的新卡 SetupIntent。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    log.info("══════ 升级新卡准备 %s ══════", request_id[:8])
    try:
        payload = request.get_json(silent=True) or {}
        result = _prepare_payment_method_elements(
            log, payload, require_paid_subscription=True,
        )
        result.update({
            "flow": "upgrade_payment_method",
            "log_file": str(log_path),
        })
        return jsonify(result)
    except (ValueError, RuntimeError) as exc:
        log.error("升级新卡准备失败: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "log_file": str(log_path)})
    except Exception as exc:
        log.exception("升级新卡准备发生未预期错误")
        return jsonify({
            "ok": False,
            "error": f"未预期错误: {exc}",
            "log_file": str(log_path),
        }), 500


@app.post("/api/subscription/upgrade")
def subscription_upgrade() -> Any:
    """使用默认卡或前端已绑定的新卡更新现有订阅。"""
    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    steps: list[dict[str, Any]] = []
    log.info("══════ 新订阅升级请求 %s ══════", request_id[:8])
    log.info("代理: %s", _proxy_log_label(OUTBOUND_PROXY_URL))
    log.info("日志文件: %s", log_path)

    try:
        payload = request.get_json(silent=True) or {}
        session_input, target_plan, http, context, account_id, current_plan = (
            _load_upgrade_account(log, payload)
        )
        payment_source = str(payload.get("payment_source", "")).strip().lower()
        payment_method_id = str(payload.get("payment_method_id", "")).strip()

        steps.append({"step": 1, "name": "验证现有订阅", "status": "running"})
        if not _upgrade_requires_paid_subscription(current_plan):
            message = "当前账号没有可更新的付费订阅，请使用普通支付页面"
            steps[-1].update({"status": "error", "detail": message})
            return jsonify({
                "ok": False,
                "flow": "checkout_required",
                "error": message,
                "checkout_url": "/",
                "steps": steps,
                "log_file": str(log_path),
            })

        steps[-1].update({
            "status": "ok",
            "detail": f"当前计划: {current_plan} | 邮箱: {session_input.email}",
        })
        log.info(
            "升级账号验证成功 — 当前计划=%s 支付来源=%s",
            current_plan,
            payment_source,
        )
        _load_payment_metadata(
            log,
            http,
            session_input.access_token,
            session_input.cookies,
            context,
        )
        return _upgrade_subscription(
            log,
            log_path,
            steps,
            http,
            session_input.access_token,
            session_input.cookies,
            context,
            account_id,
            current_plan,
            target_plan,
            payment_source,
            payment_method_id,
        )
    except (ValueError, RuntimeError) as exc:
        log.error("订阅升级失败: %s", exc)
        log.debug("Traceback:\n%s", traceback.format_exc())
        if steps and steps[-1].get("status") == "running":
            steps[-1].update({"status": "error", "detail": str(exc)})
        return jsonify({
            "ok": False,
            "flow": "upgrade",
            "error": str(exc),
            "steps": steps,
            "log_file": str(log_path),
        })
    except Exception as exc:
        log.exception("订阅升级发生未预期错误")
        if steps and steps[-1].get("status") == "running":
            steps[-1].update({"status": "error", "detail": str(exc)})
        return jsonify({
            "ok": False,
            "flow": "upgrade",
            "error": f"未预期错误: {exc}",
            "steps": steps,
            "log_file": str(log_path),
        }), 500


@app.post("/api/pay")
def pay() -> Any:
    """未订阅账号的新开通支付接口。"""

    request_id = _uuid()
    log, log_path = _setup_request_logger(request_id)
    steps: list[dict[str, Any]] = []

    # 记录请求基本信息
    log.info("══════ 新支付请求 %s ══════", request_id[:8])
    log.info("代理: %s", _proxy_log_label(OUTBOUND_PROXY_URL))
    log.info("日志文件: %s", log_path)

    try:
        payload = request.get_json(silent=True) or {}

        payment_input = _parse_payment_input(payload, log)
        access_token = payment_input.access_token
        email = payment_input.email
        cookies = payment_input.cookies
        card = payment_input.card
        billing = payment_input.billing
        plan = payment_input.plan

        http = make_http_session()
        platform_context = _new_platform_context(cookies)

        # ── Step 1: 验证账号 ──────────────────────────────────────
        steps.append({"step": 1, "name": "验证 Platform 账号", "status": "running"})
        try:
            accounts = _platform_get(log, http, access_token, cookies,
                                    "/api/v1/accounts/check/v4-2023-04-27",
                                    context=platform_context,
                                    params={"timezone_offset_min": -480})
            acct = list(accounts.get("accounts", {}).values())[0]
            current_plan = acct.get("account", {}).get("plan_type", "unknown")
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"当前计划: {current_plan} | 邮箱: {email}"
            log.info("Step 1 ✓ — 当前计划=%s", current_plan)
            account_id = next(iter(accounts.get("accounts", {})), "")
            if not account_id:
                raise RuntimeError("账号检查响应中缺少 account_id")
            platform_context.account_id = account_id
        except Exception as exc:
            log.error("Step 1 ✗ — %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        current_subscription_type = _subscription_plan_type(str(current_plan))
        if current_subscription_type in ("basic", "standard", "premium"):
            message = "检测到当前账号已有付费订阅，普通开通流程不适用，请前往订阅升级页面"
            log.info("普通支付已停止: 当前计划=%s，应转入升级页面", current_plan)
            steps.append({
                "step": 2,
                "name": "选择支付流程",
                "status": "action_required",
                "detail": message,
            })
            return jsonify({
                "ok": False,
                "flow": "upgrade_required",
                "error": message,
                "upgrade_url": "/upgrade",
                "steps": steps,
                "log_file": str(log_path),
            })

        # 普通开通在账号确认后再加载支付元数据，升级流程不再进入本接口。
        _load_payment_metadata(log, http, access_token, cookies, platform_context)

        use_new_pro_protocol = _is_new_pro_checkout_plan(plan)
        if use_new_pro_protocol:
            log.info("启用 Pro 新开通协议: plan=%s", plan)
        elif plan in NEW_PRO_CHECKOUT_PLANS:
            log.info("启用 Pro Legacy Checkout 协议: plan=%s", plan)

        # ── Step 2: 创建 Checkout 会话 ────────────────────────────
        steps.append({"step": 2, "name": "创建 Checkout 会话", "status": "running"})
        try:
            checkout_create_plan = (
                _new_pro_checkout_create_plan(plan)
                if use_new_pro_protocol
                else plan
            )
            checkout_body = {
                "entry_point": "all_plans_pricing_modal",
                "plan_name": checkout_create_plan,
                "billing_details": {"country": "PH", "currency": "PHP"},
                "checkout_ui_mode": "custom",
            }
            log.info("Step 2 — 请求 body: %s", json.dumps(checkout_body, ensure_ascii=False))
            log.debug(
                "Step 2 — 请求头: %s",
                json.dumps(
                    _safe_headers_for_log(_platform_headers(
                        access_token,
                        cookies,
                        path="/api/v1/payments/checkout",
                        context=platform_context,
                    )),
                    ensure_ascii=False,
                )[:800],
            )
            checkout_headers = None
            if use_new_pro_protocol:
                checkout_headers = _new_pro_challenge_headers(
                    log,
                    http,
                    access_token,
                    cookies,
                    platform_context,
                    flow="platform_checkout",
                    include_account_id=False,
                )
            checkout = _platform_post(log, http, access_token, cookies,
                                     "/api/v1/payments/checkout", checkout_body,
                                     extra_headers=checkout_headers,
                                     context=platform_context)
            checkout_id = checkout["checkout_session_id"]

            if use_new_pro_protocol and plan != checkout_create_plan:
                update_headers = _new_pro_payment_headers(
                    log,
                    http,
                    access_token,
                    cookies,
                    platform_context,
                    include_account_id=True,
                )
                update_result = _platform_post(
                    log,
                    http,
                    access_token,
                    cookies,
                    "/api/v1/payments/checkout/update",
                    {
                        "checkout_session_id": checkout_id,
                        "processor_entity": checkout.get(
                            "processor_entity", "vendor_entity"
                        ),
                        "plan_name": plan,
                        "price_interval": "month",
                        "seat_quantity": 1,
                    },
                    extra_headers=update_headers,
                    context=platform_context,
                )
                updated_checkout = update_result.get("checkout_session")
                if not isinstance(updated_checkout, dict):
                    raise RuntimeError("Pro Checkout 切换计划响应缺少 checkout_session")
                if updated_checkout.get("checkout_session_id") != checkout_id:
                    raise RuntimeError("Pro Checkout 切换计划返回了不同的 Checkout ID")
                checkout = updated_checkout
                log.info("Pro Checkout 计划已切换: %s → %s", checkout_create_plan, plan)

            cuss_secret = checkout.get("customer_session_client_secret", "")
            billing["_cuss_secret"] = cuss_secret
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = checkout_id
            log.info("Step 2 ✓ — checkout_id=%s", checkout_id)
        except Exception as exc:
            log.error("Step 2 ✗ — %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 3: 设置账单地址和税费 ─────────────────────────────
        steps.append({"step": 3, "name": "设置账单地址 & 税费", "status": "running"})
        try:
            tax_body: dict[str, Any] = {
                "checkout_session_id": checkout_id,
                "checkout_email": billing["email"],
                "billing_country": billing["country"],
                "billing_name": billing["name"],
                "currency": billing["currency"],
                "processor_entity": "vendor_entity",
                "billing_address": {
                    "line1": billing["line1"],
                    "city": billing["city"],
                    "country": billing["country"],
                    "postal_code": billing["postal_code"],
                    "state": billing["state"],
                },
            }
            tax_headers = None
            if use_new_pro_protocol:
                tax_headers = _new_pro_payment_headers(
                    log,
                    http,
                    access_token,
                    cookies,
                    platform_context,
                    include_account_id=True,
                )
            tax_result = _platform_post(
                log,
                http,
                access_token,
                cookies,
                "/api/v1/payments/checkout/taxes",
                tax_body,
                extra_headers=tax_headers,
                context=platform_context,
            )
            cs = tax_result.get("checkout_session", {})
            amount_total = cs.get("amount_total", 0)
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"扣款金额: {amount_total/100:,.2f} {billing['currency'].upper()}"
            log.info("Step 3 ✓ — amount=%d minor_units (%s)", amount_total, billing["currency"])
        except Exception as exc:
            log.error("Step 3 ✗ — %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 4: 银行卡令牌化 ────────────────────────────────────
        steps.append({"step": 4, "name": "银行卡令牌化 (Stripe)", "status": "running"})
        try:
            ctoken_result = _stripe_confirmation_token(log, http, card, billing)
            confirm_token = ctoken_result["id"]
            preview = ctoken_result.get("payment_method_preview", {}).get("card", {})
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = (
                f"{preview.get('brand', 'card').upper()} ····{preview.get('last4', '****')}"
                f" | 发行国: {preview.get('country', '?')}"
                f" | 类型: {preview.get('funding', '?')}"
            )
            log.info("Step 4 ✓ — token=%s  brand=%s last4=%s country=%s",
                     confirm_token[:20] + "…", preview.get("brand"), preview.get("last4"), preview.get("country"))
        except Exception as exc:
            log.error("Step 4 ✗ — %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 5: Platform 确认 Checkout ──────────────────────────
        steps.append({"step": 5, "name": "确认 Checkout (Platform)", "status": "running"})
        try:
            confirm_headers = {"Referer": (
                f"{PLATFORM_BASE}/checkout/"
                f"{checkout.get('processor_entity', 'vendor_entity')}/{checkout_id}"
            )}
            if use_new_pro_protocol:
                confirm_headers.update(_new_pro_challenge_headers(
                    log,
                    http,
                    access_token,
                    cookies,
                    platform_context,
                    flow="checkout_session_approval",
                    include_account_id=True,
                ))
            confirm_result = _platform_post(log, http, access_token, cookies,
                                           "/api/v1/payments/checkout/confirm", {
                                               "checkout_session_id": checkout_id,
                                               "confirm_token": confirm_token,
                                               "selected_payment_method_type": "card",
                                           }, extra_headers=confirm_headers,
                                           context=platform_context)
            client_secret = confirm_result.get("client_secret", "")
            confirm_return_url = confirm_result.get("confirm_return_url", "")
            if not client_secret:
                raise RuntimeError(f"Platform 确认异常: {json.dumps(confirm_result)}")
            pi_id = client_secret.split("_secret_")[0] if "_secret_" in client_secret else ""
            steps[-1]["status"] = "ok"
            steps[-1]["detail"] = f"PaymentIntent: {pi_id}"
            log.info("Step 5 ✓ — pi_id=%s", pi_id)
        except Exception as exc:
            log.error("Step 5 ✗ — %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

        # ── Step 6: Stripe 确认扣款 ──────────────────────────────────
        steps.append({"step": 6, "name": "确认扣款 (Stripe)", "status": "running"})
        try:
            pi_result = _stripe_confirm_payment_intent(
                log, http, pi_id, client_secret, confirm_token, confirm_return_url
            )

            if pi_result.get("ok"):
                pi = pi_result.get("payment_intent", {})
                steps[-1]["status"] = "ok"
                steps[-1]["detail"] = f"支付成功! PI: {pi.get('id', pi_id)} | 状态: {pi.get('status', 'succeeded')}"
                log.info("Step 6 ✓ — 支付成功!  pi_id=%s  status=%s", pi.get("id"), pi.get("status"))

                # Step 7: 回调 Platform Verify
                # Stripe 扣款成功后，浏览器会跳转 Platform verify 页面来激活订阅：
                #   https://platform.example.com/checkout/verify?stripe_session_id=xxx&processor_entity=vendor_entity&plan_type=pro
                # 我们在后端同样 GET 这个 URL，触发 Platform 侧订阅激活
                # 然后用 subscriptions API 验证订阅状态（accounts/check 的 plan_type 不是实时订阅状态）
                steps.append({"step": 7, "name": "回调 Platform Verify", "status": "running"})
                try:
                    verify_url = confirm_return_url
                    log.info("Step 7 — GET %s", verify_url)
                    verify_resp = _http_get(http, verify_url,
                                            headers=_platform_headers(
                                                access_token,
                                                cookies,
                                                context=platform_context,
                                            ))
                    log.info("Step 7 — verify HTTP %s", verify_resp.status_code)
                    import time as _time
                    _time.sleep(2)
                    # 用 subscriptions API 查询实时订阅状态
                    acct_list = list(accts.get("accounts", {}).keys()) if 'accts' in dir() else []
                    if not acct_list:
                        # 从 accounts/check 获取 account_id
                        accts_check = _platform_get(log, http, access_token, cookies,
                                                    "/api/v1/accounts/check/v4-2023-04-27",
                                                    context=platform_context,
                                                    params={"timezone_offset_min": -480})
                        acct_list = list(accts_check.get("accounts", {}).keys())
                    account_id = acct_list[0] if acct_list else ""
                    if account_id:
                        subs = _platform_get(log, http, access_token, cookies,
                                            "/api/v1/subscriptions",
                                            context=platform_context,
                                            params={"account_id": account_id})
                        new_plan = subs.get("plan_type", "unknown")
                        will_renew = subs.get("will_renew", False)
                        active_until = subs.get("active_until", "")
                        steps[-1]["status"] = "ok"
                        steps[-1]["detail"] = f"订阅已生效: {new_plan} (续费: {'是' if will_renew else '否'})"
                        log.info("Step 7 ✓ — 订阅计划=%s will_renew=%s active_until=%s",
                                 new_plan, will_renew, active_until)
                    else:
                        raise RuntimeError("无法获取 account_id")
                except Exception as exc:
                    steps[-1]["status"] = "ok"
                    steps[-1]["detail"] = f"verify 已访问 ({exc})"
                    log.info("Step 7 ⚠ — verify 完成: %s", exc)

                log.info("══════ 支付完成 — 成功 ══════")
                return jsonify({
                    "ok": True, "payment_intent": pi, "steps": steps,
                    "checkout_id": checkout_id, "log_file": str(log_path),
                    "confirm_return_url": confirm_return_url,
                })

            error_detail = pi_result.get("payment_intent", {})
            if error_detail.get("status") == "requires_action":
                log.warning("Step 6 ⚠ — 需要 3D Secure 验证")
                steps[-1]["status"] = "action_required"
                steps[-1]["detail"] = "需要 3D Secure 验证"
                action_client_secret = str(
                    error_detail.get("client_secret") or client_secret
                )
                return jsonify({
                    "ok": False,
                    "flow": "checkout",
                    "action_required": True,
                    "message": "请完成银行卡 3D Secure 验证",
                    "payment_intent": {
                        "id": error_detail.get("id", pi_id),
                        "status": "requires_action",
                    },
                    "client_secret": action_client_secret,
                    "stripe_publishable_key": (
                        checkout.get("publishable_key") or STRIPE_PUBLISHABLE_KEY
                    ),
                    "account_id": account_id,
                    "checkout_id": checkout_id,
                    "processor_entity": checkout.get(
                        "processor_entity", "vendor_entity"
                    ),
                    "plan": plan,
                    "steps": steps,
                    "log_file": str(log_path),
                })

            err_msg = pi_result.get("error", "扣款被拒绝")
            log.error("Step 6 ✗ — %s  code=%s  decline_code=%s",
                      err_msg, pi_result.get("code"), pi_result.get("decline_code"))
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = err_msg
            log.info("══════ 支付完成 — 被拒绝 ══════")
            return jsonify({
                "ok": False, "error": err_msg,
                "code": pi_result.get("code", ""),
                "decline_code": pi_result.get("decline_code", ""),
                "payment_intent": pi_result.get("payment_intent", {}),
                "steps": steps, "log_file": str(log_path),
            })
        except Exception as exc:
            log.error("Step 6 ✗ — 异常: %s", exc)
            log.debug("Traceback:\n%s", traceback.format_exc())
            steps[-1]["status"] = "error"
            steps[-1]["detail"] = str(exc)
            log.info("══════ 支付完成 — 异常 ══════")
            return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)})

    except ValueError as exc:
        log.error("参数错误: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 400
    except json.JSONDecodeError:
        log.error("Session JSON 格式不正确")
        return jsonify({"ok": False, "error": "Session JSON 格式不正确", "steps": steps, "log_file": str(log_path)}), 400
    except RuntimeError as exc:
        log.error("运行时错误: %s", exc)
        return jsonify({"ok": False, "error": str(exc), "steps": steps, "log_file": str(log_path)}), 502
    except Exception as exc:
        log.error("未预期错误: %s", exc)
        log.debug("Traceback:\n%s", traceback.format_exc())
        return jsonify({"ok": False, "error": f"未预期错误: {exc}", "steps": steps, "log_file": str(log_path)}), 500


@app.after_request
def _security_headers(response: Any) -> Any:
    response.headers["Cache-Control"] = "no-store"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


# ── 入口 ──────────────────────────────────────────────────────────
if __name__ == "__main__":
    host = os.environ.get("HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", "8088"))
    print(f"\n  Subscription Manager → http://{host}:{port}")
    print(f"  日志目录 → {LOG_DIR}\n")
    app.run(host=host, port=port, debug=False)
