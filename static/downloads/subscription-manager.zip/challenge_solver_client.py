"""Challenge Solver SDK 风控上下文获取。

通过本地 SOCKS5 转发器 + Playwright 加载 Platform Challenge Solver SDK，
按支付 flow 生成 Vendor-Challenge-Token，并从首页 HTML 提取
X-Vendor-Web-Deployment-Attestation 等支付元数据。

解决 confirm 返回 blocked 的问题（缺少风控上下文头）。
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import socket
import struct
import threading
import time
import uuid
from typing import Any, Callable
from urllib.parse import urlsplit

CHALLENGE_VERSION = "prod-0000000"  # 从 HAR 提取的当前版本
CHALLENGE_FRAME_URL = f"https://platform.example.com/challenge_solver/{CHALLENGE_VERSION}/frame.html"
CHALLENGE_SDK_URL = f"https://platform.example.com/challenge_solver/{CHALLENGE_VERSION}/sdk.js"
PLATFORM_BASE = "https://platform.example.com"

# token 缓存: key=代理 + 请求上下文 + flow → (token, expiry)
_challenge_cache: dict[str, tuple[str, float]] = {}
CHALLENGE_TTL = 900  # 15 分钟
CHALLENGE_FLOWS = frozenset({"platform_checkout", "checkout_session_approval"})


class LocalSocksForwarder:
    """本地 SOCKS5 服务器，将连接转发到上游认证代理。

    Playwright 无法直接使用带认证的 socks5h（socks5 本地 DNS 会失败），
    这里在本地起一个无认证 SOCKS5，把流量转发给 proxy-provider 上游代理。
    上游做远程 DNS（socks5h 语义由上游代理完成）。
    """

    def __init__(self, upstream: str, *, host: str = "127.0.0.1",
                 timeout: float = 60.0, logger: Callable[[str], None] | None = None) -> None:
        self.upstream = upstream
        self.host = host
        self.timeout = timeout
        self.log = logger or (lambda _m: None)
        self.port = 0
        self._server: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()

        parsed = urlsplit(upstream)
        self._upstream_host = parsed.hostname or ""
        self._upstream_port = parsed.port or 1080
        self._upstream_user = parsed.username or ""
        self._upstream_pass = parsed.password or ""

    @property
    def proxy_url(self) -> str:
        if not self.port:
            raise RuntimeError("SOCKS forwarder not started")
        return f"socks5://{self.host}:{self.port}"

    def start(self) -> str:
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind((self.host, 0))
        self._server.listen(64)
        self.port = self._server.getsockname()[1]
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()
        self.log(f"本地 SOCKS 转发器: {self.proxy_url} → {self._upstream_host}:{self._upstream_port}")
        return self.proxy_url

    def stop(self) -> None:
        self._stop.set()
        if self._server:
            try:
                self._server.close()
            except Exception:
                pass
            self._server = None

    # ── accept loop ────────────────────────────────────────────────
    def _accept_loop(self) -> None:
        while not self._stop.is_set():
            try:
                client, _addr = self._server.accept()  # type: ignore[union-attr]
            except OSError:
                break
            threading.Thread(target=self._handle_client, args=(client,), daemon=True).start()

    def _handle_client(self, client: socket.socket) -> None:
        try:
            client.settimeout(self.timeout)
            # SOCKS5 握手: 版本协商
            ver, nmethods = self._recv_exact(client, 2)
            if ver != 5 or nmethods == 0:
                client.close()
                return
            methods = self._recv_exact(client, nmethods)
            if 0x00 not in methods:  # 无认证
                client.sendall(b"\x05\xff")
                client.close()
                return
            client.sendall(b"\x05\x00")

            # 连接请求
            ver, cmd, _rsv = self._recv_exact(client, 3)
            if ver != 5 or cmd != 1:  # 只支持 CONNECT
                client.close()
                return
            atyp = self._recv_exact(client, 1)[0]
            if atyp == 1:  # IPv4
                host = socket.inet_ntoa(self._recv_exact(client, 4))
            elif atyp == 3:  # 域名
                length = self._recv_exact(client, 1)[0]
                host = self._recv_exact(client, length).decode()
            elif atyp == 4:  # IPv6
                host = socket.inet_ntop(socket.AF_INET6, self._recv_exact(client, 16))
            else:
                client.close()
                return
            port = struct.unpack(">H", self._recv_exact(client, 2))[0]

            # 连接上游代理
            upstream = socket.create_connection(
                (self._upstream_host, self._upstream_port), timeout=self.timeout
            )
            upstream.settimeout(self.timeout)

            # 上游 SOCKS5 握手（带认证）
            self._upstream_connect(upstream, host, port)

            # 回复客户端成功
            client.sendall(b"\x05\x00\x00\x01" + socket.inet_aton("0.0.0.0") + struct.pack(">H", 0))

            # 双向转发
            self._relay(client, upstream)
        except Exception as exc:
            self.log(f"SOCKS 转发错误: {exc}")
            try:
                client.close()
            except Exception:
                pass
        finally:
            try:
                client.close()
            except Exception:
                pass

    def _upstream_connect(self, upstream: socket.socket, host: str, port: int) -> None:
        # 版本协商 + 认证
        if self._upstream_user:
            user = self._upstream_user.encode()
            pwd = self._upstream_pass.encode()
            upstream.sendall(b"\x05\x01\x02")
            ver = self._recv_exact(upstream, 2)[0]
            if ver != 5:
                raise RuntimeError("upstream SOCKS5 auth failed")
            upstream.sendall(bytes([0x01, len(user)]) + user + bytes([len(pwd)]) + pwd)
            status = self._recv_exact(upstream, 2)[1]
            if status != 0:
                raise RuntimeError("upstream SOCKS5 auth rejected")
        else:
            upstream.sendall(b"\x05\x01\x00")
            self._recv_exact(upstream, 2)

        # 连接请求 — 用域名（远程 DNS）
        host_bytes = host.encode()
        upstream.sendall(b"\x05\x01\x00\x03" + bytes([len(host_bytes)]) + host_bytes + struct.pack(">H", port))
        resp = self._recv_exact(upstream, 4)
        if resp[1] != 0:
            raise RuntimeError(f"upstream CONNECT failed: {resp[1]}")
        atyp = resp[3]
        if atyp == 1:
            self._recv_exact(upstream, 4)
        elif atyp == 3:
            length = self._recv_exact(upstream, 1)[0]
            self._recv_exact(upstream, length)
        elif atyp == 4:
            self._recv_exact(upstream, 16)
        self._recv_exact(upstream, 2)

    def _relay(self, client: socket.socket, upstream: socket.socket) -> None:
        def pump(src: socket.socket, dst: socket.socket) -> None:
            try:
                while True:
                    data = src.recv(65536)
                    if not data:
                        break
                    dst.sendall(data)
            except Exception:
                pass
            finally:
                try:
                    dst.shutdown(socket.SHUT_WR)
                except Exception:
                    pass

        t1 = threading.Thread(target=pump, args=(client, upstream), daemon=True)
        t2 = threading.Thread(target=pump, args=(upstream, client), daemon=True)
        t1.start()
        t2.start()
        t1.join(timeout=self.timeout)
        t2.join(timeout=self.timeout)

    def _recv_exact(self, sock: socket.socket, size: int) -> bytes:
        data = b""
        while len(data) < size:
            chunk = sock.recv(size - len(data))
            if not chunk:
                raise ConnectionError("connection closed")
            data += chunk
        return data


# ── Playwright Challenge 上下文获取 ──────────────────────────────────
def fetch_challenge_context(
    proxy_url: str = "",
    *,
    flow: str,
    timeout: float = 90.0,
    access_token: str = "",
    cookies: str = "",
    device_id: str = "",
    account_id: str = "",
    logger: Callable[[str], None] | None = None,
) -> dict[str, str]:
    """用 Playwright 获取指定 Checkout flow 的 Token 与 Telemetry。

    流程：
    1. 本地 SOCKS 转发器（解决 socks5h 认证代理）
    2. 访问 platform.example.com 首页（让 Cloudflare challenge 自动通过）
    3. 动态加载 challenge_solver sdk.js
    4. 调用 init(flow) / token(flow) / timing()
    """
    if flow not in CHALLENGE_FLOWS:
        raise ValueError(f"不支持的 Challenge flow: {flow}")

    log = logger or (lambda _m: None)
    from playwright.sync_api import sync_playwright

    forwarder: LocalSocksForwarder | None = None
    local_proxy = ""
    if proxy_url:
        parsed = urlsplit(proxy_url)
        scheme = (parsed.scheme or "").lower()
        if scheme in ("socks5h", "socks5", "http", "https"):
            if scheme == "socks5h":
                forwarder = LocalSocksForwarder(proxy_url, logger=log)
                local_proxy = forwarder.start()
            else:
                local_proxy = proxy_url

    result_context = {"token": "", "telemetry": ""}

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(
                headless=True,
                args=[
                    "--disable-blink-features=AutomationControlled",
                    "--no-sandbox",
                ],
            )
            context_kwargs: dict[str, Any] = {
                "user_agent": (
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                    "AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/147.0.0.0 Safari/537.36"
                ),
                "viewport": {"width": 1280, "height": 720},
                "locale": "fil-PH",
                "timezone_id": "Asia/Manila",
            }
            if local_proxy:
                context_kwargs["proxy"] = {"server": local_proxy}
                log(f"Playwright 代理: {local_proxy}")

            context = browser.new_context(**context_kwargs)
            browser_cookies = []
            for item in cookies.split(";"):
                name, separator, value = item.strip().partition("=")
                if separator and name:
                    browser_cookies.append({
                        "name": name.strip(),
                        "value": value.strip(),
                        "url": PLATFORM_BASE,
                    })
            if browser_cookies:
                context.add_cookies(browser_cookies)

            # 认证和 OAI 上下文只注入 platform.example.com，避免向第三方资源泄漏。
            def add_platform_context(route: Any, req: Any) -> None:
                headers = dict(req.headers)
                if access_token:
                    headers["authorization"] = f"Bearer {access_token}"
                if device_id:
                    headers["x-vendor-device-id"] = device_id
                if account_id:
                    headers["platform-account-id"] = account_id
                route.continue_(headers=headers)

            context.route(f"{PLATFORM_BASE}/**", add_platform_context)
            # 去除自动化标记
            context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {get: () => undefined});
                window.chrome = {runtime: {}};
            """)
            page = context.new_page()
            page.set_default_timeout(max(1_000, int(timeout * 1_000)))

            # 1. 访问首页（让 Cloudflare challenge 自动通过）
            try:
                page.goto(f"{PLATFORM_BASE}/", wait_until="load", timeout=60000)
                # 等待 challenge 通过（最多 60 秒）
                deadline = time.time() + 60
                while time.time() < deadline:
                    html = page.content()
                    if "cf_chl" not in html and "challenge" not in html.lower():
                        break
                    time.sleep(5)
                log("首页加载完成，Cloudflare challenge 已通过")
            except Exception as exc:
                log(f"首页加载: {exc}")

            # 2. 动态加载 SDK，并按 HAR 中的 flow 生成最终请求头值。
            try:
                sdk_result = page.evaluate("""
                    async (flow) => {
                        await new Promise((resolve, reject) => {
                            const s = document.createElement('script');
                            s.src = 'https://platform.example.com/challenge_solver/prod-0000000/sdk.js';
                            s.onload = resolve;
                            s.onerror = reject;
                            document.head.appendChild(s);
                        });
                        await new Promise(r => setTimeout(r, 2000));
                        if (typeof window.ChallengeSDK === 'undefined') {
                            throw new Error('ChallengeSDK 未定义');
                        }

                        await window.ChallengeSDK.init(flow);
                        const tokenValue = await window.ChallengeSDK.token(flow);
                        let timingValue = null;
                        if (typeof window.ChallengeSDK.timing === 'function') {
                            timingValue = await window.ChallengeSDK.timing();
                        }

                        return {
                            token: typeof tokenValue === 'string'
                                ? tokenValue
                                : JSON.stringify(tokenValue),
                            telemetry: timingValue == null
                                ? ''
                                : (typeof timingValue === 'string'
                                    ? timingValue
                                    : JSON.stringify(timingValue)),
                        };
                    }
                """, flow)
                if isinstance(sdk_result, dict):
                    result_context = {
                        "token": str(sdk_result.get("token") or "").strip(),
                        "telemetry": str(sdk_result.get("telemetry") or "").strip(),
                    }
                if result_context["token"]:
                    try:
                        token_flow = json.loads(result_context["token"]).get("flow")
                    except (AttributeError, TypeError, ValueError):
                        token_flow = ""
                    if token_flow and token_flow != flow:
                        raise RuntimeError(
                            f"Challenge flow 不匹配: expected={flow}, actual={token_flow}"
                        )
                    log(f"Challenge Token 已加载: flow={flow}")
                if result_context["telemetry"]:
                    log(f"X-Vendor-Telemetry 已加载: flow={flow}")
            except Exception as exc:
                log(f"SDK 执行失败: {exc}")

            browser.close()
    finally:
        if forwarder:
            forwarder.stop()

    return result_context


def fetch_challenge_token(
    proxy_url: str = "",
    *,
    flow: str = "platform_checkout",
    timeout: float = 90.0,
    access_token: str = "",
    cookies: str = "",
    device_id: str = "",
    account_id: str = "",
    logger: Callable[[str], None] | None = None,
) -> str:
    """兼容旧调用方，仅返回指定 flow 的 Challenge Token。"""
    return fetch_challenge_context(
        proxy_url,
        flow=flow,
        timeout=timeout,
        access_token=access_token,
        cookies=cookies,
        device_id=device_id,
        account_id=account_id,
        logger=logger,
    )["token"]


# ── 支付元数据提取（首页 HTML）───────────────────────────────────
def fetch_payment_metadata(
    http: Any,
    access_token: str,
    cookies: str,
    *,
    device_id: str = "",
    account_id: str = "",
    logger: Callable[[str], None] | None = None,
) -> dict[str, str]:
    """从 platform.example.com 首页 HTML 提取支付元数据。

    返回: {client_version, client_build_number, session_id, attestation}
    """
    log = logger or (lambda _m: None)
    metadata = {"client_version": "", "client_build_number": "",
                "session_id": "", "attestation": ""}

    try:
        headers = {
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Authorization": f"Bearer {access_token}",
            "Cookie": cookies,
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
            ),
            "Referer": f"{PLATFORM_BASE}/",
        }
        if device_id:
            headers["x-vendor-device-id"] = device_id
        if account_id:
            headers["platform-account-id"] = account_id
        resp = http.get(f"{PLATFORM_BASE}/", headers=headers, timeout=30)
        if resp.status_code < 400:
            html = resp.text if hasattr(resp, "text") else resp.content.decode("utf-8", errors="replace")
            patterns = {
                "client_version": r'data-build="([^"]+)"',
                "client_build_number": r'data-seq="([^"]+)"',
                "attestation": r'"webDeploymentAttestation":"([^"]+)"',
                "session_id": r'"sessionId":"([0-9a-fA-F-]{36})"',
            }
            for key, pattern in patterns.items():
                match = re.search(pattern, html)
                if match:
                    metadata[key] = match.group(1)
                    log(f"元数据 {key} 已加载")
    except Exception as exc:
        log(f"支付元数据提取失败: {exc}")

    if not metadata["session_id"]:
        metadata["session_id"] = str(uuid.uuid4())
    return metadata


# ── 缓存管理 ──────────────────────────────────────────────────────
def get_challenge_token(
    proxy_url: str = "",
    *,
    flow: str = "platform_checkout",
    cache_scope: str = "",
    access_token: str = "",
    cookies: str = "",
    device_id: str = "",
    account_id: str = "",
    logger: Callable[[str], None] | None = None,
) -> str:
    """获取 Challenge token（带缓存）。"""
    log = logger or (lambda _m: None)
    if flow not in CHALLENGE_FLOWS:
        raise ValueError(f"不支持的 Challenge flow: {flow}")
    cache_key = (
        f"{proxy_url or '__direct'}|{cache_scope or '__anonymous'}|{flow}"
    )
    now = time.time()
    cached = _challenge_cache.get(cache_key)
    if cached and now < cached[1]:
        log(f"Challenge token 命中缓存（剩余 {int(cached[1] - now)}s）")
        return cached[0]

    token = fetch_challenge_token(
        proxy_url,
        flow=flow,
        access_token=access_token,
        cookies=cookies,
        device_id=device_id,
        account_id=account_id,
        logger=log,
    )
    if token:
        _challenge_cache[cache_key] = (token, now + CHALLENGE_TTL)
        log(f"Challenge token 已缓存（TTL {CHALLENGE_TTL}s）")
    return token


def get_challenge_context(
    proxy_url: str = "",
    *,
    flow: str,
    access_token: str = "",
    cookies: str = "",
    device_id: str = "",
    account_id: str = "",
    logger: Callable[[str], None] | None = None,
) -> dict[str, str]:
    """获取一次性的 flow 上下文；Checkout Create/Confirm 不跨阶段复用。"""
    return fetch_challenge_context(
        proxy_url,
        flow=flow,
        access_token=access_token,
        cookies=cookies,
        device_id=device_id,
        account_id=account_id,
        logger=logger,
    )
