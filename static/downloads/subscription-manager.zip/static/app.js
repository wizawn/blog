'use strict';

const el = {
  session: document.getElementById('session'),
  cardNumber: document.getElementById('card-number'),
  cardName: document.getElementById('card-name'),
  expMonth: document.getElementById('exp-month'),
  expYear: document.getElementById('exp-year'),
  cvc: document.getElementById('cvc'),
  plan: document.getElementById('plan'),
  payButton: document.getElementById('pay-button'),
  autoFetch: document.getElementById('autoFetch'),
  steps: document.getElementById('steps'),
  result: document.getElementById('result'),
};

async function init() {
  try {
    const resp = await fetch('/api/config');
    const config = await resp.json();
    if (!config.ok) return;
    if (config.default_plan) {
      const opt = el.plan.querySelector(`option[value="${config.default_plan}"]`);
      if (opt) opt.selected = true;
    }
  } catch { }
}

// 复制当前 Session 内容
document.getElementById('copySession').addEventListener('click', async () => {
  const btn = document.getElementById('copySession');
  const text = el.session.value.trim();
  if (!text) {
    showMessage('info', 'Session 内容为空，请先获取');
    return;
  }
  try {
    await navigator.clipboard.writeText(text);
    btn.textContent = '✅ 已复制';
    setTimeout(() => { btn.textContent = '复制当前内容'; }, 1500);
  } catch {
    showMessage('error', '复制失败，请手动选择复制');
  }
});

el.autoFetch.addEventListener('click', async () => {
  el.autoFetch.disabled = true;
  el.autoFetch.textContent = '获取中 …';
  try {
    const tabs = await chrome?.tabs?.query({ url: 'https://platform.example.com/*' });
    if (tabs && tabs.length > 0) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try { const r = await fetch('/api/auth/session', { credentials: 'include' }); return await r.json(); } catch { return null; }
        },
      });
      const data = results?.[0]?.result;
      if (data) el.session.value = JSON.stringify(data);
    }
  } catch { showMessage('info', '无法自动获取 Session，请手动粘贴'); }
  finally { el.autoFetch.disabled = false; el.autoFetch.textContent = '从浏览器自动获取 Session'; }
});

el.cardNumber.addEventListener('input', () => {
  let v = el.cardNumber.value.replace(/\s+/g, '').replace(/\D/g, '').slice(0, 19);
  el.cardNumber.value = v.replace(/(\d{4})(?=\d)/g, '$1 ');
});
el.expMonth.addEventListener('input', () => { el.expMonth.value = el.expMonth.value.replace(/\D/g, '').slice(0, 2); });
el.expYear.addEventListener('input', () => { el.expYear.value = el.expYear.value.replace(/\D/g, '').slice(0, 4); });
el.cvc.addEventListener('input', () => { el.cvc.value = el.cvc.value.replace(/\D/g, '').slice(0, 4); });

el.payButton.addEventListener('click', async () => {
  const rawCard = el.cardNumber.value.replace(/\s+/g, '');
  if (!rawCard || rawCard.length < 13) { showMessage('error', '请输入有效的卡号'); return; }
  if (!el.expMonth.value || !el.expYear.value) { showMessage('error', '请输入有效期'); return; }
  if (!el.cvc.value) { showMessage('error', '请输入 CVV'); return; }
  if (!el.session.value.trim()) { showMessage('error', '请填写 Platform Session'); return; }

  el.payButton.disabled = true;
  el.payButton.textContent = '支付处理中 …';
  el.result.className = 'result hidden';
  el.steps.classList.remove('hidden');
  el.steps.innerHTML = '<p style="color:var(--muted)">正在处理 …</p>';

  try {
    const payload = {
      session: el.session.value.trim(),
      card_number: rawCard,
      exp_month: el.expMonth.value,
      exp_year: el.expYear.value,
      cvc: el.cvc.value,
      billing_name: el.cardName.value.trim(),
      plan: el.plan.value,
    };

    const resp = await fetch('/api/pay', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    let data = await resp.json();
    renderSteps(data.steps || []);

    if (data.action_required && data.client_secret && data.flow === 'checkout') {
      data = await completeCheckoutAuthentication(data, payload);
    }

    if (data.ok) {
      const intent = data.payment_intent || {};
      showMessage('success', `<strong>支付成功!</strong><div style="margin-top:8px">PaymentIntent: <code>${escHtml(intent.id || '')}</code></div><div>状态: ${escHtml(intent.status || '')}</div><div>金额: ${(intent.amount || 0) / 100} ${(intent.currency || 'php').toUpperCase()}</div><div style="margin-top:4px">Checkout: <code>${escHtml(data.checkout_id || '')}</code></div>`);
    } else {
      let msg = data.error || '支付失败';

      // Session 过期（401）特殊提示
      if (data.error && (data.error.includes('401') || data.error.includes('已过期'))) {
        msg = '⚠️ Session 已过期，请重新获取后再试';
        // 高亮 Session 输入框引导用户
        el.session.style.borderColor = 'var(--danger)';
        el.session.style.boxShadow = '0 0 0 3px rgba(180, 35, 24, .12)';
        setTimeout(() => {
          el.session.style.borderColor = '';
          el.session.style.boxShadow = '';
        }, 5000);
      } else if (data.flow === 'upgrade_required' && data.upgrade_url) {
        msg = [
          '<strong>当前账号已有付费订阅</strong>',
          `<div class="result-description">${escHtml(data.error || msg)}</div>`,
          '<a class="result-action" href="/upgrade">前往订阅升级</a>',
        ].join('');
        showMessage('info', msg);
        return;
      } else {
        if (data.code) msg += ` (${data.code})`;
        if (data.decline_code) msg += ` [${data.decline_code}]`;
        if (data.action_required) msg = `⚠️ ${data.message || msg}<br><br>在 Platform 页面完成 3D Secure 验证`;
      }
      showMessage(data.action_required || data.pending ? 'info' : 'error', msg);
    }
  } catch (err) {
    showMessage('error', `请求失败: ${escHtml(err.message)}`);
  } finally {
    el.payButton.disabled = false;
    el.payButton.textContent = '发起支付';
  }
});

async function completeCheckoutAuthentication(data, originalPayload) {
  if (!window.Stripe || !data.stripe_publishable_key) {
    return {
      ...data,
      action_required: false,
      error: 'Stripe.js 未加载，无法完成 3D Secure 验证',
    };
  }

  showMessage('info', '请在银行卡验证窗口中完成 3D Secure 验证');
  const stripe = window.Stripe(data.stripe_publishable_key);
  let authenticationFailed = false;
  try {
    const actionResult = await stripe.handleNextAction({
      clientSecret: data.client_secret,
    });
    authenticationFailed = Boolean(actionResult?.error);
  } catch {
    authenticationFailed = true;
  }

  const resp = await fetch('/api/pay/finalize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      session: originalPayload.session,
      account_id: data.account_id,
      payment_intent_id: data.payment_intent?.id || '',
      client_secret: data.client_secret,
      checkout_id: data.checkout_id,
      processor_entity: data.processor_entity,
      plan: data.plan || originalPayload.plan,
      authentication_failed: authenticationFailed,
    }),
  });
  return await resp.json();
}

function renderSteps(steps) {
  if (!steps || !steps.length) { el.steps.classList.add('hidden'); return; }
  el.steps.innerHTML = steps.map((s, i) => {
    let cls = s.status === 'running' ? 'running' : s.status === 'ok' ? 'ok' : s.status === 'error' ? 'error' : s.status === 'action_required' ? 'action' : '';
    return `<div class="step-item ${cls}"><div class="step-num">${s.step || i}</div><div class="step-body"><div class="step-name">${escHtml(s.name || '')}</div>${s.detail ? `<div class="step-detail">${escHtml(s.detail)}</div>` : ''}</div></div>`;
  }).join('');
}

function showMessage(type, html) { el.result.className = `result ${type}`; el.result.innerHTML = html; }
function escHtml(s) { const d = document.createElement('div'); d.textContent = String(s || ''); return d.innerHTML; }

init();
