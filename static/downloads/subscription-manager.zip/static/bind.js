'use strict';

const el = {
  session: document.getElementById('session'),
  prepareButton: document.getElementById('prepare-button'),
  bindButton: document.getElementById('bind-button'),
  autoFetch: document.getElementById('autoFetch'),
  copySession: document.getElementById('copySession'),
  cardPanel: document.getElementById('card-panel'),
  cardLoading: document.getElementById('card-loading'),
  paymentElement: document.getElementById('payment-element'),
  steps: document.getElementById('steps'),
  result: document.getElementById('result'),
};

let stripe = null;
let elements = null;
let paymentElement = null;
let setupContext = null;
let cardReady = false;
let prepareGeneration = 0;

el.copySession.addEventListener('click', async () => {
  const text = el.session.value.trim();
  if (!text) {
    showMessage('info', 'Session 内容为空，请先获取');
    return;
  }
  try {
    await navigator.clipboard.writeText(text);
    el.copySession.textContent = '已复制';
    setTimeout(() => { el.copySession.textContent = '复制当前内容'; }, 1500);
  } catch {
    showMessage('error', '复制失败，请手动选择复制');
  }
});

el.autoFetch.addEventListener('click', async () => {
  el.autoFetch.disabled = true;
  el.autoFetch.textContent = '获取中 …';
  try {
    const tabs = await chrome?.tabs?.query({ url: 'https://platform.example.com/*' });
    if (tabs && tabs.length > 0) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try {
            const response = await fetch('/api/auth/session', { credentials: 'include' });
            return await response.json();
          } catch {
            return null;
          }
        },
      });
      const data = results?.[0]?.result;
      if (data) {
        el.session.value = JSON.stringify(data);
        resetCardInput();
      }
    }
  } catch {
    showMessage('info', '无法自动获取 Session，请手动粘贴');
  } finally {
    el.autoFetch.disabled = false;
    el.autoFetch.textContent = '从浏览器自动获取 Session';
  }
});

el.session.addEventListener('input', resetCardInput);

el.prepareButton.addEventListener('click', prepareCardInput);

el.bindButton.addEventListener('click', async () => {
  if (!stripe || !elements || !setupContext || !cardReady) {
    showMessage('error', '银行卡输入尚未准备完成');
    return;
  }

  setBusy(el.bindButton, true, '绑定中 …');
  el.result.className = 'result hidden';
  renderSteps([{ step: 1, name: 'Stripe 验证银行卡', status: 'running' }]);

  try {
    const result = await stripe.confirmSetup({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/bind`,
        payment_method_data: {
          billing_details: cleanObject(setupContext.billing_details || {}),
        },
      },
      redirect: 'if_required',
    });
    if (result.error) {
      throw stripeError(result.error);
    }

    const setupIntent = result.setupIntent || {};
    if (setupIntent.status !== 'succeeded') {
      throw new Error(`SetupIntent 状态: ${setupIntent.status || 'unknown'}`);
    }
    const paymentMethod = setupIntent.payment_method;
    const paymentMethodId = typeof paymentMethod === 'string' ? paymentMethod : paymentMethod?.id;
    if (!paymentMethodId || !paymentMethodId.startsWith('pm_')) {
      throw new Error('Stripe 未返回有效的支付方式');
    }

    const data = await postJson('/api/payment-methods/bind/complete', {
      session: el.session.value.trim(),
      payment_method_id: paymentMethodId,
    });
    renderSteps(data.steps || []);
    if (!data.ok) throw new Error(data.error || '绑卡确认失败');

    showMessage('success', [
      '<strong>绑定成功</strong>',
      `<div style="margin-top:8px">支付方式: <code>${escHtml(data.payment_method || '')}</code></div>`,
      `<div>卡号: ${escHtml(data.card_last4 ? `···· ${data.card_last4}` : '')}</div>`,
    ].join(''));
  } catch (error) {
    renderSteps([{
      step: 1,
      name: '绑定银行卡',
      status: 'error',
      detail: error.message || '绑卡失败',
    }]);
    showMessage('error', escHtml(error.message || '绑卡失败'));
  } finally {
    setBusy(el.bindButton, false, '绑定银行卡');
  }
});

async function prepareCardInput() {
  if (!el.session.value.trim()) {
    showMessage('error', '请填写 Platform Session');
    return;
  }

  const generation = ++prepareGeneration;
  destroyPaymentElement();
  el.cardPanel.classList.remove('hidden');
  el.cardLoading.classList.remove('hidden');
  el.cardLoading.textContent = '正在初始化 Stripe …';
  el.bindButton.classList.add('hidden');
  el.result.className = 'result hidden';
  setBusy(el.prepareButton, true, '加载中 …');

  try {
    const data = await postJson('/api/payment-methods/bind/prepare', {
      session: el.session.value.trim(),
    });
    if (generation !== prepareGeneration) return;
    if (!data.ok) throw new Error(data.error || '银行卡输入初始化失败');
    if (!window.Stripe || !data.stripe_publishable_key || !data.client_secret) {
      throw new Error('Stripe.js 初始化信息不完整');
    }

    setupContext = data;
    stripe = window.Stripe(data.stripe_publishable_key);
    elements = stripe.elements({
      clientSecret: data.client_secret,
      appearance: {
        theme: 'stripe',
        variables: {
          colorPrimary: '#5b4cf0',
          colorText: '#18202a',
          borderRadius: '8px',
          spacingUnit: '4px',
        },
      },
    });
    paymentElement = elements.create('payment', {
      layout: 'tabs',
      fields: { billingDetails: { address: 'never' } },
      defaultValues: { billingDetails: data.billing_details || {} },
    });
    paymentElement.on('ready', () => {
      if (generation !== prepareGeneration) return;
      cardReady = true;
      el.cardLoading.classList.add('hidden');
      el.prepareButton.classList.add('hidden');
      el.bindButton.classList.remove('hidden');
      el.bindButton.disabled = false;
    });
    paymentElement.on('loaderror', (event) => {
      if (generation !== prepareGeneration) return;
      cardReady = false;
      el.cardLoading.classList.remove('hidden');
      el.cardLoading.textContent = event?.error?.message || 'Stripe 输入框加载失败';
      el.bindButton.classList.add('hidden');
    });
    paymentElement.mount('#payment-element');
  } catch (error) {
    if (generation !== prepareGeneration) return;
    setupContext = null;
    el.cardLoading.classList.remove('hidden');
    el.cardLoading.textContent = error.message || 'Stripe 输入框加载失败';
    showMessage('error', escHtml(error.message));
  } finally {
    if (generation === prepareGeneration) {
      setBusy(el.prepareButton, false, '重新加载银行卡输入');
    }
  }
}

function resetCardInput() {
  prepareGeneration += 1;
  destroyPaymentElement();
  el.cardPanel.classList.add('hidden');
  el.prepareButton.classList.remove('hidden');
  el.prepareButton.disabled = false;
  el.prepareButton.textContent = '加载银行卡输入';
  el.bindButton.classList.add('hidden');
  el.steps.classList.add('hidden');
  el.result.className = 'result hidden';
}

function destroyPaymentElement() {
  if (paymentElement) paymentElement.destroy();
  paymentElement = null;
  elements = null;
  stripe = null;
  setupContext = null;
  cardReady = false;
  el.paymentElement.replaceChildren();
}

function stripeError(error) {
  const suffix = [error.code, error.decline_code].filter(Boolean).join(' / ');
  return new Error(`${error.message || '银行卡验证失败'}${suffix ? ` (${suffix})` : ''}`);
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok && !data.error) throw new Error(`HTTP ${response.status}`);
  return data;
}

function renderSteps(steps) {
  if (!steps || !steps.length) {
    el.steps.classList.add('hidden');
    return;
  }
  el.steps.classList.remove('hidden');
  el.steps.innerHTML = steps.map((step, index) => {
    const statusClass = ['running', 'ok', 'error', 'action_required'].includes(step.status)
      ? (step.status === 'action_required' ? 'action' : step.status)
      : '';
    return `<div class="step-item ${statusClass}"><div class="step-num">${step.step || index + 1}</div><div class="step-body"><div class="step-name">${escHtml(step.name || '')}</div>${step.detail ? `<div class="step-detail">${escHtml(step.detail)}</div>` : ''}</div></div>`;
  }).join('');
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  button.textContent = label;
}

function cleanObject(value) {
  if (Array.isArray(value)) return value.map(cleanObject);
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value)
    .filter(([, item]) => item !== '' && item !== null && item !== undefined)
    .map(([key, item]) => [key, cleanObject(item)]));
}

function showMessage(type, html) {
  el.result.className = `result ${type}`;
  el.result.innerHTML = html;
}

function escHtml(value) {
  const div = document.createElement('div');
  div.textContent = String(value || '');
  return div.innerHTML;
}
