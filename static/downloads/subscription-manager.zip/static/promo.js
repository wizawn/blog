'use strict';

const el = {
  session: document.getElementById('session'),
  cardNumber: document.getElementById('card-number'),
  cardName: document.getElementById('card-name'),
  expMonth: document.getElementById('exp-month'),
  expYear: document.getElementById('exp-year'),
  cvc: document.getElementById('cvc'),
  payButton: document.getElementById('pay-button'),
  autoFetch: document.getElementById('autoFetch'),
  copySession: document.getElementById('copySession'),
  eligibility: document.getElementById('eligibility'),
  steps: document.getElementById('steps'),
  result: document.getElementById('result'),
};

// 粘贴 Session 后自动查询资格
el.session.addEventListener('input', debounce(async () => {
  const raw = el.session.value.trim();
  if (!raw) return;
  try {
    el.eligibility.className = 'eligibility checking';
    el.eligibility.textContent = '⏳ 正在查询资格…';
    const resp = await fetch('/api/promo/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ session: raw }),
    });
    const data = await resp.json();
    if (data.ok && data.eligible) {
      el.eligibility.className = 'eligibility ok';
      el.eligibility.innerHTML = `✅ 账号符合零元购资格！<br><small>${escHtml(data.detail || '')}</small>`;
      el.payButton.disabled = false;
    } else {
      el.eligibility.className = 'eligibility no';
      el.eligibility.innerHTML = `❌ ${escHtml(data.error || '账号不符合零元购资格')}<br><small>此活动仅限曾订阅过 Plus 且已过期的老用户</small>`;
      el.payButton.disabled = true;
    }
  } catch (err) {
    el.eligibility.className = 'eligibility no';
    el.eligibility.textContent = `❌ 查询失败: ${err.message}`;
  }
}, 600));

// 复制 Session
el.copySession.addEventListener('click', async () => {
  const text = el.session.value.trim();
  if (!text) { showMsg('info', 'Session 内容为空，请先获取'); return; }
  try {
    await navigator.clipboard.writeText(text);
    el.copySession.textContent = '✅ 已复制';
    setTimeout(() => { el.copySession.textContent = '复制当前内容'; }, 1500);
  } catch { showMsg('error', '复制失败，请手动选择复制'); }
});

// 自动获取 Session
el.autoFetch.addEventListener('click', async () => {
  el.autoFetch.disabled = true;
  el.autoFetch.textContent = '获取中 …';
  try {
    const tabs = await chrome?.tabs?.query({ url: 'https://platform.example.com/*' });
    if (tabs && tabs.length > 0) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try { const r = await fetch('/api/auth/session', { credentials: 'include' }); return await r.json(); } catch { return null; }
        },
      });
      const data = results?.[0]?.result;
      if (data) { el.session.value = JSON.stringify(data); el.session.dispatchEvent(new Event('input')); }
    }
  } catch { showMsg('info', '无法自动获取 Session，请手动粘贴'); }
  finally { el.autoFetch.disabled = false; el.autoFetch.textContent = '从浏览器自动获取 Session'; }
});

// 卡号格式化
el.cardNumber.addEventListener('input', () => {
  let v = el.cardNumber.value.replace(/\s+/g, '').replace(/\D/g, '').slice(0, 19);
  el.cardNumber.value = v.replace(/(\d{4})(?=\d)/g, '$1 ');
});
el.expMonth.addEventListener('input', () => { el.expMonth.value = el.expMonth.value.replace(/\D/g, '').slice(0, 2); });
el.expYear.addEventListener('input', () => { el.expYear.value = el.expYear.value.replace(/\D/g, '').slice(0, 4); });
el.cvc.addEventListener('input', () => { el.cvc.value = el.cvc.value.replace(/\D/g, '').slice(0, 4); });

// 提交零元购
el.payButton.addEventListener('click', async () => {
  const rawCard = el.cardNumber.value.replace(/\s+/g, '');
  if (!rawCard || rawCard.length < 13) { showMsg('error', '请输入有效的卡号'); return; }
  if (!el.expMonth.value || !el.expYear.value) { showMsg('error', '请输入有效期'); return; }
  if (!el.cvc.value) { showMsg('error', '请输入 CVV'); return; }
  if (!el.session.value.trim()) { showMsg('error', '请填写 Platform Session'); return; }

  el.payButton.disabled = true;
  el.payButton.textContent = '开通中 …';
  el.result.className = 'result hidden';
  el.steps.classList.remove('hidden');
  el.steps.innerHTML = '<p style="color:var(--muted)">正在处理 …</p>';

  try {
    const resp = await fetch('/api/promo/subscribe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session: el.session.value.trim(),
        card_number: rawCard,
        exp_month: el.expMonth.value,
        exp_year: el.expYear.value,
        cvc: el.cvc.value,
        billing_name: el.cardName.value.trim(),
      }),
    });

    const data = await resp.json();
    renderSteps(data.steps || []);

    if (data.ok) {
      showMsg('success', `
        <strong>🎉 零元购成功!</strong>
        <div style="margin-top:8px">首月免费 · Plus 已开通</div>
        <div>下次续费: ${escHtml(data.active_until || '')}</div>
        <div style="margin-top:4px">Checkout: <code>${escHtml(data.checkout_id || '')}</code></div>
      `);
    } else {
      let msg = data.error || '开通失败';
      // Session 过期（401）特殊提示
      if (data.error && (data.error.includes('401') || data.error.includes('已过期'))) {
        msg = '⚠️ Session 已过期，请重新获取后再试';
        el.session.style.borderColor = 'var(--danger)';
        el.session.style.boxShadow = '0 0 0 3px rgba(180, 35, 24, .12)';
        setTimeout(() => {
          el.session.style.borderColor = '';
          el.session.style.boxShadow = '';
        }, 5000);
      } else {
        if (data.code) msg += ` (${data.code})`;
        if (data.decline_code) msg += ` [${data.decline_code}]`;
        if (data.action_required) msg = `⚠️ ${data.message || msg}<br><br>在 Platform 页面完成 3D Secure 验证`;
      }
      showMsg(data.action_required ? 'info' : 'error', msg);
    }
  } catch (err) {
    showMsg('error', `请求失败: ${escHtml(err.message)}`);
  } finally {
    el.payButton.disabled = false;
    el.payButton.textContent = '🎁 零元购开通';
  }
});

function renderSteps(steps) {
  if (!steps || !steps.length) { el.steps.classList.add('hidden'); return; }
  el.steps.innerHTML = steps.map((s, i) => {
    let cls = s.status === 'running' ? 'running' : s.status === 'ok' ? 'ok' : s.status === 'error' ? 'error' : s.status === 'action_required' ? 'action' : '';
    return `<div class="step-item ${cls}"><div class="step-num">${s.step || i}</div><div class="step-body"><div class="step-name">${escHtml(s.name || '')}</div>${s.detail ? `<div class="step-detail">${escHtml(s.detail)}</div>` : ''}</div></div>`;
  }).join('');
}

function showMsg(type, html) { el.result.className = `result ${type}`; el.result.innerHTML = html; }
function escHtml(s) { const d = document.createElement('div'); d.textContent = String(s || ''); return d.innerHTML; }
function debounce(fn, ms) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); }; }
