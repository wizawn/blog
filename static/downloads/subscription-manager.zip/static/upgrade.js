'use strict';

const el = {
  session: document.getElementById('session'),
  plan: document.getElementById('plan'),
  previewButton: document.getElementById('preview-button'),
  paymentSection: document.getElementById('payment-section'),
  upgradeSummary: document.getElementById('upgrade-summary'),
  paymentSourceControl: document.getElementById('payment-source-control'),
  sourceDefault: document.getElementById('source-default'),
  sourceNew: document.getElementById('source-new'),
  defaultCardLabel: document.getElementById('default-card-label'),
  newCardPanel: document.getElementById('new-card-panel'),
  cardNumber: document.getElementById('card-number'),
  cardName: document.getElementById('card-name'),
  expMonth: document.getElementById('exp-month'),
  expYear: document.getElementById('exp-year'),
  cvc: document.getElementById('cvc'),
  upgradeButton: document.getElementById('upgrade-button'),
  autoFetch: document.getElementById('autoFetch'),
  steps: document.getElementById('steps'),
  result: document.getElementById('result'),
};

let previewState = null;
let confirmedPaymentMethodId = '';

document.getElementById('copySession').addEventListener('click', async () => {
  const button = document.getElementById('copySession');
  const text = el.session.value.trim();
  if (!text) {
    showMessage('info', 'Session 内容为空，请先获取');
    return;
  }
  try {
    await navigator.clipboard.writeText(text);
    button.textContent = '已复制';
    setTimeout(() => { button.textContent = '复制当前内容'; }, 1500);
  } catch {
    showMessage('error', '复制失败，请手动选择复制');
  }
});

el.autoFetch.addEventListener('click', async () => {
  el.autoFetch.disabled = true;
  el.autoFetch.textContent = '获取中 …';
  try {
    const tabs = await chrome?.tabs?.query({ url: 'https://platform.example.com/*' });
    if (tabs && tabs.length > 0) {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: async () => {
          try {
            const response = await fetch('/api/auth/session', { credentials: 'include' });
            return await response.json();
          } catch {
            return null;
          }
        },
      });
      const data = results?.[0]?.result;
      if (data) {
        el.session.value = JSON.stringify(data);
        resetUpgradeState();
      }
    }
  } catch {
    showMessage('info', '无法自动获取 Session，请手动粘贴');
  } finally {
    el.autoFetch.disabled = false;
    el.autoFetch.textContent = '从浏览器自动获取 Session';
  }
});

el.session.addEventListener('input', resetUpgradeState);
el.plan.addEventListener('change', resetUpgradeState);
el.sourceDefault.addEventListener('change', () => {
  if (el.sourceDefault.checked) selectPaymentSource('default');
});
el.sourceNew.addEventListener('change', () => {
  if (el.sourceNew.checked) selectPaymentSource('new');
});
el.cardNumber.addEventListener('input', () => {
  const value = el.cardNumber.value.replace(/\s+/g, '').replace(/\D/g, '').slice(0, 19);
  el.cardNumber.value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
  confirmedPaymentMethodId = '';
});
el.expMonth.addEventListener('input', () => {
  el.expMonth.value = el.expMonth.value.replace(/\D/g, '').slice(0, 2);
  confirmedPaymentMethodId = '';
});
el.expYear.addEventListener('input', () => {
  el.expYear.value = el.expYear.value.replace(/\D/g, '').slice(0, 4);
  confirmedPaymentMethodId = '';
});
el.cvc.addEventListener('input', () => {
  el.cvc.value = el.cvc.value.replace(/\D/g, '').slice(0, 4);
  confirmedPaymentMethodId = '';
});
el.cardName.addEventListener('input', () => { confirmedPaymentMethodId = ''; });

el.previewButton.addEventListener('click', async () => {
  if (!el.session.value.trim()) {
    showMessage('error', '请填写 Platform Session');
    return;
  }

  resetUpgradeState();
  setBusy(el.previewButton, true, '查询中 …');
  try {
    const data = await postJson('/api/subscription/upgrade/preview', basePayload());
    if (!data.ok) {
      if (data.flow === 'checkout_required' && data.checkout_url) {
        showMessage('info', `${escHtml(data.error)}<br><br><a href="${escHtml(data.checkout_url)}">前往普通支付页面</a>`);
      } else {
        showMessage('error', escHtml(data.error || '升级信息查询失败'));
      }
      return;
    }

    previewState = data;
    renderPreview(data);
    el.paymentSection.classList.remove('hidden');
    el.upgradeButton.classList.remove('hidden');

    if (data.same_plan) {
      el.paymentSourceControl.classList.add('hidden');
      el.upgradeButton.textContent = data.will_renew ? '确认当前计划' : '恢复自动续费';
      el.upgradeButton.disabled = false;
      return;
    }

    el.paymentSourceControl.classList.remove('hidden');
    const defaultCard = data.default_payment_method;
    el.sourceDefault.disabled = !defaultCard;
    if (defaultCard) {
      el.defaultCardLabel.textContent = `${cardBrand(defaultCard.brand)} ···· ${defaultCard.last4}`;
      el.sourceDefault.checked = true;
      selectPaymentSource('default');
    } else {
      el.defaultCardLabel.textContent = '当前账号没有默认卡';
      el.sourceNew.checked = true;
      selectPaymentSource('new');
    }
  } catch (error) {
    showMessage('error', `请求失败: ${escHtml(error.message)}`);
  } finally {
    setBusy(el.previewButton, false, '查询升级信息');
  }
});

el.upgradeButton.addEventListener('click', async () => {
  if (!previewState) {
    showMessage('error', '请先查询升级信息');
    return;
  }

  const paymentSource = previewState.same_plan
    ? 'default'
    : document.querySelector('input[name="payment-source"]:checked')?.value;
  if (!paymentSource) {
    showMessage('error', '请选择升级支付方式');
    return;
  }

  setBusy(el.upgradeButton, true, '升级处理中 …');
  el.result.className = 'result hidden';
  el.steps.classList.remove('hidden');
  el.steps.innerHTML = '<p style="color:var(--muted)">正在处理 …</p>';

  try {
    let paymentMethodId = '';
    if (paymentSource === 'new') {
      paymentMethodId = await confirmNewCard();
    }

    const payload = {
      ...basePayload(),
      payment_source: paymentSource,
      payment_method_id: paymentMethodId,
    };
    let data = await postJson('/api/subscription/upgrade', payload);
    renderSteps(data.steps || []);

    if (data.action_required && data.client_secret) {
      data = await completeUpgradeAuthentication(data, payload);
      renderSteps(data.steps || []);
    }
    renderUpgradeResult(data);
  } catch (error) {
    renderSteps([{
      step: 1,
      name: '提交订阅升级',
      status: 'error',
      detail: error.message || '升级失败',
    }]);
    el.result.className = 'result hidden';
  } finally {
    el.upgradeButton.disabled = false;
    updateUpgradeButtonState();
  }
});

function basePayload() {
  return {
    session: el.session.value.trim(),
    plan: el.plan.value,
  };
}

function resetUpgradeState(hideMessage = true) {
  previewState = null;
  resetNewCard();
  el.paymentSection.classList.add('hidden');
  el.upgradeButton.classList.add('hidden');
  el.upgradeButton.disabled = false;
  el.upgradeButton.textContent = '提交订阅升级';
  el.sourceDefault.checked = false;
  el.sourceNew.checked = false;
  el.newCardPanel.classList.add('hidden');
  el.steps.classList.add('hidden');
  if (hideMessage) el.result.className = 'result hidden';
}

function renderPreview(data) {
  const currentPlan = planLabel(data.current_plan);
  const targetPlan = planLabel(data.target_plan_type);
  const amount = data.same_plan ? '无需补款' : `${(data.amount / 100).toFixed(2)} ${(data.currency || 'php').toUpperCase()}`;
  el.upgradeSummary.innerHTML = [
    ['当前计划', currentPlan],
    ['目标计划', targetPlan],
    ['本次应付', amount],
  ].map(([label, value]) => (
    `<div class="summary-item"><span class="summary-label">${escHtml(label)}</span><span class="summary-value">${escHtml(value)}</span></div>`
  )).join('');
}

function selectPaymentSource(source) {
  if (source === 'new') {
    el.newCardPanel.classList.remove('hidden');
  } else {
    el.newCardPanel.classList.add('hidden');
  }
  updateUpgradeButtonState();
}

async function confirmNewCard() {
  if (confirmedPaymentMethodId) return confirmedPaymentMethodId;
  const cardNumber = el.cardNumber.value.replace(/\s+/g, '');
  if (!cardNumber || cardNumber.length < 13) throw new Error('请输入有效的卡号');
  if (!el.expMonth.value || !el.expYear.value) throw new Error('请输入有效期');
  if (!el.cvc.value) throw new Error('请输入 CVV');

  const data = await postJson('/api/payment-methods/bind', {
    session: el.session.value.trim(),
    card_number: cardNumber,
    exp_month: el.expMonth.value,
    exp_year: el.expYear.value,
    cvc: el.cvc.value,
    billing_name: el.cardName.value.trim(),
  });
  if (data.action_required && data.flow === 'setup_intent') {
    confirmedPaymentMethodId = await completeSetupAuthentication(data);
    return confirmedPaymentMethodId;
  }
  if (!data.ok) throw new Error(data.error || '新卡绑定失败');
  const paymentMethodId = data.payment_method;
  if (!paymentMethodId || !paymentMethodId.startsWith('pm_')) {
    throw new Error('绑卡接口未返回有效的支付方式');
  }
  confirmedPaymentMethodId = paymentMethodId;
  return paymentMethodId;
}

async function completeSetupAuthentication(data) {
  if (!window.Stripe || !data.stripe_publishable_key || !data.client_secret) {
    throw new Error('Stripe.js 未加载，无法完成绑卡 3D Secure 验证');
  }

  renderSteps(data.steps || []);
  showMessage('info', '请在银行卡验证窗口中完成绑卡 3D Secure 验证');
  const actionStripe = window.Stripe(data.stripe_publishable_key);
  const actionResult = await actionStripe.handleNextAction({
    clientSecret: data.client_secret,
  });
  if (actionResult?.error) {
    const suffix = [actionResult.error.code, actionResult.error.decline_code]
      .filter(Boolean).join(' / ');
    throw new Error(`${actionResult.error.message || '绑卡验证失败'}${suffix ? ` (${suffix})` : ''}`);
  }

  const setupIntent = actionResult?.setupIntent || {};
  if (setupIntent.status && setupIntent.status !== 'succeeded') {
    throw new Error(`绑卡 SetupIntent 状态: ${setupIntent.status}`);
  }
  const returnedMethod = setupIntent.payment_method;
  const paymentMethodId = typeof returnedMethod === 'string'
    ? returnedMethod
    : returnedMethod?.id || data.payment_method;
  if (!paymentMethodId || !paymentMethodId.startsWith('pm_')) {
    throw new Error('3D Secure 完成后未返回有效的支付方式');
  }

  const confirmed = await postJson('/api/payment-methods/bind/complete', {
    session: el.session.value.trim(),
    payment_method_id: paymentMethodId,
  });
  renderSteps(confirmed.steps || []);
  if (!confirmed.ok) throw new Error(confirmed.error || '绑卡状态确认失败');
  return confirmed.payment_method || paymentMethodId;
}

async function completeUpgradeAuthentication(data, originalPayload) {
  if (!window.Stripe || !data.stripe_publishable_key) {
    return { ...data, action_required: false, error: 'Stripe.js 未加载，无法完成 3D Secure 验证' };
  }

  showMessage('info', '请在银行卡验证窗口中完成 3D Secure 验证');
  const actionStripe = window.Stripe(data.stripe_publishable_key);
  let authenticationFailed = false;
  try {
    const actionResult = await actionStripe.handleNextAction({ clientSecret: data.client_secret });
    authenticationFailed = Boolean(actionResult?.error);
  } catch {
    authenticationFailed = true;
  }

  return await postJson('/api/subscription/update/finalize', {
    session: originalPayload.session,
    account_id: data.account_id,
    payment_intent_id: data.payment_intent?.id || '',
    client_secret: data.client_secret,
    target_plan: data.target_plan || originalPayload.plan,
    restore_canceled: Boolean(data.restore_canceled),
    authentication_failed: authenticationFailed,
  });
}

function renderUpgradeResult(data) {
  if (data.ok) {
    const subscription = data.subscription || {};
    const plan = planLabel(subscription.plan_type || previewState?.target_plan_type);
    showMessage('success', `<strong>${escHtml(data.message || '订阅升级成功')}</strong><div style="margin-top:8px">当前计划: ${escHtml(plan)}</div>`);
    return;
  }
  if (data.flow === 'checkout_required' && data.checkout_url) {
    showMessage('info', `${escHtml(data.error || '当前账号没有付费订阅')}<br><br><a href="${escHtml(data.checkout_url)}">前往普通支付页面</a>`);
    return;
  }

  let message = data.error || data.message || '升级失败';
  if (data.code) message += ` (${data.code})`;
  if (data.decline_code) message += ` [${data.decline_code}]`;
  showMessage(data.pending || data.action_required ? 'info' : 'error', escHtml(message));
}

function updateUpgradeButtonState() {
  if (!previewState || previewState.same_plan) return;
  const source = document.querySelector('input[name="payment-source"]:checked')?.value;
  el.upgradeButton.disabled = !source;
  el.upgradeButton.textContent = '提交订阅升级';
}

function resetNewCard() {
  confirmedPaymentMethodId = '';
  el.cardNumber.value = '';
  el.cardName.value = '';
  el.expMonth.value = '';
  el.expYear.value = '';
  el.cvc.value = '';
}

function renderSteps(steps) {
  if (!steps || !steps.length) {
    el.steps.classList.add('hidden');
    return;
  }
  el.steps.innerHTML = steps.map((step, index) => {
    const statusClass = step.status === 'running' ? 'running'
      : step.status === 'ok' ? 'ok'
        : step.status === 'error' ? 'error'
          : step.status === 'action_required' ? 'action' : '';
    const detail = step.detail ? `<div class="step-detail">${escHtml(step.detail)}</div>` : '';
    return `<div class="step-item ${statusClass}"><div class="step-num">${step.step || index}</div><div class="step-body"><div class="step-name">${escHtml(step.name || '')}</div>${detail}</div></div>`;
  }).join('');
}

async function postJson(url, payload) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok && !data.error) throw new Error(`请求失败 (HTTP ${response.status})`);
  return data;
}

function setBusy(button, busy, text) {
  button.disabled = busy;
  button.textContent = text;
}

function planLabel(value) {
  const plans = {
    plus: 'Plus',
    basic_plan: 'Plus',
    prolite: 'Standard',
    standard_plan: 'Standard',
    pro: 'Premium',
    premium_plan: 'Premium',
  };
  return plans[String(value || '').toLowerCase()] || String(value || '未知');
}

function cardBrand(value) {
  const brand = String(value || '').toLowerCase();
  if (brand === 'mastercard') return 'Mastercard';
  if (brand === 'visa') return 'Visa';
  if (brand === 'amex') return 'American Express';
  return value || '银行卡';
}

function showMessage(type, html) {
  el.result.className = `result ${type}`;
  el.result.innerHTML = html;
}

function escHtml(value) {
  const node = document.createElement('div');
  node.textContent = String(value || '');
  return node.innerHTML;
}
