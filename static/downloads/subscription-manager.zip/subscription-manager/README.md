# Subscription Manager

A self-hosted web application for managing Stripe-based subscriptions. Supports new checkout, plan upgrades, card binding, invoice retrieval, and promotional campaigns.

## Features

- **New Subscription Checkout** -- Create a Stripe Checkout session, tokenize card details, and confirm payment.
- **Plan Upgrade** -- Preview upgrade cost, optionally bind a new card, and switch plans with 3D Secure support.
- **Card Binding** -- Bind a payment method via Stripe Elements (SetupIntent flow) for future use.
- **Invoice Download** -- Query transaction history and retrieve Stripe-hosted invoice links.
- **Promo Campaigns** -- Check eligibility for promotional offers and apply them during checkout.

## Plans

| Display Name | Internal ID      |
|-------------|-----------------|
| Basic       | `basic_plan`     |
| Standard    | `standard_plan`  |
| Premium     | `premium_plan`   |

## Quick Start

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Edit .env with your configuration
python app.py
```

Open in browser:

- Checkout: `http://127.0.0.1:8088/`
- Upgrade: `http://127.0.0.1:8088/upgrade`
- Card Binding: `http://127.0.0.1:8088/bind`
- Invoices: `http://127.0.0.1:8088/invoices`

## Docker Compose

```bash
cp .env.example .env
# Set APP_SECRET_KEY and other variables
docker compose up --build -d
```

Health check endpoint: `/healthz`. Logs are stored in the `subscription-manager-logs` named volume.

## Configuration

| Variable | Description |
|---|---|
| `APP_SECRET_KEY` | Required. Flask secret key. |
| `OUTBOUND_PROXY_URL` | Optional. HTTP/SOCKS5 proxy for outbound requests. |
| `DEFAULT_BILLING_*` | Optional. Default billing address fields (NAME, LINE1, CITY, STATE, POSTAL_CODE, COUNTRY). |
| `DEFAULT_PLAN` | Default plan for new subscriptions (default: `premium_plan`). |
| `PRO_CHECKOUT_PROTOCOL` | `legacy` (default) or `new`. Controls checkout flow for Standard/Premium plans. |

## Security

- Card numbers and CVVs are used only in server memory, never persisted.
- Upgrade card binding uses Stripe Elements; the backend never receives raw card data.
- No database. No token storage.
- Listens on `127.0.0.1` by default.
