import logging
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

import app
import challenge_solver_client


class CheckoutContextTests(unittest.TestCase):
    def setUp(self) -> None:
        self.log = logging.getLogger("test.checkout-context")
        self.cookies = "__Secure-platform.session-token=session-token"
        self.context = app.PlatformRequestContext(
            device_id="device-123",
            account_id="account-456",
            payment_metadata={
                "client_version": "build-version",
                "client_build_number": "42",
                "session_id": "session-id",
                "attestation": "attestation-payload",
            },
        )

    def test_device_context_is_stable_without_unobserved_account_header(self) -> None:
        account_headers = app._platform_headers(
            "access-token",
            self.cookies,
            path="/api/v1/accounts/check/v4-2023-04-27",
            context=self.context,
        )
        checkout_headers = app._platform_headers(
            "access-token",
            self.cookies,
            path="/api/v1/payments/checkout",
            context=self.context,
        )

        self.assertEqual(account_headers["x-vendor-device-id"], "device-123")
        self.assertEqual(checkout_headers["x-vendor-device-id"], "device-123")
        self.assertIn("x-vendor-did=device-123", account_headers["Cookie"])
        self.assertNotIn("platform-account-id", checkout_headers)

    def test_existing_vendor_did_cookie_becomes_context_device(self) -> None:
        context = app._new_platform_context("foo=bar; x-vendor-did=existing-device")
        headers = app._platform_headers(
            "access-token",
            "foo=bar; x-vendor-did=existing-device",
            context=context,
        )

        self.assertEqual(context.device_id, "existing-device")
        self.assertEqual(headers["x-vendor-device-id"], "existing-device")
        self.assertEqual(headers["Cookie"].count("x-vendor-did="), 1)

    def test_payment_headers_include_route_and_observed_page_metadata(self) -> None:
        headers = app._platform_headers(
            "access-token",
            self.cookies,
            path="/api/v1/payments/checkout",
            context=self.context,
        )

        self.assertEqual(
            headers["x-vendor-target-path"],
            "/api/v1/payments/checkout",
        )
        self.assertEqual(
            headers["x-vendor-target-route"],
            "/api/v1/payments/checkout",
        )
        self.assertEqual(headers["X-Vendor-Client-Version"], "build-version")
        self.assertEqual(headers["X-Vendor-Client-Build-Number"], "42")
        self.assertEqual(headers["X-Vendor-Session-Id"], "session-id")
        self.assertNotIn("X-Vendor-Web-Deployment-Attestation", headers)
        self.assertNotIn("Vendor-Challenge-Token", headers)
        self.assertNotIn("X-Vendor-Telemetry", headers)

    def test_subscription_update_headers_include_exact_route(self) -> None:
        path = "/api/v1/subscriptions/update"
        headers = app._platform_headers(
            "access-token", self.cookies, path=path, context=self.context,
        )

        self.assertEqual(headers["x-vendor-target-path"], path)
        self.assertEqual(headers["x-vendor-target-route"], path)
        self.assertNotIn("platform-account-id", headers)
        self.assertFalse(any(name.startswith("sec-ch-") for name in headers))

    def test_sensitive_context_headers_are_redacted_from_logs(self) -> None:
        safe = app._safe_headers_for_log({
            "Authorization": "Bearer secret",
            "Cookie": "secret-cookie",
            "Vendor-Challenge-Token": "challenge_solver-secret",
            "X-Vendor-Web-Deployment-Attestation": "attestation-secret",
            "X-Vendor-Session-Id": "session-secret",
            "platform-account-id": "account-secret",
            "X-Vendor-Client-Version": "public-version",
        })

        self.assertEqual(safe["Authorization"], "***")
        self.assertEqual(safe["Cookie"], "***")
        self.assertEqual(safe["Vendor-Challenge-Token"], "***")
        self.assertEqual(safe["X-Vendor-Web-Deployment-Attestation"], "***")
        self.assertEqual(safe["X-Vendor-Session-Id"], "***")
        self.assertEqual(safe["platform-account-id"], "***")
        self.assertEqual(safe["X-Vendor-Client-Version"], "public-version")

    def test_metadata_loader_uses_same_device_and_account(self) -> None:
        context = app.PlatformRequestContext(
            device_id="device-123",
            account_id="account-456",
        )
        metadata = {
            "client_version": "version",
            "client_build_number": "7",
            "session_id": "session-id",
            "attestation": "attestation",
        }

        with patch.object(app, "fetch_payment_metadata", return_value=metadata) as fetch:
            app._load_payment_metadata(
                self.log,
                object(),
                "access-token",
                self.cookies,
                context,
            )

        self.assertEqual(context.payment_metadata, metadata)
        _, _, sent_cookies = fetch.call_args.args
        self.assertIn("x-vendor-did=device-123", sent_cookies)
        self.assertEqual(fetch.call_args.kwargs["device_id"], "device-123")
        self.assertEqual(fetch.call_args.kwargs["account_id"], "account-456")


class PaymentMetadataTests(unittest.TestCase):
    def test_homepage_metadata_request_carries_request_context(self) -> None:
        class Response:
            status_code = 200
            text = (
                '<html data-build="version" data-seq="9">'
                '"sessionId":"12345678-1234-1234-1234-123456789abc",'
                '"webDeploymentAttestation":"attestation"'
                "</html>"
            )

        class Http:
            def __init__(self) -> None:
                self.headers = {}

            def get(self, _url, *, headers, timeout):
                self.headers = headers
                self.timeout = timeout
                return Response()

        http = Http()
        metadata = challenge_solver_client.fetch_payment_metadata(
            http,
            "access-token",
            "session=cookie; x-vendor-did=device-123",
            device_id="device-123",
            account_id="account-456",
        )

        self.assertEqual(http.headers["x-vendor-device-id"], "device-123")
        self.assertEqual(http.headers["platform-account-id"], "account-456")
        self.assertEqual(metadata["client_version"], "version")
        self.assertEqual(metadata["client_build_number"], "9")
        self.assertEqual(metadata["attestation"], "attestation")

    def test_challenge_cache_is_isolated_by_request_context(self) -> None:
        challenge_solver_client._challenge_cache.clear()
        with patch.object(
            challenge_solver_client,
            "fetch_challenge_token",
            side_effect=["token-a", "token-b"],
        ) as fetch:
            first = challenge_solver_client.get_challenge_token(
                "socks5://proxy",
                cache_scope="account-a:device-a",
                access_token="access-a",
                cookies="x-vendor-did=device-a",
                device_id="device-a",
                account_id="account-a",
            )
            repeated = challenge_solver_client.get_challenge_token(
                "socks5://proxy",
                cache_scope="account-a:device-a",
            )
            second_context = challenge_solver_client.get_challenge_token(
                "socks5://proxy",
                cache_scope="account-b:device-b",
            )

        self.assertEqual(first, "token-a")
        self.assertEqual(repeated, "token-a")
        self.assertEqual(second_context, "token-b")
        self.assertEqual(fetch.call_count, 2)
        self.assertEqual(fetch.call_args_list[0].kwargs["access_token"], "access-a")
        self.assertEqual(fetch.call_args_list[0].kwargs["cookies"], "x-vendor-did=device-a")
        self.assertEqual(fetch.call_args_list[0].kwargs["device_id"], "device-a")
        self.assertEqual(fetch.call_args_list[0].kwargs["account_id"], "account-a")
        challenge_solver_client._challenge_cache.clear()

    def test_challenge_cache_is_isolated_by_flow(self) -> None:
        challenge_solver_client._challenge_cache.clear()
        with patch.object(
            challenge_solver_client,
            "fetch_challenge_token",
            side_effect=["create-token", "confirm-token"],
        ) as fetch:
            create = challenge_solver_client.get_challenge_token(
                cache_scope="account:device",
                flow="platform_checkout",
            )
            confirm = challenge_solver_client.get_challenge_token(
                cache_scope="account:device",
                flow="checkout_session_approval",
            )

        self.assertEqual(create, "create-token")
        self.assertEqual(confirm, "confirm-token")
        self.assertEqual(
            [call.kwargs["flow"] for call in fetch.call_args_list],
            ["platform_checkout", "checkout_session_approval"],
        )
        challenge_solver_client._challenge_cache.clear()


class NewProCheckoutProtocolTests(unittest.TestCase):
    def setUp(self) -> None:
        self.log = logging.getLogger("test.new-pro-checkout")
        self.context = app.PlatformRequestContext(
            device_id="device-123",
            account_id="account-456",
            payment_metadata={
                "client_version": "build-version",
                "client_build_number": "42",
                "session_id": "session-id",
                "attestation": "attestation-payload",
            },
        )

    def test_protocol_is_limited_to_new_pro_plans(self) -> None:
        with patch.object(app, "PRO_CHECKOUT_PROTOCOL", "new"):
            self.assertTrue(app._is_new_pro_checkout_plan("standard_plan"))
            self.assertTrue(app._is_new_pro_checkout_plan("premium_plan"))
            self.assertFalse(app._is_new_pro_checkout_plan("basic_plan"))

        with patch.object(app, "PRO_CHECKOUT_PROTOCOL", "legacy"):
            self.assertFalse(app._is_new_pro_checkout_plan("standard_plan"))
            self.assertFalse(app._is_new_pro_checkout_plan("premium_plan"))

    def test_pro20_starts_from_browser_observed_pro5_checkout(self) -> None:
        self.assertEqual(
            app._new_pro_checkout_create_plan("standard_plan"),
            "standard_plan",
        )
        self.assertEqual(
            app._new_pro_checkout_create_plan("premium_plan"),
            "standard_plan",
        )
        self.assertEqual(
            app._new_pro_checkout_create_plan("basic_plan"),
            "basic_plan",
        )

    def test_create_and_confirm_use_separate_flow_contexts(self) -> None:
        challenge_solver_results = [
            {"token": '{"flow":"platform_checkout"}', "telemetry": "[1,10]"},
            {
                "token": '{"flow":"checkout_session_approval"}',
                "telemetry": "[1,20]",
            },
        ]
        with patch.object(
            app,
            "get_challenge_context",
            side_effect=challenge_solver_results,
        ) as get_context:
            create = app._new_pro_challenge_headers(
                self.log,
                object(),
                "access-token",
                "session=cookie",
                self.context,
                flow="platform_checkout",
                include_account_id=False,
            )
            confirm = app._new_pro_challenge_headers(
                self.log,
                object(),
                "access-token",
                "session=cookie",
                self.context,
                flow="checkout_session_approval",
                include_account_id=True,
            )

        self.assertNotIn("platform-account-id", create)
        self.assertEqual(create["X-Vendor-Telemetry"], "[1,10]")
        self.assertEqual(confirm["platform-account-id"], "account-456")
        self.assertEqual(confirm["X-Vendor-Telemetry"], "[1,20]")
        self.assertEqual(
            [call.kwargs["flow"] for call in get_context.call_args_list],
            ["platform_checkout", "checkout_session_approval"],
        )

    def test_rejects_mismatched_challenge_solver_flow(self) -> None:
        with patch.object(
            app,
            "get_challenge_context",
            return_value={
                "token": '{"flow":"platform_checkout"}',
                "telemetry": "[1,10]",
            },
        ):
            with self.assertRaisesRegex(RuntimeError, "flow 不匹配"):
                app._new_pro_challenge_headers(
                    self.log,
                    object(),
                    "access-token",
                    "session=cookie",
                    self.context,
                    flow="checkout_session_approval",
                    include_account_id=True,
                )

    def test_taxes_use_attestation_and_account_without_challenge_solver(self) -> None:
        headers = app._new_pro_payment_headers(
            self.log,
            object(),
            "access-token",
            "session=cookie",
            self.context,
            include_account_id=True,
        )

        self.assertEqual(
            headers,
            {
                "X-Vendor-Web-Deployment-Attestation": "attestation-payload",
                "platform-account-id": "account-456",
            },
        )


class PlanMappingTests(unittest.TestCase):
    def test_current_plan_values(self) -> None:
        self.assertEqual(app._normalize_plan("plus"), "basic_plan")
        self.assertEqual(app._normalize_plan("standard"), "standard_plan")
        self.assertEqual(app._normalize_plan("premium"), "premium_plan")
        self.assertEqual(app._normalize_plan("standard_plan"), "standard_plan")
        self.assertEqual(app._normalize_plan("premium_plan"), "premium_plan")

    def test_outdated_plan_values_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            app._normalize_plan("premium_planplan")
        with self.assertRaises(ValueError):
            app._normalize_plan("standard_planplan")


class UpgradeFlowTests(unittest.TestCase):
    def setUp(self) -> None:
        self.log = logging.getLogger("test.upgrade")
        self.context = app.PlatformRequestContext(device_id="device-123", account_id="account-456")
    def _run_upgrade(
        self,
        payment_source: str,
        payment_method_id: str = "",
        default_last4: str = "4444",
    ) -> tuple[dict, list]:
        get_results = [
            {"plan_type": "plus", "will_renew": True},
            {
                "amount_due": {"amount": 12345},
                "currency": "php",
                "default_payment_method": {"card_last4": default_last4},
            },
        ]
        post_calls = []

        def fake_post(*args, **kwargs):
            post_calls.append((args[4], args[5]))
            return {"status": "succeeded"}

        with app.app.app_context(), \
                patch.object(app, "_platform_get", side_effect=get_results), \
                patch.object(app, "_platform_post", side_effect=fake_post), \
                patch.object(
                    app,
                    "_wait_for_account_payment_method",
                    return_value={"id": "pm_new12345", "card": {"last4": "1111"}},
                ) as wait_for_card, \
                patch.object(
                    app,
                    "_wait_for_subscription_plan",
                    return_value=({"plan_type": "prolite", "will_renew": True}, True),
                ):
            response = app._upgrade_subscription(
                self.log, Path("/tmp/test.log"), [], object(), "token", "cookie",
                self.context, "account-456", "plus", "standard_plan",
                payment_source, payment_method_id,
            )
            return response.get_json(), [post_calls, wait_for_card]

    def test_default_card_update_omits_payment_method(self) -> None:
        result, (post_calls, wait_for_card) = self._run_upgrade("default")
        update_body = next(body for path, body in post_calls if path.endswith("/update"))

        self.assertTrue(result["ok"])
        self.assertEqual(update_body, {
            "account_id": "account-456",
            "updated_plan": "standard_plan",
        })
        wait_for_card.assert_not_called()

    def test_new_card_update_includes_verified_payment_method(self) -> None:
        result, (post_calls, wait_for_card) = self._run_upgrade("new", "pm_new12345")
        update_body = next(body for path, body in post_calls if path.endswith("/update"))

        self.assertTrue(result["ok"])
        self.assertEqual(update_body["payment_method_id"], "pm_new12345")
        wait_for_card.assert_called_once()

    def test_default_card_mode_rejects_account_without_default_card(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "没有默认已绑卡"):
            self._run_upgrade("default", default_last4="")

    def test_prepare_new_card_only_returns_setup_intent_credentials(self) -> None:
        prepared = {"client_secret": "seti_12345678_secret_value"}
        with patch.object(
                app, "_platform_get", return_value={"publishable_key": "pk_live_test"}), \
                patch.object(app, "_platform_post", return_value=prepared) as post, \
                patch.object(app, "_http_post_form") as stripe_confirm:
            result = app._prepare_upgrade_payment_method(
                self.log,
                object(),
                "token",
                "cookie",
                self.context,
                "account-456",
            )

        self.assertEqual(result["publishable_key"], "pk_live_test")
        self.assertEqual(result["setup_intent_id"], "seti_12345678")
        self.assertEqual(post.call_args.args[4], "/api/v1/payments/payment_method")
        stripe_confirm.assert_not_called()

    def test_new_payment_method_must_exist_on_current_account(self) -> None:
        methods = {
            "payment_methods": [
                {"id": "pm_other", "card": {"last4": "9999"}},
                {"id": "pm_new12345", "card": {"last4": "1111"}},
            ],
        }
        with patch.object(app, "_platform_get", return_value=methods) as get:
            result = app._wait_for_account_payment_method(
                self.log,
                object(),
                "token",
                "cookie",
                self.context,
                "account-456",
                "pm_new12345",
            )

        self.assertEqual(result["card"]["last4"], "1111")
        self.assertEqual(get.call_args.kwargs["params"], {"account_id": "account-456"})


class UpgradeFinalizeTests(unittest.TestCase):
    def _finalize(self, activated: bool) -> dict:
        subscription = {"plan_type": "pro", "will_renew": True} if activated else {
            "plan_type": "plus", "will_renew": True,
        }
        with app.app.test_client() as client, \
                patch.object(app, "_parse_session", return_value={"session": "ok"}), \
                patch.object(
                    app,
                    "_extract_auth",
                    return_value=("access", "test@example.com", "user", "cookie=value"),
                ), \
                patch.object(app, "make_http_session", return_value=object()), \
                patch.object(app, "_get_account_id", return_value="account-456"), \
                patch.object(app, "_load_payment_metadata"), \
                patch.object(
                    app,
                    "_stripe_get_payment_intent",
                    return_value={"id": "pi_test", "status": "succeeded"},
                ), \
                patch.object(
                    app,
                    "_wait_for_subscription_plan",
                    return_value=(subscription, activated),
                ) as wait_for_plan:
            response = client.post("/api/subscription/update/finalize", json={
                "session": "session-json",
                "account_id": "account-456",
                "payment_intent_id": "pi_test",
                "client_secret": "pi_test_secret_value",
                "target_plan": "premium_plan",
            })

        self.assertEqual(wait_for_plan.call_args.args[-1], "premium_plan")
        return response.get_json()

    def test_payment_and_target_plan_are_both_required_for_success(self) -> None:
        result = self._finalize(activated=True)

        self.assertTrue(result["ok"])
        self.assertEqual(result["payment_intent"]["status"], "succeeded")
        self.assertEqual(result["subscription"]["plan_type"], "pro")

    def test_succeeded_payment_remains_pending_until_plan_changes(self) -> None:
        result = self._finalize(activated=False)

        self.assertFalse(result["ok"])
        self.assertTrue(result["pending"])
        self.assertIn("同步", result["message"])


class StripeStatusTests(unittest.TestCase):
    def test_payment_intent_log_includes_error_without_client_secret(self) -> None:
        log = Mock()
        app._log_payment_intent_summary(log, "3DS 结果", {
            "id": "pi_test",
            "status": "requires_payment_method",
            "amount": 891964,
            "currency": "php",
            "client_secret": "pi_test_secret_must_not_be_logged",
            "last_payment_error": {
                "message": "Your card has insufficient funds.",
                "code": "card_declined",
                "decline_code": "insufficient_funds",
            },
        })

        rendered_calls = repr(log.method_calls)
        self.assertIn("requires_payment_method", rendered_calls)
        self.assertIn("card_declined", rendered_calls)
        self.assertIn("insufficient_funds", rendered_calls)
        self.assertNotIn("secret_must_not_be_logged", rendered_calls)

    def test_insufficient_funds_returns_chinese_user_message(self) -> None:
        message = app._stripe_user_error({
            "message": "Your card has insufficient funds.",
            "code": "card_declined",
            "decline_code": "insufficient_funds",
        }, "支付失败")

        self.assertEqual(message, "银行卡余额不足")

    def test_http_200_requires_action_is_not_payment_success(self) -> None:
        class Response:
            status_code = 200
            ok = True
            content = b"{}"

            @staticmethod
            def json():
                return {"id": "pi_test", "status": "requires_action"}

        with patch.object(app, "_http_post_form", return_value=Response()):
            result = app._stripe_confirm_payment_intent(
                logging.getLogger("test.stripe"), object(), "pi_test",
                "pi_test_secret_value", "ctoken_test", "https://platform.example.com/return",
            )

        self.assertFalse(result["ok"])
        self.assertTrue(result["action_required"])


class Checkout3DSFinalizeTests(unittest.TestCase):
    def test_verify_url_uses_checkout_plan_type(self) -> None:
        url = app._checkout_verify_url(
            "oaics_12345678",
            "vendor_entity",
            "premium_plan",
        )

        self.assertEqual(
            url,
            "https://platform.example.com/checkout/verify"
            "?stripe_session_id=oaics_12345678"
            "&processor_entity=vendor_entity"
            "&plan_type=pro",
        )

    def test_verify_url_rejects_untrusted_values(self) -> None:
        with self.assertRaises(ValueError):
            app._checkout_verify_url(
                "https://example.com/checkout",
                "vendor_entity",
                "premium_plan",
            )
        with self.assertRaises(ValueError):
            app._checkout_verify_url(
                "oaics_12345678",
                "https://example.com",
                "premium_plan",
            )

    def test_successful_3ds_rechecks_intent_and_calls_verify(self) -> None:
        class VerifyResponse:
            status_code = 200

        stripe_intent = {
            "id": "pi_test",
            "status": "succeeded",
            "amount": 891964,
            "currency": "php",
        }
        with app.app.test_client() as client, \
                patch.object(app, "_parse_session", return_value={"session": "ok"}), \
                patch.object(
                    app,
                    "_extract_auth",
                    return_value=("access", "test@example.com", "user", "cookie=value"),
                ), \
                patch.object(app, "make_http_session", return_value=object()), \
                patch.object(app, "_get_account_id", return_value="account-456"), \
                patch.object(app, "_load_payment_metadata"), \
                patch.object(
                    app,
                    "_stripe_get_payment_intent",
                    return_value=stripe_intent,
                ) as get_intent, \
                patch.object(
                    app,
                    "_http_get",
                    return_value=VerifyResponse(),
                ) as verify, \
                patch.object(
                    app,
                    "_platform_get",
                    return_value={"plan_type": "pro", "will_renew": True},
                ):
            response = client.post("/api/pay/finalize", json={
                "session": "session-json",
                "account_id": "account-456",
                "payment_intent_id": "pi_test",
                "client_secret": "pi_test_secret_value",
                "checkout_id": "oaics_12345678",
                "processor_entity": "vendor_entity",
                "plan": "premium_plan",
            })

        self.assertEqual(response.status_code, 200)
        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["flow"], "checkout")
        self.assertEqual(result["payment_intent"]["status"], "succeeded")
        get_intent.assert_called_once()
        self.assertIn("plan_type=pro", verify.call_args.args[1])


class PaymentRouteSeparationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.payment_input = app.PaymentInput(
            access_token="access-token",
            email="test@example.com",
            user_id="user-123",
            cookies="session=cookie",
            card={
                "number": "5555555555554444",
                "exp_month": "12",
                "exp_year": "2030",
                "cvc": "123",
            },
            billing={
                "name": "Test User",
                "email": "test@example.com",
                "line1": "1 Main St",
                "city": "Manila",
                "state": "",
                "postal_code": "1000",
                "country": "PH",
                "currency": "php",
            },
            plan="standard_plan",
        )
        self.accounts = {
            "accounts": {
                "account-456": {"account": {"plan_type": "plus"}},
            },
        }

    def _upgrade_account_context(self) -> tuple:
        session_input = app.SessionInput(
            access_token="access-token",
            email="test@example.com",
            user_id="user-123",
            cookies="session=cookie",
        )
        context = app.PlatformRequestContext(
            device_id="device-123", account_id="account-456",
        )
        return (
            session_input,
            "standard_plan",
            object(),
            context,
            "account-456",
            "plus",
        )

    def test_pages_are_served_by_separate_routes(self) -> None:
        with app.app.test_client() as client:
            checkout = client.get("/")
            upgrade = client.get("/upgrade")
            bind = client.get("/bind")

        self.assertEqual(checkout.status_code, 200)
        self.assertEqual(upgrade.status_code, 200)
        self.assertEqual(bind.status_code, 200)
        self.assertIn("订阅管理", checkout.get_data(as_text=True))
        upgrade_html = upgrade.get_data(as_text=True)
        self.assertIn("订阅升级", upgrade_html)
        self.assertIn('id="card-number"', upgrade_html)
        self.assertNotIn('id="payment-element"', upgrade_html)
        bind_html = bind.get_data(as_text=True)
        self.assertIn("/static/bind.js", bind_html)
        self.assertNotIn('id="card-number"', bind_html)
        checkout.close()
        upgrade.close()
        bind.close()

    def test_normal_payment_redirects_existing_subscription_to_upgrade_page(self) -> None:
        with app.app.test_client() as client, \
                patch.object(app, "_parse_payment_input", return_value=self.payment_input), \
                patch.object(app, "make_http_session", return_value=object()), \
                patch.object(app, "_platform_get", return_value=self.accounts), \
                patch.object(app, "_load_payment_metadata") as load_metadata, \
                patch.object(app, "_upgrade_subscription") as upgrade:
            response = client.post("/api/pay", json={})

        result = response.get_json()
        self.assertFalse(result["ok"])
        self.assertEqual(result["flow"], "upgrade_required")
        self.assertEqual(result["upgrade_url"], "/upgrade")
        self.assertEqual(result["steps"][-1]["status"], "action_required")
        load_metadata.assert_not_called()
        upgrade.assert_not_called()

    def test_upgrade_endpoint_is_the_only_route_that_runs_upgrade_flow(self) -> None:
        def upgrade_response(*_args, **_kwargs):
            return app.jsonify({"ok": True, "flow": "upgrade"})

        with app.app.test_client() as client, \
                patch.object(
                    app,
                    "_load_upgrade_account",
                    return_value=self._upgrade_account_context(),
                ), \
                patch.object(app, "_load_payment_metadata") as load_metadata, \
                patch.object(app, "_upgrade_subscription", side_effect=upgrade_response) as upgrade:
            response = client.post("/api/subscription/upgrade", json={
                "payment_source": "new",
                "payment_method_id": "pm_new12345",
            })

        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["flow"], "upgrade")
        load_metadata.assert_called_once()
        upgrade.assert_called_once()
        self.assertEqual(upgrade.call_args.args[-2:], ("new", "pm_new12345"))

    def test_upgrade_preview_returns_default_card_and_amount(self) -> None:
        subscription = {"plan_type": "plus", "will_renew": True}
        preview = {
            "amount_due": {"amount": 12345},
            "currency": "php",
            "default_payment_method": {"card_last4": "4444"},
        }
        methods = {
            "default_payment_method_id": "pm_default123",
            "payment_methods": [{
                "id": "pm_default123",
                "card": {"brand": "mastercard", "last4": "4444"},
            }],
        }
        with app.app.test_client() as client, \
                patch.object(
                    app, "_load_upgrade_account",
                    return_value=self._upgrade_account_context(),
                ), \
                patch.object(app, "_load_payment_metadata"), \
                patch.object(
                    app, "_platform_get", side_effect=[subscription, preview, methods],
                ):
            response = client.post("/api/subscription/upgrade/preview", json={})

        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["amount"], 12345)
        self.assertEqual(result["default_payment_method"], {
            "brand": "mastercard",
            "last4": "4444",
            "exp_month": None,
            "exp_year": None,
        })

    def test_new_card_prepare_returns_only_stripe_elements_context(self) -> None:
        billing = {
            "name": "Test User",
            "email": "test@example.com",
            "line1": "1 Main St",
            "city": "Manila",
            "state": "",
            "postal_code": "1000",
            "country": "PH",
            "currency": "php",
        }
        with app.app.test_client() as client, \
                patch.object(
                    app, "_load_upgrade_account",
                    return_value=self._upgrade_account_context(),
                ), \
                patch.object(app, "_billing_details", return_value=billing), \
                patch.object(app, "_load_payment_metadata"), \
                patch.object(app, "_prepare_upgrade_payment_method", return_value={
                    "publishable_key": "pk_live_test",
                    "client_secret": "seti_12345678_secret_value",
                    "setup_intent_id": "seti_12345678",
                }):
            response = client.post(
                "/api/subscription/upgrade/payment-method/prepare", json={},
            )

        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["stripe_publishable_key"], "pk_live_test")
        self.assertNotIn("card_number", result)
        self.assertNotIn("cvc", result)

    def test_standalone_bind_prepare_uses_same_elements_setup(self) -> None:
        billing = {
            "name": "Test User",
            "email": "test@example.com",
            "line1": "1 Main St",
            "city": "Manila",
            "state": "",
            "postal_code": "1000",
            "country": "PH",
            "currency": "php",
        }
        account_context = list(self._upgrade_account_context())
        account_context[-1] = "free"
        with app.app.test_client() as client, \
                patch.object(
                    app, "_load_upgrade_account", return_value=tuple(account_context),
                ), \
                patch.object(app, "_billing_details", return_value=billing), \
                patch.object(app, "_load_payment_metadata"), \
                patch.object(app, "_prepare_upgrade_payment_method", return_value={
                    "publishable_key": "pk_live_test",
                    "client_secret": "seti_12345678_secret_value",
                    "setup_intent_id": "seti_12345678",
                }):
            response = client.post("/api/payment-methods/bind/prepare", json={})

        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["flow"], "payment_method_bind")
        self.assertEqual(result["stripe_publishable_key"], "pk_live_test")
        self.assertNotIn("card_number", result)
        self.assertNotIn("cvc", result)

    def test_standalone_bind_complete_returns_verified_payment_method(self) -> None:
        with app.app.test_client() as client, \
                patch.object(
                    app,
                    "_load_upgrade_account",
                    return_value=self._upgrade_account_context(),
                ), \
                patch.object(
                    app,
                    "_wait_for_account_payment_method",
                    return_value={
                        "id": "pm_new12345",
                        "card": {"brand": "visa", "last4": "4242"},
                    },
                ) as wait_for_method:
            response = client.post("/api/payment-methods/bind/complete", json={
                "payment_method_id": "pm_new12345",
            })

        result = response.get_json()
        self.assertTrue(result["ok"])
        self.assertEqual(result["payment_method"], "pm_new12345")
        self.assertEqual(result["card_last4"], "4242")
        wait_for_method.assert_called_once()

    def test_backend_bind_returns_setup_intent_3ds_context(self) -> None:
        class StripeResponse:
            status_code = 200
            ok = True
            content = b"{}"

            def __init__(self, payload: dict) -> None:
                self.payload = payload

            def json(self) -> dict:
                return self.payload

        elements_response = StripeResponse({"config_id": "config_12345678"})
        setup_response = StripeResponse({
            "id": "seti_12345678",
            "client_secret": "seti_12345678_secret_value",
            "payment_method": "pm_new12345",
            "status": "requires_action",
        })
        with app.app.test_client() as client, \
                patch.object(app, "_parse_session", return_value={}), \
                patch.object(
                    app,
                    "_extract_auth",
                    return_value=(
                        "access-token", "test@example.com", "user-123", "session=cookie",
                    ),
                ), \
                patch.object(app, "make_http_session", return_value=object()), \
                patch.object(app, "_get_account_id", return_value="account-456"), \
                patch.object(
                    app,
                    "_platform_get",
                    return_value={"publishable_key": "pk_live_test"},
                ), \
                patch.object(app, "_platform_post", return_value={
                    "id": "seti_12345678",
                    "client_secret": "seti_12345678_secret_value",
                }), \
                patch.object(app, "_http_get", return_value=elements_response), \
                patch.object(app, "_http_post_form", return_value=setup_response):
            response = client.post("/api/payment-methods/bind", json={
                "session": "session-json",
                "card_number": "4242424242424242",
                "exp_month": "12",
                "exp_year": "2030",
                "cvc": "123",
            })

        result = response.get_json()
        self.assertFalse(result["ok"])
        self.assertTrue(result["action_required"])
        self.assertEqual(result["flow"], "setup_intent")
        self.assertEqual(result["payment_method"], "pm_new12345")
        self.assertEqual(result["stripe_publishable_key"], "pk_live_test")
        self.assertEqual(result["client_secret"], "seti_12345678_secret_value")


if __name__ == "__main__":
    unittest.main()
